# ADM - Administração
Desenvolvimento do microserviço de administração.

## Execução
Antes de executar o ADM será necessário criar a network `sgu30` se ela ainda
não tiver sido criada:
```
docker network create sgu30
```

A execução local do ADM pode ser realizada através do Docker Compose:
```
docker-compose up -d
```
