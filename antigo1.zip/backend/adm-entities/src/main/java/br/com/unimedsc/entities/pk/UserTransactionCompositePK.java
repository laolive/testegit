package br.com.unimedsc.entities.pk;

import javax.persistence.Column;

public class UserTransactionCompositePK<TID> extends UserCompositePK<TID> {

    private static final long serialVersionUID = 3293324320305171073L;

    private Long transactioId;

    @Column(name = "COD_TRANSC")
    public Long getTransactioId() {
	return transactioId;
    }

    public void setTransactioId(Long transactioId) {
	this.transactioId = transactioId;
    }

    @Override
    @Column(name = "COD_USU")
    public Long getUserId() {
	return super.getUserId();
    }

    @Override
    @Column(name = "COD")
    public TID getId() {
	return super.id;
    }

}
