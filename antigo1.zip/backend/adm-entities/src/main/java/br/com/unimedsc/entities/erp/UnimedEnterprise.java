package br.com.unimedsc.entities.erp;

import java.util.Calendar;

import javax.persistence.AttributeOverride;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import br.com.unimedsc.core.annotation.DefaultLoginReturn;
import br.com.unimedsc.core.entity.EntityAbstractEnterprise;
import br.com.unimedsc.core.entity.pk.CompositeEnterprisePK;
import br.com.unimedsc.core.utils.DatabaseDefinition;

@Entity
@Table(name = DatabaseDefinition.TABLE_PREFIX_ERP + "_EMPRESA_UNIMED")
@AttributeOverride(name = "pk.id", column = @Column(name = "COD_UNIMED"))
@DefaultLoginReturn
public class UnimedEnterprise extends EntityAbstractEnterprise<CompositeEnterprisePK<Long>> {

	private static final long serialVersionUID = 7158752484152941170L;

	private Unimed unimed;
	
	private Calendar dateInitialValidity;
	
	private Calendar dateFinalValidity;

	@Override
	@EmbeddedId
	public CompositeEnterprisePK<Long> getPk() {
		return super.getPk();
	}

	@ManyToOne
	@JoinColumn(name = "COD_UNIMED", referencedColumnName = "COD_UNIMED", insertable = false, updatable = false)
	public Unimed getUnimed() {
		return unimed;
	}

	public void setUnimed(Unimed unimed) {
		this.unimed = unimed;
	}

	@Column(name = "DAT_INIC_VIGEN" )
	public Calendar getDateInitialValidity() {
		return dateInitialValidity;
	}

	public void setDateInitialValidity(Calendar dateInitialValidity) {
		this.dateInitialValidity = dateInitialValidity;
	}

	@Column(name = "DAT_FINAL_VIGEN" )
	public Calendar getDateFinalValidity() {
		return dateFinalValidity;
	}

	public void setDateFinalValidity(Calendar dateFinalValidity) {
		this.dateFinalValidity = dateFinalValidity;
	}

}
