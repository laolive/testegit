package br.com.unimedsc.entities.erp;

import javax.persistence.AttributeOverride;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import br.com.unimedsc.core.annotation.DefaultEntityReturn;
import br.com.unimedsc.core.entity.EntityAbstract;
import br.com.unimedsc.core.entity.pk.CompositeEnterprisePK;
import br.com.unimedsc.core.utils.DatabaseDefinition;

@Entity
@Table(name = DatabaseDefinition.TABLE_PREFIX_ERP + "_EMPRESA_ARQUIVO")
@AttributeOverride(name = "pk.id", column = @Column(name = "COD_ARQ"))
public class EnterpriseArchive extends EntityAbstract<Long, CompositeEnterprisePK<Long>> {

	private static final long serialVersionUID = -7509086623796416305L;
	
	@DefaultEntityReturn
	private String domainTypeArchive;
	
	@DefaultEntityReturn
	private Archive archive; 

	@EmbeddedId
	public CompositeEnterprisePK<Long> getPk() {
		return super.getPk();
	}

	/**
	 * @return Arquivo de empresa | TIPO_ARQUIVO
	 */
    @Column(name = "TIP_ARQ")
    public String getDomainTypeArchive() {
        return domainTypeArchive;
    }

    public void setDomainTypeArchive(String domainTypeArchive) {
        this.domainTypeArchive = domainTypeArchive;
    }

	@ManyToOne
	@JoinColumn(name = "COD_ARQ", referencedColumnName = "COD_ARQ", insertable = false, updatable = false)
	public Archive getArchive() {
		return archive;
	}

	public void setArchive(Archive archive) {
		this.archive = archive;
	}
	
}
