package br.com.unimedsc.entities.erp;

import java.util.Calendar;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import br.com.unimedsc.core.annotation.DefaultEntityReturn;
import br.com.unimedsc.core.entity.EntityAbstract;
import br.com.unimedsc.core.entity.pk.DoubleCompositePK;
import br.com.unimedsc.core.utils.DatabaseDefinition;

@Entity
@Table(name = DatabaseDefinition.TABLE_PREFIX_ERP + "_DOMINIO")
@AttributeOverrides({ @AttributeOverride(name = "pk.id", column = @Column(name = "NOM_DOMAIN")),
		@AttributeOverride(name = "pk.secondaryId", column = @Column(name = "VAL_DOMAIN")) })
@JsonSerialize()
public class Domain extends EntityAbstract<String, DoubleCompositePK<String, String>> {

	private static final long serialVersionUID = 1931819065683442161L;

	private String nameDomain;

	@DefaultEntityReturn
	private String valueDescription;

	@DefaultEntityReturn
	private String maskDescriptionValue;

	private String explanationDescription;
	
	private Calendar initialDateVlid;
	
	private Calendar finalDateVlid;
	

	@EmbeddedId
	@Override
	public DoubleCompositePK<String, String> getPk() {
		return super.getPk();
	}

	/**
	 * @return Código do domínio.
	 */
	@Column(name = "NOM_DOMAIN", insertable = false, updatable = false)
	public String getNameDomain() {
		return nameDomain;
	}

	public void setNameDomain(String nameDomain) {
		this.nameDomain = nameDomain;
	}

	/**
	 * @return Nome do domínio.
	 */
	@Column(name = "VAL_DOMAIN", insertable = false, updatable = false)

	public String getValueDescription() {
		return valueDescription;
	}

	public void setValueDescription(String valueDescription) {
		this.valueDescription = valueDescription;
	}

	/**
	 * @return Descrição da máscara do valor.
	 */
	@Column(name = "DES_LABEL")
	public String getMaskDescriptionValue() {
		return maskDescriptionValue;
	}

	public void setMaskDescriptionValue(String maskDescriptionValue) {
		this.maskDescriptionValue = maskDescriptionValue;
	}

	/**
	 * @return Explicação do valor e/ou domínio.
	 */
	@Column(name = "DES_EXPLIC")
	public String getExplanationDescription() {
		return explanationDescription;
	}

	public void setExplanationDescription(String explanationDescription) {
		this.explanationDescription = explanationDescription;
	}

	@Override
	public String toString() {
		return this.maskDescriptionValue;
	}

	@Column(name = "DAT_INIC_VIGEN")
	public Calendar getInitialDateVlid() {
		return initialDateVlid;
	}

	public void setInitialDateVlid(Calendar initialDateVlid) {
		this.initialDateVlid = initialDateVlid;
	}

	@Column(name = "DAT_FINAL_VIGEN")
	public Calendar getFinalDateVlid() {
		return finalDateVlid;
	}

	public void setFinalDateVlid(Calendar finalDateVlid) {
		this.finalDateVlid = finalDateVlid;
	}
	
	

}