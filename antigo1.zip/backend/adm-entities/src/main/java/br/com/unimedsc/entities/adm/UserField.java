package br.com.unimedsc.entities.adm;

import br.com.unimedsc.core.annotation.DefaultEntityReturn;
import br.com.unimedsc.core.annotation.GenerateKey;
import br.com.unimedsc.core.entity.EntityAbstract;
import br.com.unimedsc.core.utils.DatabaseDefinition;
import br.com.unimedsc.entities.pk.UserEnterpriseTransactionCompositePK;

import javax.persistence.*;

@Entity
@Table(name = DatabaseDefinition.TABLE_PREFIX_ADM + "_USUARIO_CAMPO")
@AttributeOverride(name = "pk.id", column = @Column(name = "NOM_CAMPO"))
@GenerateKey(sequence = "S_TADM0009")
public class UserField extends EntityAbstract<String, UserEnterpriseTransactionCompositePK<String>> {

	private String domainView;

	private String domainUpdate;

	private String defaultValue;
	
	@DefaultEntityReturn
	private UserTransaction userTransaction;

	@EmbeddedId
	public UserEnterpriseTransactionCompositePK<String> getPk() {
		return super.getPk();
	}

	/**
	 * @return Visualiza: Informa se o usuário tem permissão para visualizar o
	 *         conteúdo do campo | FLAG
	 */
	@Column(name = "FLG_APRSTR")
	public String getDomainView() {
		return domainView;
	}

	public void setDomainView(String domainView) {
		this.domainView = domainView;
	}

	/**
	 * @return Alteração: Informa se o usuário possui permissão para alterar o
	 *         conteúdo do campo | FLAG
	 */
	@Column(name = "FLG_ALT")
	public String getDomainUpdate() {
		return domainUpdate;
	}

	public void setDomainUpdate(String domainUpdate) {
		this.domainUpdate = domainUpdate;
	}

	/**
	 * @return Valor padrão: Valor padrão do campo para o usuário
	 */
	@Column(name = "VAL_PADRAO")
	public String getDefaultValue() {
		return defaultValue;
	}

	public void setDefaultValue(String defaultValue) {
		this.defaultValue = defaultValue;
	}

	@ManyToOne
	@JoinColumns({@JoinColumn(name = "COD_USU", referencedColumnName = "COD_USU", insertable = false, updatable = false),
		@JoinColumn(name = "COD_EMP", referencedColumnName = "COD_EMP", insertable = false, updatable = false),
		@JoinColumn(name = "COD_TRANSC", referencedColumnName = "COD_TRANSC", insertable = false, updatable = false)})
	public UserTransaction getUserTransaction() {
		return userTransaction;
	}

	public void setUserTransaction(UserTransaction userTransaction) {
		this.userTransaction = userTransaction;
	}
}
