package br.com.unimedsc.entities.adm;

import br.com.unimedsc.core.annotation.DefaultLoginReturn;
import br.com.unimedsc.core.annotation.GenerateKey;
import br.com.unimedsc.core.entity.EntityAbstract;
import br.com.unimedsc.core.entity.pk.SimplePK;
import br.com.unimedsc.core.utils.DatabaseDefinition;
import br.com.unimedsc.entities.erp.Enterprise;

import javax.persistence.*;
import java.util.Calendar;
import java.util.List;

@Entity
@Table(name = DatabaseDefinition.TABLE_PREFIX_ADM + "_USUARIO")
@AttributeOverride(name = "pk.id", column = @Column(name = "COD_USU"))
@GenerateKey(sequence = "S_TADM0002")
@DefaultLoginReturn
public class User extends EntityAbstract<Long, SimplePK<Long>> {

    private Enterprise empresa;

    private String fullName;

    private String login;

    private String password;

    private String domainUserBlocked;

    private String email;

    private String networkDomain;

    private String networkUser;

    private Long daysToExpirePassword;

    private Calendar dateExpirePassword;

    private Calendar dateInactivation;

    private Calendar dateLastAccess;

    private List<UserAccessGroup> accessGroup;

    private List<UserMenu> menus;

    private List<UserSubsidiary> userSubsidiaries;

    private String token;

    private Calendar validityToken;

    @EmbeddedId
    public SimplePK<Long> getPk() {
        return super.getPk();
    }

    @PrePersist
    public void prePersist() {
        super.prePersist();
    }

    @ManyToOne
    @JoinColumn(name = "EMPRESA_ID", referencedColumnName = "COD_EMP")
    public Enterprise getEmpresa() {
        return empresa;
    }

    public void setEmpresa(Enterprise empresa) {
        this.empresa = empresa;
    }

    /**
     * @return Nome: Nome do usuário para apresentação no sistema
     */
    @Column(name = "NOM_USU_APRSTR")
    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    /**
     * @return Login: Login do usuário no sistema
     */
    @Column(name = "NOM_LOGIN", nullable = false)
    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    /**
     * @return Senha: Senha do usuário
     */
    @Column(name = "DES_SENHA", nullable = true, updatable = false)
    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    /**
     * @return Bloqueado: Informa se o usuário possui acesso bloqueado | FLAG
     */
    @Column(name = "FLG_BLOQDO")
    public String getDomainUserBlocked() {
        return domainUserBlocked;
    }

    public void setDomainUserBlocked(String domainUserBlocked) {
        this.domainUserBlocked = domainUserBlocked;
    }

    /**
     * @return Email: Endereço de e-mail do usuário
     */
    @Column(name = "DES_EMAIL", nullable = false)
    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * @return Domínio de Rede: Domínio de rede do login do usuário na rede
     */
    @Column(name = "DES_DOMAIN_REDE")
    public String getNetworkDomain() {
        return networkDomain;
    }

    public void setNetworkDomain(String networkDomain) {
        this.networkDomain = networkDomain;
    }

    /**
     * @return Login na Rede: Login do usuário na rede
     */
    @Column(name = "DES_LOGIN_REDE")
    public String getNetworkUser() {
        return networkUser;
    }

    public void setNetworkUser(String networkUser) {
        this.networkUser = networkUser;
    }

    /**
     * @return Expiração da senha (dias): Número de dias em que a senha expira em
     * relação a última alteração
     */
    @Column(name = "QTD_DIA_EXPIRA_SENHA")
    public Long getDaysToExpirePassword() {
        return daysToExpirePassword;
    }

    public void setDaysToExpirePassword(Long daysToExpirePassword) {
        this.daysToExpirePassword = daysToExpirePassword;
    }

    /**
     * @return Expiração da senha (data): Data em que a senha do usuário deve
     * expirar
     */
    @Column(name = "DAT_EXPIRA_SENHA")
    public Calendar getDateExpirePassword() {
        return dateExpirePassword;
    }

    public void setDateExpirePassword(Calendar dateExpirePassword) {
        this.dateExpirePassword = dateExpirePassword;
    }

    /**
     * @return Data da inativação: Data da inativação do usuário
     */
    @Column(name = "DAT_INATIV")
    public Calendar getDateInactivation() {
        return dateInactivation;
    }

    public void setDateInactivation(Calendar dateInactivation) {
        this.dateInactivation = dateInactivation;
    }

    /**
     * @return Data do Último Acesso: Data do último acesso do usuário
     */
    @Column(name = "DAT_ULTIMO_ACESSO")
    public Calendar getDateLastAccess() {
        return dateLastAccess;
    }

    public void setDateLastAccess(Calendar dateLastAccess) {
        this.dateLastAccess = dateLastAccess;
    }

    /**
     * @return Token: Token gerado para a recuperação da senha
     */
    @Column(name = "NRO_UUID_TOKEN_SENHA")
    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    /**
     * @return Validade Token: Data de validade do token gerado para a recuperação
     * da senha
     */
    @Column(name = "DAT_VALDE_UUID_TOKEN_SENHA")
    public Calendar getValidityToken() {
        return validityToken;
    }

    public void setValidityToken(Calendar validityToken) {
        this.validityToken = validityToken;
    }

    /**
     * @return Perfis do usuário
     */
    @OneToMany(mappedBy = "user")
    public List<UserAccessGroup> getAccessGroup() {
        return accessGroup;
    }

    public void setAccessGroup(List<UserAccessGroup> accessGroup) {
        this.accessGroup = accessGroup;
    }

    @OneToMany(mappedBy = "user", cascade = CascadeType.ALL)
    public List<UserMenu> getMenus() {
        return menus;
    }

    public void setMenus(List<UserMenu> menus) {
        this.menus = menus;
    }

    @OneToMany(mappedBy = "user")
    public List<UserSubsidiary> getUserSubsidiaries() {
        return userSubsidiaries;
    }

    public void setUserSubsidiaries(List<UserSubsidiary> userSubsidiaries) {
        this.userSubsidiaries = userSubsidiaries;
    }

}
