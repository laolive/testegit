package br.com.unimedsc.entities.adm;

import br.com.unimedsc.core.annotation.DefaultLoginReturn;
import br.com.unimedsc.core.annotation.GenerateKey;
import br.com.unimedsc.core.entity.EntityAbstract;
import br.com.unimedsc.core.utils.DatabaseDefinition;
import br.com.unimedsc.entities.erp.Subsidiary;
import br.com.unimedsc.entities.pk.SubsidiaryCompositePK;
import com.fasterxml.jackson.annotation.JsonBackReference;

import javax.persistence.*;

@Entity
@Table(name = DatabaseDefinition.TABLE_PREFIX_ADM + "_USUARIO_FILIAL")
@AttributeOverride(name = "pk.id", column = @Column(name = "COD_USU"))
@DefaultLoginReturn
@GenerateKey(sequence = "S_TADM0014")
public class UserSubsidiary extends EntityAbstract<Long, SubsidiaryCompositePK<Long>> {

	private Subsidiary subsidiary;

	private User user;

	private String domainDefault;

	@EmbeddedId
	public SubsidiaryCompositePK<Long> getPk() {
		return super.getPk();
	}

	@ManyToOne
	@JoinColumns({
			@JoinColumn(name = "COD_EMP", referencedColumnName = "COD_EMP", insertable = false, updatable = false),
			@JoinColumn(name = "COD_FILIAL", referencedColumnName = "COD_FILIAL", insertable = false, updatable = false) })
	public Subsidiary getSubsidiary() {
		return subsidiary;
	}

	public void setSubsidiary(Subsidiary subsidiary) {
		this.subsidiary = subsidiary;
	}

	/**
	 * @return Filial padrão: Informa se é a filial padrão do usuário na empresa |
	 *         FLAG
	 */
	@Column(name = "FLG_PADRAO")
	public String getDomainDefault() {
		return domainDefault;
	}

	public void setDomainDefault(String domainDefault) {
		this.domainDefault = domainDefault;
	}

	@ManyToOne
	@JoinColumns({
			@JoinColumn(name = "COD_USU", referencedColumnName = "COD_USU", insertable = false, updatable = false) })
	@JsonBackReference
	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

}
