package br.com.unimedsc.entities.erp;

import java.util.Calendar;

import javax.persistence.AttributeOverride;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.PrePersist;
import javax.persistence.Table;

import br.com.unimedsc.core.annotation.GenerateKey;
import br.com.unimedsc.core.entity.EntityAbstract;
import br.com.unimedsc.core.entity.pk.SimplePK;

@Entity
@AttributeOverride(name = "pk.id", column = @Column(name = "ID"))
@Table(name = "UNIMED_INTEGRACAO")
@GenerateKey(sequence = "S_UNIMED_INTEGRACAO")
public class UnimedIntegracao extends EntityAbstract<Long, SimplePK<Long>>{

    private Enterprise empresa;
    private Unimed unimed;
    private String urlIntegracao;
    private Calendar dataInicio;
    private Calendar dataFim;
    private TipoIntegracao tipoIntegracao;
    
    @EmbeddedId
    public SimplePK<Long> getPk() {
        return super.getPk();
    }
    
    @Override
    @PrePersist
    public void prePersist() {
        super.prePersist();
    }
    
    @ManyToOne
    @JoinColumn(name = "EMPRESA_ID", referencedColumnName = "COD_EMP")
    public Enterprise getEmpresa() {
        return empresa;
    }

    public void setEmpresa(Enterprise empresa) {
        this.empresa = empresa;
    }

    @ManyToOne
    @JoinColumn(name = "UNIMED_ID", referencedColumnName = "COD_UNIMED")
    public Unimed getUnimed() {
        return unimed;
    }

    public void setUnimed(Unimed unimed) {
        this.unimed = unimed;
    }

    public String getUrlIntegracao() {
        return urlIntegracao;
    }

    public void setUrlIntegracao(String urlIntegracao) {
        this.urlIntegracao = urlIntegracao;
    }

    public Calendar getDataInicio() {
        return dataInicio;
    }

    public void setDataInicio(Calendar dataInicio) {
        this.dataInicio = dataInicio;
    }

    public Calendar getDataFim() {
        return dataFim;
    }

    public void setDataFim(Calendar dataFim) {
        this.dataFim = dataFim;
    }

    @ManyToOne
    @JoinColumn(name = "TIPO_INTEGRACAO_ID", referencedColumnName = "ID")
    public TipoIntegracao getTipoIntegracao() {
        return tipoIntegracao;
    }

    public void setTipoIntegracao(TipoIntegracao tipoIntegracao) {
        this.tipoIntegracao = tipoIntegracao;
    }
}
