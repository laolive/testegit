package br.com.unimedsc.entities.erp;

import javax.persistence.AttributeOverride;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.PrePersist;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;

import br.com.unimedsc.core.annotation.GenerateKey;
import br.com.unimedsc.core.entity.EntityAbstract;
import br.com.unimedsc.core.utils.DatabaseDefinition;
import br.com.unimedsc.entities.pk.ProcessCompositePK;

@Entity
@Table(name = DatabaseDefinition.TABLE_PREFIX_ERP + "_PROCESSO_ERRO")
@AttributeOverride(name = "pk.id", column = @Column(name = "COD_SEQ"))
@GenerateKey(sequence = "S_TERP0019")
public class ProcessError extends EntityAbstract<Long, ProcessCompositePK<Long>> {

	private static final long serialVersionUID = -3687021256267045555L;

	private Process process;

	private String errorMessage;

	private String originalErrorMessage;

	private String key;

	@EmbeddedId
	@Override
	public ProcessCompositePK<Long> getPk() {
		return super.getPk();
	}
	
    @PrePersist
    public void prePersist() {
        super.prePersist();
    }

	@JsonBackReference
	@ManyToOne
	@JoinColumn(name = "COD_PRCSSO", referencedColumnName = "COD_PRCSSO", insertable = false, updatable = false)
	public Process getProcess() {
		return process;
	}

	public void setProcess(Process process) {
		this.process = process;
	}

	/**
	 * @return Erro: Mensagem de erro gerada
	 */
	@Column(name = "DES_ERRO")
	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	/**
	 * @return Erro original: Texto original da mensagem de erro gerada
	 */
	@Column(name = "DES_ERRO_ORIG")
	public String getOriginalErrorMessage() {
		return originalErrorMessage;
	}

	public void setOriginalErrorMessage(String originalErrorMessage) {
		this.originalErrorMessage = originalErrorMessage;
	}

	/**
	 * @return Localizador: Localizador/chave do registro a partir do qual foi gerado o
	 * erro
	 */
	@Column(name = "DES_CHAVE")
	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

}
