package br.com.unimedsc.entities.erp;

import javax.persistence.AttributeOverride;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

import br.com.unimedsc.core.entity.EntityAbstract;
import br.com.unimedsc.core.entity.pk.SimplePK;
import br.com.unimedsc.core.utils.DatabaseDefinition;

@Entity
@Table(name = DatabaseDefinition.TABLE_PREFIX_ERP + "_MODULO")
@AttributeOverride(name = "pk.id", column = @Column(name = "COD_MODULO"))
public class Module extends EntityAbstract<String, SimplePK<String>> {

	private static final long serialVersionUID = 5367336625390523853L;

	private String moduleName;

	private String domainPeriodControl;

	@EmbeddedId
	public SimplePK<String> getPk() {
		return super.getPk();
	}

	/**
	 * @return Decrição: Decrição do módulo do sistema
	 */
	@Column(name = "DES_MODULO")
	public String getModuleName() {
		return moduleName;
	}

	public void setModuleName(String moduleName) {
		this.moduleName = moduleName;
	}

	/**
	 * @return Controlado por período: Informa se o módulo é controlado por período
	 *         (bloqueio de lançamentos por data limite) | FLAG
	 */
	@Column(name = "FLG_CNTRLA_PERIOD")
	public String getDomainPeriodControl() {
		return domainPeriodControl;
	}

	public void setDomainPeriodControl(String domainPeriodControl) {
		this.domainPeriodControl = domainPeriodControl;
	}

}