package br.com.unimedsc.entities.adm;

import br.com.unimedsc.core.annotation.DefaultLoginReturn;
import br.com.unimedsc.core.annotation.GenerateKey;
import br.com.unimedsc.core.entity.EntityAbstractEnterprise;
import br.com.unimedsc.core.entity.pk.CompositeEnterprisePK;
import br.com.unimedsc.core.utils.DatabaseDefinition;

import javax.persistence.*;
import java.util.List;

@Entity
@Table(name = DatabaseDefinition.TABLE_PREFIX_ADM + "_GRUPO_ACESSO")
@AttributeOverride(name = "pk.id", column = @Column(name = "COD_GRUPO_ACESSO"))
@DefaultLoginReturn
@GenerateKey(sequence = "S_TADM0001")
public class AccessGroup extends EntityAbstractEnterprise<CompositeEnterprisePK<Long>> {

	private String nameProfile;

	private List<AccessGroupMenu> accessGroupMenus;

	@EmbeddedId
	public CompositeEnterprisePK<Long> getPk() {
		return super.getPk();
	}

	@PrePersist
	public void prePersist() {
		super.prePersist();
	}

	/**
	 * Nome do perfil que será associado ao usuário.
	 * 
	 * @return o nome do perfil
	 */
	@Column(name = "DES_GRUPO_ACESSO")
	public String getNameProfile() {
		return nameProfile;
	}

	public void setNameProfile(String nameProfile) {
		this.nameProfile = nameProfile;
	}

	/**
	 * @return Menus para o perfil
	 */
	@OneToMany(mappedBy = "accessGroup")
	public List<AccessGroupMenu> getAccessGroupMenus() {
		return accessGroupMenus;
	}

	public void setAccessGroupMenus(List<AccessGroupMenu> AccessGroupMenus) {
		this.accessGroupMenus = AccessGroupMenus;
	}

}
