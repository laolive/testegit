package br.com.unimedsc.entities.erp;

import javax.persistence.AttributeOverride;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;

import br.com.unimedsc.core.annotation.DefaultLoginReturn;
import br.com.unimedsc.core.entity.EntityAbstract;
import br.com.unimedsc.core.entity.pk.SimplePK;
import br.com.unimedsc.core.utils.DatabaseDefinition;

@Entity
@Table(name = DatabaseDefinition.TABLE_PREFIX_ERP + "_PARAMETRO")
@AttributeOverride(name = "pk.id", column = @Column(name = "COD_PARAM"))
@JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class, property = "pk")
@DefaultLoginReturn
public class Parameter extends EntityAbstract<String, SimplePK<String>> {

	private static final long serialVersionUID = 2751578629545814671L;

	private ParameterGroup group;

	private String descriptionParameter;

	private String domainUserOption;

	private String domainDataType;

	private String domainMandatory;

	private String domainName;

	private String tableName;

	private String observation;
	
	private String domainGlobal;
	
	@EmbeddedId
	@Override
	public SimplePK<String> getPk() {
		return super.getPk();
	}

	/**
	 * @return Código do Grupo de Parametros.
	 */
	@ManyToOne
	@JoinColumn(name = "COD_GRUPO_PARAM", referencedColumnName = "COD_GRUPO")
	public ParameterGroup getGroup() {
		return group;
	}

	public void setGroup(ParameterGroup group) {
		this.group = group;
	}

	/**
	 * @return Label: Label (texto) apresentada ao usuário para identificar
	 *         parâmetro
	 */
	@Column(name = "DES_LABEL")
	public String getDescriptionParameter() {
		return descriptionParameter;
	}

	public void setDescriptionParameter(String descriptionParameter) {
		this.descriptionParameter = descriptionParameter;
	}

	/**
	 * @return Opção do usuário: Informa a opção de manutenção pelo usuário |
	 *         OPCAO_PARAMETRO_USUARIO
	 */
	@Column(name = "IND_OPCAO_USU")
	public String getDomainUserOption() {
		return domainUserOption;
	}

	public void setDomainUserOption(String domainUserOption) {
		this.domainUserOption = domainUserOption;
	}

	/**
	 * @return Tipo de dado: Informa o tipo de dado permitido no valor do parâmetro
	 *         | TIPO_DADO
	 */
	@Column(name = "NOM_DOMAIN")
	public String getDomainName() {
		return domainName;
	}

	public void setDomainName(String domainName) {
		this.domainName = domainName;
	}

	/**
	 * @return Tipo de dado: Informa o tipo de dado permitido no valor do parâmetro
	 *         | TIPO_DADO
	 */
	@Column(name = "TIP_DADO")
	public String getDomainDataType() {
		return domainDataType;
	}

	public void setDomainDataType(String domainDataType) {
		this.domainDataType = domainDataType;
	}

	/**
	 * @return Obrigatório: Informa se o filtro é de preenchimento obrigatório |
	 *         FLAG
	 */
	@Column(name = "FLG_OBR")
	public String getDomainMandatory() {
		return domainMandatory;
	}

	public void setDomainMandatory(String domainMandatory) {
		this.domainMandatory = domainMandatory;
	}

	/**
	 * @return Tabela: Nome da tabela que contém os valores permitidos no valor do
	 *         parâmetro
	 */
	@Column(name = "NOM_TABELA")
	public String getTableName() {
		return tableName;
	}

	public void setTableName(String tableName) {
		this.tableName = tableName;
	}

	/**
	 * @return Observação: Orientação sobre a utilidade do parâmetro
	 */
	@Column(name = "DES_OBS")
	public String getObservation() {
		return observation;
	}

	public void setObservation(String observation) {
		this.observation = observation;
	}

	@Column(name = "FLG_GLOBAL")
	public String getDomainGlobal() {
		return domainGlobal;
	}

	public void setDomainGlobal(String domainGlobal) {
		this.domainGlobal = domainGlobal;
	}
}
