package br.com.unimedsc.entities.erp;

import java.util.Calendar;

import javax.persistence.AttributeOverride;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

import br.com.unimedsc.core.entity.EntityAbstract;
import br.com.unimedsc.core.utils.DatabaseDefinition;
import br.com.unimedsc.entities.pk.RoutineCompositePK;

@Entity
@Table(name = DatabaseDefinition.TABLE_PREFIX_ERP + "_ROTINA_FILTRO")
@AttributeOverride(name = "pk.id", column = @Column(name = "COD_FILTRO"))
public class RoutineFilter extends EntityAbstract<Long, RoutineCompositePK<Long>> {

	private static final long serialVersionUID = -5661842258854244400L;

	private Long presentationOrder;

	private String label;

	private String domainDataType;

	private Long minLength;

	private Long maxLength;

	private String domainMandatory;

	private String domainName;

	private String tableName;

	private String defaultValue;

	private Calendar activationDate;

	private Calendar inactivationDate;

	private String obs;

	@EmbeddedId
	@Override
	public RoutineCompositePK<Long> getPk() {
		return super.getPk();
	}

	/**
	 * @return Ordem: Ordem para apresentação (de acordo com a forma de utilização)
	 */
	@Column(name = "NRO_ORDEM_APRSTR")
	public Long getPresentationOrder() {
		return presentationOrder;
	}

	public void setPresentationOrder(Long presentationOrder) {
		this.presentationOrder = presentationOrder;
	}

	/**
	 * @return Label: Label (texto) que será apresentada para o filtro
	 */
	@Column(name = "DES_LABEL")
	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}

	/**
	 * @return Tipo de dado: Tipo de dado permitido para o filtro | TIPO_DADO
	 */
	@Column(name = "TIP_DADO")
	public String getDomainDataType() {
		return domainDataType;
	}

	public void setDomainDataType(String domainDataType) {
		this.domainDataType = domainDataType;
	}

	/**
	 * @return Tamanho mínimo: Quantidade mínima de caracteres ao preencher o filtro
	 */
	@Column(name = "QTD_TMANHO_MIN")
	public Long getMinLength() {
		return minLength;
	}

	public void setMinLength(Long minLength) {
		this.minLength = minLength;
	}

	/**
	 * @return Tamanho máximo: Quantidade máxima de caracteres ao preencher o filtro
	 */
	@Column(name = "QTD_TMANHO_MAX")
	public Long getMaxLength() {
		return maxLength;
	}

	public void setMaxLength(Long maxLength) {
		this.maxLength = maxLength;
	}

	/**
	 * @return Obrigatório: Informa se o filtro é de preenchimento obrigatório |
	 *         FLAG
	 */
	@Column(name = "FLG_OBR")
	public String getDomainMandatory() {
		return domainMandatory;
	}

	public void setDomainMandatory(String domainMandatory) {
		this.domainMandatory = domainMandatory;
	}

	/**
	 * @return Domínio: Nome do domínio que contém os valores permitidos no valor do
	 *         filtro
	 */
	@Column(name = "NOM_DOMAIN")
	public String getDomainName() {
		return domainName;
	}

	public void setDomainName(String domainName) {
		this.domainName = domainName;
	}

	/**
	 * @return Tabela: Nome da tabela que contém os valores permitidos no valor do
	 *         parâmetro
	 */
	@Column(name = "NOM_TABELA")
	public String getTableName() {
		return tableName;
	}

	public void setTableName(String tableName) {
		this.tableName = tableName;
	}

	/**
	 * @return Valor: Valor padrão para o filtro
	 */
	@Column(name = "VAL_PADRAO")
	public String getDefaultValue() {
		return defaultValue;
	}

	public void setDefaultValue(String defaultValue) {
		this.defaultValue = defaultValue;
	}

	/**
	 * @return Data da ativação: Data da ativação do valor do filtro
	 */
	@Column(name = "DAT_ATIV")
	public Calendar getActivationDate() {
		return activationDate;
	}

	public void setActivationDate(Calendar activationDate) {
		this.activationDate = activationDate;
	}

	/**
	 * @return Data da inativação: Data da inativação do valor do filtro
	 */
	@Column(name = "DAT_INATIV")
	public Calendar getInactivationDate() {
		return inactivationDate;
	}

	public void setInactivationDate(Calendar inactivationDate) {
		this.inactivationDate = inactivationDate;
	}

	/**
	 * @return Observação: Observação sobre a utilidade do filtro
	 */
	@Column(name = "DES_OBS")
	public String getObs() {
		return obs;
	}

	public void setObs(String obs) {
		this.obs = obs;
	}

}
