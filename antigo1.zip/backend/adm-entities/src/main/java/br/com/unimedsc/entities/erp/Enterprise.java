package br.com.unimedsc.entities.erp;

import javax.persistence.AttributeOverride;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;

import br.com.unimedsc.core.annotation.DefaultEntityReturn;
import br.com.unimedsc.core.entity.EntityAbstract;
import br.com.unimedsc.core.entity.pk.SimplePK;
import br.com.unimedsc.core.utils.DatabaseDefinition;

@Entity
@Table(name = DatabaseDefinition.TABLE_PREFIX_ERP + "_EMPRESA")
@AttributeOverride(name = "pk.id", column = @Column(name = "COD_EMP"))
public class Enterprise extends EntityAbstract<Long, SimplePK<Long>> {

	private static final long serialVersionUID = -9041058721010010916L;

	@DefaultEntityReturn
	private String enterpriseName;

	private BusinessGroup businessGroup;

	@EmbeddedId
	public SimplePK<Long> getPk() {
		return super.getPk();
	}

	public void setEnterpriseName(String enterpriseName) {
		this.enterpriseName = enterpriseName;
	}

	/**
	 * @return Nome: Nome da empresa para apresentação no sistema
	 */
	@Column(name = "NOM_EMP_APRSTR")
	public String getEnterpriseName() {
		return enterpriseName;
	}

	@ManyToOne
	@JoinColumn(name = "COD_GRUPO_EMPRSL", referencedColumnName = "COD_GRUPO_EMPRSL")
	public BusinessGroup getBusinessGroup() {
		return businessGroup;
	}

	public void setBusinessGroup(BusinessGroup businessGroup) {
		this.businessGroup = businessGroup;
	}

}