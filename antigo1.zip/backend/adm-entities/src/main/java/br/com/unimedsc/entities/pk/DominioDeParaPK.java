package br.com.unimedsc.entities.pk;

import javax.persistence.Column;

import com.fasterxml.jackson.annotation.JsonProperty;

import br.com.unimedsc.core.entity.pk.SimplePK;

public class DominioDeParaPK<TID, T2, T3, T4>  extends SimplePK<TID> {

    private T2 dominioItemIdDe;
    
    private T3 dominioIdPara;
    
    private T4 dominioItemIdPara;
        
    @Override
    @JsonProperty("dominioItemId")
    @Column(name = "COD")
    public TID getId() {
        return super.id;
    }

    @Column(name = "DOMINIO_ITEM_ID_DE")
    public T2 getDominioItemIdDe() {
        return dominioItemIdDe;
    }

    public void setDominioItemIdDe(T2 dominioItemIdDe) {
        this.dominioItemIdDe = dominioItemIdDe;
    }

    @Column(name = "DOMINIO_ID_PARA")
    public T3 getDominioIdPara() {
        return dominioIdPara;
    }

    public void setDominioIdPara(T3 dominioIdPara) {
        this.dominioIdPara = dominioIdPara;
    }

    @Column(name = "DOMINIO_ITEM_ID_PARA")
    public T4 getDominioItemIdPara() {
        return dominioItemIdPara;
    }

    public void setDominioItemIdPara(T4 dominioItemIdPara) {
        this.dominioItemIdPara = dominioItemIdPara;
    }
    
}
