package br.com.unimedsc.entities.repository;

import br.com.unimedsc.entities.erp.Menu;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface MenuRepository extends JpaRepository<Menu, Long> {

    @Query("SELECT m "
            + "    FROM Menu m, AccessGroupMenu agm , UserAccessGroup uag  "
            + " WHERE uag.pk.enterpriseId = :enterpriseId "
            + "   AND uag.user.pk.id = :userId"
            + "   AND agm.pk.enterpriseId = uag.pk.enterpriseId "
            + "   AND agm.id.accessGroupId = uag.id.accessGroupId "
            + "   AND m.pk.id = :menuId "
            + "   AND agm.menu.id = m.pk.id "
            + "   AND m.trasaction.id IS NOT NULL "
    )
    List<Menu> findMenuFromGroupMenuAndUserGroup(@Param("userId") Long userId, @Param("enterpriseId") Long enterpriseId, @Param("menuId") Long menuId);

    @Query("SELECT m "
            + "    FROM Menu m, UserMenu um "
            + " WHERE um.pk.enterpriseId = :enterpriseId "
            + "   AND um.user.pk.id = :userId"
            + "   AND m.pk.id = :menuId "
            + "   AND um.menu.pk.id = m.pk.id "
            + "   AND m.trasaction.id IS NOT NULL "
    )
    List<Menu> findMenuFromAdmMenu(@Param("userId") Long userId, @Param("enterpriseId") Long enterpriseId, @Param("menuId") Long menuId);

    @Query("SELECT m "
            + "    FROM Menu m "
            + "      LEFT OUTER JOIN m.trasaction t "
            + "    WHERE m.domainEnable = 'S'"
            + "          AND m.menuSuperior IS NULL "
    )
    List<Menu> findAllWithTransaction();


    @Query("SELECT m " +
            "    FROM Menu m " +
            "  WHERE m.menuSuperior.pk.id = ?1"
    )
    List<Menu> findByAndSort(Long menuId, Sort sort);
}
