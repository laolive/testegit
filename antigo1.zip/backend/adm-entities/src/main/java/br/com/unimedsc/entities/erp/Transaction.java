package br.com.unimedsc.entities.erp;

import javax.persistence.AttributeOverride;
import javax.persistence.Column;
import javax.persistence.ColumnResult;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.EntityResult;
import javax.persistence.FieldResult;
import javax.persistence.SqlResultSetMapping;
import javax.persistence.Table;
import javax.persistence.Transient;

import br.com.unimedsc.core.annotation.DefaultLoginReturn;
import br.com.unimedsc.core.entity.EntityAbstract;
import br.com.unimedsc.core.entity.pk.SimplePK;
import br.com.unimedsc.core.utils.DatabaseDefinition;

@Entity
@Table(name = DatabaseDefinition.TABLE_PREFIX_ERP + "_TRANSACAO")
@AttributeOverride(name = "pk.id", column = @Column(name = "COD_TRANSC"))
@SqlResultSetMapping(name = "TransactionTransient", entities = {
		@EntityResult(entityClass = br.com.unimedsc.entities.erp.Transaction.class, fields = {
				@FieldResult(name = "id", column = "id"),
				@FieldResult(name = "transactionName", column = "transactionName"),
				@FieldResult(name = "transactionRoute", column = "transactionRoute") }) }, columns = {
						@ColumnResult(name = "ALLOWINSERT"), @ColumnResult(name = "ALLOWUPDATE"),
						@ColumnResult(name = "ALLOWDELETE") })
@DefaultLoginReturn
public class Transaction extends EntityAbstract<Long, SimplePK<Long>> {

	private static final long serialVersionUID = 1813359570780248215L;

	private String transactionName;

	private String transactionRoute;

	@Transient
	private String allowInsert = "N";

	@Transient
	private String allowUpdate = "N";

	@Transient
	private String allowDelete = "N";
	
	private String moduleName;

	public Transaction() {

	}

	public Transaction(Long id, String transactionName, String transactionRoute, String allowInsert, String allowUpdate,
			String allowDelete) {

		this.setPk(new SimplePK<Long>(id));
		this.transactionName = transactionName;
		this.transactionRoute = transactionRoute;
		this.allowInsert = allowInsert;
		this.allowUpdate = allowUpdate;
		this.allowDelete = allowDelete;

	}

	@EmbeddedId
	public SimplePK<Long> getPk() {
		return super.getPk();
	}

	/**
	 * @return Nome: Nome da transação
	 */
	@Column(name = "NOM_TRANSC")
	public String getTransactionName() {
		return transactionName;
	}

	public void setTransactionName(String transactionName) {
		this.transactionName = transactionName;
	}

	/**
	 * @return Descrição: Descrição da transação
	 */
	@Column(name = "DES_ROTA")
	public String getTransactionRoute() {
		return transactionRoute;
	}

	public void setTransactionRoute(String transactionRoute) {
		this.transactionRoute = transactionRoute;
	}

	@Transient
	public String getAllowInsert() {
		return allowInsert;
	}

	public void setAllowInsert(String allowInsert) {
		this.allowInsert = allowInsert;
	}

	@Transient
	public String getAllowUpdate() {
		return allowUpdate;
	}

	public void setAllowUpdate(String allowUpdate) {
		this.allowUpdate = allowUpdate;
	}

	@Transient
	public String getAllowDelete() {
		return allowDelete;
	}

	public void setAllowDelete(String allowDelete) {
		this.allowDelete = allowDelete;
	}

	@Column(name = "COD_MODULO")
	public String getModuleName() {
		return moduleName;
	}

	public void setModuleName(String moduleName) {
		this.moduleName = moduleName;
	}
}
