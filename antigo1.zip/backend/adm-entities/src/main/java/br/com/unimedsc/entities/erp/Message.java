package br.com.unimedsc.entities.erp;

import javax.persistence.AttributeOverride;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

import br.com.unimedsc.core.entity.EntityAbstract;
import br.com.unimedsc.core.entity.pk.SimplePK;
import br.com.unimedsc.core.utils.DatabaseDefinition;

@Entity
@Table(name = DatabaseDefinition.TABLE_PREFIX_ERP + "_MENSAGEM")
@AttributeOverride(name = "pk.id", column = @Column(name = "COD_MSG"))
public class Message extends EntityAbstract<Long, SimplePK<Long>> {

	private static final long serialVersionUID = -2848650801750570475L;

	private String domainMessageType;

	private String message;

	private String messageDetail;

	private String correctiveAction;

	@EmbeddedId
	@Override
	public SimplePK<Long> getPk() {
		return super.getPk();
	}

	/**
	 * @return Tipo: Tipo da mensagem | TIPO_MENSAGEM_SISTEMA
	 */
	@Column(name = "TIP_MSG")
	public String getDomainMessageType() {
		return domainMessageType;
	}

	public void setDomainMessageType(String domainMessageType) {
		this.domainMessageType = domainMessageType;
	}

	/**
	 * @return Descrição: Descrição da mensagem.
	 */
	@Column(name = "DES_MSG")
	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	/**
	 * @return Explicação: Explicação sobre a mensgem apresentada.
	 */
	@Column(name = "DES_EXPLIC")
	public String getMessageDetail() {
		return messageDetail;
	}

	public void setMessageDetail(String messageDetail) {
		this.messageDetail = messageDetail;
	}

	/**
	 * @return Ação Corretiva: Ação corretiva referente a mensgem apresentada.
	 */
	@Column(name = "DES_ACAO_CORTVA")
	public String getCorrectiveAction() {
		return correctiveAction;
	}
	
	public void setCorrectiveAction(String correctiveAction) {
		this.correctiveAction = correctiveAction;
	}

}
