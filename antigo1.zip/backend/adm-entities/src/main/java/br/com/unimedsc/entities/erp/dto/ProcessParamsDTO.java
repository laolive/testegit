package br.com.unimedsc.entities.erp.dto;

public class ProcessParamsDTO{
	private Long processId;
	private Long routineId;
	private Long userRequestingId;
	private String descriptionFilter;
	private String descriptionOption;
	private String dateStartPreview;
	private String domainSchedulingType;
	private Long processOriginalId;
	private String descriptionErrorMessage;
	private String descriptionWarning;
	private String descriptionError;
	private String descriptionKey;
	private Integer percentual;
	
	public ProcessParamsDTO() {
	}
	
	public Long getProcessId() {
		return processId;
	}
	
	public void setProcessId(Long processId) {
		this.processId = processId;
	}
	
	public Long getRoutineId() {
		return routineId;
	}
	
	public void setRoutineId(Long routineId) {
		this.routineId = routineId;
	}
	
	public Long getUserRequestingId() {
		return userRequestingId;
	}

	public void setUserRequestingId(Long userRequestingId) {
		this.userRequestingId = userRequestingId;
	}

	public String getDescriptionFilter() {
		return descriptionFilter;
	}
	
	public void setDescriptionFilter(String descriptionFilter) {
		this.descriptionFilter = descriptionFilter;
	}
	
	public String getDescriptionOption() {
		return descriptionOption;
	}
	
	public void setDescriptionOption(String descriptionOption) {
		this.descriptionOption = descriptionOption;
	}
	
	public String getDateStartPreview() {
		return dateStartPreview;
	}
	
	public void setDateStartPreview(String dateStartPreview) {
		this.dateStartPreview = dateStartPreview;
	}
	
	public String getDomainSchedulingType() {
		return domainSchedulingType;
	}
	
	public void setDomainSchedulingType(String domainSchedulingType) {
		this.domainSchedulingType = domainSchedulingType;
	}
	
	public Long getProcessOriginalId() {
		return processOriginalId;
	}
	
	public void setProcessOriginalId(Long processOriginalId) {
		this.processOriginalId = processOriginalId;
	}

	public String getDescriptionErrorMessage() {
		return descriptionErrorMessage;
	}

	public void setDescriptionErrorMessage(String descriptionErrorMessage) {
		this.descriptionErrorMessage = descriptionErrorMessage;
	}

	public String getDescriptionWarning() {
		return descriptionWarning;
	}

	public void setDescriptionWarning(String descriptionWarning) {
		this.descriptionWarning = descriptionWarning;
	}

	public String getDescriptionError() {
		return descriptionError;
	}

	public void setDescriptionError(String descriptionError) {
		this.descriptionError = descriptionError;
	}

	public String getDescriptionKey() {
		return descriptionKey;
	}

	public void setDescriptionKey(String descriptionKey) {
		this.descriptionKey = descriptionKey;
	}

	public Integer getPercentual() {
		return percentual;
	}

	public void setPercentual(Integer percentual) {
		this.percentual = percentual;
	}
}
