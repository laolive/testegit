package br.com.unimedsc.entities.erp;

import br.com.unimedsc.core.annotation.DefaultLoginReturn;
import br.com.unimedsc.core.entity.EntityAbstract;
import br.com.unimedsc.core.entity.pk.SimplePK;
import br.com.unimedsc.core.utils.DatabaseDefinition;
import com.fasterxml.jackson.annotation.JsonBackReference;

import javax.persistence.*;
import java.util.LinkedList;
import java.util.List;

@Entity
@Table(name = DatabaseDefinition.TABLE_PREFIX_ERP + "_MENU")
@AttributeOverride(name = "pk.id", column = @Column(name = "COD_MENU"))
@DefaultLoginReturn
public class Menu extends EntityAbstract<Long, SimplePK<Long>> {

	private static final long serialVersionUID = -6704046661425185769L;

	private String nameMenu;

	private String helpMenu;

	private String domainEnable;

	private Menu menuSuperior;

	private Long orderNumber;

	private Transaction trasaction;

	private String parameterList;

	private String keyWord;
	
	private String icon;

	List<Menu> children = new LinkedList<Menu>();

	@EmbeddedId
	public SimplePK<Long> getPk() {
		return super.getPk();
	}

	/**
	 * @return Descrição: Descrição do item do menu para apresentação no sistema
	 */
	@Column(name = "DES_MENU_APRSTR")
	public String getNameMenu() {
		return nameMenu;
	}

	public void setNameMenu(String nameMenu) {
		this.nameMenu = nameMenu;
	}

	/**
	 * @return Descrição: Descrição do item do menu para apresentação no sistema
	 */
	@Column(name = "DES_MENU_AJUDA")
	public String getHelpMenu() {
		return helpMenu;
	}

	public void setHelpMenu(String helpMenu) {
		this.helpMenu = helpMenu;
	}

	/**
	 * @return Indica se o parametro esta ativo ou não.
	 */
	@Column(name = "FLG_ATIVO")
	public String getDomainEnable() {
		return domainEnable;
	}

	public void setDomainEnable(String domainEnable) {
		this.domainEnable = domainEnable;
	}

	/**
	 * @return Menu Superior: Código do item do menu superior
	 */

	@ManyToOne
	@JoinColumn(name = "COD_MENU_SUPERI", referencedColumnName = "COD_MENU")
	@JsonBackReference
	public Menu getMenuSuperior() {
		return menuSuperior;
	}

	public void setMenuSuperior(Menu menuSuperior) {
		this.menuSuperior = menuSuperior;
	}

	/**
	 * @return Ordem: Ordem de apresentação do item do menu conforme menu superior
	 */
	@Column(name = "NRO_ORDEM_APRSTR")
	public Long getOrderNumber() {
		return orderNumber;
	}

	public void setOrderNumber(Long orderNumber) {
		this.orderNumber = orderNumber;
	}

	/**
	 * @return Transação acionada
	 */
	@ManyToOne
	@JoinColumn(name = "COD_TRANSC", referencedColumnName = "COD_TRANSC")
	public Transaction getTrasaction() {
		return trasaction;
	}

	public void setTrasaction(Transaction trasaction) {
		this.trasaction = trasaction;
	}

	/**
	 * @return Lista de parâmetros: Lista de parâmetros a serem passados para a
	 *         transação
	 */
	@Column(name = "DES_LISTA_PARAM")
	public String getParameterList() {
		return parameterList;
	}

	public void setParameterList(String parameterList) {
		this.parameterList = parameterList;
	}

	/**
	 * @return Palavras Chaves: Contém as palavras chaves associadas ao item de menu
	 */
	@Column(name = "DES_PLAVRA_CHAVE")
	public String getKeyWord() {
		return keyWord;
	}

	public void setKeyWord(String keyWord) {
		this.keyWord = keyWord;
	}

	@Transient
	public List<Menu> getChildren() {
		return children;
	}

	public void setChildren(List<Menu> children) {
		this.children = children;
	}

	public void addChild(Menu menu) {
		if (this.children == null)
			this.children = new LinkedList<Menu>();

		this.children.add(menu);
	}

	@Column(name = "DES_ICONE")
	public String getIcon() {
		return icon;
	}

	public void setIcon(String icon) {
		this.icon = icon;
	}

}
