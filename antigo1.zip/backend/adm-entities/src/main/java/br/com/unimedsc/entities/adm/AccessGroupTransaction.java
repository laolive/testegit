package br.com.unimedsc.entities.adm;

import br.com.unimedsc.core.annotation.GenerateKey;
import br.com.unimedsc.core.entity.EntityAbstract;
import br.com.unimedsc.core.utils.DatabaseDefinition;
import br.com.unimedsc.entities.erp.Transaction;
import br.com.unimedsc.entities.pk.AccessGroupCompositePK;

import javax.persistence.*;

@Entity
@Table(name = DatabaseDefinition.TABLE_PREFIX_ADM + "_GRUPO_ACESSO_TRANSACAO")
@AttributeOverride(name = "pk.id", column = @Column(name = "COD_TRANSC"))
@GenerateKey(sequence = "S_TADM0004")
public class AccessGroupTransaction extends EntityAbstract<Long, AccessGroupCompositePK<Long>> {

	private String domainInsert;

	private String domainUpdate;

	private String domainDelete;

	private AccessGroup accessGroup;

	private Transaction transaction;

	@EmbeddedId
	public AccessGroupCompositePK<Long> getPk() {
		return super.getPk();
	}

	/**
	 * @return Inclusão: Informa se o perfil possui permissão de inclusão na transação |
	 * FLAG
	 */
	@Column(name = "FLG_INCL")
	public String getDomainInsert() {
		return domainInsert;
	}

	public void setDomainInsert(String domainInsert) {
		this.domainInsert = domainInsert;
	}

	/**
	 * @return Alteração: Informa se o perfil possui permissão de alteração na transação
	 * | FLAG
	 */
	@Column(name = "FLG_ALT")
	public String getDomainUpdate() {
		return domainUpdate;
	}

	public void setDomainUpdate(String domainUpdate) {
		this.domainUpdate = domainUpdate;
	}

	/**
	 * @return Exclusão: Informa se o perfil possui permissão de exclusão na transação |
	 * FLAG
	 */
	@Column(name = "FLG_EXCL")
	public String getDomainDelete() {
		return domainDelete;
	}

	public void setDomainDelete(String domainDelete) {
		this.domainDelete = domainDelete;
	}

	@ManyToOne
	@JoinColumns({
			@JoinColumn(name = "COD_EMP", referencedColumnName = "COD_EMP", insertable = false, updatable = false),
			@JoinColumn(name = "COD_GRUPO_ACESSO", referencedColumnName = "COD_GRUPO_ACESSO", insertable = false, updatable = false) })
	public AccessGroup getAccessGroup() {
		return accessGroup;
	}

	public void setAccessGroup(AccessGroup accessGroup) {
		this.accessGroup = accessGroup;
	}

	@ManyToOne
	@JoinColumn(name = "COD_TRANSC", referencedColumnName = "COD_TRANSC", insertable = false, updatable = false)
	public Transaction getTransaction() {
		return transaction;
	}

	public void setTransaction(Transaction transaction) {
		this.transaction = transaction;
	}

}
