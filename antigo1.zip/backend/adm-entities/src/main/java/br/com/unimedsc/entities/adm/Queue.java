package br.com.unimedsc.entities.adm;

import br.com.unimedsc.core.annotation.GenerateKey;
import br.com.unimedsc.core.entity.EntityAbstractEnterprise;
import br.com.unimedsc.core.entity.pk.CompositeEnterprisePK;
import br.com.unimedsc.core.utils.DatabaseDefinition;
import br.com.unimedsc.entities.erp.Enterprise;

import javax.persistence.*;

@Entity
@Table(name = DatabaseDefinition.TABLE_PREFIX_ADM + "_FILA_EXECUCAO")
@AttributeOverride(name = "pk.id", column = @Column(name = "COD_FILA"))
@GenerateKey(sequence = "S_TADM0010")
public class Queue extends EntityAbstractEnterprise<CompositeEnterprisePK<Long>> {

	private String descriptionQueue;

	private String domainStatus;

	private String startTime;

	private String endTime;

	private Long parallelProcesses;

	private Enterprise enterprise;

	@EmbeddedId
	public CompositeEnterprisePK<Long> getPk() {
		return super.getPk();
	}

	/**
	 * @return Descrição: Descrição da fila de execução
	 */
	@Column(name = "DES_FILA")
	public String getDescriptionQueue() {
		return descriptionQueue;
	}

	public void setDescriptionQueue(String descriptionQueue) {
		this.descriptionQueue = descriptionQueue;
	}

	/**
	 *  @return Situação:
	 *            Informa a situação atual da fila de execução |
	 *            SITUACAO_FILA_EXECUCAO
	 */
	@Column(name = "IND_SITUAC")
	public String getDomainStatus() {
		return domainStatus;
	}

	public void setDomainStatus(String domainStatus) {
		this.domainStatus = domainStatus;
	}

	/**
	 *  @return Hora
	 *            de início: Hora em que a fila inicia a execução de processos
	 */
	@Column(name = "HRA_INIC_EXEC")
	public String getStartTime() {
		return startTime;
	}

	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}

	/**
	 *  @return Hora
	 *            de início: Hora em que a fila encerra a execução de processos
	 */
	@Column(name = "HRA_FIM_EXEC")
	public String getEndTime() {
		return endTime;
	}

	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}

	/**
	 *  @return Quantidade
	 *            de processos: Informa a quantidade de processos paralelos
	 *            permitidos
	 */
	@Column(name = "QTD_PRCSSO_PARELO")
	public Long getParallelProcesses() {
		return parallelProcesses;
	}

	public void setParallelProcesses(Long parallelProcesses) {
		this.parallelProcesses = parallelProcesses;
	}

	@ManyToOne
	@JoinColumn(name = "COD_EMP", referencedColumnName = "COD_EMP", insertable = false, updatable = false)
	public Enterprise getEnterprise() {
		return enterprise;
	}

	public void setEnterprise(Enterprise enterprise) {
		this.enterprise = enterprise;
	}

}
