package br.com.unimedsc.entities.adm;

import br.com.unimedsc.core.annotation.DefaultEntityReturn;
import br.com.unimedsc.core.annotation.GenerateKey;
import br.com.unimedsc.core.entity.EntityAbstract;
import br.com.unimedsc.core.utils.DatabaseDefinition;
import br.com.unimedsc.entities.pk.AccessGroupCompositePK;

import javax.persistence.*;

@Entity
@Table(name = DatabaseDefinition.TABLE_PREFIX_ADM + "_GRUPO_ACESSO_PARAMETRO")
@AttributeOverride(name = "pk.id", column = @Column(name = "COD_PARAM"))
@GenerateKey(sequence = "S_TADM0011")
public class AccessGroupParameter extends EntityAbstract<String, AccessGroupCompositePK<String>> {

	@DefaultEntityReturn
	private String parameterValue;

	@EmbeddedId
	public AccessGroupCompositePK<String> getPk() {
		return super.getPk();
	}

	/**
	 * @return Valor: Valor do parâmetro para o perfil
	 */
	@Column(name = "VAL_PARAM")
	public String getParameterValue() {
		return parameterValue;
	}

	public void setParameterValue(String parameterValue) {
		this.parameterValue = parameterValue;
	}

}
