package br.com.unimedsc.entities.pk;

import javax.persistence.Column;

import br.com.unimedsc.core.entity.pk.CompositeEnterprisePK;

public class CalendarCompositePK<TID> extends CompositeEnterprisePK<TID> {

	private static final long serialVersionUID = -1307317940484458483L;

	private Long calendarId;

	@Column(name = "COD_CALEND")
	public Long getCalendarId() {
		return calendarId;
	}

	public void setCalendarId(Long calendarId) {
		this.calendarId = calendarId;
	}

	@Override
	@Column(name = "COD_EMP")
	public Long getEnterpriseId() {
		return super.getEnterpriseId();
	}

	@Override
	@Column(name = "COD")
	public TID getId() {
		return super.id;
	}
}
