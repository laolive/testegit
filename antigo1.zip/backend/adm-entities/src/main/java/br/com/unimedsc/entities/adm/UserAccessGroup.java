package br.com.unimedsc.entities.adm;

import br.com.unimedsc.core.annotation.DefaultLoginReturn;
import br.com.unimedsc.core.annotation.GenerateKey;
import br.com.unimedsc.core.entity.EntityAbstract;
import br.com.unimedsc.core.utils.DatabaseDefinition;
import br.com.unimedsc.entities.pk.AccessGroupCompositePK;
import com.fasterxml.jackson.annotation.JsonBackReference;

import javax.persistence.*;

@Entity
@Table(name = DatabaseDefinition.TABLE_PREFIX_ADM + "_USUARIO_GRUPO_ACESSO")
@AttributeOverride(name = "pk.id", column = @Column(name = "COD_USU"))
@DefaultLoginReturn
@GenerateKey(sequence = "S_TADM0003")
public class UserAccessGroup extends EntityAbstract<String, AccessGroupCompositePK<String>> {

	private User user;

	private AccessGroup accessGroup;

	@Override
	@EmbeddedId
	public AccessGroupCompositePK<String> getPk() {
		return super.getPk();
	}

	/**
	 * @return Usuário: Código do usuário do sistema
	 */
	@ManyToOne
	@JoinColumn(name = "COD_USU", referencedColumnName = "COD_USU", insertable = false, updatable = false)
	@JsonBackReference
	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	/**
	 * @return Perfil: perfil ao qual o usuário está relacionado
	 */
	@ManyToOne
	@JoinColumns(value = {
			@JoinColumn(name = "COD_EMP", referencedColumnName = "COD_EMP", insertable = false, updatable = false),
			@JoinColumn(name = "COD_GRUPO_ACESSO", referencedColumnName = "COD_GRUPO_ACESSO", insertable = false, updatable = false) })
	public AccessGroup getProfile() {
		return accessGroup;
	}

	public void setProfile(AccessGroup profile) {
		this.accessGroup = profile;
	}

}
