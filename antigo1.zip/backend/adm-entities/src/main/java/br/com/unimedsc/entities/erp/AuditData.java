package br.com.unimedsc.entities.erp;

import java.util.Calendar;

import javax.persistence.AttributeOverride;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import br.com.unimedsc.core.entity.EntityAbstract;
import br.com.unimedsc.core.entity.pk.SimplePK;
import br.com.unimedsc.core.utils.DatabaseDefinition;
import br.com.unimedsc.entities.adm.User;

@Entity
@Table(name = DatabaseDefinition.TABLE_PREFIX_ERP + "_AUDITORIA_DADO")
@AttributeOverride(name = "pk.id", column = @Column(name = "COD_SEQ"))
public class AuditData extends EntityAbstract<Long, SimplePK<Long>> {

	private static final long serialVersionUID = -7046372329184655884L;

	private String tableName;

	private String column;

	private String keyRecord;

	private Calendar dateTransaction;

	private String domainTransactionType;

	private String oldContent;

	private String newContent;

	private User user;

	private String dataBaseLogin;

	private String networkLogin;

	private String computer;

	private String ipNumber;

	private Enterprise enterprise;

	@EmbeddedId
	public SimplePK<Long> getPk() {
		return super.getPk();
	}

	/** 
	 * @return Tabela: Tabela cujo registro sofreu alteração
	 */ 
	@Column(name = "NOM_TABELA")
	public String getTableName() {
		return tableName;
	} 

	public void setTableName(String tableName) {
		this.tableName = tableName;
	}

	/**
	 * @return Coluna: Coluna cujo dado sofreu alteração
	 */
	@Column(name = "NOM_COLUNA")
	public String getColumn() {
		return column;
	}

	public void setColumn(String column) {
		this.column = column;
	}

	/**
	 * @return Chave: Chave identificadora do registro alterado
	 */
	@Column(name = "VAL_CHAVE_REG")
	public String getKeyRecord() {
		return keyRecord;
	}

	public void setKeyRecord(String keyRecord) {
		this.keyRecord = keyRecord;
	}

	/**
	 * @return Data: Data que em ocorreu a operação
	 */
	@Column(name = "DTH_OPRCAO")
	public Calendar getDateTransaction() {
		return dateTransaction;
	}

	public void setDateTransaction(Calendar dateTransaction) {
		this.dateTransaction = dateTransaction;
	}

	/**
	 * @return Tipo de operação: Tipo da operação efetuada | TIPO_OPERACAO_AUDITORIA
	 */
	@Column(name = "TIP_OPRCAO")
	public String getDomainTransactionType() {
		return domainTransactionType;
	}

	public void setDomainTransactionType(String domainTransactionType) {
		this.domainTransactionType = domainTransactionType;
	}

	/**
	 * @return Conteúdo anterior: Conteúdo anterior da coluna
	 */
	@Column(name = "VAL_CONTD_DE")
	public String getOldContent() {
		return oldContent;
	}

	public void setOldContent(String oldContent) {
		this.oldContent = oldContent;
	}

	/**
	 * @return Conteúdo atualizado: Conteúdo atualizado da coluna
	 */
	@Column(name = "VAL_CONTD_PARA")
	public String getNewContent() {
		return newContent;
	}

	public void setNewContent(String newContent) {
		this.newContent = newContent;
	}

	/**
	 * @return Usuário: Código do usuário, no sistema, que efetuou a operação
	 */
	@ManyToOne
	@JoinColumn(name = "COD_USU", referencedColumnName = "COD_USU")
	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	/**
	 * @return Login: Login, no banco de dados, que efetuou a operação
	 */
	@Column(name = "NOM_LOGIN_BCO_DADOS")
	public String getDataBaseLogin() {
		return dataBaseLogin;
	}

	public void setDataBaseLogin(String dataBaseLogin) {
		this.dataBaseLogin = dataBaseLogin;
	}

	/**
	 * @return Login na rede: Login, na rede, que efetuou a operação
	 */
	@Column(name = "NOM_LOGIN_REDE")
	public String getNetworkLogin() {
		return networkLogin;
	}

	public void setNetworkLogin(String networkLogin) {
		this.networkLogin = networkLogin;
	}

	/**
	 * @return Computador: Computador de onde foi realizada a operação
	 */
	@Column(name = "NOM_COMPUT")
	public String getComputer() {
		return computer;
	}

	public void setComputer(String computer) {
		this.computer = computer;
	}

	/**
	 * @return Número do IP: Armazena o número do IP do usuário
	 */
	@Column(name = "NRO_IP")
	public String getIpNumber() {
		return ipNumber;
	}

	public void setIpNumber(String ipNumber) {
		this.ipNumber = ipNumber;
	}

	/**
	 * @return Empresa: Código da empresa
	 */
	@ManyToOne
	@JoinColumn(name = "COD_EMP", referencedColumnName = "COD_EMP")
	public Enterprise getEnterprise() {
		return enterprise;
	}

	public void setEnterprise(Enterprise enterprise) {
		this.enterprise = enterprise;
	}

}
