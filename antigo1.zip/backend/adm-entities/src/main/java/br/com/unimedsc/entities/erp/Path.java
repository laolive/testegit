package br.com.unimedsc.entities.erp;

import javax.persistence.AttributeOverride;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

import br.com.unimedsc.core.entity.EntityAbstract;
import br.com.unimedsc.core.entity.pk.SimplePK;
import br.com.unimedsc.core.utils.DatabaseDefinition;

@Entity
@Table(name = DatabaseDefinition.TABLE_PREFIX_ERP + "_DIRETORIO")
@AttributeOverride(name = "pk.id", column = @Column(name = "NOM_DIR"))
public class Path extends EntityAbstract<String, SimplePK<String>> {

	private static final long serialVersionUID = -5825485333942454108L;

	private String pathDataBase;

	private String pathNetwork;

	@EmbeddedId
	public SimplePK<String> getPk() {
		return super.getPk();
	}

	/**
	 * @return Diretório no banco de dados: Caminho do diretório para o banco de
	 *         dados
	 */
	@Column(name = "DES_CAMINH_BCO_DADOS")
	public String getPathDataBase() {
		return pathDataBase;
	}

	public void setPathDataBase(String pathDataBase) {
		this.pathDataBase = pathDataBase;
	}

	/**
	 * @return Diretório na rede: Caminho do diretório para a rede
	 */
	@Column(name = "DES_CAMINH_REDE")
	public String getPathNetwork() {
		return pathNetwork;
	}

	public void setPathNetwork(String pathNetwork) {
		this.pathNetwork = pathNetwork;
	}

}
