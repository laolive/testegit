package br.com.unimedsc.entities.pk;

import javax.persistence.Column;

import br.com.unimedsc.core.entity.pk.CompositeEnterprisePK;

public class MenuCompositePK<TID> extends CompositeEnterprisePK<TID> {

	private static final long serialVersionUID = 1252836457302137772L;

	private Long menuId;

	@Column(name = "COD_MENU")
	public Long getMenuId() {
		return menuId;
	}

	public void setMenuId(Long menuId) {
		this.menuId = menuId;
	}

	@Override
	@Column(name = "COD_EMP")
	public Long getEnterpriseId() {
		return super.getEnterpriseId();
	}

	@Override
	@Column(name = "COD")
	public TID getId() {
		return super.id;
	}

}
