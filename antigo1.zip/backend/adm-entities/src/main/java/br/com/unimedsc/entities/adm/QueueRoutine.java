package br.com.unimedsc.entities.adm;

import br.com.unimedsc.core.annotation.GenerateKey;
import br.com.unimedsc.core.entity.EntityAbstract;
import br.com.unimedsc.core.entity.pk.CompositeEnterprisePK;
import br.com.unimedsc.core.utils.DatabaseDefinition;
import br.com.unimedsc.entities.erp.Routine;
import com.fasterxml.jackson.annotation.JsonBackReference;

import javax.persistence.*;

@Entity
@Table(name = DatabaseDefinition.TABLE_PREFIX_ADM + "_FILA_EXECUCAO_ROTINA")
@AttributeOverride(name = "pk.id", column = @Column(name = "COD_ROTINA"))
@GenerateKey(sequence = "S_TADM0016")
public class QueueRoutine extends EntityAbstract<Long, CompositeEnterprisePK<Long>> {

	private Routine routine;

	private Queue queue;

	@EmbeddedId
	public CompositeEnterprisePK<Long> getPk() {
		return super.getPk();
	}

	@ManyToOne
	@JoinColumn(name = "COD_ROTINA", insertable = false, updatable = false)
	@JsonBackReference
	public Routine getRoutine() {
		return routine;
	}

	public void setRoutine(Routine routine) {
		this.routine = routine;
	}

	@ManyToOne
	@JoinColumns({
			@JoinColumn(name = "COD_EMP", referencedColumnName = "COD_EMP", insertable = false, updatable = false),
			@JoinColumn(name = "COD_FILA", referencedColumnName = "COD_FILA", insertable = false, updatable = false) })
	public Queue getQueue() {
		return queue;
	}

	public void setQueue(Queue queue) {
		this.queue = queue;
	}

}
