package br.com.unimedsc.entities.adm;

import br.com.unimedsc.core.annotation.DefaultLoginReturn;
import br.com.unimedsc.core.annotation.GenerateKey;
import br.com.unimedsc.core.entity.EntityAbstract;
import br.com.unimedsc.core.entity.pk.CompositeEnterprisePK;
import br.com.unimedsc.core.utils.DatabaseDefinition;
import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;

import javax.persistence.*;

@Entity
@Table(name = DatabaseDefinition.TABLE_PREFIX_ADM + "_PARAMETRO_EMPRESA")
@AttributeOverride(name = "pk.id", column = @Column(name = "COD_PARAM"))
@JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class, property = "pk")
@DefaultLoginReturn
@GenerateKey(sequence = "S_TADM0020")
public class EnterpriseParameter extends EntityAbstract<String, CompositeEnterprisePK<String>>  {

	private String value;
	
	@EmbeddedId
	@Override
	public CompositeEnterprisePK<String> getPk() {
		return super.getPk();
	}

	/**
	 * @return Descrição do valor do parametro.
	 */

	@Column(name = "VAL_PARAM")
	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

}
