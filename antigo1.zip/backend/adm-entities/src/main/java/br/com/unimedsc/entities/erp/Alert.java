package br.com.unimedsc.entities.erp;

import java.util.Calendar;

import javax.persistence.AttributeOverride;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.PrePersist;
import javax.persistence.Table;

import br.com.unimedsc.core.annotation.GenerateKey;
import br.com.unimedsc.core.entity.EntityAbstract;
import br.com.unimedsc.core.entity.pk.SimplePK;
import br.com.unimedsc.core.utils.DatabaseDefinition;
import br.com.unimedsc.entities.adm.User;

@Entity
@Table(name = DatabaseDefinition.TABLE_PREFIX_ERP + "_ALERTA")
@AttributeOverride(name = "pk.id", column = @Column(name = "COD_ALERTA"))
@GenerateKey(sequence = "S_TERP0027")
public class Alert extends EntityAbstract<Long, SimplePK<Long>> {

	private static final long serialVersionUID = 9111372863848779955L;

	private Calendar creationDate;

	private User creationUser;

	private String subject;

	private String domainAlertType;

	private String domainSendType;

	private String domainOpen;

	private String alertDescription;

	private User destinationUser;

	private Process process;

	private Enterprise enterprise;

	@PrePersist
	public void prePersist() {
		super.prePersist();
	}

	@EmbeddedId
	public SimplePK<Long> getPk() {
		return super.getPk();
	}

	/**
	 * @return Data: Data e hora da geração do alerta
	 */
	@Column(name = "DTH_GRCAO")
	public Calendar getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(Calendar creationDate) {
		this.creationDate = creationDate;
	}

	/**
	 * @return Usuário: Usuário que gerou o alerta
	 */
	@ManyToOne
	@JoinColumn(name = "COD_USU_GRCAO", referencedColumnName = "COD_USU")
	public User getCreationUser() {
		return creationUser;
	}

	public void setCreationUser(User creationUser) {
		this.creationUser = creationUser;
	}

	/**
	 * @return Assunto: Assunto do alerta
	 */
	@Column(name = "DES_ASSUNT")
	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	/**
	 * @return Tipo: Informa o tipo do alerta | TIPO_ALERTA_USUARIO
	 */
	@Column(name = "TIP_ALERTA")
	public String getDomainAlertType() {
		return domainAlertType;
	}

	public void setDomainAlertType(String domainAlertType) {
		this.domainAlertType = domainAlertType;
	}

	/**
	 * @return Tipo de envio: Informa o tipo de envio do alerta |
	 *         TIPO_ENVIO_ALERTA_USUARIO
	 */
	@Column(name = "TIP_ENVIO_ALERTA")
	public String getDomainSendType() {
		return domainSendType;
	}

	public void setDomainSendType(String domainSendType) {
		this.domainSendType = domainSendType;
	}

	/**
	 * @return Tipo: Informa o tipo do alerta | TIPO_ALERTA_USUARIO
	 */
	@Column(name = "FLG_PNTE_ENVIO")
	public String getDomainOpen() {
		return domainOpen;
	}

	public void setDomainOpen(String domainOpen) {
		this.domainOpen = domainOpen;
	}

	/**
	 * @return Mensagem: Mensagem completa do alerta
	 */
	@Column(name = "DES_ALERTA")
	public String getAlertDescription() {
		return alertDescription;
	}

	public void setAlertDescription(String alertDescription) {
		this.alertDescription = alertDescription;
	}

	/**
	 * @return Usuário: Usuário alertado
	 */
	@ManyToOne
	@JoinColumn(name = "COD_USU_DESTIN", referencedColumnName = "COD_USU")
	public User getDestinationUser() {
		return destinationUser;
	}

	public void setDestinationUser(User destinationUser) {
		this.destinationUser = destinationUser;
	}

	/**
	 * @return Processo: Processo que gerou o alerta
	 */
	@ManyToOne
	@JoinColumn(name = "COD_PRCSSO", referencedColumnName = "COD_PRCSSO")
	public Process getProcess() {
		return process;
	}

	public void setProcess(Process process) {
		this.process = process;
	}

	/**
	 * @return Empresa: Código da empresa para a qual se destina o alerta
	 */
	@ManyToOne
	@JoinColumn(name = "COD_EMP", referencedColumnName = "COD_EMP")
	public Enterprise getEnterprise() {
		return enterprise;
	}

	public void setEnterprise(Enterprise enterprise) {
		this.enterprise = enterprise;
	}

}
