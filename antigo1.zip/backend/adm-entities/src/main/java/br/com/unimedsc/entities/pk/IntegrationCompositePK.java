package br.com.unimedsc.entities.pk;

import javax.persistence.Column;

import br.com.unimedsc.core.entity.pk.SimplePK;

public class IntegrationCompositePK<T> extends SimplePK<T> {

	private static final long serialVersionUID = 3953276189679156585L;

	private Long integrationId;

	public IntegrationCompositePK() {
	}

	public IntegrationCompositePK(T id, Long integrationId) {
		super(id);
		this.integrationId = integrationId;
	}

	@Column(name = "COD_INTEGRACAO")
	public Long getIntegrationId() {
		return integrationId;
	}

	public void setIntegrationId(Long integrationId) {
		this.integrationId = integrationId;
	}

	@Column(name = "COD")
	public T getId() {
		return this.id;
	}

}
