package br.com.unimedsc.entities.erp;

import javax.persistence.AttributeOverride;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

import br.com.unimedsc.core.entity.EntityAbstract;
import br.com.unimedsc.core.utils.DatabaseDefinition;
import br.com.unimedsc.entities.pk.TransactionCompositePK;

@Entity
@Table(name = DatabaseDefinition.TABLE_PREFIX_ERP + "_TRANSACAO_CAMPO")
@AttributeOverride(name = "pk.id", column = @Column(name = "NOM_CAMPO"))
public class TransactionField extends EntityAbstract<String, TransactionCompositePK<String>> {

	private static final long serialVersionUID = -2213056556183876272L;

	@EmbeddedId
	public TransactionCompositePK<String> getPk() {
		return super.getPk();
	}

}
