package br.com.unimedsc.entities.adm;

import br.com.unimedsc.core.annotation.GenerateKey;
import br.com.unimedsc.core.entity.EntityAbstractEnterprise;
import br.com.unimedsc.core.entity.pk.CompositeEnterprisePK;
import br.com.unimedsc.core.utils.DatabaseDefinition;

import javax.persistence.*;

@Entity
@Table(name = DatabaseDefinition.TABLE_PREFIX_ADM + "_USUARIO_EMPRESA")
@AttributeOverride(name = "pk.id", column = @Column(name = "COD_USU"))
@GenerateKey(sequence = "S_TADM0021")
public class UserEnterprise  extends EntityAbstractEnterprise<CompositeEnterprisePK<Long>> {

	private User user;
	
	@EmbeddedId
	@Override
	public CompositeEnterprisePK<Long> getPk() {
		return super.getPk();
	}

	@ManyToOne
	@JoinColumn(name = "COD_USU", referencedColumnName = "COD_USU", insertable = false, updatable = false)
	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}
	
	

}
