package br.com.unimedsc.entities.cfg;

import javax.persistence.AttributeOverride;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.PrePersist;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;

import br.com.unimedsc.core.annotation.GenerateKey;
import br.com.unimedsc.core.entity.EntityAbstract;
import br.com.unimedsc.core.utils.DatabaseDefinition;
import br.com.unimedsc.entities.pk.SearchCompositePK;

@Entity
@Table(name = DatabaseDefinition.TABLE_PREFIX_CFG + "_PESQUISA_FILTRO")
@AttributeOverride(name = "pk.id", column = @Column(name = "COD_PESQSA_FILTRO"))
@GenerateKey(sequence = "S_TCFG0025")
public class SearchFilter extends EntityAbstract<Long, SearchCompositePK<Long>> {

	private static final long serialVersionUID = 1640601861373364696L;

	private String field;

	private String operator;

	private String value;

	private String domainOr; 

	private Search search;

	@EmbeddedId
	public SearchCompositePK<Long> getPk() {
		return super.getPk();
	}

	@PrePersist
	public void prePersist() {
		super.prePersist();
	}

	/** 
	 * @return Campo: Campo do filtro
	 */ 
	@Column(name = "DES_CAMPO")
	public String getField() {
		return field;
	}

	public void setField(String field) {
		this.field = field;
	}

	/** 
	 * @return Operador: Operador do filtro
	 */ 
	@Column(name = "DES_OPEDR")
	public String getOperator() {
		return operator;
	}

	public void setOperator(String operator) {
		this.operator = operator;
	}

	/**
	 * @return Valor: Valor do filtro
	 */
	@Column(name = "DES_VALOR")
	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	/**
	 * @return Condição OR: Indica se o filtro é uma condição "OR" | FLAG
	 */
	@Column(name = "FLG_OU")
	public String getDomainOr() {
		return domainOr;
	}

	public void setDomainOr(String domainOr) {
		this.domainOr = domainOr;
	}

	@JsonBackReference
	@ManyToOne
	@JoinColumns({
			@JoinColumn(name = "COD_EMP", referencedColumnName = "COD_EMP", insertable = false, updatable = false),
			@JoinColumn(name = "COD_PAINEL", referencedColumnName = "COD_PAINEL", insertable = false, updatable = false),
			@JoinColumn(name = "COD_PESQSA", referencedColumnName = "COD_PESQSA", insertable = false, updatable = false) })
	public Search getSearch() {
		return search;
	}

	public void setSearch(Search search) {
		this.search = search;
	}

}
