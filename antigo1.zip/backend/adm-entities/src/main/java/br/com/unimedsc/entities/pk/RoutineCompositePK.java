package br.com.unimedsc.entities.pk;

import javax.persistence.Column;

import br.com.unimedsc.core.entity.pk.SimplePK;

public class RoutineCompositePK<TID> extends SimplePK<TID> {

    private static final long serialVersionUID = 5912801824123702410L;

    private Long routineId;

    @Column(name = "COD_ROTINA")
    public Long getRoutineId() {
	return routineId;
    }

    public void setRoutineId(Long routineId) {
	this.routineId = routineId;
    }

    @Override
    @Column(name = "COD")
    public TID getId() {
	return super.id;
    }

}
