package br.com.unimedsc.entities.repository;

import br.com.unimedsc.entities.adm.Holiday;
import br.com.unimedsc.entities.vo.HolidayReturnVO;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.Calendar;
import java.util.List;

public interface HolidayRepository extends JpaRepository<Holiday, Long> {

    @Query("SELECT new br.com.unimedsc.entities.vo.HolidayReturnVO(h.pk.id) "
            + "    FROM Holiday h "
            + "  WHERE h.pk.enterpriseId = :enterpriseId "
            + "    AND h.pk.id BETWEEN :startDate AND :endDate "
    )
    List<HolidayReturnVO> findHolidayAnnual(@Param("enterpriseId") Long enterpriseId, @Param("startDate") Calendar startDate,
                                            @Param("endDate") Calendar endDate);
}
