package br.com.unimedsc.entities.pk;

import javax.persistence.Column;

public class UserEnterpriseCompositePK<TID> extends UserCompositePK<TID> {

	private static final long serialVersionUID = -4336781621599706220L;
	
	private Long enterpriseId;

	@Column(name = "COD_EMP")
	public Long getEnterpriseId() {
		return enterpriseId;
	}

	public void setEnterpriseId(Long enterpriseId) {
		this.enterpriseId = enterpriseId;
	}
	
	@Override
    @Column(name = "COD_USU")
    public Long getUserId() {
	return super.getUserId();
    }
	
	@Override
	@Column(name = "COD")
	public TID getId() {
		return super.id;
	}

}
