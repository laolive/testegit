package br.com.unimedsc.entities.erp;

import javax.persistence.AttributeOverride;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.PrePersist;
import javax.persistence.Table;

import br.com.unimedsc.core.annotation.DefaultEntityReturn;
import br.com.unimedsc.core.annotation.GenerateKey;
import br.com.unimedsc.core.entity.EntityAbstract;
import br.com.unimedsc.core.entity.pk.SimplePK;
import br.com.unimedsc.core.utils.DatabaseDefinition;
import br.com.unimedsc.entities.adm.User;

@Entity
@Table(name = DatabaseDefinition.TABLE_PREFIX_ERP + "_ARQUIVO")
@AttributeOverride(name = "pk.id", column = @Column(name = "COD_ARQ"))
@GenerateKey(sequence = "S_TERP0026")
public class Archive extends EntityAbstract<Long, SimplePK<Long>> {

	private static final long serialVersionUID = 2341906895084923302L;

	@DefaultEntityReturn
	private String identifier;

	private String fileName;

	private String extension;

	private User user;

	private Enterprise enterprise;

	private String domainEntry;
	
	private String nameBucket;
	
	private String path;

	@Override
	@EmbeddedId
	public SimplePK<Long> getPk() {
		return super.getPk();
	}

	@Override
	@PrePersist
	public void prePersist() {
		super.prePersist();
	}

	/**
	 * @return UUID: Identificador do arquivo no sistema de arquivos
	 */
	@Column(name = "NRO_UUID")
	public String getIdentifier() {
		return identifier;
	}

	public void setIdentifier(String identifier) {
		this.identifier = identifier;
	}

	/**
	 * @return Nome: Nome original do arquivo
	 */
	@Column(name = "NOM_ARQ")
	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	/**
	 * @return Extensão: Extensão do arquivo
	 */
	@Column(name = "DES_EXTSAO")
	public String getExtension() {
		return extension;
	}

	public void setExtension(String extension) {
		this.extension = extension;
	}

	/**
	 * @return Usuário: Código do usuário que realizou o upload
	 */
	@ManyToOne
	@JoinColumn(name = "COD_USU", referencedColumnName = "COD_USU")
	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	/**
	 * @return Empresa: Código da empresa
	 */
	@ManyToOne
	@JoinColumn(name = "COD_EMP", referencedColumnName = "COD_EMP")
	public Enterprise getEnterprise() {
		return enterprise;
	}

	public void setEnterprise(Enterprise enterprise) {
		this.enterprise = enterprise;
	}

	/**
	 * @return Entrada: Informa se é um arquivo de entrada | FLAG
	 */
	@Column(name = "FLG_ARQ_ENTRDA")
	public String getDomainEntry() {
		return domainEntry;
	}

	public void setDomainEntry(String domainEntry) {
		this.domainEntry = domainEntry;
	}

	/**
	 * @return Bucket: Nome do bucket
    */
    @Column(name = "NOM_BUCKET")
    public String getNameBucket() {
        return nameBucket;
    }

    public void setNameBucket(String nameBucket) {
        this.nameBucket = nameBucket;
    }

    /**
     * @return Caminho: Caminho com diretório/subdiretório (se houver subdiretório)
    */
    @Column(name = "CAMINHO")
    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }
}
