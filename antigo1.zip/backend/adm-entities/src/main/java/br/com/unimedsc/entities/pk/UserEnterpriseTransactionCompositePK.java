package br.com.unimedsc.entities.pk;

import javax.persistence.Column;

public class UserEnterpriseTransactionCompositePK<TID> extends UserCompositePK<TID> {

	private static final long serialVersionUID = -1979291447194946397L;

	private Long enterpriseId;
	private Long transactionId;

	@Column(name = "COD_EMP")
	public Long getEnterpriseId() {
		return enterpriseId;
	}

	public void setEnterpriseId(Long enterpriseId) {
		this.enterpriseId = enterpriseId;
	}
	
	@Column(name = "COD_TRANSC")
	public Long getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(Long transactionId) {
		this.transactionId = transactionId;
	}
	
	@Override
    @Column(name = "COD_USU")
    public Long getUserId() {
	return super.getUserId();
    }

	@Override
	@Column(name = "COD")
	public TID getId() {
		return super.id;
	}
	

}
