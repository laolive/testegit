package br.com.unimedsc.entities.pk;

import javax.persistence.Column;

import br.com.unimedsc.core.entity.pk.SimplePK;

public class ProcessCompositePK<TID> extends SimplePK<TID> {

	private static final long serialVersionUID = 773404307649833649L;

	private Long processId;

	@Column(name = "COD_PRCSSO")
	public Long getProcessId() {
		return processId;
	}

	public void setProcessId(Long processId) {
		this.processId = processId;
	}

	@Override
	@Column(name = "COD")
	public TID getId() {
		return super.id;
	}

}
