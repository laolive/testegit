package br.com.unimedsc.entities.adm;

import br.com.unimedsc.core.annotation.GenerateKey;
import br.com.unimedsc.core.entity.EntityAbstract;
import br.com.unimedsc.core.utils.DatabaseDefinition;
import br.com.unimedsc.entities.pk.CalendarSubsidaryCompositePK;

import javax.persistence.*;
import java.util.Calendar;

@Entity
@Table(name = DatabaseDefinition.TABLE_PREFIX_ADM + "_CALENDARIO_USUARIO")
@AttributeOverride(name = "pk.id", column = @Column(name = "DTH_INIC_AGENDA"))
@GenerateKey(sequence = "S_TADM0019")
public class CalendarUser extends EntityAbstract<Calendar, CalendarSubsidaryCompositePK<Calendar>> {

	private CalendarDate calendarDate;

	private User user;

	private Calendar startDiary;

	private Calendar endDiary;

	private String observation;

	@EmbeddedId
	public CalendarSubsidaryCompositePK<Calendar> getPk() {
		return super.getPk();
	}

	@ManyToOne
	@JoinColumns({
			@JoinColumn(name = "COD_EMP", referencedColumnName = "COD_EMP", insertable = false, updatable = false),
			@JoinColumn(name = "COD_CALEND", referencedColumnName = "COD_CALEND", insertable = false, updatable = false),
			@JoinColumn(name = "DAT_CALEND", referencedColumnName = "DAT_CALEND", insertable = false, updatable = false) })
	public CalendarDate getCalendarDate() {
		return calendarDate;
	}

	public void setCalendarDate(CalendarDate calendarDate) {
		this.calendarDate = calendarDate;
	}

	/**
	 * @return Usuário: Código do usuário
	 */
	@ManyToOne
	@JoinColumn(name = "COD_USUARIO")
	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	/**
	 * @return Início: Hora de início
	 */
	@Column(name = "DTH_INIC_AGENDA", insertable = false, updatable = false)
	public Calendar getStartDiary() {
		return startDiary;
	}

	public void setStartDiary(Calendar startDiary) {
		this.startDiary = startDiary;
	}

	/**
	 * @return Fim: Hora de fim
	 */
	@Column(name = "DTH_FIM_AGENDA")
	public Calendar getEndDiary() {
		return endDiary;
	}

	public void setEndDiary(Calendar endDiary) {
		this.endDiary = endDiary;
	}

	/**
	 * @return Observação: Observação
	 */
	@Column(name = "OBS_AGENDA")
	public String getObservation() {
		return observation;
	}

	public void setObservation(String observation) {
		this.observation = observation;
	}

}
