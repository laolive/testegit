package br.com.unimedsc.entities.adm;

import br.com.unimedsc.core.annotation.DefaultEntityReturn;
import br.com.unimedsc.core.entity.EntityAbstract;
import br.com.unimedsc.core.entity.pk.SimplePK;

import javax.persistence.*;
import java.util.Calendar;

@Entity
@AttributeOverride(name = "pk.id", column = @Column(name = "ID"))
public class DominioItem extends EntityAbstract<Integer, SimplePK<Integer>> {

    private Dominio dominio;

    @DefaultEntityReturn
    private String nome;

    @DefaultEntityReturn
    private String valor;

    @DefaultEntityReturn
    private String descricao;

    @DefaultEntityReturn
    private Calendar dataInicioVigencia;

    @DefaultEntityReturn
    private Calendar dataFimVigencia;

    @EmbeddedId
    public SimplePK<Integer> getPk() {
        return super.getPk();
    }

    @ManyToOne
    public Dominio getDominio() {
        return dominio;
    }

    public void setDominio(Dominio dominio) {
        this.dominio = dominio;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getValor() {
        return valor;
    }

    public void setValor(String valor) {
        this.valor = valor;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public Calendar getDataInicioVigencia() {
        return dataInicioVigencia;
    }

    public void setDataInicioVigencia(Calendar dataInicioVigencia) {
        this.dataInicioVigencia = dataInicioVigencia;
    }

    public Calendar getDataFimVigencia() {
        return dataFimVigencia;
    }

    public void setDataFimVigencia(Calendar dataFimVigencia) {
        this.dataFimVigencia = dataFimVigencia;
    }

}
