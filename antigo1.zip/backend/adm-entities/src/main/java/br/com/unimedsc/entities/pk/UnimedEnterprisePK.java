package br.com.unimedsc.entities.pk;

import javax.persistence.Column;

import br.com.unimedsc.core.entity.pk.CompositeEnterprisePK;

public class UnimedEnterprisePK<T> extends CompositeEnterprisePK<T> {

	private static final long serialVersionUID = 2663630756132904912L;
	
	private Long unimedId;

    @Column(name = "COD_UNIMED")
    public Long getUnimedId() {
	return unimedId;
    }

    public void setUnimedId(Long unimedId) {
	this.unimedId = unimedId;
    }

    @Override
    @Column(name = "COD_EMP")
    public Long getEnterpriseId() {
	return super.enterpriseId;
    }

    @Override
    @Column(name = "COD")
    public T getId() {
	return super.id;
    }

}
