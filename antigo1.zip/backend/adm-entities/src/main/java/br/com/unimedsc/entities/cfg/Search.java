package br.com.unimedsc.entities.cfg;

import java.io.IOException;

import javax.persistence.AttributeOverride;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.PostLoad;
import javax.persistence.PrePersist;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;

import br.com.unimedsc.core.annotation.GenerateKey;
import br.com.unimedsc.core.entity.EntityAbstract;
import br.com.unimedsc.core.filter.Node;
import br.com.unimedsc.core.utils.CommonsHelper;
import br.com.unimedsc.core.utils.DatabaseDefinition;
import br.com.unimedsc.entities.adm.User;
import br.com.unimedsc.entities.erp.Enterprise;
import br.com.unimedsc.entities.pk.PanelCompositePK;

@Entity
@Table(name = DatabaseDefinition.TABLE_PREFIX_CFG + "_PESQUISA")
@AttributeOverride(name = "pk.id", column = @Column(name = "COD_PESQSA"))
@GenerateKey(sequence = "S_TCFG0024")
public class Search extends EntityAbstract<Long, PanelCompositePK<Long>> {

	private static final long serialVersionUID = -7799486103575166207L;

	private String descriptionSearch;

	private User user;

	private Enterprise enterprise;

	private String filterJson;

	private Node filter;

	@EmbeddedId
	public PanelCompositePK<Long> getPk() {
		return super.getPk();
	}

	@PrePersist
	public void prePersistSearch() throws JsonGenerationException, JsonMappingException, IllegalArgumentException,
			IllegalAccessException, IOException {
		this.node2Json();
		super.prePersist();
	}

	/**
	 * @return Descrição: Descrição da pesquisa
	 */
	@Column(name = "DES_PESQSA")
	public String getDescriptionSearch() {
		return descriptionSearch;
	}

	public void setDescriptionSearch(String descriptionSearch) {
		this.descriptionSearch = descriptionSearch;
	}

	/**
	 * @return Usuário: Código do usuário responsável pelo filtro
	 */
	@ManyToOne
	@JoinColumn(name = "COD_USU", referencedColumnName = "COD_USU")
	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	@ManyToOne
	@JoinColumn(name = "COD_EMP", referencedColumnName = "COD_EMP", insertable = false, updatable = false)
	public Enterprise getEnterprise() {
		return enterprise;
	}

	public void setEnterprise(Enterprise enterprise) {
		this.enterprise = enterprise;
	}

	@JsonIgnore
	@Column(name = "FILTRO_JSON")
	public String getFilterJson() {
		return filterJson;
	}

	public void setFilterJson(String filterJson) {
		this.filterJson = filterJson;
	}

	@Transient
	public Node getFilter() {
		return filter;
	}

	public void setFilter(Node filter) {
		this.filter = filter;
	}

	public void node2Json() throws JsonGenerationException, JsonMappingException, IllegalArgumentException,
			IllegalAccessException, IOException {
		if (this.filter != null)
			this.filterJson = CommonsHelper.getInstance().DynamicItemVO(null, null, this.filter, true).toString();
	}

	@PostLoad
	public void json2Node() throws JsonParseException, JsonMappingException, IOException {
		if (this.filterJson != null)
			this.filter = (Node) CommonsHelper.getInstance().StringToObject(this.filterJson, Node.class);
	}

}
