package br.com.unimedsc.entities.pk;

import javax.persistence.Column;

import br.com.unimedsc.core.entity.pk.CompositeEnterprisePK;

public class PanelCompositePK<T> extends CompositeEnterprisePK<T> {

	private static final long serialVersionUID = 6018687234364319718L;

	private Long panelId;

	@Column(name = "COD_PAINEL")
	public Long getPanelId() {
		return panelId;
	}

	public void setPanelId(Long panelId) {
		this.panelId = panelId;
	}

	@Override
	@Column(name = "COD_EMP")
	public Long getEnterpriseId() {
		return super.getEnterpriseId();
	}

	@Override
	@Column(name = "COD")
	public T getId() {
		return super.getId();
	}

}
