package br.com.unimedsc.entities.adm;

import br.com.unimedsc.core.annotation.DefaultEntityReturn;
import br.com.unimedsc.core.annotation.GenerateKey;
import br.com.unimedsc.core.entity.EntityAbstract;
import br.com.unimedsc.core.utils.DatabaseDefinition;
import br.com.unimedsc.entities.erp.Transaction;
import br.com.unimedsc.entities.pk.UserEnterpriseCompositePK;

import javax.persistence.*;

@Entity
@Table(name = DatabaseDefinition.TABLE_PREFIX_ADM + "_USUARIO_TRANSACAO")
@AttributeOverride(name = "pk.id", column = @Column(name = "COD_TRANSC"))
@GenerateKey(sequence = "S_TADM0005")
public class UserTransaction extends EntityAbstract<Long, UserEnterpriseCompositePK<Long>> {

	@DefaultEntityReturn
	private UserEnterprise userEnterprise;

	@DefaultEntityReturn
	private Transaction transaction;

	@DefaultEntityReturn
	private String domainInsert;

	@DefaultEntityReturn
	private String domainUpdate;

	@DefaultEntityReturn
	private String domainDelete;

	@EmbeddedId
	public UserEnterpriseCompositePK<Long> getPk() {
		return super.getPk();
	}

	@ManyToOne
	@JoinColumns({@JoinColumn(name = "COD_USU", referencedColumnName = "COD_USU", insertable = false, updatable = false),
		@JoinColumn(name = "COD_EMP", referencedColumnName = "COD_EMP", insertable = false, updatable = false)})
	public UserEnterprise getUserEnterprise() {
		return userEnterprise;
	}
	
	public void setUserEnterprise(UserEnterprise userEnterprise) {
		this.userEnterprise = userEnterprise;
	}

	@ManyToOne
	@JoinColumn(name = "COD_TRANSC", referencedColumnName = "COD_TRANSC", insertable = false, updatable = false)
	public Transaction getTransaction() {
		return transaction;
	}

	public void setTransaction(Transaction transaction) {
		this.transaction = transaction;
	}

	/**
	 * @return Inclusão: Informa se o usuário possui permissão de inclusão na transação
	 * | FLAG
	 */
	@Column(name = "FLG_INCL")
	public String getDomainInsert() {
		return domainInsert;
	}

	public void setDomainInsert(String domainInsert) {
		this.domainInsert = domainInsert;
	}

	/**
	 * @return Alteração: Informa se o usuário possui permissão de alteração na
	 * transação | FLAG
	 */
	@Column(name = "FLG_ALT")
	public String getDomainUpdate() {
		return domainUpdate;
	}

	public void setDomainUpdate(String domainUpdate) {
		this.domainUpdate = domainUpdate;
	}

	/**
	 * @return Exclusão: Informa se o usuário possui permissão de exclusão na transação
	 * | FLAG
	 */
	@Column(name = "FLG_EXCL")
	public String getDomainDelete() {
		return domainDelete;
	}

	public void setDomainDelete(String domainDelete) {
		this.domainDelete = domainDelete;
	}

}
