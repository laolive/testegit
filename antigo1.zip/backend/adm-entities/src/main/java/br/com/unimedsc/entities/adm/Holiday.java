package br.com.unimedsc.entities.adm;

import java.util.Calendar;

import javax.persistence.AttributeOverride;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

import br.com.unimedsc.core.annotation.GenerateKey;
import br.com.unimedsc.core.entity.EntityAbstract;
import br.com.unimedsc.core.entity.pk.CompositeEnterprisePK;
import br.com.unimedsc.core.utils.DatabaseDefinition;

@Entity
@Table(name = DatabaseDefinition.TABLE_PREFIX_ADM + "_FERIADO")
@AttributeOverride(name = "pk.id", column = @Column(name = "DAT_CALEND"))
@GenerateKey(sequence = "S_TADM0015")
public class Holiday extends EntityAbstract<Calendar, CompositeEnterprisePK<Calendar>> {

	private String description;

	private String domainCoverage;

	@EmbeddedId
	public CompositeEnterprisePK<Calendar> getPk() {
		return super.getPk();
	}

	/**
	 * @return Descrição: Descrição da data do Feriado
	 */
	@Column(name = "DES_FRIADO")
	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * @return Abrangência: Indica a abrangência do Feriado | FERIADO_ABRANGENCIA
	 */
	@Column(name = "IND_ABRANG")
	public String getDomainCoverage() {
		return domainCoverage;
	}

	public void setDomainCoverage(String domainCoverage) {
		this.domainCoverage = domainCoverage;
	}

}
