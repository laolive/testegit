package br.com.unimedsc.entities.erp;

import javax.persistence.AttributeOverride;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;

import br.com.unimedsc.core.entity.EntityAbstract;
import br.com.unimedsc.core.entity.pk.SimplePK;

@Entity
@AttributeOverride(name = "pk.id", column = @Column(name = "ID"))
public class TipoIntegracao extends EntityAbstract<Integer, SimplePK<Integer>>{
    
    private String nome;
    
    @EmbeddedId
    public SimplePK<Integer> getPk() {
        return super.getPk();
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
}
