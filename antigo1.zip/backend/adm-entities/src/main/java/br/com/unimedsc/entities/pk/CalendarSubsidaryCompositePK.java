package br.com.unimedsc.entities.pk;

import java.util.Calendar;

import javax.persistence.Column;

public class CalendarSubsidaryCompositePK<TID> extends SubsidiaryCompositePK<TID> {

	private static final long serialVersionUID = -1307317940484458483L;

	private Long calendarId;

	private Calendar date;

	@Column(name = "COD_CALEND")
	public Long getCalendarId() {
		return calendarId;
	}

	public void setCalendarId(Long calendarId) {
		this.calendarId = calendarId;
	}

	@Column(name = "DAT_CALEND")
	public Calendar getDate() {
		return date;
	}

	public void setDate(Calendar date) {
		this.date = date;
	}

	@Override
	@Column(name = "COD_FILIAL")
	public Long getSubsidiaryId() {
		return super.getSubsidiaryId();
	}

	@Override
	@Column(name = "COD_EMP")
	public Long getEnterpriseId() {
		return super.getEnterpriseId();
	}

	@Override
	@Column(name = "COD")
	public TID getId() {
		return super.id;
	}
}
