package br.com.unimedsc.entities.pk;

import javax.persistence.Column;

public class SearchCompositePK<T> extends PanelCompositePK<T> {

	private static final long serialVersionUID = 8021942653908341451L;

	private Long searchId;
	
	@Column(name = "COD_PESQSA")
	public Long getSearchId() {
		return searchId;
	}

	public void setSearchId(Long searchId) {
		this.searchId = searchId;
	}

	@Override
	@Column(name = "COD_PAINEL")
	public Long getPanelId() {
		return super.getPanelId();
	}

	@Override
	@Column(name = "COD_EMP")
	public Long getEnterpriseId() {
		return super.getEnterpriseId();
	}

	@Override
	@Column(name = "COD")
	public T getId() {
		return super.getId();
	}

}
