package br.com.unimedsc.entities.adm;

import javax.persistence.AttributeOverride;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

import br.com.unimedsc.core.annotation.GenerateKey;
import br.com.unimedsc.core.entity.EntityAbstract;
import br.com.unimedsc.core.entity.pk.CompositeEnterprisePK;
import br.com.unimedsc.core.utils.DatabaseDefinition;

@Entity
@Table(name = DatabaseDefinition.TABLE_PREFIX_ADM + "_PARAMETRO_EMPRESA")
@AttributeOverride(name = "pk.id", column = @Column(name = "COD_PARAM"))
@GenerateKey(sequence = "S_TADM0020")
public class ParameterEnterprise extends EntityAbstract<String, CompositeEnterprisePK<String>> {

	private String valueParam;
	
	@EmbeddedId
	public CompositeEnterprisePK<String> getPk() {
		return super.getPk();
	}

	@Column(name ="VAL_PARAM")
	public String getValueParam() {
		return valueParam;
	}

	public void setValueParam(String valueParam) {
		this.valueParam = valueParam;
	}
	
}
