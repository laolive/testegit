package br.com.unimedsc.entities.adm;

import br.com.unimedsc.core.annotation.GenerateKey;
import br.com.unimedsc.core.entity.EntityAbstract;
import br.com.unimedsc.core.utils.DatabaseDefinition;
import br.com.unimedsc.entities.pk.CalendarSubsidaryCompositePK;

import javax.persistence.*;
import java.util.Calendar;

@Entity
@Table(name = DatabaseDefinition.TABLE_PREFIX_ADM + "_CALENDARIO_FILIAL")
@AttributeOverride(name = "pk.id", column = @Column(name = "COD_MODULO"))
@GenerateKey(sequence = "S_TADM0018")
public class CalendarDateSubsidiary extends EntityAbstract<Calendar, CalendarSubsidaryCompositePK<Calendar>> {

	private CalendarDate calendarDate;

	private String domainUtilDay;

	private String observation;

	@EmbeddedId
	public CalendarSubsidaryCompositePK<Calendar> getPk() {
		return super.getPk();
	}

	@ManyToOne
	@JoinColumns({
			@JoinColumn(name = "COD_EMP", referencedColumnName = "COD_EMP", insertable = false, updatable = false),
			@JoinColumn(name = "COD_CALEND", referencedColumnName = "COD_CALEND", insertable = false, updatable = false),
			@JoinColumn(name = "DAT_CALEND", referencedColumnName = "DAT_CALEND", insertable = false, updatable = false) })
	public CalendarDate getCalendarDate() {
		return calendarDate;
	}

	public void setCalendarDate(CalendarDate calendarDate) {
		this.calendarDate = calendarDate;
	}

	/**
	 * @return Dia útil: India se a data representa um dia útil | FLAG
	 */
	@Column(name = "FLG_DIA_UTIL")
	public String getDomainUtilDay() {
		return domainUtilDay;
	}

	public void setDomainUtilDay(String domainUtilDay) {
		this.domainUtilDay = domainUtilDay;
	}

	/**
	 * @return Observação: Observações relacionadas a data
	 */
	@Column(name = "DES_OBS")
	public String getObservation() {
		return observation;
	}

	public void setObservation(String observation) {
		this.observation = observation;
	}

}
