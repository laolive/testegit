package br.com.unimedsc.entities.vo;

import java.util.Calendar;

public class HolidayReturnVO {

    private Calendar holidayDate;

    public HolidayReturnVO(Calendar holidayDate) {
        this.holidayDate = holidayDate;
    }

    public Calendar getHolidayDate() {
        return holidayDate;
    }

    public void setHolidayDate(Calendar holidayDate) {
        this.holidayDate = holidayDate;
    }
}
