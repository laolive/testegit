package br.com.unimedsc.entities.adm;

import javax.persistence.AttributeOverride;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import br.com.unimedsc.core.annotation.DefaultLoginReturn;
import br.com.unimedsc.core.annotation.GenerateKey;
import br.com.unimedsc.core.entity.EntityAbstract;
import br.com.unimedsc.core.utils.DatabaseDefinition;
import br.com.unimedsc.entities.erp.Menu;
import br.com.unimedsc.entities.pk.MenuCompositePK;

@Entity
@Table(name = DatabaseDefinition.TABLE_PREFIX_ADM + "_USUARIO_MENU")
@AttributeOverride(name = "pk.id", column = @Column(name = "COD_USU"))
@JsonIgnoreProperties({"user"})
@DefaultLoginReturn
@GenerateKey(sequence = "S_TADM0007")
public class UserMenu extends EntityAbstract<Long, MenuCompositePK<Long>> {

    private Menu menu;

    private User user;

    @EmbeddedId
    public MenuCompositePK<Long> getPk() {
        return super.getPk();
    }

    @ManyToOne
    @JoinColumn(name = "COD_MENU", referencedColumnName = "COD_MENU", insertable = false, updatable = false)
    public Menu getMenu() {
        return menu;
    }

    public void setMenu(Menu menu) {
        this.menu = menu;
    }

    @ManyToOne
    @JoinColumn(name = "COD_USU", referencedColumnName = "COD_USU", insertable = false, updatable = false)
    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }
}
