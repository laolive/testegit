package br.com.unimedsc.entities.erp;

import javax.persistence.AttributeOverride;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnore;

import br.com.unimedsc.core.entity.EntityAbstract;
import br.com.unimedsc.core.utils.DatabaseDefinition;
import br.com.unimedsc.entities.pk.ProcessCompositePK;

@Entity
@Table(name = DatabaseDefinition.TABLE_PREFIX_ERP + "_PROCESSO_OPCAO")
@AttributeOverride(name = "pk.id", column = @Column(name = "COD_OPCAO"))
public class ProcessOption extends EntityAbstract<Long, ProcessCompositePK<Long>> {

	private static final long serialVersionUID = 6887407626395633320L;

	private Process process;

	private RoutineOption routineOption;

	private String description;

	private String paramValue;

	@EmbeddedId
	public ProcessCompositePK<Long> getPk() {
		return super.getPk();
	}

	@JsonBackReference
	@ManyToOne
	@JoinColumn(name = "COD_PRCSSO", referencedColumnName = "COD_PRCSSO", insertable = false, updatable = false)
	public Process getProcess() {
		return process;
	}

	public void setProcess(Process process) {
		this.process = process;
	}

	@ManyToOne
	@JoinColumns({
			@JoinColumn(name = "COD_ROTINA", referencedColumnName = "COD_ROTINA", insertable = false, updatable = false),
			@JoinColumn(name = "COD_OPCAO", referencedColumnName = "COD_OPCAO", insertable = false, updatable = false) })
	public RoutineOption getRoutineOption() {
		return routineOption;
	}

	public void setRoutineOption(RoutineOption routineOption) {
		this.routineOption = routineOption;
	}

	@JsonIgnore
	@Column(name = "COD_ROTINA")
	public Long getCodRoutine() {
		if (this.routineOption == null)
			return null;
		return this.routineOption.getPk().getRoutineId();
	}

	public void setCodRoutine(Long codRoutine) {
	}

	/**
	 * @return Label: Label (texto) apresentada para identificar a opção do
	 *         processo
	 */
	@Column(name = "DES_LABEL")
	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * @return Valor: Valor da opção utilizado no agendamento do processo
	 */
	@Column(name = "VAL_PARAM")
	public String getParamValue() {
		return paramValue;
	}

	public void setParamValue(String paramValue) {
		this.paramValue = paramValue;
	}

}
