package br.com.unimedsc.entities.pk;

import javax.persistence.Column;

import br.com.unimedsc.core.entity.pk.SimplePK;

public class TransactionCompositePK<TID> extends SimplePK<TID> {

    private static final long serialVersionUID = 2217664156289687217L;

    private Long transactionId;

    @Column(name = "COD_TRANSC")
    public Long getTransactionId() {
	return transactionId;
    }

    public void setTransactionId(Long transactionId) {
	this.transactionId = transactionId;
    }

    @Override
    @Column(name = "COD")
    public TID getId() {
	return super.id;
    }

}
