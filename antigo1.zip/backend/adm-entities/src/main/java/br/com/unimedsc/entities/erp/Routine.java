package br.com.unimedsc.entities.erp;

import javax.persistence.AttributeOverride;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import br.com.unimedsc.core.entity.EntityAbstract;
import br.com.unimedsc.core.entity.pk.SimplePK;
import br.com.unimedsc.core.utils.DatabaseDefinition;
import br.com.unimedsc.entities.adm.QueueRoutine;

@Entity
@Table(name = DatabaseDefinition.TABLE_PREFIX_ERP + "_ROTINA")
@AttributeOverride(name = "pk.id", column = @Column(name = "COD_ROTINA"))
public class Routine extends EntityAbstract<Long, SimplePK<Long>> {

	private static final long serialVersionUID = -6347938173050696984L;

	private String routineDescription;

	private String procedureName;

	private String obs;

	private RoutineSQL routineSQL;

	private QueueRoutine queueRoutine;

	@EmbeddedId
	@Override
	public SimplePK<Long> getPk() {
		return super.getPk();
	}

	/**
	 * @return Descrição: Descrição da rotina
	 */
	@Column(name = "DES_ROTINA")
	public String getRoutineDescription() {
		return routineDescription;
	}

	public void setRoutineDescription(String routineDescription) {
		this.routineDescription = routineDescription;
	}

	/**
	 * @return Procedure: Nome da procedure da base de dados a ser executada
	 */
	@Column(name = "NOM_PRC_BCO_DADOS")
	public String getProcedureName() {
		return procedureName;
	}

	public void setProcedureName(String procedureName) {
		this.procedureName = procedureName;
	}

	/**
	 * @return Observação: Observação sobre a utilidade da rotina
	 */
	@Column(name = "DES_OBS")
	public String getObs() {
		return obs;
	}

	public void setObs(String obs) {
		this.obs = obs;
	}

	@OneToOne
	@JoinColumn(name = "COD_ROTINA", referencedColumnName = "COD_ROTINA", insertable = false, updatable = false)
	public RoutineSQL getRoutineSQL() {
		return routineSQL;
	}

	public void setRoutineSQL(RoutineSQL routineSQL) {
		this.routineSQL = routineSQL;
	}

	@OneToOne(mappedBy = "routine")
	public QueueRoutine getQueueRoutine() {
		return queueRoutine;
	}

	public void setQueueRoutine(QueueRoutine queueRoutine) {
		this.queueRoutine = queueRoutine;
	}

}
