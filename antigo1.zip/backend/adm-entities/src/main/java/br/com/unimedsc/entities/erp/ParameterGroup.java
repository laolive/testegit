package br.com.unimedsc.entities.erp;

import java.util.Calendar;

import javax.persistence.AttributeOverride;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;

import br.com.unimedsc.core.entity.EntityAbstract;
import br.com.unimedsc.core.entity.pk.SimplePK;
import br.com.unimedsc.core.utils.DatabaseDefinition;

@Entity
@Table(name = DatabaseDefinition.TABLE_PREFIX_ERP + "_GRUPO_PARAMETRO")
@AttributeOverride(name = "pk.id", column = @Column(name = "COD_GRUPO"))
@JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class, property = "pk")
public class ParameterGroup extends EntityAbstract<String, SimplePK<String>> {

	private static final long serialVersionUID = -7857025427701400771L;

	private String groupName;

	private Module module;

	private ParameterGroup parent;

	private Calendar inactivityDate;

	@EmbeddedId
	public SimplePK<String> getPk() {
		return super.getPk();
	}

	/**
	 * @return Descrição: Descrição do grupo de parâmetros
	 */
	@Column(name = "DES_GRUPO")
	public String getGroupName() {
		return groupName;
	}

	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	/**
	 * @return Módulo: Código do Módulo ao qual o Grupo de Parâmetros esta
	 *         relacionado
	 */
	@ManyToOne
	@JoinColumn(name = "COD_MODULO", referencedColumnName = "COD_MODULO")
	public Module getModule() {
		return module;
	}

	public void setModule(Module module) {
		this.module = module;
	}

	/**
	 * @return Grupo Pai: Código do Grupo Superior
	 */
	@ManyToOne
	@JoinColumn(name = "COD_GRUPO_SUP", referencedColumnName = "COD_GRUPO")
	public ParameterGroup getParent() {
		return parent;
	}

	public void setParent(ParameterGroup parent) {
		this.parent = parent;
	}

	/**
	 * @return Data da inativação: Informa a data em que o grupo de parâmetros foi
	 *         desativado
	 */
	@Column(name = "DAT_INATIV")
	public Calendar getInactivityDate() {
		return inactivityDate;
	}

	public void setInactivityDate(Calendar inactivityDate) {
		this.inactivityDate = inactivityDate;
	}

}
