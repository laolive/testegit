package br.com.unimedsc.entities.adm;

import br.com.unimedsc.core.annotation.DefaultEntityReturn;
import br.com.unimedsc.core.entity.EntityAbstract;
import br.com.unimedsc.core.entity.pk.SimplePK;

import javax.persistence.*;

@Entity
@AttributeOverride(name = "pk.id", column = @Column(name = "COD_LABEL"))
public class EntityLabels extends EntityAbstract<Long, SimplePK<Long>> {
	
	@DefaultEntityReturn
	private String tableName;
	
	@DefaultEntityReturn
	private String columnName;
	
	@DefaultEntityReturn
	private String descLabel;
	
	private String descTip;
	
	private String paramCode;
	
	private String tableLabel;
	
	private Long columnPrecision;
	
	private Long columnScale;
	
	@Override
	@EmbeddedId
	public SimplePK<Long> getPk() {
		return super.getPk();
	}

	@Override
	@PrePersist
	public void prePersist() {
		super.prePersist();
	}

	@Column(name = "NOM_TABELA")
	public String getTableName() {
		return tableName;
	}

	public void setTableName(String tableName) {
		this.tableName = tableName;
	}

	@Column(name = "NOM_COLUNA")
	public String getColumnName() {
		return columnName;
	}

	public void setColumnName(String columnName) {
		this.columnName = columnName;
	}

	@Column(name = "DES_LABEL")
	public String getDescLabel() {
		return descLabel;
	}

	public void setDescLabel(String descLabel) {
		this.descLabel = descLabel;
	}

	@Column(name = "DES_DICA")
	public String getDescTip() {
		return descTip;
	}

	public void setDescTip(String descTip) {
		this.descTip = descTip;
	}

	@Column(name = "COD_PARAM_DM")
	public String getParamCode() {
		return paramCode;
	}

	public void setParamCode(String paramCode) {
		this.paramCode = paramCode;
	}

	@Column(name = "TABLE_LABEL")
	public String getTableLabel() {
		return tableLabel;
	}

	public void setTableLabel(String tableLabel) {
		this.tableLabel = tableLabel;
	}

	@Column(name = "COLUNA_TAMANHO")
	public Long getColumnPrecision() {
		return columnPrecision;
	}

	public void setColumnPrecision(Long columnPrecision) {
		this.columnPrecision = columnPrecision;
	}

	@Column(name = "COLUNA_PRECISAO")
	public Long getColumnScale() {
		return columnScale;
	}

	public void setColumnScale(Long columnScale) {
		this.columnScale = columnScale;
	}	

}
