package br.com.unimedsc.entities.erp;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

import br.com.unimedsc.core.entity.EntityAbstract;
import br.com.unimedsc.core.entity.pk.SimplePK;
import br.com.unimedsc.core.utils.DatabaseDefinition;

@Entity
@Table(name = DatabaseDefinition.TABLE_PREFIX_ERP + "_TABELA_SISTEMA_COLUNA")
public class TableSystemColumn extends EntityAbstract<Long, SimplePK<Long>> {

	private static final long serialVersionUID = 7498715147034131617L;

	private String tableName;

	private String descriptionLabel;

	private String useTip;

	private String nameDomain;

	@EmbeddedId
	public SimplePK<Long> getPk() {
		return super.getPk();
	}

	/**
	 * @return Nome da tabela.
	 */
	@Column(name = "NOM_TABELA")
	public String getTableName() {
		return tableName;
	}

	/**
	 * @return Label a ser utilizado no campo que referência a coluna da tabela
	 */
	@Column(name = "DES_LABEL")
	public String getDescriptionLabel() {
		return descriptionLabel;
	}

	/**
	 * @return Duca de utilização ou preenchimento do campo que referência a coluna.
	 */
	@Column(name = "DES_DICA")
	public String getUseTip() {
		return useTip;
	}

	/**
	 * @return Nome do domínio utilizado pela coluna.
	 */
	@Column(name = "COD_PARAM")
	public String getNameDomain() {
		return nameDomain;
	}

	public void setTableName(String tableName) {
		this.tableName = tableName;
	}

	public void setDescriptionLabel(String descriptionLabel) {
		this.descriptionLabel = descriptionLabel;
	}

	public void setUseTip(String useTip) {
		this.useTip = useTip;
	}

	public void setNameDomain(String nameDomain) {
		this.nameDomain = nameDomain;
	}

}
