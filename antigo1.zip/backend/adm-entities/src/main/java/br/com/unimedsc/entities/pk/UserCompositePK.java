package br.com.unimedsc.entities.pk;

import javax.persistence.Column;

import br.com.unimedsc.core.entity.pk.SimplePK;

public class UserCompositePK<TID> extends SimplePK<TID> {

	private static final long serialVersionUID = 2217664156289687217L;

	private Long userId;

	@Column(name = "COD_USU")
	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	@Override
	@Column(name = "COD")
	public TID getId() {
		return super.id;
	}

}
