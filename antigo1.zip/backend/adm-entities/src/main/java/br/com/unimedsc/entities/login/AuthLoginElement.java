package br.com.unimedsc.entities.login;

import java.io.Serializable;

public class AuthLoginElement implements Serializable {

	private static final long serialVersionUID = -7295601275040480124L;

	private String userName;

	private String password;

	public AuthLoginElement() {
 		this(null,null);
 	}
	
	public AuthLoginElement(String userName, String password) {
		this.userName = userName;
		this.password = password;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
}