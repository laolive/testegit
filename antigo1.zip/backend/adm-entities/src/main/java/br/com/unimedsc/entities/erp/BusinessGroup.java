package br.com.unimedsc.entities.erp;

import javax.persistence.AttributeOverride;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

import br.com.unimedsc.core.entity.EntityAbstract;
import br.com.unimedsc.core.entity.pk.SimplePK;
import br.com.unimedsc.core.utils.DatabaseDefinition;

@Entity
@Table(name = DatabaseDefinition.TABLE_PREFIX_ERP + "_GRUPO_EMPRESARIAL")
@AttributeOverride(name = "pk.id", column = @Column(name = "COD_GRUPO_EMPRSL"))
public class BusinessGroup extends EntityAbstract<Long, SimplePK<Long>> {

	private static final long serialVersionUID = 7839817948580170508L;

	private String nameBusinessGroup;

	private String loginPrefix;

	@EmbeddedId
	public SimplePK<Long> getPk() {
		return super.getPk();
	}

	/**
	 * @return Nome: Nome do grupo de empresas
	 */
	@Column(name = "NOM_GRUPO_EMPRSL")
	public String getNameBusinessGroup() {
		return nameBusinessGroup;
	}

	public void setNameBusinessGroup(String nameBusinessGroup) {
		this.nameBusinessGroup = nameBusinessGroup;
	}

	/**
	 * Método para recuperar o prefixo do login
	 * 
	 * @return Retorna o prefixo do login
	 */
	@Column(name = "DES_PREFIX_LOGIN_USU")
	public String getLoginPrefix() {
		return loginPrefix;
	}

	public void setLoginPrefix(String loginPrefix) {
		this.loginPrefix = loginPrefix;
	}

}
