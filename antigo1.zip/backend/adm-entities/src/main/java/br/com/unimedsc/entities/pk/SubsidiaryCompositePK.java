package br.com.unimedsc.entities.pk;

import javax.persistence.Column;

import br.com.unimedsc.core.entity.pk.CompositeEnterprisePK;

public class SubsidiaryCompositePK<T> extends CompositeEnterprisePK<T> {

    private static final long serialVersionUID = -4568275748237285966L;

    private Long subsidiaryId;

	@Column(name = "COD_FILIAL")
    public Long getSubsidiaryId() {
		return subsidiaryId;
	}

	public void setSubsidiaryId(Long subsidiaryId) {
		this.subsidiaryId = subsidiaryId;
	}

	@Override
    @Column(name = "COD_EMP")
    public Long getEnterpriseId() {
	return super.enterpriseId;
    }

    @Override
    @Column(name = "COD")
    public T getId() {
	return super.id;
    }

}
