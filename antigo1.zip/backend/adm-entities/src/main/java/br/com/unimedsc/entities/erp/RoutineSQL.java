package br.com.unimedsc.entities.erp;

import javax.persistence.AttributeOverride;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import br.com.unimedsc.core.entity.EntityAbstract;
import br.com.unimedsc.core.entity.pk.SimplePK;
import br.com.unimedsc.core.utils.DatabaseDefinition;

@Entity
@Table(name = DatabaseDefinition.TABLE_PREFIX_ERP + "_ROTINA_SQL")
@AttributeOverride(name = "pk.id", column = @Column(name = "COD_ROTINA"))
public class RoutineSQL extends EntityAbstract<Long, SimplePK<Long>> {

	private static final long serialVersionUID = -957332243462324226L;

	private String command;

	private String domainHeaderCriationType;

	private String tittle;

	private String delimitChar;

	private String separatorChar;

	private Path path;

	@EmbeddedId
	@Override
	public SimplePK<Long> getPk() {
		return super.getPk();
	}

	/**
	 * @return Descrição: Descrição da rotina
	 */
	@Column(name = "DES_COMNDO")
	public String getCommand() {
		return command;
	}

	public void setCommand(String command) {
		this.command = command;
	}

	/**
	 * @return Cabeçalho: Informa sobre a utilização do cabeçalho e suas informações
	 *         | FORMA_GERACAO_CABECALHO
	 */
	@Column(name = "IND_FORMA_GRCAO_CABLH")
	public String getDomainHeaderCriationType() {
		return domainHeaderCriationType;
	}

	public void setDomainHeaderCriationType(String domainHeaderCriationType) {
		this.domainHeaderCriationType = domainHeaderCriationType;
	}

	/**
	 * @return Título: Informa o título a ser apresentado no cabeçalho da listagem
	 */
	@Column(name = "DES_TITULO")
	public String getTittle() {
		return tittle;
	}

	public void setTittle(String tittle) {
		this.tittle = tittle;
	}

	/**
	 * @return Delimitador: Caractere que determina os limites das informações
	 */
	@Column(name = "DES_CRCTRE_DLIMIT")
	public String getDelimitChar() {
		return delimitChar;
	}

	public void setDelimitChar(String delimitChar) {
		this.delimitChar = delimitChar;
	}

	/**
	 * @return Separador: Caracter utilizado para separar as informações
	 */
	@Column(name = "DES_CRCTRE_SEP")
	public String getSeparatorChar() {
		return separatorChar;
	}

	public void setSeparatorChar(String separatorChar) {
		this.separatorChar = separatorChar;
	}

	/**
	 * @return Nome do diretório: Nome que identifica o diretório de localização do
	 *         arquivo
	 */
	@ManyToOne
	@JoinColumn(name = "NOM_DIR", referencedColumnName = "NOM_DIR")
	public Path getPath() {
		return path;
	}

	public void setPath(Path path) {
		this.path = path;
	}

}
