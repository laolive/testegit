package br.com.unimedsc.entities.adm;

import br.com.unimedsc.core.annotation.GenerateKey;
import br.com.unimedsc.core.entity.EntityAbstract;
import br.com.unimedsc.core.utils.DatabaseDefinition;
import br.com.unimedsc.entities.pk.AccessGroupTransactionCompositePK;

import javax.persistence.*;

@Entity
@Table(name = DatabaseDefinition.TABLE_PREFIX_ADM + "_GRUPO_ACESSO_CAMPO")
@AttributeOverride(name = "pk.id", column = @Column(name = "NOM_CAMPO"))
@GenerateKey(sequence = "S_TADM0008")
public class AccessGroupField extends EntityAbstract<String, AccessGroupTransactionCompositePK<String>> {

	private String domainView;

	private String domainUpdate;

	private String defaultValue;

	@EmbeddedId
	public AccessGroupTransactionCompositePK<String> getPk() {
		return super.getPk();
	}

	/**
	 * @return Inclusão: Informa se o perfil possui permissão de inclusão na
	 *         transação | FLAG
	 */
	@Column(name = "FLG_INCL")
	public String getDomainView() {
		return domainView;
	}

	public void setDomainView(String domainView) {
		this.domainView = domainView;
	}

	/**
	 * @return Alteração: Informa se o perfil possui permissão de alteração na
	 *         transação | FLAG
	 */
	@Column(name = "FLG_ALT")
	public String getDomainUpdate() {
		return domainUpdate;
	}

	public void setDomainUpdate(String domainUpdate) {
		this.domainUpdate = domainUpdate;
	}

	@Column(name = "VAL_PADRAO")
	public String getDefaultValue() {
		return defaultValue;
	}

	public void setDefaultValue(String defaultValue) {
		this.defaultValue = defaultValue;
	}

}
