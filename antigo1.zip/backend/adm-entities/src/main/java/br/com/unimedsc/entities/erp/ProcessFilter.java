package br.com.unimedsc.entities.erp;

import javax.persistence.AttributeOverride;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnore;

import br.com.unimedsc.core.entity.EntityAbstract;
import br.com.unimedsc.core.utils.DatabaseDefinition;
import br.com.unimedsc.entities.pk.ProcessCompositePK;

@Entity
@Table(name = DatabaseDefinition.TABLE_PREFIX_ERP + "_PROCESSO_FILTRO")
@AttributeOverride(name = "pk.id", column = @Column(name = "COD_FILTRO"))
public class ProcessFilter extends EntityAbstract<Long, ProcessCompositePK<Long>> {

	private static final long serialVersionUID = -8750997415404016144L;

	private Process process;

	private RoutineFilter routineFilter;

	private String label;

	private String parameterValue;

	@EmbeddedId
	@Override
	public ProcessCompositePK<Long> getPk() {
		return super.getPk();
	}

	@JsonBackReference
	@ManyToOne
	@JoinColumn(name = "COD_PRCSSO", referencedColumnName = "COD_PRCSSO", insertable = false, updatable = false)
	public Process getProcess() {
		return process;
	}

	public void setProcess(Process process) {
		this.process = process;
	}

	@ManyToOne
	@JoinColumns({
			@JoinColumn(name = "COD_ROTINA", referencedColumnName = "COD_ROTINA", insertable = false, updatable = false),
			@JoinColumn(name = "COD_FILTRO", referencedColumnName = "COD_FILTRO", insertable = false, updatable = false) })
	public RoutineFilter getRoutineFilter() {
		return routineFilter;
	}

	public void setRoutineFilter(RoutineFilter routineFilter) {
		this.routineFilter = routineFilter;
	}

	@JsonIgnore
	@Column(name = "COD_ROTINA")
	public Long getCodRoutine() {
		if (this.routineFilter == null)
			return null;
		return this.routineFilter.getPk().getRoutineId();
	}

	public void setCodRoutine(Long codRoutine) {
	}

	/**
	 * @return Label: Label (texto) apresentada para identificar o filtro do processo
	 */
	@Column(name = "DES_LABEL")
	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}

	/**
	 * @return Valor: Valor do filtro utilizado no agendamento do processo
	 */
	@Column(name = "VAL_PARAM")
	public String getParameterValue() {
		return parameterValue;
	}

	public void setParameterValue(String parameterValue) {
		this.parameterValue = parameterValue;
	}

}
