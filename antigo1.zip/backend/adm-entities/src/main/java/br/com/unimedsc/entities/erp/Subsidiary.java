package br.com.unimedsc.entities.erp;

import java.util.Calendar;

import javax.persistence.AttributeOverride;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import br.com.unimedsc.core.annotation.DefaultLoginReturn;
import br.com.unimedsc.core.entity.EntityAbstract;
import br.com.unimedsc.core.entity.pk.CompositeEnterprisePK;
import br.com.unimedsc.core.utils.DatabaseDefinition;

@Entity
@Table(name = DatabaseDefinition.TABLE_PREFIX_ERP + "_EMPRESA_FILIAL")
@AttributeOverride(name = "pk.id", column = @Column(name = "COD_FILIAL"))
@DefaultLoginReturn
public class Subsidiary extends EntityAbstract<Long, CompositeEnterprisePK<Long>> {

	private static final long serialVersionUID = 874676361354362284L;

	private String subsidiaryName;

	private Calendar dateInactivation;

	private Enterprise enterprise;

	@EmbeddedId
	public CompositeEnterprisePK<Long> getPk() {
		return super.getPk();
	}

	/**
	 * @return Nome da filial: Nome da filial para apresentação no sistema
	 */
	@Column(name = "NOM_FILIAL_APRSTR")
	public String getSubsidiaryName() {
		return subsidiaryName;
	}

	public void setSubsidiaryName(String subsidiaryName) {
		this.subsidiaryName = subsidiaryName;
	}

	/**
	 * @return Data da inativação: Data da inativação da filial
	 */
	@Column(name = "DAT_INATIV")
	public Calendar getDateInactivation() {
		return dateInactivation;
	}

	public void setDateInactivation(Calendar dateInactivation) {
		this.dateInactivation = dateInactivation;
	}

	@ManyToOne
	@JoinColumn(name = "COD_EMP", referencedColumnName = "COD_EMP", insertable = false, updatable = false)
	public Enterprise getEnterprise() {
		return enterprise;
	}

	public void setEnterprise(Enterprise enterprise) {
		this.enterprise = enterprise;
	}

}