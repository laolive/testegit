package br.com.unimedsc.entities.adm;

import br.com.unimedsc.core.annotation.GenerateKey;
import br.com.unimedsc.core.entity.EntityAbstract;
import br.com.unimedsc.core.utils.DatabaseDefinition;
import br.com.unimedsc.entities.pk.CalendarCompositePK;

import javax.persistence.*;
import java.util.Calendar;

@Entity
@Table(name = DatabaseDefinition.TABLE_PREFIX_ADM + "_CALENDARIO")
@AttributeOverride(name = "pk.id", column = @Column(name = "DAT_CALEND"))
@GenerateKey(sequence = "S_TADM0017")
public class CalendarDate extends EntityAbstract<Calendar, CalendarCompositePK<Calendar>> {

	private Calendar date;

	private String domainUtilDay;

	@EmbeddedId
	public CalendarCompositePK<Calendar> getPk() {
		return super.getPk();
	}

	/**
	 * @return Data: Data do calendário
	 */
	@Column(name = "DAT_CALEND", insertable = false, updatable = false)
	public Calendar getDate() {
		return date;
	}

	public void setDate(Calendar date) {
		this.date = date;
	}

	/**
	 * @return Dia útil: India se a data representa um dia útil | FLAG
	 */
	@Column(name = "FLG_DIA_UTIL")
	public String getDomainUtilDay() {
		return domainUtilDay;
	}

	public void setDomainUtilDay(String domainUtilDay) {
		this.domainUtilDay = domainUtilDay;
	}

}
