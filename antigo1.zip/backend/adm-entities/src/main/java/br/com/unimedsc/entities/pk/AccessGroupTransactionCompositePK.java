package br.com.unimedsc.entities.pk;

import javax.persistence.Column;

public class AccessGroupTransactionCompositePK<TID> extends AccessGroupCompositePK<TID> {

    private static final long serialVersionUID = 2217664156289687217L;

    private Long transactionId;
    private Long accessGroupId;

    @Column(name = "COD_TRANSC")
    public Long getTransactionId() {
	return transactionId;
    }

    public void setTransactionId(Long transactionId) {
	this.transactionId = transactionId;
    }

    @Override
    @Column(name = "COD_GRUPO_ACESSO")
    public Long getAccessGroupId() {
	return accessGroupId;
    }

    @Override
    @Column(name = "COD_EMP")
    public Long getEnterpriseId() {
	return super.getEnterpriseId();
    }

    @Override
    @Column(name = "COD")
    public TID getId() {
	return super.id;
    }

}
