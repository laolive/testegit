package br.com.unimedsc.entities.pk;

import javax.persistence.Column;

public class UserParameterCompositePK<TID> extends UserCompositePK<TID> {
	private static final long serialVersionUID = 3847589456860004295L;
	
	private Long enterpriseId;

	@Column(name = "COD_EMP")
	public Long getEnterpriseId() {
		return enterpriseId;
	}

	public void setEnterpriseId(Long enterpriseId) {
		this.enterpriseId = enterpriseId;
	}

	@Override
    @Column(name = "COD_USU")
    public Long getUserId() {
	return super.getUserId();
    }

    @Override
    @Column(name = "COD")
    public TID getId() {
	return super.id;
    }
	
	

}
