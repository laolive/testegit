package br.com.unimedsc.entities.adm;

import java.util.Calendar;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;

import br.com.unimedsc.core.entity.EntityAbstract;
import br.com.unimedsc.entities.pk.DominioDeParaPK;

@Entity
@AttributeOverrides({ @AttributeOverride(name = "pk.id", column = @Column(name = "DOMINIO_ID_DE")),
    @AttributeOverride(name = "pk.dominioItemIdDe", column = @Column(name = "DOMINIO_ITEM_ID_DE")),
    @AttributeOverride(name = "pk.dominioIdPara", column = @Column(name = "DOMINIO_ID_PARA")),
    @AttributeOverride(name = "pk.dominioItemIdPara", column = @Column(name = "DOMINIO_ITEM_ID_PARA"))})
public class DominioDePara extends EntityAbstract<Long, DominioDeParaPK<Long,Long,Long,Long>> {

    private Calendar dataInicioVigencia;

    private Calendar dataFimVigencia;

    @EmbeddedId
    public DominioDeParaPK<Long,Long,Long,Long> getPk() {
        return super.getPk();
    }

	public Calendar getDataInicioVigencia() {
		return dataInicioVigencia;
	}

	public void setDataInicioVigencia(Calendar dataInicioVigencia) {
		this.dataInicioVigencia = dataInicioVigencia;
	}

	public Calendar getDataFimVigencia() {
		return dataFimVigencia;
	}

	public void setDataFimVigencia(Calendar dataFimVigencia) {
		this.dataFimVigencia = dataFimVigencia;
	}

}
