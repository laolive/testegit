package br.com.unimedsc.entities.pk;

import java.util.Calendar;

import javax.persistence.Column;

public class CalendarUserCompositePK<TID> extends CalendarCompositePK<TID> {

	private static final long serialVersionUID = -2769703230985607599L;

	private Long userId;

	private Calendar date;

	@Column(name = "COD_USUARIO")
	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	@Column(name = "DAT_CALEND")
	public Calendar getDate() {
		return date;
	}

	public void setDate(Calendar date) {
		this.date = date;
	}

	@Override
	@Column(name = "COD_CALEND")
	public Long getCalendarId() {
		return super.getCalendarId();
	}

	@Override
	@Column(name = "COD_EMP")
	public Long getEnterpriseId() {
		return super.getEnterpriseId();
	}

	@Override
	@Column(name = "COD")
	public TID getId() {
		return super.id;
	}
}
