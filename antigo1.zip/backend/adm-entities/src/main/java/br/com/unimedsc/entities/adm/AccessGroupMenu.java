package br.com.unimedsc.entities.adm;

import br.com.unimedsc.core.annotation.DefaultLoginReturn;
import br.com.unimedsc.core.annotation.GenerateKey;
import br.com.unimedsc.core.entity.EntityAbstractEnterprise;
import br.com.unimedsc.core.utils.DatabaseDefinition;
import br.com.unimedsc.entities.erp.Menu;
import br.com.unimedsc.entities.pk.AccessGroupCompositePK;
import com.fasterxml.jackson.annotation.JsonBackReference;

import javax.persistence.*;

@Entity
@Table(name = DatabaseDefinition.TABLE_PREFIX_ADM + "_GRUPO_ACESSO_MENU")
@AttributeOverride(name = "pk.id", column = @Column(name = "COD_MENU"))
@DefaultLoginReturn
@GenerateKey(sequence = "S_TADM0006")
public class AccessGroupMenu extends EntityAbstractEnterprise<AccessGroupCompositePK<Long>> {

	private AccessGroup accessGroup;

	private Menu menu;

	@EmbeddedId
	public AccessGroupCompositePK<Long> getPk() {
		return super.getPk();
	}

	@ManyToOne
	@JoinColumns({
			@JoinColumn(name = "COD_EMP", referencedColumnName = "COD_EMP", insertable = false, updatable = false),
			@JoinColumn(name = "COD_GRUPO_ACESSO", referencedColumnName = "COD_GRUPO_ACESSO", insertable = false, updatable = false) })
	@JsonBackReference
	public AccessGroup getAccessGroup() {
		return accessGroup;
	}

	public void setAccessGroup(AccessGroup accessGroup) {
		this.accessGroup = accessGroup;
	}

	@ManyToOne
	@JoinColumn(name = "COD_MENU", referencedColumnName = "COD_MENU", insertable = false, updatable = false)
	public Menu getMenu() {
		return menu;
	}

	public void setMenu(Menu menu) {
		this.menu = menu;
	}

}
