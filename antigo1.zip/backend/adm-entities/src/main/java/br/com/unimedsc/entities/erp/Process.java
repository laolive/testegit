package br.com.unimedsc.entities.erp;

import java.util.Calendar;

import javax.persistence.AttributeOverride;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.PrePersist;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonIgnore;

import br.com.unimedsc.core.annotation.DefaultEntityReturn;
import br.com.unimedsc.core.annotation.GenerateKey;
import br.com.unimedsc.core.entity.EntityAbstract;
import br.com.unimedsc.core.entity.pk.SimplePK;
import br.com.unimedsc.core.utils.DatabaseDefinition;
import br.com.unimedsc.entities.adm.Queue;
import br.com.unimedsc.entities.adm.User;

@Entity
@Table(name = DatabaseDefinition.TABLE_PREFIX_ERP + "_PROCESSO")
@AttributeOverride(name = "pk.id", column = @Column(name = "COD_PRCSSO"))
@GenerateKey(sequence = "S_TERP0013")
public class Process extends EntityAbstract<Long, SimplePK<Long>> {

    private static final long serialVersionUID = 6859970910373491076L;
    
    private Enterprise enterprise;

    private Routine routine;

    private User userRequesting;

    private String domainSchedulingType;

    private String domainOpen;

    private Calendar dateRequested;

    private Calendar dateStartPreview;

    @DefaultEntityReturn
    private Calendar dateStartReal;

    @DefaultEntityReturn
    private Calendar dateEndReal;

    private Calendar dateCancel;

    private Queue queue;

    private Process processOriginal;

    private String domainArchive;

    private String domainAlert;

    private String domainError;

    private String domainSituation;
    
    @DefaultEntityReturn
    private Integer percentual;

    @EmbeddedId
    public SimplePK<Long> getPk() {
        return super.getPk();
    }
    
    @PrePersist
    public void prePersist() {
        super.prePersist();
    }
    
    /**
     * @return Empresa: Empresa do processo
     */
    @ManyToOne
    @JoinColumn(name = "COD_EMP", referencedColumnName = "COD_EMP")
    public Enterprise getEnterprise() {
        return enterprise;
    }

    public void setEnterprise(Enterprise enterprise) {
        this.enterprise = enterprise;
    }

    /**
     * @return Rotina: Rotina executada pelo processo
     */
    @ManyToOne
    @JoinColumn(name = "COD_ROTINA", referencedColumnName = "COD_ROTINA")
    public Routine getRoutine() {
        return routine;
    }

    public void setRoutine(Routine routine) {
        this.routine = routine;
    }

    /**
     * @return Usuário: Código do usuário que solicitou o agendamento do processo
     */
    @ManyToOne
    @JoinColumn(name = "COD_USU_SOLIC", referencedColumnName = "COD_USU")
    public User getUserRequesting() {
        return userRequesting;
    }

    public void setUserRequesting(User userRequesting) {
        this.userRequesting = userRequesting;
    }

    /**
     * @return Forma de geração: Forma de agendamento do processo |
     *         FORMA_AGENDAMENTO
     */
    @Column(name = "IND_FORMA_AGENDA")
    public String getDomainSchedulingType() {
        return domainSchedulingType;
    }

    public void setDomainSchedulingType(String domainSchedulingType) {
        this.domainSchedulingType = domainSchedulingType;
    }

    /**
     * @return Pendente: Informa se o agendamento está pendente de execução | FLAG
     */
    @Column(name = "FLG_PNTE")
    public String getDomainOpen() {
        return domainOpen;
    }

    public void setDomainOpen(String domainOpen) {
        this.domainOpen = domainOpen;
    }

    /**
     * @return Início previsto: Data/hora prevista para início da execução do
     *         processo
     */
    @Column(name = "DTH_SOLIC")
    public Calendar getDateRequested() {
        return dateRequested;
    }

    public void setDateRequested(Calendar dateRequested) {
        this.dateRequested = dateRequested;
    }

    /**
     * @return Início previsto: Data/hora prevista para início da execução do
     *         processo
     */
    @Column(name = "DTH_INIC_PREV")
    public Calendar getDateStartPreview() {
        return dateStartPreview;
    }

    public void setDateStartPreview(Calendar dateStartPreview) {
        this.dateStartPreview = dateStartPreview;
    }

    /**
     * @return Início real: Data/hora real do início da execução do processo
     */
    @Column(name = "DTH_INIC_REAL")
    public Calendar getDateStartReal() {
        return dateStartReal;
    }

    public void setDateStartReal(Calendar dateStartReal) {
        this.dateStartReal = dateStartReal;
    }

    /**
     * @return Fim real: Data/hora real do término da execução do processo
     */
    @Column(name = "DTH_FINAL_REAL")
    public Calendar getDateEndReal() {
        return dateEndReal;
    }

    public void setDateEndReal(Calendar dateEndReal) {
        this.dateEndReal = dateEndReal;
    }

    /**
     * @return Cancelamento em: Data/hora na qual o usuário solicitou o cancelamento
     *         do processo
     */
    @Column(name = "DTH_SOLIC_CANCEL")
    public Calendar getDateCancel() {
        return dateCancel;
    }

    public void setDateCancel(Calendar dateCancel) {
        this.dateCancel = dateCancel;
    }

    /**
     * @return Fila de execução: Código da fila de execução
     */
    @ManyToOne
    @JoinColumns({
            @JoinColumn(name = "COD_EMP", referencedColumnName = "COD_EMP", insertable = false, updatable = false),
            @JoinColumn(name = "COD_FILA", referencedColumnName = "COD_FILA", insertable = false, updatable = false) })
    public Queue getQueue() {
        return queue;
    }

    public void setQueue(Queue queue) {
        this.queue = queue;
    }
    
    @JsonIgnore
    @Column(name = "COD_FILA")
    public Long getQueueCod() {
        if (this.queue == null || this.queue.getPk() == null)
            return null;
        return this.queue.getPk().getId();
    }

    public void setQueueCod(Long queue) {
    }

    @ManyToOne
    @JoinColumn(name = "COD_PRCSSO_ORIG", referencedColumnName = "COD_PRCSSO")
    public Process getProcessOriginal() {
        return processOriginal;
    }

    public void setProcessOriginal(Process processOriginal) {
        this.processOriginal = processOriginal;
    }

    /**
     * @return Gerou arquivo: Informa se o processo gerou arquivo | FLAG
     */
    @Column(name = "FLG_ARQ")
    public String getDomainArchive() {
        return domainArchive;
    }

    public void setDomainArchive(String domainArchive) {
        this.domainArchive = domainArchive;
    }

    /**
     * @return Gerou aviso: Informa se o processo gerou aviso | FLAG
     */
    @Column(name = "FLG_AVISO")
    public String getDomainAlert() {
        return domainAlert;
    }

    public void setDomainAlert(String domainAlert) {
        this.domainAlert = domainAlert;
    }

    /**
     * @return Gerou erro: Informa se o processo gerou erro | FLAG
     */
    @Column(name = "FLG_ERRO")
    public String getDomainError() {
        return domainError;
    }

    public void setDomainError(String domainError) {
        this.domainError = domainError;
    }

    @Transient
    public String getDomainSituation() {
        return domainSituation;
    }

    public void setDomainSituation(String domainSituation) {
        this.domainSituation = domainSituation;
    }

    @Column(name = "VAL_PERCENT")
	public Integer getPercentual() {
		return percentual;
	}

	public void setPercentual(Integer percentual) {
		this.percentual = percentual;
	}
}
