package br.com.unimedsc.entities.adm;

import br.com.unimedsc.core.annotation.DefaultEntityReturn;
import br.com.unimedsc.core.annotation.DefaultLoginReturn;
import br.com.unimedsc.core.annotation.GenerateKey;
import br.com.unimedsc.core.entity.EntityAbstract;
import br.com.unimedsc.core.utils.DatabaseDefinition;
import br.com.unimedsc.entities.pk.UserParameterCompositePK;

import javax.persistence.*;

@Entity
@Table(name = DatabaseDefinition.TABLE_PREFIX_ADM + "_USUARIO_PARAMETRO")
@AttributeOverride(name = "pk.id", column = @Column(name = "COD_PARAM"))
@DefaultLoginReturn
@GenerateKey(sequence = "S_TADM0012")
public class UserParameter extends EntityAbstract<String, UserParameterCompositePK<String>> {

	@DefaultEntityReturn
	private String parameterValue;

	@EmbeddedId
	@Override
	public UserParameterCompositePK<String> getPk() {
		return super.getPk();
	}

	/**
	 * @return Valor: Valor do parâmetro para o perfil
	 */
	@Column(name = "VAL_PARAM")
	public String getParameterValue() {
		return parameterValue;
	}

	public void setParameterValue(String parameterValue) {
		this.parameterValue = parameterValue;
	}

}
