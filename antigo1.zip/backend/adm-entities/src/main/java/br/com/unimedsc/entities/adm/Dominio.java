package br.com.unimedsc.entities.adm;

import javax.persistence.AttributeOverride;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;

import br.com.unimedsc.core.annotation.DefaultEntityReturn;
import br.com.unimedsc.core.entity.EntityAbstract;
import br.com.unimedsc.core.entity.pk.SimplePK;

@Entity
@AttributeOverride(name = "pk.id", column = @Column(name = "ID"))
public class Dominio extends EntityAbstract<Integer, SimplePK<Integer>>{

    @DefaultEntityReturn
    private String nome;

    private String descricao;
    
    @EmbeddedId
    public SimplePK<Integer> getPk() {
        return super.getPk();
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }
}
