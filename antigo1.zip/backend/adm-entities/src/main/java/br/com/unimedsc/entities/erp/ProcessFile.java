package br.com.unimedsc.entities.erp;

import javax.persistence.AttributeOverride;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;

import br.com.unimedsc.core.entity.EntityAbstract;
import br.com.unimedsc.core.utils.DatabaseDefinition;
import br.com.unimedsc.entities.pk.ProcessCompositePK;

@Entity
@Table(name = DatabaseDefinition.TABLE_PREFIX_ERP + "_PROCESSO_ARQUIVO")
@AttributeOverride(name = "pk.id", column = @Column(name = "COD_ARQ"))
public class ProcessFile extends EntityAbstract<Long, ProcessCompositePK<Long>> {

	private static final long serialVersionUID = 5851250010979420491L;

	private Process process;

	private Archive archive;

	@EmbeddedId
	@Override
	public ProcessCompositePK<Long> getPk() {
		return super.getPk();
	}

	@JsonBackReference
	@ManyToOne
	@JoinColumn(name = "COD_PRCSSO", referencedColumnName = "COD_PRCSSO", insertable = false, updatable = false)
	public Process getProcess() {
		return process;
	}

	public void setProcess(Process process) {
		this.process = process;
	}

	@ManyToOne
	@JoinColumn(name = "COD_ARQ", referencedColumnName = "COD_ARQ", insertable = false, updatable = false)
	public Archive getArchive() {
		return archive;
	}

	public void setArchive(Archive archive) {
		this.archive = archive;
	}

}
