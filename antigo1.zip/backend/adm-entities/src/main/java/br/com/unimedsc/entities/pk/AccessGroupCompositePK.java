package br.com.unimedsc.entities.pk;

import javax.persistence.Column;

import br.com.unimedsc.core.entity.pk.CompositeEnterprisePK;

public class AccessGroupCompositePK<TID> extends CompositeEnterprisePK<TID> {

    private static final long serialVersionUID = 2217664156289687217L;

    private Long accessGroupId;

    @Column(name = "COD_GRUPO_ACESSO")
    public Long getAccessGroupId() {
	return accessGroupId;
    }

    public void setAccessGroupId(Long accessGroupId) {
	this.accessGroupId = accessGroupId;
    }

    @Override
    @Column(name = "COD_EMP")
    public Long getEnterpriseId() {
	return super.enterpriseId;
    }

    @Override
    @Column(name = "COD")
    public TID getId() {
	return super.id;
    }

}
