package br.com.unimedsc.entities.erp;

import javax.persistence.AttributeOverride;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;

import br.com.unimedsc.core.annotation.DefaultEntityReturn;
import br.com.unimedsc.core.entity.EntityAbstract;
import br.com.unimedsc.core.entity.pk.SimplePK;
import br.com.unimedsc.core.utils.DatabaseDefinition;

@Entity
@Table(name = DatabaseDefinition.TABLE_PREFIX_ERP + "_UNIMED")
@AttributeOverride(name = "pk.id", column = @Column(name = "COD_UNIMED"))
public class Unimed extends EntityAbstract<Long, SimplePK<Long>> {

	private static final long serialVersionUID = -4568190410233112594L;

	@DefaultEntityReturn
	private String unimedName;

	private String unimedType;
	
	private Unimed unimedFederation;
	
	private Long personId;

	@EmbeddedId
	public SimplePK<Long> getPk() {
		return super.getPk();
	}

	@Column(name = "NOM_UNIMED")
	public String getUnimedName() {
		return unimedName;
	}
	
	public void setUnimedName(String unimedName) {
		this.unimedName = unimedName;
	}

	@ManyToOne
	@JoinColumn(name = "COD_UNIMED_FED", referencedColumnName = "COD_UNIMED")
	@JsonBackReference
	public Unimed getUnimedFederation() {
		return unimedFederation;
	}

	public void setUnimedFederation(Unimed unimedFederation) {
		this.unimedFederation = unimedFederation;
	}

	@Column(name = "TIP_UNIMED")
	public String getUnimedType() {
		return unimedType;
	}

	public void setUnimedType(String unimedType) {
		this.unimedType = unimedType;
	}

    @Column(name = "COD_PESSOA")
    public Long getPersonId() {
        return personId;
    }

    public void setPersonId(Long personId) {
        this.personId = personId;
    }

}