ALTER TABLE adm_calendario_filial
    ADD CONSTRAINT fk_tadm0018_tadm0017 FOREIGN KEY ( cod_emp, nro_ano_calend, dat_calend )
        REFERENCES adm_calendario ( cod_emp, nro_ano_calend, dat_calend )
    NOT DEFERRABLE;
