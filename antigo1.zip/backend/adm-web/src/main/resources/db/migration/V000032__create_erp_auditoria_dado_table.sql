CREATE TABLE erp_auditoria_dado (
    cod_seq               NUMBER(38) NOT NULL,
    nom_tabela            VARCHAR2(30) NOT NULL,
    nom_coluna            VARCHAR2(30),
    val_chave_reg         VARCHAR2(4000) NOT NULL,
    dth_oprcao            DATE NOT NULL,
    tip_oprcao            VARCHAR2(1) NOT NULL,
    val_contd_de          VARCHAR2(4000),
    val_contd_para        VARCHAR2(4000),
    cod_usu               NUMBER(6),
    nom_login_bco_dados   VARCHAR2(30),
    nom_login_rede        VARCHAR2(30),
    nom_comput            VARCHAR2(100),
    nro_ip                VARCHAR2(30),
    cod_emp               NUMBER(3)
);

COMMENT ON TABLE erp_auditoria_dado is 'TERP1000: Auditoria';
COMMENT ON COLUMN erp_auditoria_dado.cod_seq is 'Sequência: Sequencial da operação';
COMMENT ON COLUMN erp_auditoria_dado.nom_tabela is 'Tabela: Tabela cujo registro sofreu alteração';
COMMENT ON COLUMN erp_auditoria_dado.nom_coluna is 'Coluna: Coluna cujo dado sofreu alteração';
COMMENT ON COLUMN erp_auditoria_dado.val_chave_reg is 'Chave: Chave identificadora do registro alterado';
COMMENT ON COLUMN erp_auditoria_dado.dth_oprcao is 'Data: Data que em ocorreu a operação';
COMMENT ON COLUMN erp_auditoria_dado.tip_oprcao is 'Tipo de operação: Tipo da operação efetuada | TIPO_OPERACAO_AUDITORIA';
COMMENT ON COLUMN erp_auditoria_dado.val_contd_de is 'Conteúdo anterior: Conteúdo anterior da coluna';
COMMENT ON COLUMN erp_auditoria_dado.val_contd_para is 'Conteúdo atualizado: Conteúdo atualizado da coluna';
COMMENT ON COLUMN erp_auditoria_dado.cod_usu is 'Usuário: Código do usuário no sistema que efetuou a operação';
COMMENT ON COLUMN erp_auditoria_dado.nom_login_bco_dados is 'Login: Login no banco de dados que efetuou a operação';
COMMENT ON COLUMN erp_auditoria_dado.nom_login_rede is 'Login na rede: Login na rede que efetuou a operação';
COMMENT ON COLUMN erp_auditoria_dado.nom_comput is 'Computador: Computador de onde foi realizada a operação';
COMMENT ON COLUMN erp_auditoria_dado.nro_ip is 'Número do IP: Armazena o número do IP do usuário';
COMMENT ON COLUMN erp_auditoria_dado.cod_emp is 'Empresa: Código da empresa';

CREATE UNIQUE INDEX ix_pk_terp1000 ON erp_auditoria_dado ( cod_seq );

CREATE INDEX ix_terp1000_1 ON erp_auditoria_dado ( nom_tabela, val_chave_reg, cod_emp );

CREATE INDEX ix_terp1000_2 ON erp_auditoria_dado ( dth_oprcao, nom_tabela, cod_emp );

CREATE INDEX ix_terp1000_3 ON erp_auditoria_dado ( nom_tabela, tip_oprcao, cod_emp );

ALTER TABLE erp_auditoria_dado
    ADD CONSTRAINT pk_terp1000 PRIMARY KEY ( cod_seq )
        USING INDEX ix_pk_terp1000;
