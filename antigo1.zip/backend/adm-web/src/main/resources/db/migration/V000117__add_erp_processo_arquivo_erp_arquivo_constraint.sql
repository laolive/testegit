ALTER TABLE erp_processo_arquivo
    ADD CONSTRAINT fk_terp0017_terp0026 FOREIGN KEY ( cod_arq )
        REFERENCES erp_arquivo ( cod_arq )
    NOT DEFERRABLE;
