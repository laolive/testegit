update ERP_DOMINIO set DES_LABEL = 'Geral' where NOM_DOMAIN = 'TIPO_MOTIVO_AME' and VAL_DOMAIN = 'A';

update ERP_DOMINIO set DES_LABEL = 'Aceite de Justificativa' where NOM_DOMAIN = 'TIPO_MOTIVO_AME' and VAL_DOMAIN = 'C';
