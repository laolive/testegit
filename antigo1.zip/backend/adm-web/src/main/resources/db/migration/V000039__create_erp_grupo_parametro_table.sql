CREATE TABLE erp_grupo_parametro (
    cod_grupo       NUMBER(38) NOT NULL,
    des_grupo       VARCHAR2(60) NOT NULL,
    cod_modulo      VARCHAR2(10),
    cod_grupo_sup   NUMBER(38),
    dat_inativ      DATE
);

COMMENT ON TABLE erp_grupo_parametro is 'TERP0004: Grupo de Parâmetros';
COMMENT ON COLUMN erp_grupo_parametro.cod_grupo is 'Código: Código do grupo de parâmetros';
COMMENT ON COLUMN erp_grupo_parametro.des_grupo is 'Descrição: Descrição do grupo de parâmetros';
COMMENT ON COLUMN erp_grupo_parametro.cod_modulo is 'Módulo: Código do módulo ao qual o grupo de parâmetros está relacionado';
COMMENT ON COLUMN erp_grupo_parametro.cod_grupo_sup is 'Grupo superior: Código do grupo superior';
COMMENT ON COLUMN erp_grupo_parametro.dat_inativ is 'Data da inativação: Informa a data em que o grupo de parâmetros foi desativado';

CREATE INDEX ix_pk_terp0004 ON erp_grupo_parametro ( cod_grupo );

CREATE INDEX ix_fk_terp0004_terp0003 ON erp_grupo_parametro ( cod_modulo );

CREATE INDEX ix_fk_terp0004_terp0004 ON erp_grupo_parametro ( cod_grupo_sup );

ALTER TABLE erp_grupo_parametro
    ADD CONSTRAINT pk_terp0004 PRIMARY KEY ( cod_grupo )
        USING INDEX ix_pk_terp0004;
