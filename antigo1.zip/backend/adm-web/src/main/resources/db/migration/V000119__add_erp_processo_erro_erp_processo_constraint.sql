ALTER TABLE erp_processo_erro
    ADD CONSTRAINT fk_terp0019_terp0015 FOREIGN KEY ( cod_prcsso )
        REFERENCES erp_processo ( cod_prcsso )
    NOT DEFERRABLE;
