DROP TABLE terminol_prot_comunic_item CASCADE CONSTRAINTS;
DROP TABLE terminologia_prot_comunic CASCADE CONSTRAINTS;
DROP TABLE protocolo_comunic_versao CASCADE CONSTRAINTS;
DROP TABLE protocolo_comunicacao CASCADE CONSTRAINTS;
