CREATE TABLE erp_processo (
    cod_prcsso         NUMBER(38) NOT NULL,
    cod_emp            NUMBER(3) NOT NULL,
    cod_rotina         NUMBER(10) NOT NULL,
    ind_forma_agenda   VARCHAR2(1) NOT NULL,
    flg_pnte           CHAR(1) NOT NULL,
    dth_inic_prev      DATE NOT NULL,
    cod_usu_solic      NUMBER NOT NULL,
    dth_solic          DATE NOT NULL,
    cod_fila           NUMBER(3),
    dth_inic_real      DATE,
    dth_final_real     DATE,
    cod_prcsso_orig    NUMBER(38),
    flg_aviso          CHAR(1),
    flg_erro           CHAR(1),
    flg_arq            CHAR(1),
    dth_solic_cancel   DATE,
    val_percent        NUMBER(3)
);

COMMENT ON TABLE erp_processo is 'TERP0015: Processo';
COMMENT ON COLUMN erp_processo.cod_prcsso is 'Número: Numeração sequencial do agendamento do processo';
COMMENT ON COLUMN erp_processo.cod_emp is 'Empresa: Código da empresa responsável pelo agendamento do processo';
COMMENT ON COLUMN erp_processo.cod_rotina is 'Rotina: Rotina executada pelo processo';
COMMENT ON COLUMN erp_processo.ind_forma_agenda is 'Forma de geração: Forma de agendamento do processo | FORMA_AGENDAMENTO';
COMMENT ON COLUMN erp_processo.flg_pnte is 'Pendente: Informa se o agendamento está pendente de execução | FLAG';
COMMENT ON COLUMN erp_processo.dth_inic_prev is 'Início previsto: Data/hora prevista para início da execução do processo';
COMMENT ON COLUMN erp_processo.cod_usu_solic is 'Usuário: Código do usuário que solicitou o agendamento do processo';
COMMENT ON COLUMN erp_processo.dth_solic is 'Solicitado em: Data/hora na qual o usuário solicitou o agendamento do processo';
COMMENT ON COLUMN erp_processo.cod_fila is 'Fila de execução: Código da fila de execução';
COMMENT ON COLUMN erp_processo.dth_inic_real is 'Início real: Data/hora real do início da execução do processo';
COMMENT ON COLUMN erp_processo.dth_final_real is 'Fim real: Data/hora real do término da execução do processo';
COMMENT ON COLUMN erp_processo.cod_prcsso_orig is 'Número: Número do processo de origem';
COMMENT ON COLUMN erp_processo.flg_aviso is 'Gerou aviso: Informa se o processo gerou aviso | FLAG';
COMMENT ON COLUMN erp_processo.flg_erro is 'Gerou erro: Informa se o processo gerou erro | FLAG';
COMMENT ON COLUMN erp_processo.flg_arq is 'Gerou arquivo: Informa se o processo gerou arquivo | FLAG';
COMMENT ON COLUMN erp_processo.dth_solic_cancel is 'Cancelamento em: Data/hora na qual o usuário solicitou o cancelamento do processo';
COMMENT ON COLUMN erp_processo.val_percent is 'Percentual: Percentual de andamento do processo';

CREATE UNIQUE INDEX ix_pk_terp0015 ON erp_processo ( cod_prcsso );

CREATE INDEX ix_terp0015_1 ON erp_processo ( cod_fila, flg_pnte, dth_inic_prev );

CREATE INDEX ix_terp0015_2 ON erp_processo ( cod_emp, cod_usu_solic );

ALTER TABLE erp_processo
    ADD CONSTRAINT pk_terp0015 PRIMARY KEY ( cod_prcsso )
        USING INDEX ix_pk_terp0015;

CREATE SEQUENCE s_terp0013 START WITH 1 NOCACHE ORDER;
