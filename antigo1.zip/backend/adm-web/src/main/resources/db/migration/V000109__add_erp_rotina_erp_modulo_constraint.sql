ALTER TABLE erp_rotina
    ADD CONSTRAINT fk_terp0013_terp0003 FOREIGN KEY ( cod_modulo )
        REFERENCES erp_modulo ( cod_modulo )
    NOT DEFERRABLE;
