ALTER TABLE erp_menu
    ADD CONSTRAINT fk_terp0006_terp0007 FOREIGN KEY ( cod_transc )
        REFERENCES erp_transacao ( cod_transc )
    NOT DEFERRABLE;
