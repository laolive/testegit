ALTER TABLE adm_usuario_grupo_acesso
    ADD CONSTRAINT fk_tadm0003_tadm0001 FOREIGN KEY ( cod_emp,
    cod_grupo_acesso )
        REFERENCES adm_grupo_acesso ( cod_emp,
        cod_grupo_acesso )
    NOT DEFERRABLE;
