CREATE TABLE terminologia_prot_comunic (
    id                            NUMBER(18) NOT NULL,
    protocolo_comunic_versao_id   NUMBER(18) NOT NULL,
    nome                          VARCHAR2(60) NOT NULL
);

ALTER TABLE terminologia_prot_comunic
    ADD CONSTRAINT terminologia_prot_comunic_pk
        PRIMARY KEY (id);

ALTER TABLE terminologia_prot_comunic
    ADD CONSTRAINT terminologia_prot_comnc_id_fk
        FOREIGN KEY (protocolo_comunic_versao_id) REFERENCES protocolo_comunic_versao (id);

ALTER TABLE terminologia_prot_comunic
    ADD CONSTRAINT terminologia_prot_comunic_uk
        UNIQUE (protocolo_comunic_versao_id,nome);

COMMENT ON TABLE terminologia_prot_comunic IS 'Terminologia do protocolo de comunicação';
COMMENT ON COLUMN terminologia_prot_comunic.id IS 'ID da terminologia no protocolo de comunicação';
COMMENT ON COLUMN terminologia_prot_comunic.protocolo_comunic_versao_id IS 'ID da versão do protocolo de comunicação';
COMMENT ON COLUMN terminologia_prot_comunic.nome IS 'Nome da terminologia';
