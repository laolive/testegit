insert into PROTOCOLO_COMUNICACAO (id, nome)
values (1, 'PTU');
insert into PROTOCOLO_COMUNICACAO (id, nome)
values (2, 'TISS');
