ALTER TABLE erp_empresa_unimed
    ADD CONSTRAINT fk_terp0030_terp0029 FOREIGN KEY ( cod_unimed )
        REFERENCES erp_unimed ( cod_unimed )
    NOT DEFERRABLE;
