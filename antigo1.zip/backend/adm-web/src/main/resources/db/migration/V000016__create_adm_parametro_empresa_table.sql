CREATE TABLE adm_parametro_empresa (
    cod_emp     NUMBER(3) NOT NULL,
    cod_param   VARCHAR2(100) NOT NULL,
    val_param   VARCHAR2(255)
);

COMMENT ON TABLE adm_parametro_empresa is'TADM0020: Parâmetro da Empresa';
COMMENT ON COLUMN adm_parametro_empresa.cod_emp is'Código: Código da empresa';
COMMENT ON COLUMN adm_parametro_empresa.cod_param is'Parâmetro: Nome do parâmetro';
COMMENT ON COLUMN adm_parametro_empresa.val_param is'Valor: Valor do parâmetro';

CREATE INDEX ix_pk_tadm0020 ON adm_parametro_empresa ( cod_emp, cod_param );

CREATE INDEX ix_fk_tadm0020_terp0005 ON adm_parametro_empresa ( cod_param );

ALTER TABLE adm_parametro_empresa
    ADD CONSTRAINT pk_tadm0020 PRIMARY KEY ( cod_emp,
    cod_param )
        USING INDEX ix_pk_tadm0020;
