CREATE TABLE tipo_integracao (
    id     NUMBER (18) NOT NULL,
    nome   VARCHAR2 (255) NOT NULL
);

ALTER TABLE tipo_integracao
    ADD CONSTRAINT tipo_integracao_pk
        PRIMARY KEY (id);

ALTER TABLE tipo_integracao
    ADD CONSTRAINT tipo_integracao_nome_uk
        UNIQUE (nome);

COMMENT ON TABLE tipo_integracao IS 'Tipo de integração';
COMMENT ON COLUMN tipo_integracao.id IS 'ID do tipo de integração';
COMMENT ON COLUMN tipo_integracao.nome IS 'Nome da integração';
