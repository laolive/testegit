ALTER TABLE erp_processo
    ADD CONSTRAINT fk_terp0015_terp0013 FOREIGN KEY ( cod_rotina )
        REFERENCES erp_rotina ( cod_rotina )
    NOT DEFERRABLE;
