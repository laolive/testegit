ALTER TABLE adm_usuario_filial
    ADD CONSTRAINT fk_tadm0014_terp0002 FOREIGN KEY ( cod_emp, cod_filial )
        REFERENCES erp_empresa_filial ( cod_emp, cod_filial )
    NOT DEFERRABLE;
