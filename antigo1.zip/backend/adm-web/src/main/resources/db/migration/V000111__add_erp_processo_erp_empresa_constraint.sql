ALTER TABLE erp_processo
    ADD CONSTRAINT fk_terp0015_terp0001 FOREIGN KEY ( cod_emp )
        REFERENCES erp_empresa ( cod_emp )
    NOT DEFERRABLE;
