insert into ERP_TRANSACAO (COD_TRANSC,NOM_TRANSC,DES_ROTA,COD_MODULO)
values (126,'Justificativas','/ame/justifications','AME');

insert into ERP_TRANSACAO (COD_TRANSC,NOM_TRANSC,DES_ROTA,COD_MODULO)
values (127,'Papel do Usuário','/aut/userRole','AUT');

insert into ERP_TRANSACAO (COD_TRANSC,NOM_TRANSC,DES_ROTA,COD_MODULO)
values (128,'Dashboard','/ame/dashboard','AME');

insert into ERP_TRANSACAO (COD_TRANSC,NOM_TRANSC,DES_ROTA,COD_MODULO)
values (32,'Empresa','/adm/enterprise','ADM');

insert into ERP_TRANSACAO (COD_TRANSC,NOM_TRANSC,DES_ROTA,COD_MODULO)
values (33,'Processos','/adm/process','ADM');

insert into ERP_TRANSACAO (COD_TRANSC,NOM_TRANSC,DES_ROTA,COD_MODULO)
values (74,'Usuário','/adm/user','ADM');

insert into ERP_TRANSACAO (COD_TRANSC,NOM_TRANSC,DES_ROTA,COD_MODULO)
values (77,'zipCode','/adm/zipCode','ADM');

insert into ERP_TRANSACAO (COD_TRANSC,NOM_TRANSC,DES_ROTA,COD_MODULO)
values (78,'Endereço','/adm/personAddress','ADM');

insert into ERP_TRANSACAO (COD_TRANSC,NOM_TRANSC,DES_ROTA,COD_MODULO)
values (79,'Contato Tipo','/adm/personContactType','ADM');

insert into ERP_TRANSACAO (COD_TRANSC,NOM_TRANSC,DES_ROTA,COD_MODULO)
values (80,'Pessoa','/adm/person','ADM');

insert into ERP_TRANSACAO (COD_TRANSC,NOM_TRANSC,DES_ROTA,COD_MODULO)
values (81,'Pessoa contato','/adm/personContact','ADM');

insert into ERP_TRANSACAO (COD_TRANSC,NOM_TRANSC,DES_ROTA,COD_MODULO)
values (106,'Filial','/adm/subsidiary','ADM');

insert into ERP_TRANSACAO (COD_TRANSC,NOM_TRANSC,DES_ROTA,COD_MODULO)
values (107,'Grupo de Acesso','/adm/accessGroup','ADM');

insert into ERP_TRANSACAO (COD_TRANSC,NOM_TRANSC,DES_ROTA,COD_MODULO)
values (108,'Rotina','/adm/routine','ADM');

insert into ERP_TRANSACAO (COD_TRANSC,NOM_TRANSC,DES_ROTA,COD_MODULO)
values (109,'Unimeds Atendidas','/adm/unimedEnterprise','ADM');

insert into ERP_TRANSACAO (COD_TRANSC,NOM_TRANSC,DES_ROTA,COD_MODULO)
values (118,'Calendário','/ame/calendar','AME');

insert into ERP_TRANSACAO (COD_TRANSC,NOM_TRANSC,DES_ROTA,COD_MODULO)
values (119,'Usuário','/ame/user','AME');

insert into ERP_TRANSACAO (COD_TRANSC,NOM_TRANSC,DES_ROTA,COD_MODULO)
values (120,'Unimed Auditada','/ame/auditedUnimed','AME');

insert into ERP_TRANSACAO (COD_TRANSC,NOM_TRANSC,DES_ROTA,COD_MODULO)
values (121,'Envio de Arquivo','/ame/protocol','AME');

insert into ERP_TRANSACAO (COD_TRANSC,NOM_TRANSC,DES_ROTA,COD_MODULO)
values (102,'Solicitação','/aut/solicitation','AUT');

insert into ERP_TRANSACAO (COD_TRANSC,NOM_TRANSC,DES_ROTA,COD_MODULO)
values (1,'Cadastro de Pessoas','/cad/person','CAD');

insert into ERP_TRANSACAO (COD_TRANSC,NOM_TRANSC,DES_ROTA,COD_MODULO)
values (34,'Máscara','/cad/mask','CAD');

insert into ERP_TRANSACAO (COD_TRANSC,NOM_TRANSC,DES_ROTA,COD_MODULO)
values (35,'Parâmetros','/adm/parameter','ADM');

insert into ERP_TRANSACAO (COD_TRANSC,NOM_TRANSC,DES_ROTA,COD_MODULO)
values (76,'Pessoa Documento','/cad/personDocument','CAD');

insert into ERP_TRANSACAO (COD_TRANSC,NOM_TRANSC,DES_ROTA,COD_MODULO)
values (103,'Usuários','/adm/user','ADM');

insert into ERP_TRANSACAO (COD_TRANSC,NOM_TRANSC,DES_ROTA,COD_MODULO)
values (2,'Cadastro de Contas','/Contas','CRM');

insert into ERP_TRANSACAO (COD_TRANSC,NOM_TRANSC,DES_ROTA,COD_MODULO)
values (40,'Ação','/crm/action','CRM');

insert into ERP_TRANSACAO (COD_TRANSC,NOM_TRANSC,DES_ROTA,COD_MODULO)
values (41,'Resultado','/crm/result','CRM');

insert into ERP_TRANSACAO (COD_TRANSC,NOM_TRANSC,DES_ROTA,COD_MODULO)
values (42,'Tipo de despesa','/crm/costType','CRM');

insert into ERP_TRANSACAO (COD_TRANSC,NOM_TRANSC,DES_ROTA,COD_MODULO)
values (43,'Fonte','/crm/source','CRM');

insert into ERP_TRANSACAO (COD_TRANSC,NOM_TRANSC,DES_ROTA,COD_MODULO)
values (44,'Tipo de conta','/crm/accountType','CRM');

insert into ERP_TRANSACAO (COD_TRANSC,NOM_TRANSC,DES_ROTA,COD_MODULO)
values (45,'Motivo atendimento','/crm/reason','CRM');

insert into ERP_TRANSACAO (COD_TRANSC,NOM_TRANSC,DES_ROTA,COD_MODULO)
values (46,'Mensagem de alerta','/crm/message','CRM');

insert into ERP_TRANSACAO (COD_TRANSC,NOM_TRANSC,DES_ROTA,COD_MODULO)
values (47,'Categoria atend.','/crm/category','CRM');

insert into ERP_TRANSACAO (COD_TRANSC,NOM_TRANSC,DES_ROTA,COD_MODULO)
values (48,'Despesa','/crm/cost','CRM');

insert into ERP_TRANSACAO (COD_TRANSC,NOM_TRANSC,DES_ROTA,COD_MODULO)
values (49,'Tipo de campanha','/crm/campaignType','CRM');

insert into ERP_TRANSACAO (COD_TRANSC,NOM_TRANSC,DES_ROTA,COD_MODULO)
values (50,'Unidade de venda','/crm/saleUnit','CRM');

insert into ERP_TRANSACAO (COD_TRANSC,NOM_TRANSC,DES_ROTA,COD_MODULO)
values (51,'Estilo','/crm/style','CRM');

insert into ERP_TRANSACAO (COD_TRANSC,NOM_TRANSC,DES_ROTA,COD_MODULO)
values (52,'Classe','/crm/class','CRM');

insert into ERP_TRANSACAO (COD_TRANSC,NOM_TRANSC,DES_ROTA,COD_MODULO)
values (53,'Objetivo','/crm/objective','CRM');

insert into ERP_TRANSACAO (COD_TRANSC,NOM_TRANSC,DES_ROTA,COD_MODULO)
values (54,'Detalhamento','/crm/detail','CRM');

insert into ERP_TRANSACAO (COD_TRANSC,NOM_TRANSC,DES_ROTA,COD_MODULO)
values (55,'Probabilidade','/crm/probability','CRM');

insert into ERP_TRANSACAO (COD_TRANSC,NOM_TRANSC,DES_ROTA,COD_MODULO)
values (56,'Pontos forte/fraco','/crm/factor','CRM');

insert into ERP_TRANSACAO (COD_TRANSC,NOM_TRANSC,DES_ROTA,COD_MODULO)
values (57,'Fase de venda','/crm/stage','CRM');

insert into ERP_TRANSACAO (COD_TRANSC,NOM_TRANSC,DES_ROTA,COD_MODULO)
values (58,'Estratégia de venda','/crm/strategy','CRM');

insert into ERP_TRANSACAO (COD_TRANSC,NOM_TRANSC,DES_ROTA,COD_MODULO)
values (59,'Conta','/crm/account','CRM');

insert into ERP_TRANSACAO (COD_TRANSC,NOM_TRANSC,DES_ROTA,COD_MODULO)
values (60,'Tarefa/Ação','/crm/task','CRM');

insert into ERP_TRANSACAO (COD_TRANSC,NOM_TRANSC,DES_ROTA,COD_MODULO)
values (61,'Grupo de atendimento','/crm/attendanceGroup','CRM');

insert into ERP_TRANSACAO (COD_TRANSC,NOM_TRANSC,DES_ROTA,COD_MODULO)
values (62,'Campanha','/crm/campaign','CRM');

insert into ERP_TRANSACAO (COD_TRANSC,NOM_TRANSC,DES_ROTA,COD_MODULO)
values (63,'Cancelamento','/crm/cancellation','CRM');

insert into ERP_TRANSACAO (COD_TRANSC,NOM_TRANSC,DES_ROTA,COD_MODULO)
values (64,'Oportunidade','/crm/opportunity','CRM');

insert into ERP_TRANSACAO (COD_TRANSC,NOM_TRANSC,DES_ROTA,COD_MODULO)
values (65,'Vendedor','/crm/seller','CRM');

insert into ERP_TRANSACAO (COD_TRANSC,NOM_TRANSC,DES_ROTA,COD_MODULO)
values (66,'Grupo de usuário','/crm/userGroup','CRM');

insert into ERP_TRANSACAO (COD_TRANSC,NOM_TRANSC,DES_ROTA,COD_MODULO)
values (67,'Protocolo','/crm/protocol','CRM');

insert into ERP_TRANSACAO (COD_TRANSC,NOM_TRANSC,DES_ROTA,COD_MODULO)
values (68,'Campanha x Ação','/crm/campaignAction','CRM');

insert into ERP_TRANSACAO (COD_TRANSC,NOM_TRANSC,DES_ROTA,COD_MODULO)
values (69,'CRM Arquivo','/crm/archive','CRM');

insert into ERP_TRANSACAO (COD_TRANSC,NOM_TRANSC,DES_ROTA,COD_MODULO)
values (70,'Forma de contato','/crm/contactForm','CRM');

insert into ERP_TRANSACAO (COD_TRANSC,NOM_TRANSC,DES_ROTA,COD_MODULO)
values (71,'Região','/crm/region','CRM');

insert into ERP_TRANSACAO (COD_TRANSC,NOM_TRANSC,DES_ROTA,COD_MODULO)
values (73,'Prioridade','/crm/priority','CRM');

insert into ERP_TRANSACAO (COD_TRANSC,NOM_TRANSC,DES_ROTA,COD_MODULO)
values (75,'Grupo atendimento','/crm/attendanceGroupMessage','CRM');

insert into ERP_TRANSACAO (COD_TRANSC,NOM_TRANSC,DES_ROTA,COD_MODULO)
values (82,'Mensagem publico','/crm/messagePublic','CRM');

insert into ERP_TRANSACAO (COD_TRANSC,NOM_TRANSC,DES_ROTA,COD_MODULO)
values (83,'Grupo Atend. Ação','/crm/attendanceGroupAction','CRM');

insert into ERP_TRANSACAO (COD_TRANSC,NOM_TRANSC,DES_ROTA,COD_MODULO)
values (84,'Grupo Atend. Categ','/crm/attendanceGroupCategory','CRM');

insert into ERP_TRANSACAO (COD_TRANSC,NOM_TRANSC,DES_ROTA,COD_MODULO)
values (85,'Grupo Atend. Member','/crm/attendanceGroupMember','CRM');

insert into ERP_TRANSACAO (COD_TRANSC,NOM_TRANSC,DES_ROTA,COD_MODULO)
values (86,'Grupo Atend. Public','/crm/attendanceGroupPublic','CRM');

insert into ERP_TRANSACAO (COD_TRANSC,NOM_TRANSC,DES_ROTA,COD_MODULO)
values (88,'Protocolo Movimento','/crm/protocolMovement','CRM');

insert into ERP_TRANSACAO (COD_TRANSC,NOM_TRANSC,DES_ROTA,COD_MODULO)
values (104,'Comercial','/crm/dashboardCommercial','CRM');

insert into ERP_TRANSACAO (COD_TRANSC,NOM_TRANSC,DES_ROTA,COD_MODULO)
values (110,'Call Center','/crm/dashboardCallCenter','CRM');

insert into ERP_TRANSACAO (COD_TRANSC,NOM_TRANSC,DES_ROTA,COD_MODULO)
values (111,'Turno','/crm/shift','CRM');

insert into ERP_TRANSACAO (COD_TRANSC,NOM_TRANSC,DES_ROTA,COD_MODULO)
values (112,'Sub Motivo','/crm/subReason','CRM');

insert into ERP_TRANSACAO (COD_TRANSC,NOM_TRANSC,DES_ROTA,COD_MODULO)
values (114,'Base de conhecimento','/crm/knowledgeBase','CRM');

insert into ERP_TRANSACAO (COD_TRANSC,NOM_TRANSC,DES_ROTA,COD_MODULO)
values (115,'Tipo de Vínclulo','/crm/linkType','CRM');

insert into ERP_TRANSACAO (COD_TRANSC,NOM_TRANSC,DES_ROTA,COD_MODULO)
values (93,'Area','/cor/area','PRT');

insert into ERP_TRANSACAO (COD_TRANSC,NOM_TRANSC,DES_ROTA,COD_MODULO)
values (94,'Motivos Cancelamento','/cor/cancellationReason','PRT');

insert into ERP_TRANSACAO (COD_TRANSC,NOM_TRANSC,DES_ROTA,COD_MODULO)
values (95,'Tipos Documento','/cor/documentType','PRT');

insert into ERP_TRANSACAO (COD_TRANSC,NOM_TRANSC,DES_ROTA,COD_MODULO)
values (96,'Etiqueta','/cor/label','PRT');

insert into ERP_TRANSACAO (COD_TRANSC,NOM_TRANSC,DES_ROTA,COD_MODULO)
values (97,'Protocolo','/cor/protocol','PRT');

insert into ERP_TRANSACAO (COD_TRANSC,NOM_TRANSC,DES_ROTA,COD_MODULO)
values (99,'Método Envio','/cor/shippingMethod','PRT');

insert into ERP_TRANSACAO (COD_TRANSC,NOM_TRANSC,DES_ROTA,COD_MODULO)
values (100,'Consulta','/cor/search','PRT');

insert into ERP_TRANSACAO (COD_TRANSC,NOM_TRANSC,DES_ROTA,COD_MODULO)
values (101,'Clientes Usuários','/cor/recipient','PRT');

insert into ERP_TRANSACAO (COD_TRANSC,NOM_TRANSC,DES_ROTA,COD_MODULO)
values (116,'Recebimento','/cor/protocolReceipt','PRT');

insert into ERP_TRANSACAO (COD_TRANSC,NOM_TRANSC,DES_ROTA,COD_MODULO)
values (117,'Perfil do Usuário','/cor/userProfile','PRT');

insert into ERP_TRANSACAO (COD_TRANSC,NOM_TRANSC,DES_ROTA,COD_MODULO)
values (123,'Processamento','/ame/processing','AME');

insert into ERP_TRANSACAO (COD_TRANSC,NOM_TRANSC,DES_ROTA,COD_MODULO)
values (125,'Mensagem','/ame/auditedMessage','AME');

insert into ERP_TRANSACAO (COD_TRANSC,NOM_TRANSC,DES_ROTA,COD_MODULO)
values (122,'Auditoria','/ame/auditing','AME');

insert into ERP_TRANSACAO (COD_TRANSC,NOM_TRANSC,DES_ROTA,COD_MODULO)
values (129,'Grupo de Análise','/aut/grupoAnalise','AUT');

insert into ERP_TRANSACAO (COD_TRANSC,NOM_TRANSC,DES_ROTA,COD_MODULO)
values (130,'Analisar Solicitação em Estudo','/aut/avaliarGuia','AUT');
