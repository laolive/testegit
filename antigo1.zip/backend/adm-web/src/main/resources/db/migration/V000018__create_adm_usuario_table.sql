CREATE TABLE adm_usuario (
    cod_usu                      NUMBER(6) NOT NULL,
    nom_usu_aprstr               VARCHAR2(25) NOT NULL,
    nom_login                    VARCHAR2(30) NOT NULL,
    des_senha                    VARCHAR2(60) NOT NULL,
    flg_bloqdo                   CHAR(1) NOT NULL,
    cod_grupo_emprsl             NUMBER(6) NOT NULL,
    des_email                    VARCHAR2(50),
    des_domain_rede              VARCHAR2(25),
    des_login_rede               VARCHAR2(25),
    qtd_dia_expira_senha         NUMBER(6),
    dat_expira_senha             DATE,
    dat_inativ                   DATE,
    dat_ultimo_acesso            DATE,
    nro_uuid_token_senha         VARCHAR2(36),
    dat_valde_uuid_token_senha   DATE
);

COMMENT ON TABLE adm_usuario is'TADM0002: Usuário do Sistema';
COMMENT ON COLUMN adm_usuario.cod_usu is'Código: Código do usuário';
COMMENT ON COLUMN adm_usuario.nom_usu_aprstr is'Nome: Nome do usuário para apresentação no sistema';
COMMENT ON COLUMN adm_usuario.nom_login is'Login: Login do usuário no sistema';
COMMENT ON COLUMN adm_usuario.des_senha is'Senha: Senha do usuário';
COMMENT ON COLUMN adm_usuario.flg_bloqdo is'Bloqueado: Informa se o usuário possui acesso bloqueado | FLAG';
COMMENT ON COLUMN adm_usuario.cod_grupo_emprsl is'Grupo empresarial: Código do grupo empresarial à qual o usuário pertence';
COMMENT ON COLUMN adm_usuario.des_email is'Email: Endereço de e-mail do usuário';
COMMENT ON COLUMN adm_usuario.des_domain_rede is'Domínio de Rede: Domínio de rede do login do usuário na rede';
COMMENT ON COLUMN adm_usuario.des_login_rede is'Login na Rede: Login do usuário na rede';
COMMENT ON COLUMN adm_usuario.qtd_dia_expira_senha is'Expiração da senha (dias): Número de dias em que a senha expira em relação a última alteração';
COMMENT ON COLUMN adm_usuario.dat_expira_senha is'Expiração da senha (data): Data em que a senha do usuário deve expirar';
COMMENT ON COLUMN adm_usuario.dat_inativ is'Data da inativação: Data da inativação do usuário';
COMMENT ON COLUMN adm_usuario.dat_ultimo_acesso is'Data do Último Acesso: Data do último acesso do usuário';
COMMENT ON COLUMN adm_usuario.nro_uuid_token_senha is'Token: Token gerado para a recuperação da senha';
COMMENT ON COLUMN adm_usuario.dat_valde_uuid_token_senha is'Validade Token: Data de validade do token gerado para a recuperação da senha';

CREATE INDEX ix_pk_tadm0002 ON adm_usuario ( cod_usu );

CREATE INDEX ix_uk_tadm0002 ON adm_usuario ( nom_login );

CREATE INDEX ix_fk_tadm0002_terp0023 ON adm_usuario ( cod_grupo_emprsl );

ALTER TABLE adm_usuario
    ADD CONSTRAINT pk_tadm0002 PRIMARY KEY ( cod_usu )
        USING INDEX ix_pk_tadm0002;

ALTER TABLE adm_usuario ADD CONSTRAINT uk_tadm0002 UNIQUE ( nom_login )
    USING INDEX ix_uk_tadm0002;
