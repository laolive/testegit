ALTER TABLE adm_calendario_filial
    ADD CONSTRAINT fk_tadm0018_terp0003 FOREIGN KEY ( cod_modulo )
        REFERENCES erp_modulo ( cod_modulo );