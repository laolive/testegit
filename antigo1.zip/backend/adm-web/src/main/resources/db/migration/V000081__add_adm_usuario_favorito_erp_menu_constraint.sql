ALTER TABLE adm_usuario_favorito
    ADD CONSTRAINT fk_tadm0013_terp0006 FOREIGN KEY ( cod_menu )
        REFERENCES erp_menu ( cod_menu )
    NOT DEFERRABLE;
