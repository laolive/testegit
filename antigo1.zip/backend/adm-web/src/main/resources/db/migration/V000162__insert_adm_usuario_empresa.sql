insert into ADM_USUARIO_EMPRESA (COD_USU, COD_EMP)
values (1, 1);
insert into ADM_USUARIO_EMPRESA (COD_USU, COD_EMP)
values (2, 1);
