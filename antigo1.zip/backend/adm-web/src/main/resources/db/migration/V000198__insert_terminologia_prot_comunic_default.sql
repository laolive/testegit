insert into TERMINOLOGIA_PROT_COMUNIC (id, protocolo_comunic_versao_id, nome)
values (1, 1, 'idUrgenciaEmergencia');
insert into TERMINOLOGIA_PROT_COMUNIC (id, protocolo_comunic_versao_id, nome)
values (10, 1, 'st_cdFinalidade');
insert into TERMINOLOGIA_PROT_COMUNIC (id, protocolo_comunic_versao_id, nome)
values (11, 1, 'st_cdMensErroEspec');
insert into TERMINOLOGIA_PROT_COMUNIC (id, protocolo_comunic_versao_id, nome)
values (12, 1, 'st_cdMensEspec');
insert into TERMINOLOGIA_PROT_COMUNIC (id, protocolo_comunic_versao_id, nome)
values (13, 1, 'st_cdViaAdmin');
insert into TERMINOLOGIA_PROT_COMUNIC (id, protocolo_comunic_versao_id, nome)
values (14, 1, 'st_clMetastase');
insert into TERMINOLOGIA_PROT_COMUNIC (id, protocolo_comunic_versao_id, nome)
values (15, 1, 'st_clNodulo');
insert into TERMINOLOGIA_PROT_COMUNIC (id, protocolo_comunic_versao_id, nome)
values (16, 1, 'st_clTumor');
insert into TERMINOLOGIA_PROT_COMUNIC (id, protocolo_comunic_versao_id, nome)
values (17, 1, 'st_codigoErro');
insert into TERMINOLOGIA_PROT_COMUNIC (id, protocolo_comunic_versao_id, nome)
values (18, 1, 'st_estadTumor');
insert into TERMINOLOGIA_PROT_COMUNIC (id, protocolo_comunic_versao_id, nome)
values (19, 1, 'st_idAcidente');
insert into TERMINOLOGIA_PROT_COMUNIC (id, protocolo_comunic_versao_id, nome)
values (2, 2, 'dm_caraterAtendimento');
insert into TERMINOLOGIA_PROT_COMUNIC (id, protocolo_comunic_versao_id, nome)
values (20, 1, 'st_idAutoriz');
insert into TERMINOLOGIA_PROT_COMUNIC (id, protocolo_comunic_versao_id, nome)
values (21, 1, 'st_idAutorizAudit');
insert into TERMINOLOGIA_PROT_COMUNIC (id, protocolo_comunic_versao_id, nome)
values (22, 1, 'st_idPlano');
insert into TERMINOLOGIA_PROT_COMUNIC (id, protocolo_comunic_versao_id, nome)
values (23, 1, 'st_idResposta');
insert into TERMINOLOGIA_PROT_COMUNIC (id, protocolo_comunic_versao_id, nome)
values (24, 1, 'st_idStatusOS');
insert into TERMINOLOGIA_PROT_COMUNIC (id, protocolo_comunic_versao_id, nome)
values (25, 1, 'st_siglaConselho');
insert into TERMINOLOGIA_PROT_COMUNIC (id, protocolo_comunic_versao_id, nome)
values (26, 1, 'st_simNao');
insert into TERMINOLOGIA_PROT_COMUNIC (id, protocolo_comunic_versao_id, nome)
values (27, 1, 'st_stRetorno');
insert into TERMINOLOGIA_PROT_COMUNIC (id, protocolo_comunic_versao_id, nome)
values (28, 1, 'st_tpAbrangencia');
insert into TERMINOLOGIA_PROT_COMUNIC (id, protocolo_comunic_versao_id, nome)
values (29, 1, 'st_tpAcomodacao');
insert into TERMINOLOGIA_PROT_COMUNIC (id, protocolo_comunic_versao_id, nome)
values (3, 1, 'st_IdRespWsd');
insert into TERMINOLOGIA_PROT_COMUNIC (id, protocolo_comunic_versao_id, nome)
values (30, 1, 'st_tpAnexo');
insert into TERMINOLOGIA_PROT_COMUNIC (id, protocolo_comunic_versao_id, nome)
values (31, 1, 'st_tpAutorizacao');
insert into TERMINOLOGIA_PROT_COMUNIC (id, protocolo_comunic_versao_id, nome)
values (32, 1, 'st_tpCliente');
insert into TERMINOLOGIA_PROT_COMUNIC (id, protocolo_comunic_versao_id, nome)
values (33, 1, 'st_tpEvento');
insert into TERMINOLOGIA_PROT_COMUNIC (id, protocolo_comunic_versao_id, nome)
values (34, 1, 'st_tpIdentificadorConfirmacao');
insert into TERMINOLOGIA_PROT_COMUNIC (id, protocolo_comunic_versao_id, nome)
values (35, 1, 'st_tpInternacao');
insert into TERMINOLOGIA_PROT_COMUNIC (id, protocolo_comunic_versao_id, nome)
values (36, 1, 'st_tpQuimio');
insert into TERMINOLOGIA_PROT_COMUNIC (id, protocolo_comunic_versao_id, nome)
values (37, 1, 'st_tpRedeMIN');
insert into TERMINOLOGIA_PROT_COMUNIC (id, protocolo_comunic_versao_id, nome)
values (38, 1, 'st_tpSexo');
insert into TERMINOLOGIA_PROT_COMUNIC (id, protocolo_comunic_versao_id, nome)
values (39, 1, 'st_tpTabela');
insert into TERMINOLOGIA_PROT_COMUNIC (id, protocolo_comunic_versao_id, nome)
values (4, 1, 'st_IdStBenef');
insert into TERMINOLOGIA_PROT_COMUNIC (id, protocolo_comunic_versao_id, nome)
values (40, 1, 'tpOrdem');
insert into TERMINOLOGIA_PROT_COMUNIC (id, protocolo_comunic_versao_id, nome)
values (41, 1, 'unMedicamento');
insert into TERMINOLOGIA_PROT_COMUNIC (id, protocolo_comunic_versao_id, nome)
values (42, 2, 'dm_UF');
insert into TERMINOLOGIA_PROT_COMUNIC (id, protocolo_comunic_versao_id, nome)
values (43, 2, 'dm_conselhoProfissional');
insert into TERMINOLOGIA_PROT_COMUNIC (id, protocolo_comunic_versao_id, nome)
values (44, 2, 'dm_debitoCreditoIndicador');
insert into TERMINOLOGIA_PROT_COMUNIC (id, protocolo_comunic_versao_id, nome)
values (45, 2, 'dm_debitoCreditoTipo');
insert into TERMINOLOGIA_PROT_COMUNIC (id, protocolo_comunic_versao_id, nome)
values (46, 2, 'dm_diagnosticoImagem');
insert into TERMINOLOGIA_PROT_COMUNIC (id, protocolo_comunic_versao_id, nome)
values (47, 2, 'dm_ecog');
insert into TERMINOLOGIA_PROT_COMUNIC (id, protocolo_comunic_versao_id, nome)
values (48, 2, 'dm_estadiamento');
insert into TERMINOLOGIA_PROT_COMUNIC (id, protocolo_comunic_versao_id, nome)
values (49, 2, 'dm_finalidadeTratamento');
insert into TERMINOLOGIA_PROT_COMUNIC (id, protocolo_comunic_versao_id, nome)
values (5, 1, 'st_IdStatusWsd');
insert into TERMINOLOGIA_PROT_COMUNIC (id, protocolo_comunic_versao_id, nome)
values (50, 2, 'dm_formaPagamento');
insert into TERMINOLOGIA_PROT_COMUNIC (id, protocolo_comunic_versao_id, nome)
values (51, 2, 'dm_grauPart');
insert into TERMINOLOGIA_PROT_COMUNIC (id, protocolo_comunic_versao_id, nome)
values (52, 2, 'dm_indicadorAcidente');
insert into TERMINOLOGIA_PROT_COMUNIC (id, protocolo_comunic_versao_id, nome)
values (53, 2, 'dm_indicadorIdentificacao');
insert into TERMINOLOGIA_PROT_COMUNIC (id, protocolo_comunic_versao_id, nome)
values (54, 2, 'dm_metastase');
insert into TERMINOLOGIA_PROT_COMUNIC (id, protocolo_comunic_versao_id, nome)
values (55, 2, 'dm_motivoSaida');
insert into TERMINOLOGIA_PROT_COMUNIC (id, protocolo_comunic_versao_id, nome)
values (56, 2, 'dm_motivoSaidaObito');
insert into TERMINOLOGIA_PROT_COMUNIC (id, protocolo_comunic_versao_id, nome)
values (57, 2, 'dm_nodulo');
insert into TERMINOLOGIA_PROT_COMUNIC (id, protocolo_comunic_versao_id, nome)
values (58, 2, 'dm_obitoMulher');
insert into TERMINOLOGIA_PROT_COMUNIC (id, protocolo_comunic_versao_id, nome)
values (59, 2, 'dm_objetoRecurso');
insert into TERMINOLOGIA_PROT_COMUNIC (id, protocolo_comunic_versao_id, nome)
values (6, 1, 'st_Identificador');
insert into TERMINOLOGIA_PROT_COMUNIC (id, protocolo_comunic_versao_id, nome)
values (60, 2, 'dm_opcaoFabricante');
insert into TERMINOLOGIA_PROT_COMUNIC (id, protocolo_comunic_versao_id, nome)
values (61, 2, 'dm_origemEventoAtencaoSaude');
insert into TERMINOLOGIA_PROT_COMUNIC (id, protocolo_comunic_versao_id, nome)
values (62, 2, 'dm_outrasDespesas');
insert into TERMINOLOGIA_PROT_COMUNIC (id, protocolo_comunic_versao_id, nome)
values (63, 2, 'dm_posicaoProfissao');
insert into TERMINOLOGIA_PROT_COMUNIC (id, protocolo_comunic_versao_id, nome)
values (64, 2, 'dm_regimeInternacao');
insert into TERMINOLOGIA_PROT_COMUNIC (id, protocolo_comunic_versao_id, nome)
values (65, 2, 'dm_sexo');
insert into TERMINOLOGIA_PROT_COMUNIC (id, protocolo_comunic_versao_id, nome)
values (66, 2, 'dm_simNao');
insert into TERMINOLOGIA_PROT_COMUNIC (id, protocolo_comunic_versao_id, nome)
values (67, 2, 'dm_statusCancelamento');
insert into TERMINOLOGIA_PROT_COMUNIC (id, protocolo_comunic_versao_id, nome)
values (68, 2, 'dm_statusComunicacaoBeneficiario');
insert into TERMINOLOGIA_PROT_COMUNIC (id, protocolo_comunic_versao_id, nome)
values (69, 2, 'dm_statusProtocolo');
insert into TERMINOLOGIA_PROT_COMUNIC (id, protocolo_comunic_versao_id, nome)
values (7, 1, 'st_cdDiagImg');
insert into TERMINOLOGIA_PROT_COMUNIC (id, protocolo_comunic_versao_id, nome)
values (70, 2, 'dm_statusSolicitacao');
insert into TERMINOLOGIA_PROT_COMUNIC (id, protocolo_comunic_versao_id, nome)
values (71, 2, 'dm_tabela');
insert into TERMINOLOGIA_PROT_COMUNIC (id, protocolo_comunic_versao_id, nome)
values (72, 2, 'dm_tabelaGeral');
insert into TERMINOLOGIA_PROT_COMUNIC (id, protocolo_comunic_versao_id, nome)
values (73, 2, 'dm_tabelasDiagnostico');
insert into TERMINOLOGIA_PROT_COMUNIC (id, protocolo_comunic_versao_id, nome)
values (74, 2, 'dm_tecnicaUtilizada');
insert into TERMINOLOGIA_PROT_COMUNIC (id, protocolo_comunic_versao_id, nome)
values (75, 2, 'dm_tipoAcomodacao');
insert into TERMINOLOGIA_PROT_COMUNIC (id, protocolo_comunic_versao_id, nome)
values (76, 2, 'dm_tipoAtendimento');
insert into TERMINOLOGIA_PROT_COMUNIC (id, protocolo_comunic_versao_id, nome)
values (77, 2, 'dm_tipoConsulta');
insert into TERMINOLOGIA_PROT_COMUNIC (id, protocolo_comunic_versao_id, nome)
values (78, 2, 'dm_tipoDemonstrativo');
insert into TERMINOLOGIA_PROT_COMUNIC (id, protocolo_comunic_versao_id, nome)
values (79, 2, 'dm_tipoDemonstrativoPagamento');
insert into TERMINOLOGIA_PROT_COMUNIC (id, protocolo_comunic_versao_id, nome)
values (8, 1, 'st_cdEcog');
insert into TERMINOLOGIA_PROT_COMUNIC (id, protocolo_comunic_versao_id, nome)
values (80, 2, 'dm_tipoDoenca');
insert into TERMINOLOGIA_PROT_COMUNIC (id, protocolo_comunic_versao_id, nome)
values (81, 2, 'dm_tipoEvento');
insert into TERMINOLOGIA_PROT_COMUNIC (id, protocolo_comunic_versao_id, nome)
values (82, 2, 'dm_tipoFaturamento');
insert into TERMINOLOGIA_PROT_COMUNIC (id, protocolo_comunic_versao_id, nome)
values (83, 2, 'dm_tipoFaturamentoOdonto');
insert into TERMINOLOGIA_PROT_COMUNIC (id, protocolo_comunic_versao_id, nome)
values (84, 2, 'dm_tipoGlosa');
insert into TERMINOLOGIA_PROT_COMUNIC (id, protocolo_comunic_versao_id, nome)
values (85, 2, 'dm_tipoGuia');
insert into TERMINOLOGIA_PROT_COMUNIC (id, protocolo_comunic_versao_id, nome)
values (86, 2, 'dm_tipoInternacao');
insert into TERMINOLOGIA_PROT_COMUNIC (id, protocolo_comunic_versao_id, nome)
values (87, 2, 'dm_tipoLancamento');
insert into TERMINOLOGIA_PROT_COMUNIC (id, protocolo_comunic_versao_id, nome)
values (88, 2, 'dm_tipoQuimioterapia');
insert into TERMINOLOGIA_PROT_COMUNIC (id, protocolo_comunic_versao_id, nome)
values (89, 2, 'dm_tumor');
insert into TERMINOLOGIA_PROT_COMUNIC (id, protocolo_comunic_versao_id, nome)
values (9, 1, 'st_cdEspec');
insert into TERMINOLOGIA_PROT_COMUNIC (id, protocolo_comunic_versao_id, nome)
values (90, 2, 'dm_unidadeMedida');
insert into TERMINOLOGIA_PROT_COMUNIC (id, protocolo_comunic_versao_id, nome)
values (91, 2, 'dm_unidadeTempoCiclo');
insert into TERMINOLOGIA_PROT_COMUNIC (id, protocolo_comunic_versao_id, nome)
values (92, 2, 'dm_viaAdministracao');
insert into TERMINOLOGIA_PROT_COMUNIC (id, protocolo_comunic_versao_id, nome)
values (93, 2, 'dm_viaDeAcesso');
