CREATE TABLE adm_feriado (
    cod_emp      NUMBER(3) NOT NULL,
    dat_calend   DATE NOT NULL,
    des_friado   VARCHAR2(100) NOT NULL,
    ind_abrang   VARCHAR2(1)
);

COMMENT ON TABLE adm_feriado is'TADM0015: Feriado';
COMMENT ON COLUMN adm_feriado.cod_emp is'Empresa: Código da empresa';
COMMENT ON COLUMN adm_feriado.dat_calend is'Data: Data do Calendário';
COMMENT ON COLUMN adm_feriado.des_friado is'Descrição: Descrição da data do Feriado';
COMMENT ON COLUMN adm_feriado.ind_abrang is'Abrangência: Indica a abrangência do Feriado | FERIADO_ABRANGENCIA';

CREATE INDEX ix_pk_tadm0015 ON adm_feriado ( cod_emp,
    dat_calend );

ALTER TABLE adm_feriado
    ADD CONSTRAINT pk_tadm0015 PRIMARY KEY ( cod_emp,
    dat_calend )
        USING INDEX ix_pk_tadm0015;