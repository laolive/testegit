ALTER TABLE erp_processo_filtro
    ADD CONSTRAINT fk_terp0016_terp0014 FOREIGN KEY ( cod_rotina,
    cod_filtro )
        REFERENCES erp_rotina_filtro ( cod_rotina,
        cod_filtro )
    NOT DEFERRABLE;
