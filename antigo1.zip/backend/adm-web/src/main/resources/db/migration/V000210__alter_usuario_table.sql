ALTER TABLE adm_usuario ADD empresa_id NUMBER(3);

ALTER TABLE adm_usuario
    ADD CONSTRAINT adm_usuario_empresa_id_fk FOREIGN KEY (empresa_id)
        REFERENCES erp_empresa (cod_emp);

UPDATE adm_usuario SET empresa_id = cod_grupo_emprsl;

COMMIT;
        
ALTER TABLE adm_usuario DROP CONSTRAINT fk_tadm0002_terp0023;

ALTER TABLE adm_usuario DROP COLUMN cod_grupo_emprsl;
