CREATE TABLE protocolo_comunicacao (
    id     NUMBER(18) NOT NULL,
    nome   VARCHAR2(40) NOT NULL
);

ALTER TABLE protocolo_comunicacao
    ADD CONSTRAINT protocolo_comunicacao_pk
        PRIMARY KEY (id);

COMMENT ON TABLE protocolo_comunicacao IS 'Protocolo de comunicação';
COMMENT ON COLUMN protocolo_comunicacao.id IS 'ID do protocolo de comunicação';
COMMENT ON COLUMN protocolo_comunicacao.nome IS 'Nome do protocolo de comunicação';
