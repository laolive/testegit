insert into erp_dominio (NOM_DOMAIN, VAL_DOMAIN, DES_LABEL, DES_EXPLIC, DAT_INIC_VIGEN, DAT_FINAL_VIGEN)
values ('TIPO_ESTILO', 'C', 'Comportamental', null, null, null);

insert into erp_dominio (NOM_DOMAIN, VAL_DOMAIN, DES_LABEL, DES_EXPLIC, DAT_INIC_VIGEN, DAT_FINAL_VIGEN)
values ('TIPO_ESTILO', 'V', 'Vida', null, null, null);

insert into erp_dominio (NOM_DOMAIN, VAL_DOMAIN, DES_LABEL, DES_EXPLIC, DAT_INIC_VIGEN, DAT_FINAL_VIGEN)
values ('TIPO_ESTILO', 'N', 'Negócio', null, null, null);
