ALTER TABLE adm_usuario_transacao
    ADD CONSTRAINT fk_tadm0005_tadm0002 FOREIGN KEY ( cod_transc )
        REFERENCES erp_transacao ( cod_transc )
    NOT DEFERRABLE;
