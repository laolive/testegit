ALTER TABLE adm_valor_campo_adicional
    ADD CONSTRAINT fk_tadm1003_tadm0023 FOREIGN KEY ( cod_grupo_campo, cod_campo )
        REFERENCES adm_campo_adicional ( cod_grupo_campo, cod_campo )
    NOT DEFERRABLE;
