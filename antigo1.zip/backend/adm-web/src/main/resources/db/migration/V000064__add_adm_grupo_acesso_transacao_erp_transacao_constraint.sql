ALTER TABLE adm_grupo_acesso_transacao
    ADD CONSTRAINT fk_tadm0004_terp0007 FOREIGN KEY ( cod_transc )
        REFERENCES erp_transacao ( cod_transc )
    NOT DEFERRABLE;
