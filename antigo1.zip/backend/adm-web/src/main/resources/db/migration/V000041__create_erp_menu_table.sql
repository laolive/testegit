CREATE TABLE erp_menu (
    cod_menu           NUMBER(6) NOT NULL,
    des_menu_aprstr    VARCHAR2(60) NOT NULL,
    des_menu_ajuda     VARCHAR2(100) NOT NULL,
    flg_ativo          CHAR(1) NOT NULL,
    cod_menu_superi    NUMBER(6),
    nro_ordem_aprstr   NUMBER(6) NOT NULL,
    cod_transc         NUMBER(6),
    des_lista_param    VARCHAR2(4000),
    des_plavra_chave   VARCHAR2(100),
    des_icone          VARCHAR2(100)
);

COMMENT ON TABLE erp_menu is 'TERP0006: Menu do Sistema';
COMMENT ON COLUMN erp_menu.cod_menu is 'Código: Código do menu';
COMMENT ON COLUMN erp_menu.des_menu_aprstr is 'Descrição: Descrição do item do menu para apresentação no sistema';
COMMENT ON COLUMN erp_menu.des_menu_ajuda is 'Ajuda: Texto orientativo sobre o item do menu';
COMMENT ON COLUMN erp_menu.flg_ativo is 'Ativo: Informa se o item do menu está ativo | FLAG';
COMMENT ON COLUMN erp_menu.cod_menu_superi is 'Menu Superior: Código do item do menu superior';
COMMENT ON COLUMN erp_menu.nro_ordem_aprstr is 'Ordem: Ordem de apresentação do item do menu conforme menu superior';
COMMENT ON COLUMN erp_menu.cod_transc is 'Transação: Código da transação a ser acionada';
COMMENT ON COLUMN erp_menu.des_lista_param is 'Lista de parâmetros: Lista de parâmetros a serem passados para a transação';
COMMENT ON COLUMN erp_menu.des_plavra_chave is 'Palavras Chaves: Contém as palavras chaves associadas ao item de menu';
COMMENT ON COLUMN ERP_MENU.des_icone is 'Ícone: Descrição do ícone usado para ilustrar o menu';

CREATE INDEX ix_fk_terp0006_terp0006 ON erp_menu ( cod_menu_superi );

CREATE INDEX ix_fk_terp0006_terp0007 ON erp_menu ( cod_transc );

CREATE INDEX ix_pk_terp0006 ON erp_menu ( cod_menu );

ALTER TABLE erp_menu
    ADD CONSTRAINT pk_terp0006 PRIMARY KEY ( cod_menu )
        USING INDEX ix_pk_terp0006;
