CREATE TABLE adm_usuario_empresa (
    cod_usu   NUMBER(6) NOT NULL,
    cod_emp   NUMBER(3) NOT NULL
);

COMMENT ON TABLE adm_usuario_empresa is'TADM0021: Empresa do Usuário';
COMMENT ON COLUMN adm_usuario_empresa.cod_usu is'Usuário: Código do usuário do sistema';
COMMENT ON COLUMN adm_usuario_empresa.cod_emp is'Empresa: Código da empresa a qual o usuário possui acesso';

CREATE INDEX ix_pk_tadm0021 ON adm_usuario_empresa ( cod_usu, cod_emp );

CREATE INDEX ix_fk_tadm0021_terp0001 ON adm_usuario_empresa ( cod_emp );

ALTER TABLE adm_usuario_empresa
    ADD CONSTRAINT pk_tadm0021 PRIMARY KEY ( cod_usu,
    cod_emp )
        USING INDEX ix_pk_tadm0021;
