insert into ERP_TRANSACAO (COD_TRANSC, NOM_TRANSC, DES_ROTA, COD_MODULO)
values (131, 'Exclusão', '/ame/exclusionType', 'AME');

insert into ERP_TRANSACAO (COD_TRANSC, NOM_TRANSC, DES_ROTA, COD_MODULO)
values (132, 'Motivo', '/ame/motive', 'AME');
