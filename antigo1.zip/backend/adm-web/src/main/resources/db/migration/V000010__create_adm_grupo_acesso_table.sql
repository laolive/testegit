CREATE TABLE adm_grupo_acesso (
    cod_emp            NUMBER(3) NOT NULL,
    cod_grupo_acesso   NUMBER(6) NOT NULL,
    des_grupo_acesso   VARCHAR2(60) NOT NULL
);

COMMENT ON TABLE adm_grupo_acesso is'TADM0001: Grupo de Acessos';
COMMENT ON COLUMN adm_grupo_acesso.cod_emp is'Empresa: Código da empresa';
COMMENT ON COLUMN adm_grupo_acesso.cod_grupo_acesso is'Código: Código do grupo de acessos';
COMMENT ON COLUMN adm_grupo_acesso.des_grupo_acesso is'Descrição: Descrição do grupo de acessos';

CREATE INDEX ix_pk_tadm0001 ON adm_grupo_acesso ( cod_emp, cod_grupo_acesso );

ALTER TABLE adm_grupo_acesso
    ADD CONSTRAINT pk_tadm0001 PRIMARY KEY ( cod_emp, cod_grupo_acesso )
        USING INDEX ix_pk_tadm0001;
