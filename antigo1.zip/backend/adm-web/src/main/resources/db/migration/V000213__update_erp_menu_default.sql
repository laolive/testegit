UPDATE ERP_MENU T SET t.cod_menu_superi = 87 WHERE t.cod_menu in (70, 86);
UPDATE ERP_MENU T SET t.cod_menu_superi = 89 WHERE t.cod_menu in (103, 104, 72, 71, 63, 64, 144, 79);
UPDATE ERP_MENU T SET t.cod_menu_superi = 92 WHERE t.cod_menu in (106, 74, 82, 60, 69, 68, 61, 73, 62);
UPDATE ERP_MENU T SET t.cod_menu_superi = 94 WHERE t.cod_menu = 80;
UPDATE ERP_MENU T SET t.cod_menu_superi = 96 WHERE t.cod_menu in (85, 77, 76, 75, 78, 84);
UPDATE ERP_MENU T SET t.cod_menu_superi = 99 WHERE t.cod_menu in (138, 107, 65, 143, 139, 67, 83, 81, 66, 102);
UPDATE ERP_MENU T SET t.des_icone = 'tag-processo' WHERE t.cod_menu in (79, 84, 102, 80);
