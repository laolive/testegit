ALTER TABLE adm_usuario_grupo_acesso
    ADD CONSTRAINT fk_tadm0003_tadm0021 FOREIGN KEY ( cod_usu,
    cod_emp )
        REFERENCES adm_usuario_empresa ( cod_usu,
        cod_emp )
    NOT DEFERRABLE;
