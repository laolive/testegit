CREATE TABLE adm_usuario_filial (
    cod_usu      NUMBER(6) NOT NULL,
    cod_emp      NUMBER(3) NOT NULL,
    cod_filial   NUMBER(3) NOT NULL,
    flg_padrao   CHAR(1) NOT NULL
);

COMMENT ON TABLE adm_usuario_filial is'TADM0014: Filial do Usuário';
COMMENT ON COLUMN adm_usuario_filial.cod_usu is'Usuário: Código do usuário do sistema';
COMMENT ON COLUMN adm_usuario_filial.cod_emp is'Empresa: Código da empresa a qual o usuário possui acesso';
COMMENT ON COLUMN adm_usuario_filial.cod_filial is'Filial: Código da filial a qual o usuário possui acesso';
COMMENT ON COLUMN adm_usuario_filial.flg_padrao is'Filial padrão: Informa se é a filial padrão do usuário na empresa | FLAG';

CREATE INDEX ix_pk_tadm0014 ON adm_usuario_filial ( cod_usu, cod_emp, cod_filial );

CREATE INDEX ix_fk_tadm0014_terp0002 ON adm_usuario_filial ( cod_emp, cod_filial );

ALTER TABLE adm_usuario_filial
    ADD CONSTRAINT pk_tadm0014 PRIMARY KEY ( cod_usu,
    cod_emp,
    cod_filial )
        USING INDEX ix_pk_tadm0014;
