create table ERP_EMPRESA_ARQUIVO (
  cod_emp NUMBER(3) not null,
  cod_arq NUMBER(38) not null,
  tip_arq VARCHAR2(1) not null
);

comment on table ERP_EMPRESA_ARQUIVO is 'TERP0050: Arquivo de empresa';
comment on column ERP_EMPRESA_ARQUIVO.cod_emp is 'Empresa: Código da empresa';
comment on column ERP_EMPRESA_ARQUIVO.cod_arq is 'Arquivo: Código do arquivo';
comment on column ERP_EMPRESA_ARQUIVO.tip_arq is 'Tipo de arquivo: Tipo de arquivo | TIPO_ARQUIVO';

create unique index IX_PK_TERP0050 on ERP_EMPRESA_ARQUIVO (COD_EMP, COD_ARQ);

alter table ERP_EMPRESA_ARQUIVO
  add constraint PK_TERP0050 primary key (COD_EMP, COD_ARQ);

alter table ERP_EMPRESA_ARQUIVO
  add constraint FK_TERP0050_TERP0001 foreign key (COD_EMP)
  references ERP_EMPRESA (COD_EMP);

alter table ERP_EMPRESA_ARQUIVO
  add constraint FK_TERP0050_TERP0026 foreign key (COD_ARQ)
  references ERP_ARQUIVO (COD_ARQ);