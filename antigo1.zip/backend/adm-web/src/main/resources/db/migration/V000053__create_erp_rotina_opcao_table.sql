CREATE TABLE erp_rotina_opcao (
    cod_rotina         NUMBER(10) NOT NULL,
    cod_opcao          NUMBER(6) NOT NULL,
    nro_ordem_aprstr   NUMBER(6) NOT NULL,
    des_label          VARCHAR2(100) NOT NULL,
    flg_obr            CHAR(1) NOT NULL,
    tip_dado           VARCHAR2(1) NOT NULL,
    nom_domain         VARCHAR2(100),
    nom_tabela         VARCHAR2(30),
    qtd_tmanho_min     NUMBER(3),
    qtd_tmanho_max     NUMBER(3),
    val_padrao         VARCHAR2(100),
    dat_ativ           DATE,
    dat_inativ         DATE,
    des_obs            VARCHAR2(2000)
);

COMMENT ON TABLE erp_rotina_opcao is 'TERP0024: Opção da Rotina';
COMMENT ON COLUMN erp_rotina_opcao.cod_rotina is 'Rotina: Código da rotina';
COMMENT ON COLUMN erp_rotina_opcao.cod_opcao is 'Código: Código da opção';
COMMENT ON COLUMN erp_rotina_opcao.nro_ordem_aprstr is 'Ordem: Ordem para apresentação da opção';
COMMENT ON COLUMN erp_rotina_opcao.des_label is 'Label: Label (texto) que será apresentada para a opção';
COMMENT ON COLUMN erp_rotina_opcao.flg_obr is 'Obrigatório: Informa se a opção é de preenchimento obrigatório | FLAG';
COMMENT ON COLUMN erp_rotina_opcao.tip_dado is 'Tipo de dado: Tipo de dado permitido para a opção | TIPO_DADO';
COMMENT ON COLUMN erp_rotina_opcao.nom_domain is 'Domínio: Nome do domínio que contém os valores permitidos no valor da opção';
COMMENT ON COLUMN erp_rotina_opcao.nom_tabela is 'Tabela: Nome da tabela que contém os valores permitidos no valor do parâmetro';
COMMENT ON COLUMN erp_rotina_opcao.qtd_tmanho_min is 'Tamanho mínimo: Quantidade mínima de caracteres ao preencher a opção';
COMMENT ON COLUMN erp_rotina_opcao.qtd_tmanho_max is 'Tamanho máximo: Quantidade máxima de caracteres ao preencher a opção';
COMMENT ON COLUMN erp_rotina_opcao.val_padrao is 'Valor: Valor padrão para a opção';
COMMENT ON COLUMN erp_rotina_opcao.dat_ativ is 'Data da ativação: Data da ativação do valor da opção';
COMMENT ON COLUMN erp_rotina_opcao.dat_inativ is 'Data da inativação: Data da inativação do valor da opção';
COMMENT ON COLUMN erp_rotina_opcao.des_obs is 'Observação: Orientação sobre o preenchimento e utilidade da opção';

CREATE UNIQUE INDEX ix_pk_terp0024 ON erp_rotina_opcao ( cod_rotina ASC, cod_opcao );

ALTER TABLE erp_rotina_opcao
    ADD CONSTRAINT pk_terp0024 PRIMARY KEY ( cod_rotina,
    cod_opcao )
        USING INDEX ix_pk_terp0024;
