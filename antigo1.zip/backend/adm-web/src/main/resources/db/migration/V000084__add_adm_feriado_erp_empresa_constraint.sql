ALTER TABLE adm_feriado
    ADD CONSTRAINT fk_tadm0015_terp0001 FOREIGN KEY ( cod_emp )
        REFERENCES erp_empresa ( cod_emp )
    NOT DEFERRABLE;
