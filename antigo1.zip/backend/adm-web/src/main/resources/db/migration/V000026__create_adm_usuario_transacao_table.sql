CREATE TABLE adm_usuario_transacao (
    cod_usu      NUMBER(6) NOT NULL,
    cod_emp      NUMBER(3) NOT NULL,
    cod_transc   NUMBER(6) NOT NULL,
    flg_incl     CHAR(1) NOT NULL,
    flg_alt      CHAR(1) NOT NULL,
    flg_excl     CHAR(1) NOT NULL
);

COMMENT ON TABLE adm_usuario_transacao is 'TADM0005: Transação do Usuário';
COMMENT ON COLUMN adm_usuario_transacao.cod_usu is 'Código: Código do usuário';
COMMENT ON COLUMN adm_usuario_transacao.cod_emp is 'Empresa: Código da empresa';
COMMENT ON COLUMN adm_usuario_transacao.cod_transc is 'Transação: Código da transação';
COMMENT ON COLUMN adm_usuario_transacao.flg_incl is 'Inclusão: Informa se o usuário possui permissão de inclusão na transação | FLAG';
COMMENT ON COLUMN adm_usuario_transacao.flg_alt is 'Alteração: Informa se o usuário possui permissão de alteração na transação | FLAG';
COMMENT ON COLUMN adm_usuario_transacao.flg_excl is 'Exclusão: Informa se o usuário possui permissão de exclusão na transação | FLAG';

CREATE INDEX ix_pk_tadm0005 ON adm_usuario_transacao ( cod_usu, cod_emp, cod_transc );

CREATE INDEX ix_fk_tadm0005_terp0007 ON adm_usuario_transacao ( cod_transc );

ALTER TABLE adm_usuario_transacao
    ADD CONSTRAINT pk_tadm0005 PRIMARY KEY ( cod_usu,
    cod_emp,
    cod_transc )
        USING INDEX ix_pk_tadm0005;
