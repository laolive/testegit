CREATE TABLE adm_usuario_campo (
    cod_usu      NUMBER(6) NOT NULL,
    cod_emp      NUMBER(3) NOT NULL,
    cod_transc   NUMBER(6) NOT NULL,
    nom_campo    VARCHAR2(30) NOT NULL,
    flg_aprstr   CHAR(1) NOT NULL,
    flg_alt      CHAR(1) NOT NULL,
    val_padrao   VARCHAR2(100)
);

COMMENT ON TABLE adm_usuario_campo is'TADM0009: Campo do Usuário';
COMMENT ON COLUMN adm_usuario_campo.cod_usu is'Código: Código do usuário';
COMMENT ON COLUMN adm_usuario_campo.cod_emp is'Empresa: Código da empresa';
COMMENT ON COLUMN adm_usuario_campo.cod_transc is'Transação: Código da transação';
COMMENT ON COLUMN adm_usuario_campo.nom_campo is'Campo: Nome do campo da transação';
COMMENT ON COLUMN adm_usuario_campo.flg_aprstr is'Visualiza: Informa se o usuário tem permissão para visualizar o conteúdo do campo | FLAG';
COMMENT ON COLUMN adm_usuario_campo.flg_alt is'Alteração: Informa se o usuário possui permissão para alterar o conteúdo do campo | FLAG';
COMMENT ON COLUMN adm_usuario_campo.val_padrao is'Valor padrão: Valor padrão do campo para o usuário';

CREATE INDEX ix_pk_tadm0009 ON adm_usuario_campo ( cod_usu, cod_emp, cod_transc, nom_campo );

CREATE INDEX ix_fk_tadm0009_terp0008 ON adm_usuario_campo ( cod_transc, nom_campo );

ALTER TABLE adm_usuario_campo
    ADD CONSTRAINT pk_tadm0009 PRIMARY KEY ( cod_usu,
    cod_emp,
    cod_transc,
    nom_campo )
        USING INDEX ix_pk_tadm0009;
