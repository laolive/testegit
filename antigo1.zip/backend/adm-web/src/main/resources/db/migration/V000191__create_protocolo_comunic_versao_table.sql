CREATE TABLE protocolo_comunic_versao (
    id                         NUMBER(18) NOT NULL,
    protocolo_comunicacao_id   NUMBER(18) NOT NULL,
    versao                     VARCHAR2(10) NOT NULL,
    data_vigencia              DATE NOT NULL
);

ALTER TABLE protocolo_comunic_versao
    ADD CONSTRAINT protocolo_comunic_versao_pk
        PRIMARY KEY (id);

ALTER TABLE protocolo_comunic_versao
    ADD CONSTRAINT versao_protocol_comunic_id_fk
        FOREIGN KEY (protocolo_comunicacao_id) REFERENCES protocolo_comunicacao (id);

ALTER TABLE protocolo_comunic_versao
    ADD CONSTRAINT protocolo_comunic_versao_uk
        UNIQUE (protocolo_comunicacao_id,versao);

COMMENT ON TABLE protocolo_comunic_versao is 'Versão do protocolo de comunicação';
COMMENT ON COLUMN protocolo_comunic_versao.id is 'ID da versão do protocolo de comunicação';
COMMENT ON COLUMN protocolo_comunic_versao.protocolo_comunicacao_id is 'ID do protocolo de comunicação';
COMMENT ON COLUMN protocolo_comunic_versao.versao is 'Número da versão do protocolo de comunicação';
COMMENT ON COLUMN protocolo_comunic_versao.data_vigencia is 'Data de início de vigência da versão do protocolo de comunicação';
