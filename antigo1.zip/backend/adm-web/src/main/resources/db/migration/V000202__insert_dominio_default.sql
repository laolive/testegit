insert into DOMINIO (id, nome, descricao)
values (96, 'UNIDADE_FEDERATIVA', null);
