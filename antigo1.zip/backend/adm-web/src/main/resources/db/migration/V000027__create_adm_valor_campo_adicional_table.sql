CREATE TABLE adm_valor_campo_adicional (
    val_chave_reg     VARCHAR2(4000) NOT NULL,
    cod_grupo_campo   NUMBER(38) NOT NULL,
    cod_campo         NUMBER(3) NOT NULL,
    val_contd         VARCHAR2(4000)
);

COMMENT ON TABLE adm_valor_campo_adicional is 'TADM1003: Valor do Campo Adicional';
COMMENT ON COLUMN adm_valor_campo_adicional.val_chave_reg is 'Chave: Chave identificadora do registro relacionado';
COMMENT ON COLUMN adm_valor_campo_adicional.cod_grupo_campo is 'Código: Código do grupo de campos da transação';
COMMENT ON COLUMN adm_valor_campo_adicional.cod_campo is 'Código: Código do campo';
COMMENT ON COLUMN adm_valor_campo_adicional.val_contd is 'Conteúdo: Conteúdo do campo adicional';

CREATE UNIQUE INDEX ix_pk_tadm1003 ON
    adm_valor_campo_adicional (
        val_chave_reg,
        cod_grupo_campo,
        cod_campo
    );

ALTER TABLE adm_valor_campo_adicional
    ADD CONSTRAINT pk_tadm1003 PRIMARY KEY ( val_chave_reg,
    cod_grupo_campo,
    cod_campo )
        USING INDEX ix_pk_tadm1003;
