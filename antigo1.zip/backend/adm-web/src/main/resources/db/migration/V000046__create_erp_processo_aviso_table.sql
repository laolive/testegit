CREATE TABLE erp_processo_aviso (
    cod_prcsso   NUMBER(38) NOT NULL,
    cod_seq      NUMBER(6) NOT NULL,
    des_aviso    VARCHAR2(4000) NOT NULL,
    des_chave    VARCHAR2(4000)
);

COMMENT ON TABLE erp_processo_aviso is 'TERP0018: Aviso do Processo';
COMMENT ON COLUMN erp_processo_aviso.cod_prcsso is 'Agendamento: Numeração sequencial do agendamento do processo';
COMMENT ON COLUMN erp_processo_aviso.cod_seq is 'Seq.: Número sequencial do aviso gerado pelo processo';
COMMENT ON COLUMN erp_processo_aviso.des_aviso is 'Aviso: Mensagem de aviso gerada';
COMMENT ON COLUMN erp_processo_aviso.des_chave is 'Localizador: Localizador/chave do registro a partir do qual foi gerado o aviso';

CREATE UNIQUE INDEX ix_pk_terp0018 ON erp_processo_aviso ( cod_prcsso, cod_seq );

ALTER TABLE erp_processo_aviso
    ADD CONSTRAINT pk_terp0018 PRIMARY KEY ( cod_prcsso,
    cod_seq )
        USING INDEX ix_pk_terp0018;

CREATE SEQUENCE s_terp0018 START WITH 1 NOCACHE ORDER;
