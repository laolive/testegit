ALTER TABLE erp_arquivo
    ADD CONSTRAINT fk_terp0026_terp0001 FOREIGN KEY ( cod_emp )
        REFERENCES erp_empresa ( cod_emp )
    NOT DEFERRABLE;
