ALTER TABLE erp_empresa
    ADD CONSTRAINT fk_terp0001_terp0023 FOREIGN KEY ( cod_grupo_emprsl )
        REFERENCES erp_grupo_empresarial ( cod_grupo_emprsl )
    NOT DEFERRABLE;
