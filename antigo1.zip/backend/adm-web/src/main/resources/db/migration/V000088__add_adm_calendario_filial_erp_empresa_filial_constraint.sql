ALTER TABLE adm_calendario_filial
    ADD CONSTRAINT fk_tadm0018_terp0002 FOREIGN KEY ( cod_emp, cod_filial )
        REFERENCES erp_empresa_filial ( cod_emp, cod_filial )
    NOT DEFERRABLE;
