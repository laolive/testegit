CREATE TABLE erp_terminologia_res (
    nom_agrmto_trmnol   VARCHAR2(30) NOT NULL,
    cod_idioma          VARCHAR2(10) NOT NULL,
    cod_trmnol          VARCHAR2(10) NOT NULL,
    des_trmnol          VARCHAR2(255) NOT NULL,
    tip_trmnol          VARCHAR2(10) NOT NULL
);

COMMENT ON TABLE erp_terminologia_res is 'TERP0031: Terminologia RES';
COMMENT ON COLUMN erp_terminologia_res.nom_agrmto_trmnol is 'Agrupamento: Agrupamento da terminologia';
COMMENT ON COLUMN erp_terminologia_res.cod_idioma is 'Idioma: Sigla do idioma da terminologia';
COMMENT ON COLUMN erp_terminologia_res.cod_trmnol is 'Código: Código da terminologia';
COMMENT ON COLUMN erp_terminologia_res.des_trmnol is 'Descrição: Descrição da terminologia';
COMMENT ON COLUMN erp_terminologia_res.tip_trmnol is 'Tipo: Tipo da terminologia';

CREATE INDEX ix_pk_terp0031 ON erp_terminologia_res ( nom_agrmto_trmnol, cod_idioma, cod_trmnol );

ALTER TABLE erp_terminologia_res
    ADD CONSTRAINT pk_terp0031 PRIMARY KEY ( nom_agrmto_trmnol,
    cod_idioma,
    cod_trmnol )
        USING INDEX ix_pk_terp0031;
