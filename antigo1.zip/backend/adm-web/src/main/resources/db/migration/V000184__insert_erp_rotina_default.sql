insert into ERP_ROTINA (COD_ROTINA, DES_ROTINA, NOM_PRC_BCO_DADOS, COD_MODULO, DES_OBS)
values (1, 'Padrão', 'Nenhum', 'ADM', null);
