ALTER TABLE adm_usuario_campo
    ADD CONSTRAINT fk_tadm0009_terp0008 FOREIGN KEY ( cod_transc,
    nom_campo )
        REFERENCES erp_transacao_campo ( cod_transc,
        nom_campo )
    NOT DEFERRABLE;
