CREATE TABLE erp_rotina_sql (
    cod_rotina              NUMBER(10) NOT NULL,
    des_comndo              CLOB NOT NULL,
    ind_forma_grcao_cablh   VARCHAR2(1) NOT NULL,
    des_titulo              VARCHAR2(100),
    des_crctre_sep          VARCHAR2(1),
    des_crctre_dlimit       VARCHAR2(1),
    nom_dir                 VARCHAR2(30)
);

COMMENT ON TABLE erp_rotina_sql is 'TERP0022: SQL da Rotina';
COMMENT ON COLUMN erp_rotina_sql.cod_rotina is 'Rotina: Código da rotina';
COMMENT ON COLUMN erp_rotina_sql.des_comndo is 'Comando: Instrução SQL a ser executada';
COMMENT ON COLUMN erp_rotina_sql.ind_forma_grcao_cablh is 'Cabeçalho: Informa sobre a utilização do cabeçalho e suas informações | FORMA_GERACAO_CABECALHO';
COMMENT ON COLUMN erp_rotina_sql.des_titulo is 'Título: Informa o título a ser apresentado no cabeçalho da listagem';
COMMENT ON COLUMN erp_rotina_sql.des_crctre_sep is 'Separador: Caracter utilizado para separar as informações';
COMMENT ON COLUMN erp_rotina_sql.des_crctre_dlimit is 'Delimitador: Caractere que determina os limites das informações';
COMMENT ON COLUMN erp_rotina_sql.nom_dir is 'Nome do diretório: Nome que identifica o diretório de localização do arquivo';

CREATE UNIQUE INDEX ix_pk_terp0022 ON erp_rotina_sql ( cod_rotina );

ALTER TABLE erp_rotina_sql
    ADD CONSTRAINT pk_terp0022 PRIMARY KEY ( cod_rotina )
        USING INDEX ix_pk_terp0022;
