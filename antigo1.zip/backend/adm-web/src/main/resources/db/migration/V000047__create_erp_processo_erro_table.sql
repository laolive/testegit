CREATE TABLE erp_processo_erro (
    cod_prcsso      NUMBER(38) NOT NULL,
    cod_seq         NUMBER(6) NOT NULL,
    des_erro        VARCHAR2(4000) NOT NULL,
    des_erro_orig   VARCHAR2(4000),
    des_chave       VARCHAR2(4000)
);

COMMENT ON TABLE erp_processo_erro is 'TERP0019: Erro do Processo';
COMMENT ON COLUMN erp_processo_erro.cod_prcsso is 'Agendamento: Numeração sequencial do agendamento do processo';
COMMENT ON COLUMN erp_processo_erro.cod_seq is 'Seq.: Número sequencial do erro gerado pelo processo';
COMMENT ON COLUMN erp_processo_erro.des_erro is 'Erro: Mensagem de erro gerada';
COMMENT ON COLUMN erp_processo_erro.des_erro_orig is 'Erro original: Texto original da mensagem de erro gerada';
COMMENT ON COLUMN erp_processo_erro.des_chave is 'Localizador: Localizador/chave do registro a partir do qual foi gerado o erro';

CREATE UNIQUE INDEX ix_pk_terp0019 ON erp_processo_erro ( cod_prcsso, cod_seq );

ALTER TABLE erp_processo_erro
    ADD CONSTRAINT pk_terp0019 PRIMARY KEY ( cod_prcsso,
    cod_seq )
        USING INDEX ix_pk_terp0019;

CREATE SEQUENCE s_terp0019 START WITH 1 NOCACHE ORDER;
