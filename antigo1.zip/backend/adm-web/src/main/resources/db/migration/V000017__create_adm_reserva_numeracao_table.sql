CREATE TABLE adm_reserva_numeracao (
    cod_emp           NUMBER(3) NOT NULL,
    cod_reserv        VARCHAR2(50) NOT NULL,
    nom_tabela        VARCHAR2(30) NOT NULL,
    dth_reserv        DATE NOT NULL,
    flg_permit_excl   CHAR(1) NOT NULL
);

COMMENT ON TABLE adm_reserva_numeracao is'TADM1002: Reserva de Numeração';
COMMENT ON COLUMN adm_reserva_numeracao.cod_emp is'Empresa: Código da empresa para qual o número foi reservado';
COMMENT ON COLUMN adm_reserva_numeracao.cod_reserv is'Código reservado: Código reservado pelo sistema';
COMMENT ON COLUMN adm_reserva_numeracao.nom_tabela is'Tabela: Nome da tabela que controla a autonumeração';
COMMENT ON COLUMN adm_reserva_numeracao.dth_reserv is'Data da reserva: Data e hora em que o código foi reservado';
COMMENT ON COLUMN adm_reserva_numeracao.flg_permit_excl is'Exclui registro: Indica se o registro pode ou não ser excluído | FLAG';

CREATE INDEX ix_pk_tadm1002 ON adm_reserva_numeracao ( cod_emp, cod_reserv, nom_tabela );

ALTER TABLE adm_reserva_numeracao
    ADD CONSTRAINT pk_tadm1002 PRIMARY KEY ( cod_emp,
    cod_reserv,
    nom_tabela )
        USING INDEX ix_pk_tadm1002;
