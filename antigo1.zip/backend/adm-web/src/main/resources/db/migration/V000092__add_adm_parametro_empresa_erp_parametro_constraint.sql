ALTER TABLE adm_parametro_empresa
    ADD CONSTRAINT fk_tadm0020_terp0005 FOREIGN KEY ( cod_param )
        REFERENCES erp_parametro ( cod_param )
    NOT DEFERRABLE;
