insert into ADM_GRUPO_ACESSO (COD_EMP, COD_GRUPO_ACESSO, DES_GRUPO_ACESSO)
values (1, 1, 'Administrador');
