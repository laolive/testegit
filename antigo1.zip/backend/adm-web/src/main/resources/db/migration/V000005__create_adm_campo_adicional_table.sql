CREATE TABLE adm_campo_adicional (
    cod_grupo_campo    NUMBER(38) NOT NULL,
    cod_campo          NUMBER(3) NOT NULL,
    nro_ordem_aprstr   NUMBER(6) NOT NULL,
    des_label          VARCHAR2(100) NOT NULL,
    flg_obr            CHAR(1) NOT NULL,
    tip_dado           VARCHAR2(1) NOT NULL,
    nom_domain         VARCHAR2(100),
    nom_tabela         VARCHAR2(30),
    qtd_tmanho_min     NUMBER(3),
    qtd_tmanho_max     NUMBER(3),
    val_padrao         VARCHAR2(100),
    dat_ativ           DATE,
    dat_inativ         DATE,
    des_obs            VARCHAR2(2000)
);

COMMENT ON TABLE adm_campo_adicional is'TADM0023: Configuração do Campo Adicional';
COMMENT ON COLUMN adm_campo_adicional.cod_grupo_campo is'Código: Código do grupo de campos da transação';
COMMENT ON COLUMN adm_campo_adicional.cod_campo is'Código: Código do campo';
COMMENT ON COLUMN adm_campo_adicional.nro_ordem_aprstr is'Ordem: Ordem para apresentação do campo';
COMMENT ON COLUMN adm_campo_adicional.des_label is'Label: Label (texto) que será apresentada para o campo';
COMMENT ON COLUMN adm_campo_adicional.flg_obr is'Obrigatório: Informa se o campo é de preenchimento obrigatório | FLAG';
COMMENT ON COLUMN adm_campo_adicional.tip_dado is'Tipo de dado: Tipo de dado permitido para o campo | TIPO_DADO';
COMMENT ON COLUMN adm_campo_adicional.nom_domain is'Domínio: Nome do domínio que contém os valores permitidos para campo';
COMMENT ON COLUMN adm_campo_adicional.nom_tabela is'Tabela: Nome da tabela que contém os valores permitidos para o campo';
COMMENT ON COLUMN adm_campo_adicional.qtd_tmanho_min is'Tamanho mínimo: Quantidade mínima de caracteres ao preencher o campo';
COMMENT ON COLUMN adm_campo_adicional.qtd_tmanho_max is'Tamanho máximo: Quantidade máxima de caracteres ao preencher o campo';
COMMENT ON COLUMN adm_campo_adicional.val_padrao is'Valor: Valor padrão para o campo';
COMMENT ON COLUMN adm_campo_adicional.dat_ativ is'Data da ativação: Data da ativação do campo';
COMMENT ON COLUMN adm_campo_adicional.dat_inativ is'Data da inativação: Data da inativação do campo';
COMMENT ON COLUMN adm_campo_adicional.des_obs is'Observação: Orientação sobre o preenchimento e utilidade do campo';

CREATE UNIQUE INDEX ix_pk_tadm0023 ON adm_campo_adicional ( cod_grupo_campo ASC,
    cod_campo );

ALTER TABLE adm_campo_adicional
    ADD CONSTRAINT pk_tadm0023 PRIMARY KEY ( cod_grupo_campo,
    cod_campo )
        USING INDEX ix_pk_tadm0023;
