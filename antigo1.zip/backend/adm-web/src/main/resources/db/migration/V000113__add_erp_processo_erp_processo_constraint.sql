ALTER TABLE erp_processo
    ADD CONSTRAINT fk_terp0015_terp0015 FOREIGN KEY ( cod_prcsso_orig )
        REFERENCES erp_processo ( cod_prcsso )
    NOT DEFERRABLE;
