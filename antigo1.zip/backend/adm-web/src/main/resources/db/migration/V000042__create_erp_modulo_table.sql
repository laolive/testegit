CREATE TABLE erp_modulo (
    cod_modulo          VARCHAR2(10) NOT NULL,
    des_modulo          VARCHAR2(60) NOT NULL,
    flg_cntrla_period   CHAR(1) NOT NULL
);

COMMENT ON TABLE erp_modulo is 'TERP0003: Módulo';
COMMENT ON COLUMN erp_modulo.cod_modulo is 'Código: Código do módulo do sistema';
COMMENT ON COLUMN erp_modulo.des_modulo is 'Decrição: Decrição do módulo do sistema';
COMMENT ON COLUMN erp_modulo.flg_cntrla_period is 'Controlado por período: Informa se o módulo é controlado por período (bloqueio de lançamentos por data limite) | FLAG';

CREATE UNIQUE INDEX ix_pk_terp0003 ON erp_modulo ( cod_modulo );

ALTER TABLE erp_modulo
    ADD CONSTRAINT pk_terp0003 PRIMARY KEY ( cod_modulo )
        USING INDEX ix_pk_terp0003;
