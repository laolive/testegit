CREATE TABLE adm_usuario_favorito (
    cod_usu    NUMBER(6) NOT NULL,
    cod_emp    NUMBER(3) NOT NULL,
    cod_menu   NUMBER(6) NOT NULL
);

COMMENT ON TABLE adm_usuario_favorito is'TADM0013: Menu Favorito do Usuário';
COMMENT ON COLUMN adm_usuario_favorito.cod_usu is'Usuário: Código do usuário do sistema';
COMMENT ON COLUMN adm_usuario_favorito.cod_emp is'Empresa: Código da Empresa';
COMMENT ON COLUMN adm_usuario_favorito.cod_menu is'Menu: Código do item de menu do sistema favorito do usuário';

CREATE INDEX ix_pk_tadm0013 ON adm_usuario_favorito ( cod_usu, cod_emp, cod_menu );

CREATE INDEX ix_fk_tadm0013_terp0006 ON adm_usuario_favorito ( cod_menu );

ALTER TABLE adm_usuario_favorito
    ADD CONSTRAINT pk_tadm0013 PRIMARY KEY ( cod_usu,
    cod_emp,
    cod_menu )
        USING INDEX ix_pk_tadm0013;
