insert into erp_empresa (COD_EMP, NOM_EMP_APRSTR, COD_GRUPO_EMPRSL)
values (1, 'INFORMAR', 1);
