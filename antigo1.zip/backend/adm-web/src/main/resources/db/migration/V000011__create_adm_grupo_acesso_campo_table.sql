CREATE TABLE adm_grupo_acesso_campo (
    cod_emp            NUMBER(3) NOT NULL,
    cod_grupo_acesso   NUMBER(6) NOT NULL,
    cod_transc         NUMBER(6) NOT NULL,
    nom_campo          VARCHAR2(30) NOT NULL,
    flg_aprstr         CHAR(1) NOT NULL,
    flg_alt            CHAR(1) NOT NULL,
    val_padrao         VARCHAR2(100)
);

COMMENT ON TABLE adm_grupo_acesso_campo is'TADM0008: Campo do Grupo de Acessos';
COMMENT ON COLUMN adm_grupo_acesso_campo.cod_emp is'Empresa: Código da empresa';
COMMENT ON COLUMN adm_grupo_acesso_campo.cod_grupo_acesso is'Grupo de acessos: Código do grupo de acessos';
COMMENT ON COLUMN adm_grupo_acesso_campo.cod_transc is'Transação: Código da transação';
COMMENT ON COLUMN adm_grupo_acesso_campo.nom_campo is'Campo: Nome do campo da transação';
COMMENT ON COLUMN adm_grupo_acesso_campo.flg_aprstr is'Visualiza: Informa se o grupo de acessos tem permissão para visualizar o conteúdo do campo | FLAG';
COMMENT ON COLUMN adm_grupo_acesso_campo.flg_alt is'Alteração: Informa se o grupo de acessos possui permissão para alterar o conteúdo do campo | FLAG';
COMMENT ON COLUMN adm_grupo_acesso_campo.val_padrao is'Valor padrão: Valor padrão do campo para o grupo de acessos';

CREATE UNIQUE INDEX ix_pk_tadm0008 ON adm_grupo_acesso_campo (
        cod_emp,
        cod_grupo_acesso,
        cod_transc,
        nom_campo
    );

CREATE INDEX ix_fk_tadm0008_terp0008 ON adm_grupo_acesso_campo ( cod_transc,
    nom_campo );

ALTER TABLE adm_grupo_acesso_campo
    ADD CONSTRAINT pk_tadm0008 PRIMARY KEY ( cod_emp,
    cod_grupo_acesso,
    cod_transc,
    nom_campo )
        USING INDEX ix_pk_tadm0008;
