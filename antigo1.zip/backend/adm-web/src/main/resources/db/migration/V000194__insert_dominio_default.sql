insert into DOMINIO (id, nome, descricao)
values (1, 'ATENDIMENTO_ACAO', null);
insert into DOMINIO (id, nome, descricao)
values (2, 'CARATER_ATENDIMENTO', null);
insert into DOMINIO (id, nome, descricao)
values (3, 'CLASSIFICACAO_FLUXO_CAIXA', null);
insert into DOMINIO (id, nome, descricao)
values (4, 'CLASSIFICACAO_METASTASE', null);
insert into DOMINIO (id, nome, descricao)
values (5, 'CLASSIFICACAO_NODULO', null);
insert into DOMINIO (id, nome, descricao)
values (6, 'CLASSIFICACAO_TUMOR', null);
insert into DOMINIO (id, nome, descricao)
values (7, 'CONSELHO_PROFISSIONAL', null);
insert into DOMINIO (id, nome, descricao)
values (8, 'DIAGNOSTICO_IMAGEM', null);
insert into DOMINIO (id, nome, descricao)
values (9, 'ECOG', null);
insert into DOMINIO (id, nome, descricao)
values (10, 'ENVIADA_RECEBIDA', null);
insert into DOMINIO (id, nome, descricao)
values (11, 'ESTADIAMENTO_TUMOR', null);
insert into DOMINIO (id, nome, descricao)
values (12, 'ESTADO_CIVIL', null);
insert into DOMINIO (id, nome, descricao)
values (13, 'FERIADO_ABRANGENCIA', null);
insert into DOMINIO (id, nome, descricao)
values (14, 'FINALIDADE_ENDERECO', null);
insert into DOMINIO (id, nome, descricao)
values (15, 'FINALIDADE_TRATAMENTO', null);
insert into DOMINIO (id, nome, descricao)
values (16, 'FLAG', null);
insert into DOMINIO (id, nome, descricao)
values (17, 'FORMA_AGENDAMENTO', null);
insert into DOMINIO (id, nome, descricao)
values (18, 'FORMA_CONTATO', null);
insert into DOMINIO (id, nome, descricao)
values (19, 'FORMA_GERACAO_CABECALHO', null);
insert into DOMINIO (id, nome, descricao)
values (20, 'FORMA_PAGAMENTO', null);
insert into DOMINIO (id, nome, descricao)
values (21, 'INDICADOR_ACIDENTE', null);
insert into DOMINIO (id, nome, descricao)
values (22, 'NIVEL_ACESSO', null);
insert into DOMINIO (id, nome, descricao)
values (23, 'OPCAO_FABRICANTE_OPME', null);
insert into DOMINIO (id, nome, descricao)
values (24, 'OPCAO_PARAMETRO_USUARIO', null);
insert into DOMINIO (id, nome, descricao)
values (25, 'ORIGEM_CID', null);
insert into DOMINIO (id, nome, descricao)
values (26, 'ORIGEM_PROTOCOLO', null);
insert into DOMINIO (id, nome, descricao)
values (27, 'PAPEL_CRM', null);
insert into DOMINIO (id, nome, descricao)
values (28, 'PROTOCOLO_PERFIL', null);
insert into DOMINIO (id, nome, descricao)
values (29, 'REGIME_INTERNACAO', null);
insert into DOMINIO (id, nome, descricao)
values (30, 'RELACAO_REQUISITO', null);
insert into DOMINIO (id, nome, descricao)
values (31, 'SEXO', null);
insert into DOMINIO (id, nome, descricao)
values (32, 'SITUACAO_FILA_EXECUCAO', null);
insert into DOMINIO (id, nome, descricao)
values (33, 'SITUACAO_FORNECEDOR', null);
insert into DOMINIO (id, nome, descricao)
values (34, 'SITUACAO_REQUISITO', null);
insert into DOMINIO (id, nome, descricao)
values (35, 'STATUS_AUTORIZACAO', null);
insert into DOMINIO (id, nome, descricao)
values (36, 'STATUS_PROTOCOLO_AME', null);
insert into DOMINIO (id, nome, descricao)
values (37, 'STATUS_PROTOCOLO_CRM', null);
insert into DOMINIO (id, nome, descricao)
values (38, 'STATUS_PROTOCOLO_WEB', null);
insert into DOMINIO (id, nome, descricao)
values (39, 'TABELA_REFERENCIA_PTU', null);
insert into DOMINIO (id, nome, descricao)
values (40, 'TABELA_REFERENCIA_TISS', null);
insert into DOMINIO (id, nome, descricao)
values (41, 'TIPO_ABRANGENCIA_AME', null);
insert into DOMINIO (id, nome, descricao)
values (42, 'TIPO_ACOMODACAO', null);
insert into DOMINIO (id, nome, descricao)
values (43, 'TIPO_ACOMODACAO_AME', null);
insert into DOMINIO (id, nome, descricao)
values (44, 'TIPO_ACOMODACAO_PTU', null);
insert into DOMINIO (id, nome, descricao)
values (45, 'TIPO_ALERTA_USUARIO', null);
insert into DOMINIO (id, nome, descricao)
values (46, 'TIPO_ANEXO_GUIA', null);
insert into DOMINIO (id, nome, descricao)
values (47, 'TIPO_ARQUIVO', null);
insert into DOMINIO (id, nome, descricao)
values (48, 'TIPO_ATRIBUTO_REQUISITO', null);
insert into DOMINIO (id, nome, descricao)
values (49, 'TIPO_CAMPANHA_CATEGORIA', null);
insert into DOMINIO (id, nome, descricao)
values (50, 'TIPO_CAMPO', null);
insert into DOMINIO (id, nome, descricao)
values (51, 'TIPO_CARACTERE', null);
insert into DOMINIO (id, nome, descricao)
values (53, 'TIPO_CATEGORIA', null);
insert into DOMINIO (id, nome, descricao)
values (54, 'TIPO_CEP', null);
insert into DOMINIO (id, nome, descricao)
values (55, 'TIPO_COMPARACAO_REGRA', null);
insert into DOMINIO (id, nome, descricao)
values (56, 'TIPO_CONTA_BANCARIA', null);
insert into DOMINIO (id, nome, descricao)
values (57, 'TIPO_CONTRATO_AME', null);
insert into DOMINIO (id, nome, descricao)
values (58, 'TIPO_DADO', null);
insert into DOMINIO (id, nome, descricao)
values (59, 'TIPO_DISTRIBUICAO_IMPOSTO', null);
insert into DOMINIO (id, nome, descricao)
values (60, 'TIPO_ENDERECO', null);
insert into DOMINIO (id, nome, descricao)
values (61, 'TIPO_ENVIO_ALERTA_USUARIO', null);
insert into DOMINIO (id, nome, descricao)
values (62, 'TIPO_EXCECAO_AME', null);
insert into DOMINIO (id, nome, descricao)
values (63, 'TIPO_FASE', null);
insert into DOMINIO (id, nome, descricao)
values (64, 'TIPO_INTERNACAO', null);
insert into DOMINIO (id, nome, descricao)
values (65, 'TIPO_INTERNACAO_AME', null);
insert into DOMINIO (id, nome, descricao)
values (66, 'TIPO_ITEM_AME', null);
insert into DOMINIO (id, nome, descricao)
values (67, 'TIPO_LOTE_PAGAMENTO', null);
insert into DOMINIO (id, nome, descricao)
values (68, 'TIPO_MANIFESTACAO', null);
insert into DOMINIO (id, nome, descricao)
values (69, 'TIPO_MATRIZ_ACAO', null);
insert into DOMINIO (id, nome, descricao)
values (70, 'TIPO_MENSAGEM_SISTEMA', null);
insert into DOMINIO (id, nome, descricao)
values (71, 'TIPO_MODALIDADE_PLANO_AME', null);
insert into DOMINIO (id, nome, descricao)
values (72, 'TIPO_MOVIMENTO_PROTOCOLO', null);
insert into DOMINIO (id, nome, descricao)
values (73, 'TIPO_NATUREZA_FLUXO_CAIXA', null);
insert into DOMINIO (id, nome, descricao)
values (74, 'TIPO_OPERACAO_AUDITORIA', null);
insert into DOMINIO (id, nome, descricao)
values (75, 'TIPO_OPERADOR_LOGICO', null);
insert into DOMINIO (id, nome, descricao)
values (76, 'TIPO_PAPEL_AME', null);
insert into DOMINIO (id, nome, descricao)
values (77, 'TIPO_PARTICIPACAO_AME', null);
insert into DOMINIO (id, nome, descricao)
values (78, 'TIPO_PESSOA', null);
insert into DOMINIO (id, nome, descricao)
values (79, 'TIPO_PRESTADOR_AME', null);
insert into DOMINIO (id, nome, descricao)
values (80, 'TIPO_PUBLICO', null);
insert into DOMINIO (id, nome, descricao)
values (81, 'TIPO_QUIMIOTERAPIA', null);
insert into DOMINIO (id, nome, descricao)
values (82, 'TIPO_REAJUSTE_AME', null);
insert into DOMINIO (id, nome, descricao)
values (83, 'TIPO_REDE_AME', null);
insert into DOMINIO (id, nome, descricao)
values (84, 'TIPO_REDE_CREDENCIADA', null);
insert into DOMINIO (id, nome, descricao)
values (85, 'TIPO_SEGMENTACAO_AME', null);
insert into DOMINIO (id, nome, descricao)
values (86, 'TIPO_TAREFA', null);
insert into DOMINIO (id, nome, descricao)
values (87, 'TIPO_TERAPIA', null);
insert into DOMINIO (id, nome, descricao)
values (88, 'TIPO_UNIMED', null);
insert into DOMINIO (id, nome, descricao)
values (89, 'TIPO_VENDEDOR', null);
insert into DOMINIO (id, nome, descricao)
values (90, 'TIPO_VERSAO_TABELA_AME', null);
insert into DOMINIO (id, nome, descricao)
values (91, 'TIPO_VINCULO_AME', null);
insert into DOMINIO (id, nome, descricao)
values (92, 'UNIDADE_MEDIDA', null);
insert into DOMINIO (id, nome, descricao)
values (93, 'VIA_ADM_MEDICAMENTO', null);
insert into DOMINIO (id, nome, descricao)
values (94, 'MOTIVO_SAIDA_INTERNACAO', null);
insert into DOMINIO (id, nome, descricao)
values (95, 'TIPO_GUIA_SOLICITACAO', 'Tipo de guia de solicitação TISS');