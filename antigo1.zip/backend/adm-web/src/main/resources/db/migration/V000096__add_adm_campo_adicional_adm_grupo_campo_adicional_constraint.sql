ALTER TABLE adm_campo_adicional
    ADD CONSTRAINT fk_tadm0023_tadm0022 FOREIGN KEY ( cod_grupo_campo )
        REFERENCES adm_grupo_campo_adicional ( cod_grupo_campo )
    NOT DEFERRABLE;
