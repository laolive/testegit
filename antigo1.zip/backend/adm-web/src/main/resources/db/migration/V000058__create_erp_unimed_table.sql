CREATE TABLE erp_unimed (
    cod_unimed       NUMBER(4) NOT NULL,
    nom_unimed       VARCHAR2(25) NOT NULL,
    tip_unimed       VARCHAR2(1) NOT NULL,
    cod_unimed_fed   NUMBER(4),
    cod_pessoa       NUMBER(10)
);

COMMENT ON TABLE erp_unimed is 'TERP0029: Unimed';
COMMENT ON COLUMN erp_unimed.cod_unimed is 'Código: Código da Unimed';
COMMENT ON COLUMN erp_unimed.nom_unimed is 'Nome: Nome da Unimed';
COMMENT ON COLUMN erp_unimed.tip_unimed is 'Tipo: Tipo da Unimed | TIPO_UNIMED';
COMMENT ON COLUMN erp_unimed.cod_unimed_fed is 'Federação: Código da Unimed Federação representante';
COMMENT ON COLUMN erp_unimed.cod_pessoa is 'Pessoa: Código da Pessoa';

CREATE INDEX ix_pk_terp0029 ON erp_unimed ( cod_unimed );

CREATE INDEX ix_fk_terp0029_terp0029 ON erp_unimed ( cod_unimed_fed );

ALTER TABLE erp_unimed
    ADD CONSTRAINT pk_terp0029 PRIMARY KEY ( cod_unimed )
        USING INDEX ix_pk_terp0029;
