ALTER TABLE adm_reserva_numeracao
    ADD CONSTRAINT fk_tadm1002_terp0001 FOREIGN KEY ( cod_emp )
        REFERENCES erp_empresa ( cod_emp )
    NOT DEFERRABLE;
