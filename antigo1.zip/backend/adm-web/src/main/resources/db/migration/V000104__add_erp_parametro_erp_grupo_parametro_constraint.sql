ALTER TABLE erp_parametro
    ADD CONSTRAINT fk_terp0005_terp0004 FOREIGN KEY ( cod_grupo_param )
        REFERENCES erp_grupo_parametro ( cod_grupo )
    NOT DEFERRABLE;
