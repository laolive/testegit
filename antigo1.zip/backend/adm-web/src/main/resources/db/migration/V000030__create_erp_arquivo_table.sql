CREATE TABLE erp_arquivo (
    cod_arq          NUMBER(38) NOT NULL,
    cod_emp          NUMBER(3) NOT NULL,
    nom_arq          VARCHAR2(255) NOT NULL,
    nro_uuid         VARCHAR2(36) NOT NULL,
    des_extsao       VARCHAR2(255) NOT NULL,
    cod_usu          NUMBER(6) NOT NULL,
    flg_arq_entrda   CHAR(1) NOT NULL,
    nom_bucket       VARCHAR2 (30) NOT NULL,
    caminho          VARCHAR2 (50) NOT NULL
);

COMMENT ON TABLE erp_arquivo is 'TERP0026: Arquivo';
COMMENT ON COLUMN erp_arquivo.cod_arq is 'Código: Sequencial do arquivo';
COMMENT ON COLUMN erp_arquivo.cod_emp is 'Empresa: Código da empresa a qual pertence o arquivo';
COMMENT ON COLUMN erp_arquivo.nom_arq is 'Nome: Nome original do arquivo';
COMMENT ON COLUMN erp_arquivo.nro_uuid is 'UUID: Identificador do arquivo no sistema de arquivos';
COMMENT ON COLUMN erp_arquivo.des_extsao is 'Extensão: Extensão do arquivo (mime type)';
COMMENT ON COLUMN erp_arquivo.cod_usu is 'Usuário: Código do usuário que importou ou gerou o arquivo';
COMMENT ON COLUMN erp_arquivo.flg_arq_entrda is 'Entrada: Informa se é um arquivo de entrada | FLAG';
COMMENT ON COLUMN erp_arquivo.nom_bucket is 'Nome do bucket: Nome do bucket em que o arquivo será armazenado. Corresponde ao nome do módulo de origem do arquivo';
COMMENT ON COLUMN erp_arquivo.caminho is 'Caminho: diretório e subdiretório (caso haja) em que o arquivo será armazenado';

CREATE INDEX ix_fk_terp0026_terp0001 ON erp_arquivo ( cod_emp );

CREATE INDEX ix_fk_terp0026_tadm0002 ON erp_arquivo ( cod_usu );

CREATE UNIQUE INDEX ix_pk_terp0026 ON erp_arquivo ( cod_arq );

CREATE UNIQUE INDEX ix_uk_terp0026 ON erp_arquivo ( nro_uuid );

ALTER TABLE erp_arquivo
    ADD CONSTRAINT pk_terp0026 PRIMARY KEY ( cod_arq )
        USING INDEX ix_pk_terp0026;

ALTER TABLE erp_arquivo ADD CONSTRAINT uk_terp0026 UNIQUE ( nro_uuid )
    USING INDEX ix_uk_terp0026;
