CREATE TABLE erp_empresa (
    cod_emp            NUMBER(3) NOT NULL,
    nom_emp_aprstr     VARCHAR2(20) NOT NULL,
    cod_grupo_emprsl   NUMBER(6) NOT NULL
);

COMMENT ON TABLE erp_empresa is 'TERP0001: Empresa';
COMMENT ON COLUMN erp_empresa.cod_emp is 'Código: Código da empresa';
COMMENT ON COLUMN erp_empresa.nom_emp_aprstr is 'Nome: Nome da empresa para apresentação no sistema';
COMMENT ON COLUMN erp_empresa.cod_grupo_emprsl is 'Grupo empresarial: Código do grupo empresarial à qual a empresa pertence';

CREATE INDEX ix_fk_terp0001_terp0023 ON erp_empresa ( cod_grupo_emprsl );

CREATE INDEX ix_pk_terp0001 ON erp_empresa ( cod_emp );

ALTER TABLE erp_empresa
    ADD CONSTRAINT pk_terp0001 PRIMARY KEY ( cod_emp )
        USING INDEX ix_pk_terp0001;

