CREATE TABLE erp_transacao (
    cod_transc   NUMBER(6) NOT NULL,
    nom_transc   VARCHAR2(100) NOT NULL,
    des_rota     VARCHAR2(4000) NOT NULL,
    cod_modulo   VARCHAR2(10) NOT NULL
);

COMMENT ON TABLE erp_transacao is 'TERP0007: Transação';
COMMENT ON COLUMN erp_transacao.cod_transc is 'Código: Código da transação';
COMMENT ON COLUMN erp_transacao.nom_transc is 'Nome: Nome da transação';
COMMENT ON COLUMN erp_transacao.des_rota is 'Rota: Rota completa de aciionamento da transação a partir do servidor';
COMMENT ON COLUMN erp_transacao.cod_modulo is 'Módulo: Código do módulo ao qual a transação pertence';

CREATE UNIQUE INDEX ix_pk_terp0007 ON erp_transacao ( cod_transc );

CREATE INDEX ix_fk_terp0007_terp0003 ON erp_transacao ( cod_modulo );

ALTER TABLE erp_transacao
    ADD CONSTRAINT pk_terp0007 PRIMARY KEY ( cod_transc )
        USING INDEX ix_pk_terp0007;
