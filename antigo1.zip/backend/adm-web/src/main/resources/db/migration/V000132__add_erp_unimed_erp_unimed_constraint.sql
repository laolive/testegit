ALTER TABLE erp_unimed
    ADD CONSTRAINT fk_terp0029_terp0029 FOREIGN KEY ( cod_unimed_fed )
        REFERENCES erp_unimed ( cod_unimed )
    NOT DEFERRABLE;
