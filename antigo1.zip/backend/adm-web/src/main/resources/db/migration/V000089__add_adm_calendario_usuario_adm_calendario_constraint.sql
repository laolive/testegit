ALTER TABLE adm_calendario_usuario
    ADD CONSTRAINT fk_tadm0019_tadm0017 FOREIGN KEY ( cod_emp, nro_ano_calend, dat_calend )
        REFERENCES adm_calendario ( cod_emp, nro_ano_calend, dat_calend )
    NOT DEFERRABLE;
