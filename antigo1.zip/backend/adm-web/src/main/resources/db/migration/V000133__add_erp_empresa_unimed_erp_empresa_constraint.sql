ALTER TABLE erp_empresa_unimed
    ADD CONSTRAINT fk_terp0030_terp0001 FOREIGN KEY ( cod_emp )
        REFERENCES erp_empresa ( cod_emp )
    NOT DEFERRABLE;
