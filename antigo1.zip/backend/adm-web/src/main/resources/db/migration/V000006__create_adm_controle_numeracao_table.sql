CREATE TABLE adm_controle_numeracao (
    cod_emp      NUMBER(3) NOT NULL,
    nom_tabela   VARCHAR2(30) NOT NULL,
    nro_gerado   NUMBER(38) NOT NULL
);

COMMENT ON TABLE adm_controle_numeracao is'TADM1001: Controle de Numeração';
COMMENT ON COLUMN adm_controle_numeracao.cod_emp is'Empresa: Código da empresa para qual o número foi gerado';
COMMENT ON COLUMN adm_controle_numeracao.nom_tabela is'Tabela: Nome da tabela para qual o número foi gerado';
COMMENT ON COLUMN adm_controle_numeracao.nro_gerado is'Número: Último número gerado para a tabela';

CREATE INDEX ix_pk_tadm1001 ON adm_controle_numeracao ( cod_emp,
    nom_tabela );

ALTER TABLE adm_controle_numeracao
    ADD CONSTRAINT pk_tadm1001 PRIMARY KEY ( cod_emp,
    nom_tabela )
        USING INDEX ix_pk_tadm1001;
