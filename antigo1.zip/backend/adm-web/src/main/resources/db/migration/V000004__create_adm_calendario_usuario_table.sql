CREATE TABLE adm_calendario_usuario (
    cod_emp           NUMBER(3) NOT NULL,
    cod_usu           NUMBER(6) NOT NULL,
    nro_ano_calend    NUMBER(4) NOT NULL,
    dat_calend        DATE NOT NULL,
    dth_inic_agenda   DATE NOT NULL,
    dth_fim_agenda    DATE,
    des_obs           VARCHAR2(1000)
);

COMMENT ON TABLE adm_calendario_usuario is'TADM0019: Agenda do Usuário';
COMMENT ON COLUMN adm_calendario_usuario.cod_emp is'Código: Código da empresa';
COMMENT ON COLUMN adm_calendario_usuario.cod_usu is'Usuário: Código do usuário';
COMMENT ON COLUMN adm_calendario_usuario.nro_ano_calend is'Calendário: Código do calendário';
COMMENT ON COLUMN adm_calendario_usuario.dat_calend is'Data: Data do calendário';
COMMENT ON COLUMN adm_calendario_usuario.dth_inic_agenda is'Início: Hora de início ';
COMMENT ON COLUMN adm_calendario_usuario.dth_fim_agenda is'Fim: Hora de fim';
COMMENT ON COLUMN adm_calendario_usuario.des_obs is'Observação: Observações relacionadas à agenda';

CREATE INDEX ix_pk_tadm0019 ON adm_calendario_usuario (
        cod_emp,
        cod_usu,
        nro_ano_calend,
        dat_calend,
        dth_inic_agenda
    );

CREATE INDEX ix_fk_tadm0019_tadm0017 ON adm_calendario_usuario ( cod_emp,
    nro_ano_calend,
    dat_calend );

ALTER TABLE adm_calendario_usuario
    ADD CONSTRAINT pk_tadm0019 PRIMARY KEY ( cod_emp,
    cod_usu,
    nro_ano_calend,
    dat_calend,
    dth_inic_agenda )
        USING INDEX ix_pk_tadm0019;