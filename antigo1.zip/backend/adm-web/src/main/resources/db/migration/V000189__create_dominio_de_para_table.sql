CREATE TABLE dominio_de_para (
    dominio_id_de          NUMBER(18) not null,
    dominio_item_id_de     NUMBER(18) not null,
    dominio_id_para        NUMBER(18) not null,
    dominio_item_id_para   NUMBER(18) not null,
    data_inicio_vigencia   DATE,
    data_fim_vigencia      DATE
);

comment ON COLUMN dominio_de_para.dominio_id_de IS 'ID do domínio de origem';
comment ON COLUMN dominio_de_para.dominio_item_id_de IS 'ID do item do domínio de origem';
comment ON COLUMN dominio_de_para.dominio_id_para IS 'ID do domínio destino';
comment ON COLUMN dominio_de_para.dominio_item_id_para IS 'ID do item de domínio de destino';
comment ON COLUMN dominio_de_para.data_inicio_vigencia IS 'Data de início de vigência';
comment ON COLUMN dominio_de_para.data_fim_vigencia IS 'Data de final de vigência';
 
ALTER TABLE dominio_de_para
  ADD CONSTRAINT dominio_de_para_pk PRIMARY KEY (dominio_id_de, dominio_item_id_de, dominio_id_para, dominio_item_id_para);

ALTER TABLE dominio_de_para
  ADD CONSTRAINT dominio_de_para_de_fk FOREIGN KEY (dominio_item_id_de)
    REFERENCES dominio_item (id);

ALTER TABLE dominio_de_para
  ADD CONSTRAINT dominio_de_para_para_fk FOREIGN KEY (dominio_item_id_para)
    REFERENCES dominio_item (id);
