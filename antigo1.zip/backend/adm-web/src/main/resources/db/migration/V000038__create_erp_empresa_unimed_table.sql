CREATE TABLE erp_empresa_unimed (
    cod_emp           NUMBER(3) NOT NULL,
    cod_unimed        NUMBER(4) NOT NULL,
    dat_inic_vigen    DATE NOT NULL,
    dat_final_vigen   DATE
);

COMMENT ON TABLE erp_empresa_unimed is 'TERP0030: Empresa x Unimed';
COMMENT ON COLUMN erp_empresa_unimed.cod_emp is 'Empresa: Código da empresa';
COMMENT ON COLUMN erp_empresa_unimed.cod_unimed is 'Unimed: Código da Unimed';
COMMENT ON COLUMN erp_empresa_unimed.dat_inic_vigen is 'Início: Data de início da vigência do relacionamento da Unimed com a empresa';
COMMENT ON COLUMN erp_empresa_unimed.dat_final_vigen is 'Fim: Data final da vigência do relacionamento da Unimed com a empresa';

CREATE INDEX ix_pk_terp0030 ON erp_empresa_unimed ( cod_emp, cod_unimed );

ALTER TABLE erp_empresa_unimed
    ADD CONSTRAINT pk_terp0030 PRIMARY KEY ( cod_emp,
    cod_unimed )
        USING INDEX ix_pk_terp0030;

