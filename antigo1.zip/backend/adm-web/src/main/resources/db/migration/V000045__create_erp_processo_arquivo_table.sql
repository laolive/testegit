CREATE TABLE erp_processo_arquivo (
    cod_prcsso   NUMBER(38) NOT NULL,
    cod_arq      NUMBER(38) NOT NULL
);

COMMENT ON TABLE erp_processo_arquivo is 'TERP0017: Arquivo do Processo';
COMMENT ON COLUMN erp_processo_arquivo.cod_prcsso is 'Agendamento: Numeração sequencial do agendamento do processo';
COMMENT ON COLUMN erp_processo_arquivo.cod_arq is 'Arquivo: Código do arquivo gerado pelo processo';

CREATE UNIQUE INDEX ix_pk_terp0017 ON erp_processo_arquivo ( cod_prcsso, cod_arq );

CREATE INDEX ix_fk_terp0017_tadm0015 ON erp_processo_arquivo ( cod_arq );

ALTER TABLE erp_processo_arquivo
    ADD CONSTRAINT pk_terp0017 PRIMARY KEY ( cod_prcsso,
    cod_arq )
        USING INDEX ix_pk_terp0017;
