CREATE TABLE erp_parametro (
    cod_param         VARCHAR2(100) NOT NULL,
    des_label         VARCHAR2(100) NOT NULL,
    cod_grupo_param   NUMBER(20) NOT NULL,
    ind_opcao_usu     VARCHAR2(1) NOT NULL,
    tip_dado          VARCHAR2(1) NOT NULL,
    flg_obr           CHAR(1) NOT NULL,
    flg_global        CHAR(1) NOT NULL,
    nom_domain        VARCHAR2(100),
    nom_tabela        VARCHAR2(30),
    des_obs           VARCHAR2(2000)
);

COMMENT ON TABLE erp_parametro is 'TERP0005: Parâmetro';
COMMENT ON COLUMN erp_parametro.cod_param is 'Parâmetro: Nome do parâmetro';
COMMENT ON COLUMN erp_parametro.des_label is 'Label: Label (texto) apresentada ao usuário para identificar parâmetro';
COMMENT ON COLUMN erp_parametro.cod_grupo_param is 'Código: Código do grupo de parâmetros';
COMMENT ON COLUMN erp_parametro.ind_opcao_usu is 'Opção do usuário: Informa a opção de manutenção pelo usuário | OPCAO_PARAMETRO_USUARIO';
COMMENT ON COLUMN erp_parametro.tip_dado is 'Tipo de dado: Informa o tipo de dado permitido no valor do parâmetro | TIPO_DADO';
COMMENT ON COLUMN erp_parametro.flg_obr is 'Obrigatório: Informa se o filtro é de preenchimento obrigatório | FLAG';
COMMENT ON COLUMN erp_parametro.flg_global is 'Global: Informa se o parâmetro é global e deve ser "carregado" na memória do servidor | FLAG';
COMMENT ON COLUMN erp_parametro.nom_domain is 'Domínio: Nome do domínio que contém os valores permitidos no valor do parâmetro';
COMMENT ON COLUMN erp_parametro.nom_tabela is 'Tabela: Nome da tabela que contém os valores permitidos no valor do parâmetro';
COMMENT ON COLUMN erp_parametro.des_obs is 'Observação: Orientação sobre a utilidade do parâmetro';

CREATE INDEX ix_pk_terp0005 ON erp_parametro ( cod_param );

CREATE INDEX ix_fk_terp0005_terp0004 ON erp_parametro ( cod_grupo_param );

ALTER TABLE erp_parametro
    ADD CONSTRAINT pk_terp0005 PRIMARY KEY ( cod_param )
        USING INDEX ix_pk_terp0005;
