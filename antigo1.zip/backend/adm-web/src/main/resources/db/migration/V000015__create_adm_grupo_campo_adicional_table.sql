CREATE TABLE adm_grupo_campo_adicional (
    cod_grupo_campo   NUMBER(38) NOT NULL,
    des_grupo_campo   VARCHAR2(60) NOT NULL,
    cod_transc        NUMBER(6) NOT NULL,
    nom_tabela        VARCHAR2(30) NOT NULL,
    cod_emp           NUMBER(3) NOT NULL,
    des_obs           VARCHAR2(1000)
);

COMMENT ON TABLE adm_grupo_campo_adicional is'TADM0022: Grupo de Campos Adicionais';
COMMENT ON COLUMN adm_grupo_campo_adicional.cod_grupo_campo is'Código: Código do grupo de campos da transação';
COMMENT ON COLUMN adm_grupo_campo_adicional.des_grupo_campo is'Descrição: Descrição do grupo de campos da transação';
COMMENT ON COLUMN adm_grupo_campo_adicional.cod_transc is'Transação: Código da transação';
COMMENT ON COLUMN adm_grupo_campo_adicional.nom_tabela is'Tabela: Nome da tabela extendida pelos campos adicionais';
COMMENT ON COLUMN adm_grupo_campo_adicional.cod_emp is'Empresa: Código da empresa para a qual se aplica o grupo de campos';
COMMENT ON COLUMN adm_grupo_campo_adicional.des_obs is'Observação: Observação sobre o grupo de campos da transação';

CREATE UNIQUE INDEX ix_pk_tadm0022 ON adm_grupo_campo_adicional ( cod_grupo_campo );

ALTER TABLE adm_grupo_campo_adicional
    ADD CONSTRAINT pk_tadm0022 PRIMARY KEY ( cod_grupo_campo )
        USING INDEX ix_pk_tadm0022;

CREATE SEQUENCE s_tadm0022 START WITH 1 NOCACHE ORDER;
