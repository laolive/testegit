ALTER TABLE adm_usuario
    ADD CONSTRAINT fk_tadm0002_terp0023 FOREIGN KEY ( cod_grupo_emprsl )
        REFERENCES erp_grupo_empresarial ( cod_grupo_emprsl )
    NOT DEFERRABLE;
