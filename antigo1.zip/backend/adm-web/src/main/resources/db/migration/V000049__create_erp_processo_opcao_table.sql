CREATE TABLE erp_processo_opcao (
    cod_prcsso   NUMBER(38) NOT NULL,
    cod_opcao    NUMBER(6) NOT NULL,
    cod_rotina   NUMBER(10) NOT NULL,
    des_label    VARCHAR2(100) NOT NULL,
    val_param    VARCHAR2(100)
);

COMMENT ON TABLE erp_processo_opcao is 'TERP0025: Opção do Processo';
COMMENT ON COLUMN erp_processo_opcao.cod_prcsso is 'Agendamento: Numeração sequencial do agendamento do processo';
COMMENT ON COLUMN erp_processo_opcao.cod_opcao is 'Código: Código da opção do processo';
COMMENT ON COLUMN erp_processo_opcao.cod_rotina is 'Rotina: Código da rotina executada pelo processo';
COMMENT ON COLUMN erp_processo_opcao.des_label is 'Label: Label (texto) apresentada para identificar a opção do processo';
COMMENT ON COLUMN erp_processo_opcao.val_param is 'Valor: Valor da opção utilizado no agendamento do processo';

CREATE UNIQUE INDEX ix_pk_terp0025 ON erp_processo_opcao ( cod_prcsso, cod_opcao );

ALTER TABLE erp_processo_opcao
    ADD CONSTRAINT pk_terp0025 PRIMARY KEY ( cod_prcsso,
    cod_opcao )
        USING INDEX ix_pk_terp0025;
