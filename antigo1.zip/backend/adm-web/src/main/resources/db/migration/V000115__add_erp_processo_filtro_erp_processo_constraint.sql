ALTER TABLE erp_processo_filtro
    ADD CONSTRAINT fk_terp0016_terp0015 FOREIGN KEY ( cod_prcsso )
        REFERENCES erp_processo ( cod_prcsso )
    NOT DEFERRABLE;
