ALTER TABLE adm_usuario_empresa
    ADD CONSTRAINT fk_tadm0021_terp0001 FOREIGN KEY ( cod_emp )
        REFERENCES erp_empresa ( cod_emp )
    NOT DEFERRABLE;
