CREATE TABLE adm_calendario (
    cod_emp          NUMBER(3) NOT NULL,
    nro_ano_calend   NUMBER(4) NOT NULL,
    dat_calend       DATE NOT NULL,
    flg_dia_util     CHAR(1) NOT NULL
);

COMMENT ON TABLE adm_calendario is'TADM0017: Calendário';
COMMENT ON COLUMN adm_calendario.cod_emp is'Código: Código da empresa';
COMMENT ON COLUMN adm_calendario.nro_ano_calend is'Calendário: Código do calendário';
COMMENT ON COLUMN adm_calendario.dat_calend is'Data: Data do calendário';
COMMENT ON COLUMN adm_calendario.flg_dia_util is'Dia útil: Indica se a data representa um dia útil | FLAG';

CREATE INDEX ix_pk_tadm0017 ON adm_calendario ( cod_emp,
    nro_ano_calend,
    dat_calend );

ALTER TABLE adm_calendario
    ADD CONSTRAINT pk_tadm0017 PRIMARY KEY ( cod_emp,
    nro_ano_calend,
    dat_calend )
        USING INDEX ix_pk_tadm0017;
