ALTER TABLE adm_usuario_parametro
    ADD CONSTRAINT fk_tadm0012_terp0005 FOREIGN KEY ( cod_param )
        REFERENCES erp_parametro ( cod_param )
    NOT DEFERRABLE;
