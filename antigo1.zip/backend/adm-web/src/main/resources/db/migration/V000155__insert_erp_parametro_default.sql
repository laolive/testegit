insert into erp_parametro (cod_param,des_label,cod_grupo_param,ind_opcao_usu,tip_dado,flg_obr,nom_domain,nom_tabela,des_obs,flg_global)
values ('USUARIO_ADMINISTRADOR_SISTEMA','Código do usuário administrador','1','O','N','S',NULL,'ADM_USUARIO','Informa o código do usuário administrador do sistema.','N');

insert into erp_parametro (cod_param,des_label,cod_grupo_param,ind_opcao_usu,tip_dado,flg_obr,nom_domain,nom_tabela,des_obs,flg_global)
values ('FILA_EXECUCAO_PADRAO','Código da fila padrão para execução dos processos','1','A','N','S',NULL,'ADM_FILA_EXECUCAO','Informa o código da fila padrão para execução dos processos.','N');

insert into erp_parametro (cod_param,des_label,cod_grupo_param,ind_opcao_usu,tip_dado,flg_obr,nom_domain,nom_tabela,des_obs,flg_global)
values ('EMAIL_HOST_NAME','Hostname do e-mail de notificações do CRM','1','A','A','N',null,null,'Informa o hostname do e-mail de notificações do CRM','N');

insert into erp_parametro (cod_param,des_label,cod_grupo_param,ind_opcao_usu,tip_dado,flg_obr,nom_domain,nom_tabela,des_obs,flg_global)
values ('EMAIL_SMTP_PORT','Porta SMTP do e-mail de notificações do CRM','1','A','N','N',null,null,'Informa a porta SMTP do e-mail de notificações do CRM','N');

insert into erp_parametro (cod_param,des_label,cod_grupo_param,ind_opcao_usu,tip_dado,flg_obr,nom_domain,nom_tabela,des_obs,flg_global)
values ('EMAIL_USER','Usuário do e-mail de notificações do CRM','1','A','A','N',null,null,'Informa o usuário do e-mail de notificações do CRM','N');

insert into erp_parametro (cod_param,des_label,cod_grupo_param,ind_opcao_usu,tip_dado,flg_obr,nom_domain,nom_tabela,des_obs,flg_global)
values ('EMAIL_PASSWORD','Senha do usuário de e-mail de notificações do CRM','1','A','A','N',null,null,'Informa a senha do usuário de e-mail de notificações do CRM','N');

insert into erp_parametro (cod_param,des_label,cod_grupo_param,ind_opcao_usu,tip_dado,flg_obr,nom_domain,nom_tabela,des_obs,flg_global)
values ('URL_GATEWAY_SGUERP','URL do Gateway do SGUERP','1','A','A','S',null,null,'Informa a URL do Gateway do SGUERP.','S');

insert into ERP_PARAMETRO (COD_PARAM, DES_LABEL, COD_GRUPO_PARAM, IND_OPCAO_USU, TIP_DADO, FLG_OBR, FLG_GLOBAL, NOM_DOMAIN, NOM_TABELA, DES_OBS)
values ('ANS_PADRAO_ATENDIMENTO', 'Código ANS padrão para abertura de Protocolos CRM', 1, 'A', 'N', 'N', 'S', null, null, 'Informa o código ANS padrão para abertura de Protocolos CRM');
