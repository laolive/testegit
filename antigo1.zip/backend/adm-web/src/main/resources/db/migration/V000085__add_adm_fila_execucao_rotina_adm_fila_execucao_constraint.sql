ALTER TABLE adm_fila_execucao_rotina
    ADD CONSTRAINT fk_tadm0016_tadm0010 FOREIGN KEY ( cod_emp, cod_fila )
        REFERENCES adm_fila_execucao ( cod_emp, cod_fila )
    NOT DEFERRABLE;
