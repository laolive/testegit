CREATE TABLE erp_diretorio (
    nom_dir                VARCHAR2(30) NOT NULL,
    des_caminh_bco_dados   VARCHAR2(4000) NOT NULL,
    des_caminh_rede        VARCHAR2(4000) NOT NULL
);

COMMENT ON TABLE erp_diretorio is 'TERP0021: Diretório';
COMMENT ON COLUMN erp_diretorio.nom_dir is 'Nome do diretório: Nome que identifica o diretório';
COMMENT ON COLUMN erp_diretorio.des_caminh_bco_dados is 'Diretório no banco de dados: Caminho do diretório para o banco de dados';
COMMENT ON COLUMN erp_diretorio.des_caminh_rede is 'Diretório na rede: Caminho do diretório para a rede';

CREATE UNIQUE INDEX ix_pk_terp0021 ON erp_diretorio ( nom_dir );

ALTER TABLE erp_diretorio
    ADD CONSTRAINT pk_terp0021 PRIMARY KEY ( nom_dir )
        USING INDEX ix_pk_terp0021;
