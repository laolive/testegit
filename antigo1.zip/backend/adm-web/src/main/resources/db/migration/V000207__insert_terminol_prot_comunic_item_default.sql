insert into TERMINOL_PROT_COMUNIC_ITEM (ID, TERMINOLOGIA_PROT_COMUNIC_ID, VALOR, DESCRICAO, DOMINIO_ITEM_ID)
values (1445, 94, '11', 'Alta Curado', 579);
insert into TERMINOL_PROT_COMUNIC_ITEM (ID, TERMINOLOGIA_PROT_COMUNIC_ID, VALOR, DESCRICAO, DOMINIO_ITEM_ID)
values (1446, 94, '12', 'Alta Melhorado', 580);
insert into TERMINOL_PROT_COMUNIC_ITEM (ID, TERMINOLOGIA_PROT_COMUNIC_ID, VALOR, DESCRICAO, DOMINIO_ITEM_ID)
values (1447, 94, '14', 'Alta a pedido', 581);
insert into TERMINOL_PROT_COMUNIC_ITEM (ID, TERMINOLOGIA_PROT_COMUNIC_ID, VALOR, DESCRICAO, DOMINIO_ITEM_ID)
values (1448, 94, '81', 'Alta com previsão de retorno para acompanhamento do paciente', 582);
insert into TERMINOL_PROT_COMUNIC_ITEM (ID, TERMINOLOGIA_PROT_COMUNIC_ID, VALOR, DESCRICAO, DOMINIO_ITEM_ID)
values (1449, 94, '83', 'Alta por Outros motivos', 585);
insert into TERMINOL_PROT_COMUNIC_ITEM (ID, TERMINOLOGIA_PROT_COMUNIC_ID, VALOR, DESCRICAO, DOMINIO_ITEM_ID)
values (1451, 94, '18', 'Alta por evasão', 583);
insert into TERMINOL_PROT_COMUNIC_ITEM (ID, TERMINOLOGIA_PROT_COMUNIC_ID, VALOR, DESCRICAO, DOMINIO_ITEM_ID)
values (1452, 94, '21', 'Permanência por características próprias da doença', 586);
insert into TERMINOL_PROT_COMUNIC_ITEM (ID, TERMINOLOGIA_PROT_COMUNIC_ID, VALOR, DESCRICAO, DOMINIO_ITEM_ID)
values (1453, 94, '22', 'Permanência por intercorrência', 587);
insert into TERMINOL_PROT_COMUNIC_ITEM (ID, TERMINOLOGIA_PROT_COMUNIC_ID, VALOR, DESCRICAO, DOMINIO_ITEM_ID)
values (1458, 94, '29', 'Permanência por reoperação', 592);
insert into TERMINOL_PROT_COMUNIC_ITEM (ID, TERMINOLOGIA_PROT_COMUNIC_ID, VALOR, DESCRICAO, DOMINIO_ITEM_ID)
values (1459, 94, '30', 'Permanência por outros motivos', 593);
insert into TERMINOL_PROT_COMUNIC_ITEM (ID, TERMINOLOGIA_PROT_COMUNIC_ID, VALOR, DESCRICAO, DOMINIO_ITEM_ID)
values (1460, 94, '72', 'Transferido para outro estabelecimento', 594);
insert into TERMINOL_PROT_COMUNIC_ITEM (ID, TERMINOLOGIA_PROT_COMUNIC_ID, VALOR, DESCRICAO, DOMINIO_ITEM_ID)
values (1461, 94, '88', 'Transferencia para Internação domiciliar', 595);
insert into TERMINOL_PROT_COMUNIC_ITEM (ID, TERMINOLOGIA_PROT_COMUNIC_ID, VALOR, DESCRICAO, DOMINIO_ITEM_ID)
values (1462, 94, '47', 'Óbito com declaração de óbito fornecida pelo médico assistente', 596);
insert into TERMINOL_PROT_COMUNIC_ITEM (ID, TERMINOLOGIA_PROT_COMUNIC_ID, VALOR, DESCRICAO, DOMINIO_ITEM_ID)
values (1463, 94, '48', 'Óbito com declaração de óbito fornecida pelo Instituto Médico Legal - IML', 597);
insert into TERMINOL_PROT_COMUNIC_ITEM (ID, TERMINOLOGIA_PROT_COMUNIC_ID, VALOR, DESCRICAO, DOMINIO_ITEM_ID)
values (1464, 94, '49', 'Óbito com declaração de óbito fornecida pelo Serviço de Verificação de Óbito - SVO', 598);
insert into TERMINOL_PROT_COMUNIC_ITEM (ID, TERMINOLOGIA_PROT_COMUNIC_ID, VALOR, DESCRICAO, DOMINIO_ITEM_ID)
values (1465, 94, '55', 'Encerramento Administrativo', 599);
insert into TERMINOL_PROT_COMUNIC_ITEM (ID, TERMINOLOGIA_PROT_COMUNIC_ID, VALOR, DESCRICAO, DOMINIO_ITEM_ID)
values (1466, 94, '82', 'Alta mãe/puérpera e do recém nascido', 600);
insert into TERMINOL_PROT_COMUNIC_ITEM (ID, TERMINOLOGIA_PROT_COMUNIC_ID, VALOR, DESCRICAO, DOMINIO_ITEM_ID)
values (1467, 94, '84', 'Alta mãe/puérpera e permanência do recém-nascido', 601);
insert into TERMINOL_PROT_COMUNIC_ITEM (ID, TERMINOLOGIA_PROT_COMUNIC_ID, VALOR, DESCRICAO, DOMINIO_ITEM_ID)
values (1468, 94, '86', 'Alta mãe/puérpera e óbito do recém-nascido', 602);
insert into TERMINOL_PROT_COMUNIC_ITEM (ID, TERMINOLOGIA_PROT_COMUNIC_ID, VALOR, DESCRICAO, DOMINIO_ITEM_ID)
values (1469, 94, '87', 'Alta mãe/puérpera com óbito fetal', 603);
insert into TERMINOL_PROT_COMUNIC_ITEM (ID, TERMINOLOGIA_PROT_COMUNIC_ID, VALOR, DESCRICAO, DOMINIO_ITEM_ID)
values (1473, 94, '85', 'Alta de Paciente Agudo em Psiquiatria', 607);
insert into TERMINOL_PROT_COMUNIC_ITEM (ID, TERMINOLOGIA_PROT_COMUNIC_ID, VALOR, DESCRICAO, DOMINIO_ITEM_ID)
values (1474, 94, '25', 'Permanência por impossibilidade sócio-familiar', 588);
insert into TERMINOL_PROT_COMUNIC_ITEM (ID, TERMINOLOGIA_PROT_COMUNIC_ID, VALOR, DESCRICAO, DOMINIO_ITEM_ID)
values (1475, 94, '26', 'Permanência por processo de doação de órgãos, tecidos e células - doador vivo', 589);
insert into TERMINOL_PROT_COMUNIC_ITEM (ID, TERMINOLOGIA_PROT_COMUNIC_ID, VALOR, DESCRICAO, DOMINIO_ITEM_ID)
values (1476, 94, '27', 'Permanência por processo de doação de órgãos, tecidos e células - doador morto', 590);
insert into TERMINOL_PROT_COMUNIC_ITEM (ID, TERMINOLOGIA_PROT_COMUNIC_ID, VALOR, DESCRICAO, DOMINIO_ITEM_ID)
values (1477, 94, '28', 'Permanência por mudança de Procedimento', 591);
insert into TERMINOL_PROT_COMUNIC_ITEM (ID, TERMINOLOGIA_PROT_COMUNIC_ID, VALOR, DESCRICAO, DOMINIO_ITEM_ID)
values (1478, 94, '89', 'Óbito da gestante e do concepto', 604);
insert into TERMINOL_PROT_COMUNIC_ITEM (ID, TERMINOLOGIA_PROT_COMUNIC_ID, VALOR, DESCRICAO, DOMINIO_ITEM_ID)
values (1479, 94, '90', 'Óbito da mãe/puérpera e alta do recém-nascido', 605);
insert into TERMINOL_PROT_COMUNIC_ITEM (ID, TERMINOLOGIA_PROT_COMUNIC_ID, VALOR, DESCRICAO, DOMINIO_ITEM_ID)
values (1480, 94, '91', 'Óbito da mãe/puérpera e permanência do recém-nascido', 606);
insert into terminol_prot_comunic_item (ID, TERMINOLOGIA_PROT_COMUNIC_ID, VALOR, DESCRICAO, DOMINIO_ITEM_ID)
values (1481, 48, '0', '0', 64);
