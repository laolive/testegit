ALTER TABLE adm_controle_numeracao
    ADD CONSTRAINT fk_tadm1001_terp0001 FOREIGN KEY ( cod_emp )
        REFERENCES erp_empresa ( cod_emp )
    NOT DEFERRABLE;
