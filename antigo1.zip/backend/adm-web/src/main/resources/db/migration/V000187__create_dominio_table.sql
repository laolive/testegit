CREATE TABLE dominio (
    id          NUMBER(18) not null,
    nome        VARCHAR2(27) not null,
    descricao   VARCHAR2(100)
);
 
comment ON COLUMN dominio.id IS 'ID do domínio';
comment ON COLUMN dominio.nome IS 'Nome do domínio';
comment ON COLUMN dominio.descricao IS 'Descrição do domínio';
 
ALTER TABLE dominio
  ADD CONSTRAINT dominio_pk PRIMARY KEY (id);
  
ALTER TABLE dominio
  ADD CONSTRAINT dominio_uk UNIQUE (nome);
