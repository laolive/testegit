CREATE TABLE adm_fila_execucao (
    cod_emp             NUMBER(3) NOT NULL,
    cod_fila            NUMBER(3) NOT NULL,
    des_fila            VARCHAR2(60) NOT NULL,
    ind_situac          VARCHAR2(1) NOT NULL,
    hra_inic_exec       VARCHAR2(5) NOT NULL,
    hra_fim_exec        VARCHAR2(5) NOT NULL,
    qtd_prcsso_parelo   NUMBER(6) NOT NULL
);

COMMENT ON TABLE adm_fila_execucao is'TADM0010: Fila de Processos';
COMMENT ON COLUMN adm_fila_execucao.cod_emp is'Empresa: Empresa que controla a fila de execução';
COMMENT ON COLUMN adm_fila_execucao.cod_fila is'Código: Código da fila de execução';
COMMENT ON COLUMN adm_fila_execucao.des_fila is'Descrição: Descrição da fila de execução';
COMMENT ON COLUMN adm_fila_execucao.ind_situac is'Situação: Informa a situação atual da fila de execução | SITUACAO_FILA_EXECUCAO';
COMMENT ON COLUMN adm_fila_execucao.hra_inic_exec is'Hora de início: Hora em que a fila inicia a execução de processos';
COMMENT ON COLUMN adm_fila_execucao.hra_fim_exec is'Hora de término: Hora em que a fila encerra a execução de processos';
COMMENT ON COLUMN adm_fila_execucao.qtd_prcsso_parelo is'Quantidade de processos: Informa a quantidade de processos paralelos permitidos';

CREATE UNIQUE INDEX ix_pk_tadm0010 ON adm_fila_execucao ( cod_emp, cod_fila );

ALTER TABLE adm_fila_execucao
    ADD CONSTRAINT pk_tadm0010 PRIMARY KEY ( cod_emp, cod_fila )
        USING INDEX ix_pk_tadm0010;
