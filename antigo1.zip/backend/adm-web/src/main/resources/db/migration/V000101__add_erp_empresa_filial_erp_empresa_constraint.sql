ALTER TABLE erp_empresa_filial
    ADD CONSTRAINT fk_terp0002_terp0001 FOREIGN KEY ( cod_emp )
        REFERENCES erp_empresa ( cod_emp )
    NOT DEFERRABLE;
