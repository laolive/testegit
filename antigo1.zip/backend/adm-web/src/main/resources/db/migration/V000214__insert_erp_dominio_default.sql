insert into ERP_DOMINIO (NOM_DOMAIN, VAL_DOMAIN, DES_LABEL, DES_EXPLIC, DAT_INIC_VIGEN, DAT_FINAL_VIGEN)
values ('TIPO_MOTIVO_AME', 'D', 'Aceite divergência', null, null, null);

insert into ERP_DOMINIO (NOM_DOMAIN, VAL_DOMAIN, DES_LABEL, DES_EXPLIC, DAT_INIC_VIGEN, DAT_FINAL_VIGEN)
values ('TIPO_MOTIVO_AME', 'N', 'Não Aceite de Justificativa', null, null, null);

insert into ERP_DOMINIO (NOM_DOMAIN, VAL_DOMAIN, DES_LABEL, DES_EXPLIC, DAT_INIC_VIGEN, DAT_FINAL_VIGEN)
values ('TOLERANCIA_EXCECAO_AME', '1', 'Tolerância de exceções', 'Tolerância de diferença de valores de exceções', null, null);

insert into ERP_DOMINIO (NOM_DOMAIN, VAL_DOMAIN, DES_LABEL, DES_EXPLIC, DAT_INIC_VIGEN, DAT_FINAL_VIGEN)
values ('STATUS_GERAL_EXCECAO_AME', 'JU', 'Justificado', null, null, null);

insert into ERP_DOMINIO (NOM_DOMAIN, VAL_DOMAIN, DES_LABEL, DES_EXPLIC, DAT_INIC_VIGEN, DAT_FINAL_VIGEN)
values ('STATUS_GERAL_EXCECAO_AME', 'NJ', 'Não Justificado', null, null, null);

insert into ERP_DOMINIO (NOM_DOMAIN, VAL_DOMAIN, DES_LABEL, DES_EXPLIC, DAT_INIC_VIGEN, DAT_FINAL_VIGEN)
values ('STATUS_GERAL_EXCECAO_AME', 'JA', 'Justificativa Aceita', null, null, null);

insert into ERP_DOMINIO (NOM_DOMAIN, VAL_DOMAIN, DES_LABEL, DES_EXPLIC, DAT_INIC_VIGEN, DAT_FINAL_VIGEN)
values ('STATUS_GERAL_EXCECAO_AME', 'JR', 'Justificativa Recusada', null, null, null);

insert into ERP_DOMINIO (NOM_DOMAIN, VAL_DOMAIN, DES_LABEL, DES_EXPLIC, DAT_INIC_VIGEN, DAT_FINAL_VIGEN)
values ('STATUS_GERAL_EXCECAO_AME', 'PE', 'Pendente', null, null, null);

insert into ERP_DOMINIO (NOM_DOMAIN, VAL_DOMAIN, DES_LABEL, DES_EXPLIC, DAT_INIC_VIGEN, DAT_FINAL_VIGEN)
values ('STATUS_GERAL_EXCECAO_AME', 'AP', 'Pendente Justificativa', null, null, null);

insert into ERP_DOMINIO (NOM_DOMAIN, VAL_DOMAIN, DES_LABEL, DES_EXPLIC, DAT_INIC_VIGEN, DAT_FINAL_VIGEN)
values ('STATUS_GERAL_EXCECAO_AME', 'DA', 'Divergência Acatada', null, null, null);
