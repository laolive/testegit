CREATE TABLE erp_rotina (
    cod_rotina          NUMBER(10) NOT NULL,
    des_rotina          VARCHAR2(100) NOT NULL,
    nom_prc_bco_dados   VARCHAR2(100) NOT NULL,
    cod_modulo          VARCHAR2(10) NOT NULL,
    des_obs             VARCHAR2(2000)
);

COMMENT ON TABLE erp_rotina is 'TERP0013: Rotina';
COMMENT ON COLUMN erp_rotina.cod_rotina is 'Código: Código da rotina';
COMMENT ON COLUMN erp_rotina.des_rotina is 'Descrição: Descrição da rotina';
COMMENT ON COLUMN erp_rotina.nom_prc_bco_dados is 'Procedure: Nome da procedure do banco de dados a ser executada';
COMMENT ON COLUMN erp_rotina.cod_modulo is 'Módulo: Código do módulo ao qual a transação pertence';
COMMENT ON COLUMN erp_rotina.des_obs is 'Observação: Observação sobre a utilidade da rotina';

CREATE UNIQUE INDEX ix_pk_terp0013 ON erp_rotina ( cod_rotina );

CREATE INDEX ix_fk_terp0013_terp0003 ON erp_rotina ( cod_modulo );

ALTER TABLE erp_rotina
    ADD CONSTRAINT pk_terp0013 PRIMARY KEY ( cod_rotina )
        USING INDEX ix_pk_terp0013;
