ALTER TABLE erp_reserva_numeracao
    ADD CONSTRAINT fk_terp1002_terp0001 FOREIGN KEY ( cod_emp )
        REFERENCES erp_empresa ( cod_emp )
    NOT DEFERRABLE;
