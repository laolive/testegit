CREATE TABLE dominio_item (
    id                     NUMBER(18) not null,
    dominio_id             NUMBER(18) not null,
    nome                   VARCHAR2(100) not null,
    valor                  VARCHAR2(100),
    descricao              VARCHAR2(200),
    data_inicio_vigencia   DATE,
    data_fim_vigencia      DATE
);
 
comment ON COLUMN dominio_item.id IS 'ID do item do domínio';
comment ON COLUMN dominio_item.dominio_id IS 'ID do domínio';
comment ON COLUMN dominio_item.nome IS 'Nome do item do domínio';
comment ON COLUMN dominio_item.valor IS 'Valor específico do item do domínio';
comment ON COLUMN dominio_item.descricao IS 'Descrição do item do domínio';
comment ON COLUMN dominio_item.data_inicio_vigencia IS 'Data de início da vigência do item do domínio';
comment ON COLUMN dominio_item.data_fim_vigencia IS 'Data de fim da vigência do item do domínio';
 
ALTER TABLE dominio_item
  ADD CONSTRAINT dominio_item_pk PRIMARY KEY (id);

ALTER TABLE dominio_item
  ADD CONSTRAINT dominio_item_valor_uk UNIQUE (dominio_id, valor) ;
  
ALTER TABLE dominio_item
  ADD CONSTRAINT dominio_fk FOREIGN KEY (dominio_id)
    REFERENCES dominio (id);
