ALTER TABLE erp_alerta
    ADD CONSTRAINT fk_terp0027_tadm0002_1 FOREIGN KEY ( cod_usu_grcao )
        REFERENCES adm_usuario ( cod_usu )
    NOT DEFERRABLE;
