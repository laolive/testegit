ALTER TABLE erp_rotina_sql
    ADD CONSTRAINT fk_terp0022_terp0013 FOREIGN KEY ( cod_rotina )
        REFERENCES erp_rotina ( cod_rotina )
    NOT DEFERRABLE;
