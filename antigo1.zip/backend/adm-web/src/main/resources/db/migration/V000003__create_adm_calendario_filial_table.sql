CREATE TABLE adm_calendario_filial (
    cod_emp          NUMBER(3) NOT NULL,
    cod_filial       NUMBER(3) NOT NULL,
    nro_ano_calend   NUMBER(4) NOT NULL,
    dat_calend       DATE NOT NULL,
    cod_modulo       VARCHAR2(10) NOT NULL,
    flg_dia_util     CHAR(1) NOT NULL,
    des_obs          VARCHAR2(1000)
);

COMMENT ON TABLE adm_calendario_filial is'TADM0018: Calendário da Filial';
COMMENT ON COLUMN adm_calendario_filial.cod_emp is'Código: Código da empresa';
COMMENT ON COLUMN adm_calendario_filial.cod_filial is'Filial: Código da filial';
COMMENT ON COLUMN adm_calendario_filial.nro_ano_calend is'Calendário: Código do calendário';
COMMENT ON COLUMN adm_calendario_filial.dat_calend is'Data: Data do calendário';
COMMENT ON COLUMN adm_calendario_filial.cod_modulo is'Módulo: Código do módulo';
COMMENT ON COLUMN adm_calendario_filial.flg_dia_util is'Dia útil: Indica se a data representa um dia útil | FLAG';
COMMENT ON COLUMN adm_calendario_filial.des_obs is'Observação: Observações relacionadas à data';

CREATE INDEX ix_pk_tadm0018 ON adm_calendario_filial (
        cod_emp,
        cod_filial,
        nro_ano_calend,
        dat_calend,
        cod_modulo
    );

CREATE INDEX ix_fk_tadm0018_tadm0017 ON adm_calendario_filial ( cod_emp,
    nro_ano_calend,
    dat_calend );

CREATE INDEX ix_fk_tadm0018_terp0003 ON adm_calendario_filial ( cod_modulo );

ALTER TABLE adm_calendario_filial
    ADD CONSTRAINT pk_tadm0018 PRIMARY KEY ( cod_emp,
    cod_filial,
    nro_ano_calend,
    dat_calend,
    cod_modulo )
        USING INDEX ix_pk_tadm0018;
