ALTER TABLE adm_parametro_empresa
    ADD CONSTRAINT fk_tadm0020_terp0001 FOREIGN KEY ( cod_emp )
        REFERENCES erp_empresa ( cod_emp )
    NOT DEFERRABLE;
