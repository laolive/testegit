ALTER TABLE erp_processo_opcao
    ADD CONSTRAINT fk_terp0025_terp0024 FOREIGN KEY ( cod_rotina, cod_opcao )
        REFERENCES erp_rotina_opcao ( cod_rotina, cod_opcao )
    NOT DEFERRABLE;
