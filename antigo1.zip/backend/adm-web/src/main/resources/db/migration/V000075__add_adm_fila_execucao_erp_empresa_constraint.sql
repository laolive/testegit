ALTER TABLE adm_fila_execucao
    ADD CONSTRAINT fk_tadm0010_terp0001 FOREIGN KEY ( cod_emp )
        REFERENCES erp_empresa ( cod_emp )
    NOT DEFERRABLE;
