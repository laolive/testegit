ALTER TABLE adm_fila_execucao_rotina
    ADD CONSTRAINT fk_tadm0016_terp0013 FOREIGN KEY ( cod_rotina )
        REFERENCES erp_rotina ( cod_rotina )
    NOT DEFERRABLE;
