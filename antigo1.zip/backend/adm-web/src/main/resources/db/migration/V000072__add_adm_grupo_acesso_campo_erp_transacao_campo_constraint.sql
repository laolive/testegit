ALTER TABLE adm_grupo_acesso_campo
    ADD CONSTRAINT fk_tadm0008_terp0008 FOREIGN KEY ( cod_transc,
    nom_campo )
        REFERENCES erp_transacao_campo ( cod_transc,
        nom_campo )
    NOT DEFERRABLE;
