CREATE TABLE erp_dominio (
    nom_domain        VARCHAR2(100) NOT NULL,
    val_domain        VARCHAR2(100) NOT NULL,
    des_label         VARCHAR2(100) NOT NULL,
    des_explic        VARCHAR2(100),
    dat_inic_vigen    DATE,
    dat_final_vigen   DATE
);

COMMENT ON TABLE erp_dominio is 'TERP0020: Domínio';
COMMENT ON COLUMN erp_dominio.nom_domain is 'Nome: Nome do domínio';
COMMENT ON COLUMN erp_dominio.val_domain is 'Valor: Valor do domínio';
COMMENT ON COLUMN erp_dominio.des_label is 'Label: Label da representação do valor do domínio';
COMMENT ON COLUMN erp_dominio.des_explic is 'Explicação: Detalhamento do valor do domínio';
COMMENT ON COLUMN erp_dominio.dat_inic_vigen is 'Início da vigência: Data inicial da vigência';
COMMENT ON COLUMN erp_dominio.dat_final_vigen is 'Final da vigência: Data final da vigência';

CREATE INDEX ix_pk_terp0020 ON erp_dominio ( nom_domain, val_domain );

ALTER TABLE erp_dominio
    ADD CONSTRAINT pk_terp0020 PRIMARY KEY ( nom_domain,
    val_domain )
        USING INDEX ix_pk_terp0020;
