CREATE TABLE erp_alerta_leitura (
    cod_alerta   NUMBER(38) NOT NULL,
    dth_leitra   DATE NOT NULL
);

COMMENT ON TABLE erp_alerta_leitura is 'TERP0028: Leitura do Alerta';
COMMENT ON COLUMN erp_alerta_leitura.cod_alerta is 'Sequencial: Código sequencial do alerta';
COMMENT ON COLUMN erp_alerta_leitura.dth_leitra is 'Lido em: Data e hora da leitura do alerta';

CREATE INDEX ix_pk_terp0028 ON erp_alerta_leitura ( cod_alerta );

ALTER TABLE erp_alerta_leitura
    ADD CONSTRAINT pk_terp0028 PRIMARY KEY ( cod_alerta )
        USING INDEX ix_pk_terp0028;
