ALTER TABLE erp_grupo_parametro
    ADD CONSTRAINT fk_terp0004_terp0004 FOREIGN KEY ( cod_grupo_sup )
        REFERENCES erp_grupo_parametro ( cod_grupo )
    NOT DEFERRABLE;
