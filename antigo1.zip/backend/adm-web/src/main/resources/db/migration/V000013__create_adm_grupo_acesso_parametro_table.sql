CREATE TABLE adm_grupo_acesso_parametro (
    cod_emp            NUMBER(3) NOT NULL,
    cod_grupo_acesso   NUMBER(6) NOT NULL,
    cod_param          VARCHAR2(100) NOT NULL,
    val_param          VARCHAR2(255)
);

COMMENT ON TABLE adm_grupo_acesso_parametro is'TADM0011: Parâmetro do Grupo de Acessos';
COMMENT ON COLUMN adm_grupo_acesso_parametro.cod_emp is'Empresa: Código da empresa';
COMMENT ON COLUMN adm_grupo_acesso_parametro.cod_grupo_acesso is'Código: Código do grupo de acessos';
COMMENT ON COLUMN adm_grupo_acesso_parametro.cod_param is'Parâmetro: Nome do parâmetro';
COMMENT ON COLUMN adm_grupo_acesso_parametro.val_param is'Valor: Valor do parâmetro para o grupo de acessos';

CREATE INDEX ix_pk_tadm0011 ON adm_grupo_acesso_parametro ( cod_emp,
    cod_grupo_acesso,
    cod_param );

CREATE INDEX ix_fk_tadm0011_terp0005 ON adm_grupo_acesso_parametro ( cod_param );

ALTER TABLE adm_grupo_acesso_parametro
    ADD CONSTRAINT pk_tadm0011 PRIMARY KEY ( cod_emp,
    cod_grupo_acesso,
    cod_param )
        USING INDEX ix_pk_tadm0011;
