insert into terminologia_prot_comunic (ID, PROTOCOLO_COMUNIC_VERSAO_ID, NOME)
values (94, 1, 'st_motivoEncerramento');
