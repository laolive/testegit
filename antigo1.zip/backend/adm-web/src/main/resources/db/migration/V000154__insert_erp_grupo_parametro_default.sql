insert into ERP_GRUPO_PARAMETRO (COD_GRUPO, DES_GRUPO, COD_MODULO, COD_GRUPO_SUP, DAT_INATIV)
values (1, 'Admistração do Sistema', 'ADM', null, null);

insert into ERP_GRUPO_PARAMETRO (COD_GRUPO, DES_GRUPO, COD_MODULO, COD_GRUPO_SUP, DAT_INATIV)
values (2, 'Cadastros', 'CAD', null, null);
