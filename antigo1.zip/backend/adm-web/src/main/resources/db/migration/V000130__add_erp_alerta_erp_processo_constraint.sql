ALTER TABLE erp_alerta
    ADD CONSTRAINT fk_terp0027_terp0015 FOREIGN KEY ( cod_prcsso )
        REFERENCES erp_processo ( cod_prcsso )
    NOT DEFERRABLE;
