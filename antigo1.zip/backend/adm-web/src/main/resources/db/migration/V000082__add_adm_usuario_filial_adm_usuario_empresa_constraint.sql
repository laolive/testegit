ALTER TABLE adm_usuario_filial
    ADD CONSTRAINT fk_tadm0014_tadm0021 FOREIGN KEY ( cod_usu, cod_emp )
        REFERENCES adm_usuario_empresa ( cod_usu, cod_emp )
    NOT DEFERRABLE;
