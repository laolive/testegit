ALTER TABLE adm_usuario_menu
    ADD CONSTRAINT fk_tadm0007_tadm0008 FOREIGN KEY ( cod_menu )
        REFERENCES erp_menu ( cod_menu )
    NOT DEFERRABLE;
