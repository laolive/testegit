insert into erp_grupo_empresarial (COD_GRUPO_EMPRSL, NOM_GRUPO_EMPRSL, DES_PREFIX_LOGIN_USU)
values (1, 'INFORMAR', '976.');
