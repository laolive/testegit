ALTER TABLE erp_alerta
    ADD CONSTRAINT fk_terp0027_terp0001 FOREIGN KEY ( cod_emp )
        REFERENCES erp_empresa ( cod_emp )
    NOT DEFERRABLE;
