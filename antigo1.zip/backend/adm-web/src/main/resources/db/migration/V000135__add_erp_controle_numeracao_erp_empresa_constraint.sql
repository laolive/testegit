ALTER TABLE erp_controle_numeracao
    ADD CONSTRAINT fk_terp1001_terp0001 FOREIGN KEY ( cod_emp )
        REFERENCES erp_empresa ( cod_emp )
    NOT DEFERRABLE;
