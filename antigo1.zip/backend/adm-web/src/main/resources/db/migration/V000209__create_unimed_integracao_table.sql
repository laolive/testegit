CREATE TABLE unimed_integracao (
    id                   NUMBER (18) NOT NULL,
    empresa_id           NUMBER (18) NOT NULL,
    unimed_id            NUMBER (18) NOT NULL,
    tipo_integracao_id   NUMBER (18) NOT NULL,
    url_integracao       VARCHAR2 (255) NOT NULL,
    data_inicio          DATE NOT NULL,
    data_fim             DATE
);

ALTER TABLE unimed_integracao
    ADD CONSTRAINT unimed_integracao_pk
        PRIMARY KEY(id) ;

ALTER TABLE unimed_integracao
    ADD CONSTRAINT tipo_integracao_id_fk
        FOREIGN KEY (tipo_integracao_id) REFERENCES tipo_integracao (id) ;
        
ALTER TABLE unimed_integracao
    ADD CONSTRAINT empresa_id_fk
        FOREIGN KEY (empresa_id) REFERENCES ERP_EMPRESA (COD_EMP);
        
ALTER TABLE unimed_integracao
    ADD CONSTRAINT unimed_id_fk
        FOREIGN KEY (unimed_id) REFERENCES ERP_UNIMED (COD_UNIMED);

ALTER TABLE unimed_integracao
    ADD CONSTRAINT unimed_integracao_unimed_id_uk
        UNIQUE (unimed_id, tipo_integracao_id);

COMMENT ON TABLE unimed_integracao IS 'Unimed integração';
COMMENT ON COLUMN unimed_integracao.id IS 'ID da Unimed integração';
COMMENT ON COLUMN unimed_integracao.empresa_id IS 'ID da empresa';
COMMENT ON COLUMN unimed_integracao.unimed_id IS 'ID da Unimed';
COMMENT ON COLUMN unimed_integracao.tipo_integracao_id IS 'Tipo de integração';
COMMENT ON COLUMN unimed_integracao.url_integracao IS 'URL da integração';
COMMENT ON COLUMN unimed_integracao.data_inicio IS 'Data inicial da utilização do sistema';
COMMENT ON COLUMN unimed_integracao.data_fim IS 'Data final da utilização do sistema';

CREATE SEQUENCE s_unimed_integracao
    MINVALUE 1 MAXVALUE 999999999999999999
        NOCACHE ORDER;
