ALTER TABLE adm_grupo_acesso
    ADD CONSTRAINT fk_tadm0001_terp0001 FOREIGN KEY ( cod_emp )
        REFERENCES erp_empresa ( cod_emp )
    NOT DEFERRABLE;
