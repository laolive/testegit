ALTER TABLE erp_transacao_campo
    ADD CONSTRAINT fk_terp0008_terp0007 FOREIGN KEY ( cod_transc )
        REFERENCES erp_transacao ( cod_transc )
    NOT DEFERRABLE;
