CREATE TABLE erp_rotina_filtro (
    cod_rotina         NUMBER(10) NOT NULL,
    cod_filtro         NUMBER(6) NOT NULL,
    nro_ordem_aprstr   NUMBER(6) NOT NULL,
    des_label          VARCHAR2(100) NOT NULL,
    flg_obr            CHAR(1) NOT NULL,
    tip_dado           VARCHAR2(1) NOT NULL,
    nom_domain         VARCHAR2(100),
    nom_tabela         VARCHAR2(30),
    qtd_tmanho_min     NUMBER(3),
    qtd_tmanho_max     NUMBER(3),
    val_padrao         VARCHAR2(100),
    dat_ativ           DATE,
    dat_inativ         DATE,
    des_obs            VARCHAR2(2000)
);

COMMENT ON TABLE erp_rotina_filtro is 'TERP0014: Filtro da Rotina';
COMMENT ON COLUMN erp_rotina_filtro.cod_rotina is 'Rotina: Código da rotina';
COMMENT ON COLUMN erp_rotina_filtro.cod_filtro is 'Código: Código do filtro';
COMMENT ON COLUMN erp_rotina_filtro.nro_ordem_aprstr is 'Ordem: Ordem para apresentação do filtro';
COMMENT ON COLUMN erp_rotina_filtro.des_label is 'Label: Label (texto) que será apresentada para o filtro';
COMMENT ON COLUMN erp_rotina_filtro.flg_obr is 'Obrigatório: Informa se o filtro é de preenchimento obrigatório | FLAG';
COMMENT ON COLUMN erp_rotina_filtro.tip_dado is 'Tipo de dado: Tipo de dado permitido para o filtro | TIPO_DADO';
COMMENT ON COLUMN erp_rotina_filtro.nom_domain is 'Domínio: Nome do domínio que contém os valores permitidos no valor do filtro';
COMMENT ON COLUMN erp_rotina_filtro.nom_tabela is 'Tabela: Nome da tabela que contém os valores permitidos no valor do parâmetro';
COMMENT ON COLUMN erp_rotina_filtro.qtd_tmanho_min is 'Tamanho mínimo: Quantidade mínima de caracteres ao preencher o filtro';
COMMENT ON COLUMN erp_rotina_filtro.qtd_tmanho_max is 'Tamanho máximo: Quantidade máxima de caracteres ao preencher o filtro';
COMMENT ON COLUMN erp_rotina_filtro.val_padrao is 'Valor: Valor padrão para o filtro';
COMMENT ON COLUMN erp_rotina_filtro.dat_ativ is 'Data da ativação: Data da ativação do valor do filtro';
COMMENT ON COLUMN erp_rotina_filtro.dat_inativ is 'Data da inativação: Data da inativação do valor do filtro';
COMMENT ON COLUMN erp_rotina_filtro.des_obs is 'Observação: Orientação sobre o preenchimento e utilidade do filtro';

CREATE UNIQUE INDEX ix_pk_terp0014 ON erp_rotina_filtro ( cod_rotina ASC, cod_filtro );

ALTER TABLE erp_rotina_filtro
    ADD CONSTRAINT pk_terp0014 PRIMARY KEY ( cod_rotina,
    cod_filtro )
        USING INDEX ix_pk_terp0014;
