CREATE TABLE erp_processo_filtro (
    cod_prcsso   NUMBER(38) NOT NULL,
    cod_filtro   NUMBER(6) NOT NULL,
    cod_rotina   NUMBER(10) NOT NULL,
    des_label    VARCHAR2(100) NOT NULL,
    val_param    VARCHAR2(100)
);

COMMENT ON TABLE erp_processo_filtro is 'TERP0016: Filtro do Processo';
COMMENT ON COLUMN erp_processo_filtro.cod_prcsso is 'Agendamento: Numeração sequencial do agendamento do processo';
COMMENT ON COLUMN erp_processo_filtro.cod_filtro is 'Código: Código do filtro do processo';
COMMENT ON COLUMN erp_processo_filtro.cod_rotina is 'Rotina: Código da rotina executada pelo processo';
COMMENT ON COLUMN erp_processo_filtro.des_label is 'Label: Label (texto) apresentada para identificar o filtro do processo';
COMMENT ON COLUMN erp_processo_filtro.val_param is 'Valor: Valor do filtro utilizado no agendamento do processo';

CREATE UNIQUE INDEX ix_pk_terp0016 ON erp_processo_filtro ( cod_prcsso, cod_filtro );

ALTER TABLE erp_processo_filtro
    ADD CONSTRAINT pk_terp0016 PRIMARY KEY ( cod_prcsso,
    cod_filtro )
        USING INDEX ix_pk_terp0016;
