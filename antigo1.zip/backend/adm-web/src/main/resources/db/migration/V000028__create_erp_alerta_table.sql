CREATE TABLE erp_alerta (
    cod_alerta         NUMBER(38) NOT NULL,
    dth_grcao          DATE NOT NULL,
    cod_usu_grcao      NUMBER(6) NOT NULL,
    des_assunt         VARCHAR2(40) NOT NULL,
    tip_alerta         VARCHAR2(2) NOT NULL,
    tip_envio_alerta   VARCHAR2(2) NOT NULL,
    flg_pnte_envio     CHAR(1) NOT NULL,
    des_alerta         VARCHAR2(2000),
    cod_usu_destin     NUMBER(6),
    cod_prcsso         NUMBER(38),
    cod_emp            NUMBER(3)
);

COMMENT ON TABLE erp_alerta is 'TERP0027: Alerta';
COMMENT ON COLUMN erp_alerta.cod_alerta is 'Sequencial: Código sequencial do alerta';
COMMENT ON COLUMN erp_alerta.dth_grcao is 'Data: Data e hora da geração do alerta';
COMMENT ON COLUMN erp_alerta.cod_usu_grcao is 'Usuário: Usuário que gerou o alerta';
COMMENT ON COLUMN erp_alerta.des_assunt is 'Assunto: Assunto do alerta';
COMMENT ON COLUMN erp_alerta.tip_alerta is 'Tipo: Informa o tipo do alerta a ser enviado ao usuário| TIPO_ALERTA_USUARIO';
COMMENT ON COLUMN erp_alerta.tip_envio_alerta is 'Tipo de envio: Informa o tipo de envio do alerta ao usuário | TIPO_ENVIO_ALERTA_USUARIO';
COMMENT ON COLUMN erp_alerta.flg_pnte_envio is 'Pendente: Informa se o alerta está pendente de envio | FLAG';
COMMENT ON COLUMN erp_alerta.des_alerta is 'Mensagem: Mensagem completa do alerta';
COMMENT ON COLUMN erp_alerta.cod_usu_destin is 'Usuário: Usuário alertado';
COMMENT ON COLUMN erp_alerta.cod_prcsso is 'Processo: Processo que gerou o alerta';
COMMENT ON COLUMN erp_alerta.cod_emp is 'Empresa: Código da empresa para a qual se destina o alerta';

CREATE UNIQUE INDEX ix_pk_terp0027 ON erp_alerta ( cod_alerta );

CREATE INDEX ix_fk_terp0027_tadm0002_2 ON erp_alerta ( cod_usu_destin );

CREATE INDEX ix_fk_terp0027_tadm0002_1 ON erp_alerta ( cod_usu_grcao );

CREATE INDEX ix_fk_terp0027_terp0001 ON erp_alerta ( cod_emp );

CREATE INDEX ix_terp0027_1 ON erp_alerta ( cod_prcsso );

ALTER TABLE erp_alerta
    ADD CONSTRAINT pk_terp0027 PRIMARY KEY ( cod_alerta )
        USING INDEX ix_pk_terp0027;
