ALTER TABLE adm_grupo_acesso_parametro
    ADD CONSTRAINT fk_tadm0011_terp0005 FOREIGN KEY ( cod_param )
        REFERENCES erp_parametro ( cod_param )
    NOT DEFERRABLE;
