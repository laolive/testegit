ALTER TABLE erp_processo_arquivo
    ADD CONSTRAINT fk_terp0017_terp0015 FOREIGN KEY ( cod_prcsso )
        REFERENCES erp_processo ( cod_prcsso )
    NOT DEFERRABLE;
