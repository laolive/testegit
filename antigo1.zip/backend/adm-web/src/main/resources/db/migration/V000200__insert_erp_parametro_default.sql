insert into ERP_PARAMETRO (COD_PARAM, DES_LABEL, COD_GRUPO_PARAM, IND_OPCAO_USU, TIP_DADO, FLG_OBR, FLG_GLOBAL, NOM_DOMAIN, NOM_TABELA, DES_OBS)
values ('URL_AUTSC', 'URL do AUTSC', 1, 'A', 'N', 'N', 'S', null, null, 'Informa a URL do AUTSC.');
insert into ERP_PARAMETRO (COD_PARAM, DES_LABEL, COD_GRUPO_PARAM, IND_OPCAO_USU, TIP_DADO, FLG_OBR, FLG_GLOBAL, NOM_DOMAIN, NOM_TABELA, DES_OBS)
values ('UNIMED_ORIGEM', 'Código da Unimed padrão do sistema', 1, 'A', 'N', 'N', 'S', null, null, 'Informa o código da Unimed utilizadora do sistema');
