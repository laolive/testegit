CREATE TABLE erp_grupo_empresarial (
    cod_grupo_emprsl       NUMBER(6) NOT NULL,
    nom_grupo_emprsl       VARCHAR2(60) NOT NULL,
    des_prefix_login_usu   VARCHAR2(5)
);

COMMENT ON TABLE erp_grupo_empresarial is 'TERP0023: Grupo Empresarial';
COMMENT ON COLUMN erp_grupo_empresarial.cod_grupo_emprsl is 'Código: Código do grupo de empresas';
COMMENT ON COLUMN erp_grupo_empresarial.nom_grupo_emprsl is 'Nome: Nome do grupo de empresas';
COMMENT ON COLUMN erp_grupo_empresarial.des_prefix_login_usu is 'Prefixo do login do usuário: Informa o prefixo que deve compor o login do usuário no sistema';

CREATE INDEX ix_pk_terp0023 ON erp_grupo_empresarial ( cod_grupo_emprsl );

CREATE INDEX ix_uk_terp0023 ON erp_grupo_empresarial ( des_prefix_login_usu );

ALTER TABLE erp_grupo_empresarial
    ADD CONSTRAINT pk_terp0023 PRIMARY KEY ( cod_grupo_emprsl )
        USING INDEX ix_pk_terp0023;

ALTER TABLE erp_grupo_empresarial ADD CONSTRAINT uk_terp0023 UNIQUE ( des_prefix_login_usu )
    USING INDEX ix_uk_terp0023;
