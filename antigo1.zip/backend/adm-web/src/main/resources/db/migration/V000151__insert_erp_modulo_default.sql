insert into ERP_MODULO (COD_MODULO, DES_MODULO, FLG_CNTRLA_PERIOD)
values ('ADM', 'Administração do Sistema', 'N');

insert into ERP_MODULO (COD_MODULO, DES_MODULO, FLG_CNTRLA_PERIOD)
values ('AME', 'Auditoria da Margem Econômica', 'N');

insert into ERP_MODULO (COD_MODULO, DES_MODULO, FLG_CNTRLA_PERIOD)
values ('AUT', 'Autorizador', 'N');

insert into ERP_MODULO (COD_MODULO, DES_MODULO, FLG_CNTRLA_PERIOD)
values ('CAD', 'Cadastros', 'N');

insert into ERP_MODULO (COD_MODULO, DES_MODULO, FLG_CNTRLA_PERIOD)
values ('CRM', 'CRM', 'N');

insert into ERP_MODULO (COD_MODULO, DES_MODULO, FLG_CNTRLA_PERIOD)
values ('CTB', 'Contábil', 'S');

insert into ERP_MODULO (COD_MODULO, DES_MODULO, FLG_CNTRLA_PERIOD)
values ('FIN', 'Financeiro', 'S');

insert into ERP_MODULO (COD_MODULO, DES_MODULO, FLG_CNTRLA_PERIOD)
values ('FPR', 'FPR', 'N');

insert into ERP_MODULO (COD_MODULO, DES_MODULO, FLG_CNTRLA_PERIOD)
values ('PRT', 'Protocolos', 'N');

insert into ERP_MODULO (COD_MODULO, DES_MODULO, FLG_CNTRLA_PERIOD)
values ('RES', 'Registro Eletrônico de Saúde', 'N');

insert into ERP_MODULO (COD_MODULO, DES_MODULO, FLG_CNTRLA_PERIOD)
values ('SUP', 'Suprimentos', 'N');
