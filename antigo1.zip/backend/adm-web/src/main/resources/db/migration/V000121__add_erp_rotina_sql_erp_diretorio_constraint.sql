ALTER TABLE erp_rotina_sql
    ADD CONSTRAINT fk_terp0022_terp0021 FOREIGN KEY ( nom_dir )
        REFERENCES erp_diretorio ( nom_dir )
    NOT DEFERRABLE;
