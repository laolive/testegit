insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100181, 'E', 'Parâmetro :1 não cadastrado ou não disponível em memória para a empresa :2.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100182, 'E', 'O conteúdo informado em :1 não deve ter espaços em branco.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100183, 'E', 'Para pessoa do tipo Jurídica o campo :1 não deve ser preenchido.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100184, 'E', 'Para pessoa do tipo Física o campo :1 deve ser preenchido.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100001, 'E', 'O campo :1 é obrigatório.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100002, 'E', ':1 não cadastrado(a). :2', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100003, 'E', 'Existe(m) registro(s) relacionado(s): :1.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100004, 'E', 'Valor do campo :1 inválido.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100005, 'E', 'ERRO [ROTINA :1] [OPERAÇÃO :2] :3', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100006, 'E', 'O comando SQL informado para :1 (:2) é inválido.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100007, 'E', 'Erro ao executar  :1 (:2).', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100008, 'E', 'Fórmula inválida :1', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100009, 'E', 'Já existe o país :1 com o código BACEN :2.', 'Não é permitido cadastrar mais de um país com o mesmo código BACEN.', null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100010, 'E', 'Já existe a unidade federativa :1 com o código IBGE :2.', 'Não é permitido cadastrar mais de uma unidade federativa com o mesmo código IBGE.', null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100011, 'E', 'Já existe o município :1 com o código IBGE :2.', 'Não é permitido cadastrar mais de um município com o mesmo código IBGE.', null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100012, 'E', ':1 já existe. :2', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100013, 'E', 'O campo :1 deve ter tamanho entre :2 e :3.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100014, 'E', 'Para parâmetro do tipo :1 o campo :2 não deve ser informado.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100015, 'E', 'O campo ":1" deve ter conteúdo igual ou maior que o do campo ":2".', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100016, 'E', 'O número de valores informados ultrapassou a :1 definida para o parâmetro :2. [:3]', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100017, 'E', 'Não é permitido agrupar regras contábeis com tipos de lançamentos diferentes. (Regra :1)', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100018, 'E', 'Informar ao menos um dos campos: :1.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100019, 'E', ':1 :2 obriga que seja informado :3.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100020, 'E', ':1 ":2" não permite que seja informado :3.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100021, 'E', 'A data inicial de um período deve ser o dia subsequente ao final do período anterior (:1).', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100022, 'E', 'O período deve ser informado dentro do exercício.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100023, 'E', 'O intervalo de datas informado já está previsto em outro período.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100024, 'E', 'Uma questão não pode executar ações sobre suas respostas.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100025, 'E', 'Uma questão não pode ser controlada por suas respostas.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100026, 'E', 'Não é permitido informar uma resposta inativa (:1).', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100027, 'E', 'Encontrado mais de um plano de contas para o mesmo documento (Datas: :1 e :2).', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100028, 'E', 'O tipo de saldo exige e permite que seja(m) preenchida(s) apenas a(s) informação(ões) :1.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100029, 'E', 'O documento legal informado [:1] não está de acordo com o tipo da pessoa [:2].', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100030, 'E', ':1 :2 já aprovado.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100031, 'E', ':1 :2 está sendo utilizado e não pode ser atualizado!', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100032, 'E', 'Período :1 bloqueado em :2.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100033, 'E', 'Solicitação de bloqueio do período :1 já foi realizada. Cálculo dos saldos está sendo processado.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100034, 'E', 'Usuário :1 não parametrizado para o tipo de aprovação (Padrão ou Faixa).', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100035, 'E', 'O bloqueio de um período não é permitido enquanto houver período anterior aberto.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100036, 'E', 'Usuário :1, diferente do Usuário Aprovador deste Documento (Usuário: :2).', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100037, 'E', 'Período :1 não está bloqueado.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100038, 'E', 'Não é permitido desfazer o bloqueio do período :1 enquanto o cálculo dos saldos estiver processando.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100039, 'E', 'Não é permitido desfazer o bloqueio do período :1 fechado.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100040, 'E', 'Não é permitido desfazer o bloqueio do período :1 enquanto houver período posterior bloqueado.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100041, 'E', 'O fechamento de um período não é permitido enquanto houver período anterior aberto.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100042, 'E', 'Não é possível fechar um período enquanto o cálculo dos saldos estiver processando.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100043, 'E', 'Para fechar um período é preciso que ele esteja bloqueado.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100044, 'E', 'Período :1 fechado em :2.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100045, 'E', 'O período :1 não está fechado.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100046, 'E', 'Não é permitido desfazer o fechamento do período :1 enquanto houver período posterior bloqueado.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100047, 'E', 'Informar apenas um dos campos: :1.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100048, 'E', ':1 já informado(a): :2', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100049, 'E', ':1 :2 já aprovado.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100050, 'E', 'O documento informado [:1] já está cadastrado para a pessoa [:2].', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100051, 'E', 'O documento [:1] informado para a pessoa [:2] não é um número válido.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100052, 'E', 'É preciso efetuar logon no sistema para que o grupo empresarial seja definido automaticamente.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100053, 'E', 'Não é permitido alterar o grupo empresarial do usuário.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100054, 'E', 'Usuário pode ter acesso apenas aos dados das empresas do grupo empresarial ao qual pertence.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100055, 'E', 'Existe outro(a) :1 com a mesma vigência de :2.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100056, 'E', 'Os campos ":1" e ":2" não podem ter conteúdo idêntico.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100057, 'E', 'Não existe registro em ":1" com o código contábil :2.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100058, 'E', '":1" não possui vínculo com ":2" através de código contábil.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100059, 'E', 'A conta contábil ":1" obriga que seja informado o campo ":2".', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100060, 'E', 'A conta contábil ":1" não permite que seja informado o campo ":2".', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100061, 'E', '":1" deve ser preenchido com valor maior que 0 (zero) e menor ou igual a 100 (cem).', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100062, 'E', 'Informar todos ou nenhum dos campos: :1.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100063, 'E', 'Informar um dos campos: :1.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100064, 'E', 'A conta contábil ":1" está parametrizada para não aceitar lançamentos.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100065, 'E', '":1" :2 não pode receber lançamentos de acordo com o seu período de vigência (:3 a :4). Data do lançamento: :5.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100066, 'E', 'O ":1" :2 está bloqueado e não pode ser utilizado.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100067, 'E', 'Não foi possível encontrar o(s) usuário(s) aprovador(es) para o Tipo de Documento :1 e Faixa :2.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100068, 'E', 'Documento :1 encontra-se cancelado. Não é permitida a aprovação ou rejeição.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100069, 'E', 'Documento :1 já rejeitado. Favor executar a rotina de aprovação de documento.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100070, 'E', '":1" deve ser preenchido com valor maior que 0 (zero).', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100071, 'E', 'Não é permitido registrar lançamentos contábeis se o período estiver fechado (data do lançamento :1).', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100072, 'E', 'Não é permitido registrar lançamentos contábeis enquanto o cálculo dos saldos estiver processando (data do lançamento :1).', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100073, 'E', 'Somente lançamentos manuais são permitidos em um período bloqueado (data do lançamento :1).', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100074, 'E', 'O campo ":1" não pode ser alterado.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100075, 'E', 'Somente lançamentos manuais podem ser alterados. (Lançamento :1)', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100076, 'E', 'A data de :1 (:2) não pode ser anterior à data de :3 (:4).', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100077, 'E', 'O plano de contas informado (:1) não é o vigente na data do lançamento (:2). Plano de contas vigente: 3.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100078, 'E', 'A espécie :1 não permite sua utilização no :2.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100079, 'E', 'O rateio :1 está parametrizado para utilizar ":2". Porém, não foi encontrado ":3".', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100080, 'E', 'Nenhuma filial parametrizada como matriz na empresa :1.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100081, 'E', 'Nenhum registro encontrado para processamento. Favor, rever os parâmetros informados.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100082, 'E', 'Nenhum saldo encontrado para rateio em: :1.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100083, 'E', 'Quantidade de Parcelas da condição de pagamento :1, maior que a quantidade de parcelas a serem inseridas.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100084, 'E', 'Quantidade de Parcelas da condição de pagamento :1, menor que a quantidade de parcelas a serem inseridas.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100085, 'E', 'Soma dos percentuais das parcelas menor que 100%.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100086, 'E', 'Soma dos percentuais das parcelas maior que 100%.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100087, 'E', 'O item :1 sequência :2 deve possuir quantidade superior a zero.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100088, 'E', 'O item :1 possui situação igual a :2 na filial :3.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100089, 'E', ':1 não existe ou não esta ativa.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100090, 'E', 'Não existe itens a serem atualizados para :1.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100091, 'E', 'Não existe itens ativos a serem atualizados para :1.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100092, 'E', 'Não existe itens inativos a serem atualizados para :1.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100093, 'E', 'O item :1 não está cadastrado para a filial :2.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100094, 'E', 'O item :1 não está classificado com um item de compra.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100095, 'E', 'O item :1 possui situação igual a :2 na empresa :3.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100096, 'E', 'Situação do documento :1 é igual a :2 . Alteração do documento não é permitida.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100097, 'E', 'Situação do item :1/:2, do documento :3 é igual a :4 . Alteração do documento não é permitida.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100098, 'E', 'Código da Entidade Contábil :1 diferente do código gerado anteriormente :2.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100099, 'E', 'Data de entrega :1 menor que o tempo de ressuprimento de :2 dias para item :3.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100100, 'E', 'O Fato Gerador (:1) do Tributo (:2) vinculado ao título não confere com o que está definido em seu cadastro (:3).', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100101, 'E', 'O somatório do rateio das apropriações informadas (:1) é diferente do valor do título (:2).', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100102, 'E', 'Não é possível calcular as bases de rateio por ato de um período enquanto o cálculo dos saldos estiver processando.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100103, 'E', 'A quantidade minima para compra do item :1 é de :2 :3.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100104, 'E', 'A quantidade informada para o item :1 não é multipla de :2', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100105, 'E', 'Título a pagar com espécie do tipo Imposto (:1) deve ter o código do tributo informado.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100106, 'E', 'A origem do título a pagar é desconhecida. Favor entrar em contato com o suporte.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100107, 'E', 'O campo :1 é obrigatório para :2.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100108, 'E', 'O tipo de movimento do título a pagar é desconhecido. Favor entrar em contato com o suporte.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100109, 'E', 'O movimento de :1 não pode ser realizado em :2 pois o título :3 já possui movimentos criados após esta data.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100110, 'E', ':1 não foi informado(a) para o Rateio :2.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100111, 'E', 'Não é permitido vincular imposto à títulos do tipo :1.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100112, 'E', 'O valor :1 é inválido para ":2".', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100113, 'E', ':1 calculado (:2) é diferente do informado (:3).', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100114, 'E', 'O processo :1 não está pendente de geração.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100115, 'E', 'Favor selecionar uma ou mais cotações para efetuar a aprovação do melhor fornecedor.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100116, 'E', 'O login do usuário no sistema deve estar de acordo com o prefixo definido no grupo empresarial (:1).', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100117, 'E', 'O login do usuário no sistema não deve ser idêntico ao prefixo definido no grupo empresarial (:1).', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100118, 'E', 'Rever parâmetros informados para nova geração, pois com os filtros informados no processo nada foi gerado!', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100119, 'E', 'O valor informado em :1 deve ter no mínimo [:2] caracteres.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100120, 'E', 'O valor informado em :1 deve ser um número com no mínimo [:2] posições.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100121, 'E', 'O valor informado em :1 deve ter no máximo [:2] caracteres.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100122, 'E', 'O valor informado em :1 deve ser um número com no máximo [:2] posições.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100123, 'E', 'Somente itens de menu que possuem vínculo com uma transação podem ser acessados (Código do menu :1).', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100124, 'E', 'Documento de Cotação :1 a ser processado, encontra-se Pendente. Favor efetuar o processo de Envio, Retorno e Aprovação da Cotação.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100125, 'E', 'Não é possível processar o Documento de Cotacação :1, pois o mesmo encontra-se aprovado.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100126, 'E', 'Não é possível processar o Documento de Cotação :1, pois o mesmo encontra-se Fechado.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100127, 'E', 'Não é possivel efetuar o processo de geração de pedido sem antes concluir o processo de cotação dos fornecedores, do Documento de Cotação :1.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100128, 'E', 'Documento de Cotação :1, a ser processado, encontra-se Pendente de Retorno dos Fornecedores. Favor efetuar o processo de Envio e Retorno, e repita a Operação.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100129, 'E', 'A lista de opções está incompleta. A opção :1 (:2) não foi informada.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100130, 'E', 'A lista de filtros está incompleta. O filtro :1 (:2) não foi informado.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100131, 'E', 'Fornecedor :1 possui situação igual a :2.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100132, 'E', 'O item :1 sequência :2 deve possuir preço superior a zero.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100133, 'E', 'O processo :1 foi agendado por JOB e não pode ser executado desta forma.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100134, 'E', 'Não existe registro em :1 que corresponda ao valor informado (:2).', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100135, 'E', 'Existe mais de um registro em :1 correspondente ao valor informado (:2).', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100136, 'E', 'O agendamento deve ser feito para execução do processo em data futura. Data informada: :1', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100137, 'A', 'Processo :1 concluído.', 'Alerta comunicando que o processo foi concluído.', null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100138, 'A', 'O processo :1 (:2) foi concluído. Favor, verificar :3', 'Alerta comunicando que o processo foi concluído e solicitando que sejam verificadas as saídas.', null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100139, 'E', 'Existe item(s) que possuem o mesmo preço para diferentes fornecedores que impedem a sugestão da melhor cotação.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100140, 'A', 'Nenhum conta definida como destino do rateio :1.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100141, 'E', 'Não foi possível determinar a base do percentual para aplicação do rateio :1.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100142, 'E', 'Situação do período contábil não permite lançamento em :1. (Situação: :2)', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100143, 'E', ':1 não é do tipo :2 [Coluna :3].', 'A informação obtida não é compatível com o tipo de dado esperado.', null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100144, 'E', 'Para o tributo '':1'' a informação do Código de Retenção é obrigatória.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100145, 'E', 'Item :1 informado não cadastrado(a) para a solicitação :2 sequência :3.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100146, 'E', 'A regra :1 não foi atendida.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100147, 'E', 'O total dos débitos difere do total dos créditos no lote :1. (Débitos: :2. Créditos: :3).', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100148, 'E', 'O Fluxo de Caixa informado para apropriação da despesa deve ser do tipo Analítico.(Código: :1 Tipo: :2).', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100149, 'E', 'Já existe :1 com :2 :3.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100150, 'E', 'Nenhuma regra ativa encontrada em :1 para a origem :2.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100151, 'E', 'Sessão (:1,:2) do processo :3 encerrada.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100152, 'E', 'Processo :1 marcado como cancelado.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100153, 'E', 'Processo :1 já foi finalizado.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100154, 'E', 'Não é permitida a inclusão de restrição para a filial titular da conta corrente.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100155, 'E', 'Espécie do tipo '':1'' não pode ter origem diferente de '':2''.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100156, 'E', 'Espécie com origem '':1'' não deve ter o parâmetro '':2'' marcado.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100157, 'E', 'Valor inválido informado para Desconto\Despesa '':1''.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100158, 'E', 'Não será possível alterar o tipo da Espécie '':1'' pois a mesma possui Título(s) relacionado(s).', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100159, 'E', 'Necessário informar a conta contábil e o plano de contas válido ou deixar os mesmos nulos para continuar o processo.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100160, 'E', ':1 '':2'' incompatível com :3 '':4''.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100161, 'E', 'Não é permitido incluir ou alterar lançamentos em lotes fechados. (Lote :1)', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100162, 'E', 'A origem :1 não está parametrizada para utilização de regras contábeis.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100163, 'E', 'O :1 de um período não é permitido enquanto houver lote contábil aberto. Exemplo: lote :2.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100164, 'E', 'Nenhum item de pedido selecionado para gerar os itens da nota fiscal. Favor selecionar ao menos um item.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100165, 'E', 'Forma de pagamento inválida para Integração Bancária - EDI.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100166, 'E', 'Destino inválido para a forma de pagamento informada.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100167, 'E', 'Ocorrência bancária '':1'' inválida para a transação '':2'' e tipo de arquivo '':3''.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100168, 'E', 'Os dados para apropriação (rateio) da despesa não foram informados. :1', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100169, 'E', 'Não foi possível determinar a data do último fechamento para a composição dos saldos (:1 a :2)', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100170, 'E', 'Não há plano de contas vigente no período informado (:1 a :2)', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100171, 'E', 'Há mais de um plano de contas vigente no período informado (:1 a :2)', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100172, 'E', 'O tributo '':1'' não permite retenção.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100173, 'E', 'O tipo da Espécie informada para o título não permite a retenção de impostos.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100174, 'E', 'Quantidade de Títulos :1 maior que a quantidade de parcelas :2, da condição de pagamento :3, da Nota Fiscal.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100175, 'E', 'Quantidade de Títulos :1 menor que a quantidade de parcelas :2, da condição de pagamento :3, da Nota Fiscal.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100176, 'E', 'Fornecedor :1 encontra-se :2, não sendo permitido a geração dos títulos para o mesmo', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100177, 'E', 'Data de Emissão :1 maior que a data de vencimento :2 do Título :3.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100178, 'E', 'Data de Vencimento :1 do Título :2, menor que a data de vencimento :3 do Título :4.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100179, 'E', 'O vendedor superior informado possui o vendedor como seu superior.', null, null);

insert into erp_mensagem (COD_MSG, TIP_MSG, DES_MSG, DES_EXPLIC, DES_ACAO_CORTVA)
values (100180, 'E', 'A :1 do código :2 está bloqueado e não pode ser utilizado.', null, null);
