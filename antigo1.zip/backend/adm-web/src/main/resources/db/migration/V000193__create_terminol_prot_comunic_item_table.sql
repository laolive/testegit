CREATE TABLE terminol_prot_comunic_item (
    id                             NUMBER(18) NOT NULL,
    terminologia_prot_comunic_id   NUMBER(18) NOT NULL,
    valor                          VARCHAR2(20) NOT NULL,
    descricao                      VARCHAR2(300) NOT NULL,
    dominio_item_id                NUMBER(18)
);

ALTER TABLE terminol_prot_comunic_item
    ADD CONSTRAINT terminol_prot_comunic_item_pk
        PRIMARY KEY (id);

ALTER TABLE terminol_prot_comunic_item
    ADD CONSTRAINT item_termino_prot_comnc_id_fk
        FOREIGN KEY (terminologia_prot_comunic_id) REFERENCES terminologia_prot_comunic (id);

ALTER TABLE terminol_prot_comunic_item
    ADD CONSTRAINT item_terminol_domino_ite_id_fk
        FOREIGN KEY (dominio_item_id) REFERENCES dominio_item (id) ;

ALTER TABLE terminol_prot_comunic_item
    ADD CONSTRAINT terminol_prot_comunic_item_uk
        UNIQUE (terminologia_prot_comunic_id,valor);

COMMENT ON TABLE terminol_prot_comunic_item IS 'Item da terminologia do protocolo de comunicação';
COMMENT ON COLUMN terminol_prot_comunic_item.id IS 'ID do item da terminologia no protocolo de comunicação';
COMMENT ON COLUMN terminol_prot_comunic_item.terminologia_prot_comunic_id IS 'ID da terminologia no protocolo de comunicação';
COMMENT ON COLUMN terminol_prot_comunic_item.valor IS 'Valor do item da terminologia';
COMMENT ON COLUMN terminol_prot_comunic_item.descricao IS 'Descrição do item da terminologia';
COMMENT ON COLUMN terminol_prot_comunic_item.dominio_item_id IS 'ID do item do domínio';
