insert into PROTOCOLO_COMUNIC_VERSAO (id, protocolo_comunicacao_id, versao, data_vigencia)
values (1, 1, '70', to_date('01-09-2017', 'dd-mm-yyyy'));
insert into PROTOCOLO_COMUNIC_VERSAO (id, protocolo_comunicacao_id, versao, data_vigencia)
values (2, 2, '3.03.02', to_date('28-12-2017', 'dd-mm-yyyy'));
