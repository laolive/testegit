insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (612, 96, 'AC', 'ACRE', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (613, 96, 'AL', 'ALAGOAS', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (614, 96, 'AM', 'AMAZONAS', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (615, 96, 'AP', 'AMAPÁ', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (616, 96, 'BA', 'BAHIA', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (617, 96, 'CE', 'CEARÁ', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (618, 96, 'DF', 'DISTRITO FEDERAL', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (619, 96, 'ES', 'ESPÍRITO SANTO', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (620, 96, 'EX', 'PAÍSES ESTRANGEIROS', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (621, 96, 'GO', 'GOIÁS', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (622, 96, 'MA', 'MARANHÃO', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (623, 96, 'MG', 'MINAS GERAIS', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (624, 96, 'MS', 'MATO GROSSO DO SUL', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (625, 96, 'MT', 'MATO GROSSO', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (626, 96, 'PA', 'PARÁ', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (627, 96, 'PB', 'PARAÍBA', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (628, 96, 'PE', 'PERNAMBUCO', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (629, 96, 'PI', 'PIAUÍ', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (630, 96, 'PR', 'PARANÁ', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (631, 96, 'RJ', 'RIO DE JANEIRO', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (632, 96, 'RN', 'RIO GRANDE DO NORTE', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (633, 96, 'RO', 'RONDÔNIA', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (634, 96, 'RR', 'RORAIMA', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (635, 96, 'RS', 'RIO GRANDE DO SUL', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (636, 96, 'SC', 'SANTA CATARINA', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (637, 96, 'SE', 'SERGIPE', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (638, 96, 'SP', 'SÃO PAULO', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (639, 96, 'TO', 'TOCANTINS', null, null, null);
