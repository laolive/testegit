ALTER TABLE erp_alerta_leitura
    ADD CONSTRAINT fk_terp0028_terp0027 FOREIGN KEY ( cod_alerta )
        REFERENCES erp_alerta ( cod_alerta )
    NOT DEFERRABLE;
