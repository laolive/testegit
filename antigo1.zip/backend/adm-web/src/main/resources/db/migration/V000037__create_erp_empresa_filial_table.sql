CREATE TABLE erp_empresa_filial (
    cod_emp             NUMBER(3) NOT NULL,
    cod_filial          NUMBER(3) NOT NULL,
    nom_filial_aprstr   VARCHAR2(20) NOT NULL,
    dat_inativ          DATE
);

COMMENT ON TABLE erp_empresa_filial is 'TERP0002: Filial';
COMMENT ON COLUMN erp_empresa_filial.cod_emp is 'Empresa: Código da empresa';
COMMENT ON COLUMN erp_empresa_filial.cod_filial is 'Filial: Código da filial';
COMMENT ON COLUMN erp_empresa_filial.nom_filial_aprstr is 'Nome da filial: Nome da filial para apresentação no sistema';
COMMENT ON COLUMN erp_empresa_filial.dat_inativ is 'Data da inativação: Data da inativação da filial';

CREATE INDEX ix_pk_terp0002 ON erp_empresa_filial ( cod_emp, cod_filial );

ALTER TABLE erp_empresa_filial
    ADD CONSTRAINT pk_terp0002 PRIMARY KEY ( cod_emp,
    cod_filial )
        USING INDEX ix_pk_terp0002;
