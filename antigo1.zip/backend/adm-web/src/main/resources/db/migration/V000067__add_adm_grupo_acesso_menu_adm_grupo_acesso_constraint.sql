ALTER TABLE adm_grupo_acesso_menu
    ADD CONSTRAINT fk_tadm0006_tadm0001 FOREIGN KEY ( cod_emp,
    cod_grupo_acesso )
        REFERENCES adm_grupo_acesso ( cod_emp,
        cod_grupo_acesso )
    NOT DEFERRABLE;
