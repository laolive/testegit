CREATE TABLE adm_grupo_acesso_transacao (
    cod_emp            NUMBER(3) NOT NULL,
    cod_grupo_acesso   NUMBER(6) NOT NULL,
    cod_transc         NUMBER(6) NOT NULL,
    flg_incl           CHAR(1) NOT NULL,
    flg_alt            CHAR(1) NOT NULL,
    flg_excl           CHAR(1) NOT NULL
);

COMMENT ON TABLE adm_grupo_acesso_transacao is'TADM0004: Transação do Grupo de Acessos';
COMMENT ON COLUMN adm_grupo_acesso_transacao.cod_emp is'Empresa: Código da empresa';
COMMENT ON COLUMN adm_grupo_acesso_transacao.cod_grupo_acesso is'Grupo de Acessos: Código do grupo de acessos';
COMMENT ON COLUMN adm_grupo_acesso_transacao.cod_transc is'Transação: Código da transação';
COMMENT ON COLUMN adm_grupo_acesso_transacao.flg_incl is'Inclusão: Informa se o grupo de acessos possui permissão de inclusão na transação | FLAG';
COMMENT ON COLUMN adm_grupo_acesso_transacao.flg_alt is'Alteração: Informa se o grupo de acessos possui permissão de alteração na transação | FLAG';
COMMENT ON COLUMN adm_grupo_acesso_transacao.flg_excl is'Exclusão: Informa se o grupo de acessos possui permissão de exclusão na transação | FLAG';

CREATE INDEX ix_pk_tadm0004 ON adm_grupo_acesso_transacao ( cod_emp,
    cod_grupo_acesso,
    cod_transc );

CREATE INDEX ix_fk_tadm0004_terp0007 ON adm_grupo_acesso_transacao ( cod_transc );

ALTER TABLE adm_grupo_acesso_transacao
    ADD CONSTRAINT pk_tadm0004 PRIMARY KEY ( cod_emp,
    cod_grupo_acesso,
    cod_transc )
        USING INDEX ix_pk_tadm0004;
