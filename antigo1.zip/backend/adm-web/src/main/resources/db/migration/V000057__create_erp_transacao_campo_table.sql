CREATE TABLE erp_transacao_campo (
    cod_transc   NUMBER(6) NOT NULL,
    nom_campo    VARCHAR2(30) NOT NULL
);

COMMENT ON TABLE erp_transacao_campo is 'TERP0008: Campo da Transação';
COMMENT ON COLUMN erp_transacao_campo.cod_transc is 'Transação: Código da transação';
COMMENT ON COLUMN erp_transacao_campo.nom_campo is 'Campo: Nome do campo da transação';

CREATE INDEX ix_pk_terp0008 ON erp_transacao_campo ( cod_transc, nom_campo );

ALTER TABLE erp_transacao_campo
    ADD CONSTRAINT pk_terp0008 PRIMARY KEY ( cod_transc,
    nom_campo )
        USING INDEX ix_pk_terp0008;
