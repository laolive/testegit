ALTER TABLE erp_menu
    ADD CONSTRAINT fk_terp0006_terp0006 FOREIGN KEY ( cod_menu_superi )
        REFERENCES erp_menu ( cod_menu )
    NOT DEFERRABLE;
