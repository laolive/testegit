CREATE TABLE adm_usuario_menu (
    cod_usu    NUMBER(6) NOT NULL,
    cod_emp    NUMBER(3) NOT NULL,
    cod_menu   NUMBER(6) NOT NULL
);

COMMENT ON TABLE adm_usuario_menu is 'TADM0007: Menu do Usuário';
COMMENT ON COLUMN adm_usuario_menu.cod_usu is 'Usuário: Código do usuário do sistema';
COMMENT ON COLUMN adm_usuario_menu.cod_emp is 'Empresa: Código da Empresa';
COMMENT ON COLUMN adm_usuario_menu.cod_menu is 'Menu: Código do item de menu do sistema ao qual o usuário tem acesso';

CREATE INDEX ix_pk_tadm0007 ON adm_usuario_menu ( cod_usu, cod_emp, cod_menu );

CREATE INDEX ix_fk_tadm0007_tadm0008 ON adm_usuario_menu ( cod_menu );

ALTER TABLE adm_usuario_menu
    ADD CONSTRAINT pk_tadm0007 PRIMARY KEY ( cod_usu,
    cod_emp,
    cod_menu )
        USING INDEX ix_pk_tadm0007;
