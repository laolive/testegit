CREATE TABLE adm_grupo_acesso_menu (
    cod_emp            NUMBER(3) NOT NULL,
    cod_grupo_acesso   NUMBER(6) NOT NULL,
    cod_menu           NUMBER(6) NOT NULL
);

COMMENT ON TABLE adm_grupo_acesso_menu is'TADM0006: Menu do Grupo de Acessos';
COMMENT ON COLUMN adm_grupo_acesso_menu.cod_emp is'Empresa: Código da empresa';
COMMENT ON COLUMN adm_grupo_acesso_menu.cod_grupo_acesso is'Grupo de acessos: Código do grupo de acessos';
COMMENT ON COLUMN adm_grupo_acesso_menu.cod_menu is'Menu: Código do item de menu do sistema';

CREATE INDEX ix_pk_tadm0006 ON adm_grupo_acesso_menu ( cod_emp,
    cod_grupo_acesso,
    cod_menu );

CREATE INDEX ix_fk_tadm0006_tadm0008 ON adm_grupo_acesso_menu ( cod_menu );

ALTER TABLE adm_grupo_acesso_menu
    ADD CONSTRAINT pk_tadm0006 PRIMARY KEY ( cod_emp,
    cod_grupo_acesso,
    cod_menu )
        USING INDEX ix_pk_tadm0006;
