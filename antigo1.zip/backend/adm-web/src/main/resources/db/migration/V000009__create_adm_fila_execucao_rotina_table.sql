CREATE TABLE adm_fila_execucao_rotina (
    cod_rotina   NUMBER(10) NOT NULL,
    cod_emp      NUMBER(3) NOT NULL,
    cod_fila     NUMBER(3) NOT NULL
);

COMMENT ON TABLE adm_fila_execucao_rotina is'TADM0016: Rotina da Fila de Processos';
COMMENT ON COLUMN adm_fila_execucao_rotina.cod_rotina is'Código: Código da rotina';
COMMENT ON COLUMN adm_fila_execucao_rotina.cod_emp is'Empresa: Empresa que controla a fila de execução';
COMMENT ON COLUMN adm_fila_execucao_rotina.cod_fila is'Código: Código da fila para execução da rotina';

CREATE INDEX ix_fk_tadm0016_tadm0010 ON adm_fila_execucao_rotina ( cod_emp, cod_fila );

CREATE UNIQUE INDEX ix_pk_tadm0016 ON adm_fila_execucao_rotina ( cod_rotina, cod_emp );

ALTER TABLE adm_fila_execucao_rotina
    ADD CONSTRAINT pk_tadm0016 PRIMARY KEY ( cod_rotina, cod_emp )
        USING INDEX ix_pk_tadm0016;
