ALTER TABLE erp_transacao
    ADD CONSTRAINT fk_terp0007_terp0003 FOREIGN KEY ( cod_modulo )
        REFERENCES erp_modulo ( cod_modulo )
    NOT DEFERRABLE;
