insert into ERP_DIRETORIO (NOM_DIR, DES_CAMINH_BCO_DADOS, DES_CAMINH_REDE)
values ('DIR_PADRAO', '/utl/ud976des/PSGU_TEMP', '/mnt/sistemas-ud976des');
