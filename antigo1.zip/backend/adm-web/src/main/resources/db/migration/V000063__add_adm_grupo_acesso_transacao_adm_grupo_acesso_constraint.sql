ALTER TABLE adm_grupo_acesso_transacao
    ADD CONSTRAINT fk_tadm0004_tadm0001 FOREIGN KEY ( cod_emp,
    cod_grupo_acesso )
        REFERENCES adm_grupo_acesso ( cod_emp,
        cod_grupo_acesso )
    NOT DEFERRABLE;
