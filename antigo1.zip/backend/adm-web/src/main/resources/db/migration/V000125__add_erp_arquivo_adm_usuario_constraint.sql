ALTER TABLE erp_arquivo
    ADD CONSTRAINT fk_terp0026_tadm0002 FOREIGN KEY ( cod_usu )
        REFERENCES adm_usuario ( cod_usu )
    NOT DEFERRABLE;
