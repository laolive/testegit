ALTER TABLE erp_rotina_opcao
    ADD CONSTRAINT fk_terp0024_terp0013 FOREIGN KEY ( cod_rotina )
        REFERENCES erp_rotina ( cod_rotina )
    NOT DEFERRABLE;
