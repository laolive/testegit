ALTER TABLE adm_grupo_campo_adicional
    ADD CONSTRAINT fk_tadm0022_terp0007 FOREIGN KEY ( cod_transc )
        REFERENCES erp_transacao ( cod_transc )
    NOT DEFERRABLE;
