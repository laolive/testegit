CREATE TABLE adm_usuario_grupo_acesso (
    cod_usu            NUMBER(6) NOT NULL,
    cod_emp            NUMBER(3) NOT NULL,
    cod_grupo_acesso   NUMBER(6) NOT NULL
);

COMMENT ON TABLE adm_usuario_grupo_acesso is 'TADM0003: Grupo de Acessos do Usuário';
COMMENT ON COLUMN adm_usuario_grupo_acesso.cod_usu is 'Usuário: Código do usuário do sistema';
COMMENT ON COLUMN adm_usuario_grupo_acesso.cod_emp is 'Empresa: Código da Empresa';
COMMENT ON COLUMN adm_usuario_grupo_acesso.cod_grupo_acesso is 'Grupo de acessos: Código do grupo de acessos ao qual o usuário está relacionado';

CREATE INDEX ix_pk_tadm0003 ON adm_usuario_grupo_acesso ( cod_usu, cod_emp, cod_grupo_acesso );

CREATE INDEX ix_fk_tadm0003_tadm0001 ON adm_usuario_grupo_acesso ( cod_emp, cod_grupo_acesso );

ALTER TABLE adm_usuario_grupo_acesso
    ADD CONSTRAINT pk_tadm0003 PRIMARY KEY ( cod_usu,
    cod_emp,
    cod_grupo_acesso )
        USING INDEX ix_pk_tadm0003;
