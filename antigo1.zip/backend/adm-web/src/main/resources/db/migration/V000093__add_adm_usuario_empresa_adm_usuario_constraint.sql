ALTER TABLE adm_usuario_empresa
    ADD CONSTRAINT fk_tadm0021_tadm0002 FOREIGN KEY ( cod_usu )
        REFERENCES adm_usuario ( cod_usu )
    NOT DEFERRABLE;
