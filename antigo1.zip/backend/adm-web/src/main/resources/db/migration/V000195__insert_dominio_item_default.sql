insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (1, 1, 'B', 'Base Conhecimento', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (2, 1, 'C', 'Cancelar Protocolo', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (3, 1, 'E', 'Encaminhar Protocolo', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (4, 1, 'F', 'Financeiro', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (5, 1, 'I', 'Imprimir Protocolo', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (6, 1, 'M', 'Guia Médico', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (7, 1, 'N', 'Geração Arq Financ', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (8, 1, 'P', 'Logs', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (9, 1, 'R', 'Repassar Protocolo', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (10, 1, 'S', 'Encerrar protocolo', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (11, 1, 'T', 'Consultar Protocolo', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (12, 1, 'U', 'Assumir Protocolo', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (13, 1, 'V', 'Vincular protocolo', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (14, 1, 'Y', 'Novo Trâmite', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (15, 1, 'Z', 'Acessar o AUTSC', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (16, 2, 'E', 'Eletiva', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (17, 2, 'U', 'Urgência/Emergência', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (18, 3, 'A', 'Analítico', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (19, 3, 'S', 'Sintético', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (20, 4, '1', 'M1', 'Metástase à distância', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (21, 4, '2', 'M0', 'Ausência de metástase à distância', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (22, 4, '3', 'Mx', 'A presença de metástase à distância não pode ser avaliada', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (23, 4, '8', 'Não se aplica', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (24, 4, '9', 'Sem informação', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (25, 5, '1', 'N1', 'O tumor se disseminou para 1 ou 3 linfonodos axilares e/ou linfonodos mamários internos', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (26, 5, '2', 'N2', 'O tumor se disseminou para 4 ou 9 linfonodos axilares ou para os linfonodos mamários internos', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (27, 5, '3', 'N3', 'Pelo menos uma área de câncer disseminada maior que 2mm', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (28, 5, '4', 'N0', 'Os linfonodos próximos estão livres', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (29, 5, '5', 'Nx', 'Os linfonodos regionais não podem ser avaliados', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (30, 5, '8', 'Não se aplica', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (31, 5, '9', 'Sem informação', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (32, 6, '1', 'T1', 'O tumor tem até 2 cm de diâmetro', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (33, 6, '2', 'T2', 'O tumor tem entre 2 cm e 5 cm de diâmetro', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (34, 6, '3', 'T3', 'O tumor tem mais de 5 cm de diâmetro', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (35, 6, '4', 'T4', 'O tumor tem qualquer tamanho e invadiu o tórax ou a pele', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (36, 6, '5', 'T0', 'Sem evidências de tumor primário', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (37, 6, '6', 'Tis', 'Carcinoma in situ', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (38, 6, '7', 'Tx', 'O tumor primário não pode ser avaliado', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (39, 6, '8', 'Não se aplica', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (40, 6, '9', 'Sem informação', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (41, 7, 'COREN', 'COREN', 'Conselho Regional de Enfermagem', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (42, 7, 'CRAS', 'CRAS', 'Conselho Regional de Assistência Social', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (43, 7, 'CREFITO', 'CREFITO', 'Conselho Regional de Fisioterapia e Terapia Ocupacional', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (44, 7, 'CRF', 'CRF', 'Conselho Regional de Farmácia', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (45, 7, 'CRFA', 'CRFA', 'Conselho Regional de Fonoaudiologia', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (46, 7, 'CRM', 'CRM', 'Conselho Regional de Medicina', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (47, 7, 'CRN', 'CRN', 'Conselho Regional de Nutrição', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (48, 7, 'CRO', 'CRO', 'Conselho Regional de Odontologia', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (49, 7, 'CRP', 'CRP', 'Conselho Regional de Psicologia', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (50, 7, 'OUT', 'OUT', 'Outros Conselhos', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (51, 8, '1', 'Tomografia', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (52, 8, '2', 'Ressonância Magnética', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (53, 8, '3', 'Raio-X', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (54, 8, '4', 'Outras', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (55, 8, '5', 'Ultrassonografia', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (56, 8, '6', 'PET', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (57, 9, '0', 'Totalmente ativo', 'Totalmente ativo capaz de exercer todas as atividades que exercia antes do diagnóstico', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (58, 9, '1', 'Não exerce atividade física', 'Não exerce atividade física extenuante. Capaz de realizar trabalho leve em casa ou no escritório', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (59, 9, '2', 'Caminha e é capaz de realizar atividade de autocuidado', 'Caminha e é capaz de exercer atividades de autocuidado. Incapaz de realizar atividade de trabalho', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (60, 9, '3', 'Capacidade de autocuidado limitada', 'Capacidade de autocuidado limitada. Permanece no leito ou cadeira mais de 50% das horas de vigília', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (61, 9, '4', 'Completamente dependente', 'Completamente dependente. Incapaz de exercer autocuidado (confinado à cama ou cadeira)', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (62, 10, 'E', 'Enviada', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (63, 10, 'R', 'Recebida', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (64, 11, '0', '0', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (65, 11, '1', 'I', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (66, 11, '2', 'II', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (67, 11, '3', 'III', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (68, 11, '4', 'IV', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (69, 11, '5', 'Não se aplica', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (70, 12, 'A', 'Separado', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (71, 12, 'C', 'Casado', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (72, 12, 'D', 'Divorciado', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (73, 12, 'O', 'Outros', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (74, 12, 'S', 'Solteiro', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (75, 12, 'U', 'União Estável', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (76, 12, 'V', 'Viúvo', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (77, 13, 'E', 'Estadual', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (78, 13, 'M', 'Municipal', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (79, 13, 'N', 'Nacional', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (80, 14, 'C', 'Correspondência', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (81, 14, 'E', 'E-Social', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (82, 14, 'F', 'Fatura (Cobrança)', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (83, 14, 'G', 'Guia Médico', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (84, 15, '1', 'Curativa', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (85, 15, '2', 'Neoadjuvante', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (86, 15, '3', 'Adjuvante', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (87, 15, '4', 'Paliativa', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (88, 15, '5', 'Controle', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (89, 16, '0', 'Não', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (90, 16, '1', 'Sim', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (91, 17, 'A', 'Agendamento', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (92, 17, 'I', 'Imediato', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (93, 17, 'J', 'JOB', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (94, 17, 'M', 'Manual', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (95, 18, 'C', 'Telefone celular', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (96, 18, 'E', 'E-mail', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (97, 18, 'F', 'Fax', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (98, 18, 'T', 'Telefone fixo', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (99, 19, 'A', 'Ambos', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (100, 19, 'F', 'Lista apenas os filtros informados', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (101, 19, 'N', 'Não gera título; nem filtros', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (102, 19, 'T', 'Gera apenas o título', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (103, 20, '101', 'Boleto', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (104, 20, '102', 'DOC', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (105, 20, '103', 'TED', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (106, 20, '104', 'DARF', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (107, 20, '105', 'GPS', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (108, 20, '201', 'Cheque', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (109, 20, '202', 'Dinheiro', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (110, 20, '203', 'Débito em C/C', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (111, 21, '0', 'Trabalho', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (112, 21, '1', 'Trânsito', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (113, 21, '2', 'Outros acidentes', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (114, 21, '9', 'Não acidentes', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (115, 22, 'T', 'Total', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (116, 23, '1', 'Primeira opção de fabricante', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (117, 23, '2', 'Segunda opção de fabricante', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (118, 23, '3', 'Terceira opção de fabricante', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (119, 24, 'A', 'Atualizável', 'O usuário poderá atualizar o valor do parâmetro', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (120, 24, 'O', 'Oculto', 'O usuário não poderá visualizar o valor do parâmetro', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (121, 24, 'V', 'Visível', 'O usuário poderá apenas visualizar o valor do parâmetro', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (122, 25, 'GUIA', 'Guia', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (123, 25, 'QUIMIO', 'Anexo de Quimioterapia', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (124, 25, 'RADIO', 'Anexo de Radioterapia', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (125, 26, 'APP', 'SGUAPP', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (126, 26, 'CRM', 'SGUCRM', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (127, 26, 'RN395', 'UNIMED BRASIL', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (128, 26, 'SGU', 'SGU20', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (129, 27, 'A', 'Atendente de Call Center', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (130, 27, 'B', 'Atendente de BackOffice', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (131, 27, 'C', 'Coordenador de Call Center', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (132, 27, 'K', 'Supervisor de BackOffice', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (133, 27, 'O', 'Coordenador de BackOffice', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (134, 27, 'S', 'Supervisor de Call Center', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (135, 28, 'A', 'Administrador', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (136, 28, 'R', 'Responsável da Área', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (137, 29, '1', 'Hospitalar', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (138, 29, '2', 'Hospital-dia', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (139, 29, '3', 'Domiciliar', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (140, 30, '1', 'Relaciona-se à', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (141, 30, '2', 'Depende de', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (142, 30, '3', 'Duplica', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (143, 30, '4', 'Contém', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (144, 30, '5', 'Impacta', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (145, 30, '6', 'Anula', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (146, 31, 'F', 'Feminino', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (147, 31, 'M', 'Masculino', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (148, 32, 'D', 'Desativada', 'A fila de execução foi desativada', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (149, 32, 'E', 'Executando', 'A fila está em execução', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (150, 32, 'I', 'Interrompida', 'A fila de execução foi interrompida devido a algum erro', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (151, 32, 'P', 'Parada', 'A fila de execução foi parada', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (152, 33, 'A', 'Ativo', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (153, 33, 'B', 'Bloqueado', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (154, 33, 'I', 'Inativo', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (155, 34, '1', 'Em Avaliação', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (156, 34, '2', 'Especificar', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (157, 34, '3', 'Em Especificação', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (158, 34, '4', 'Desenvolver', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (159, 34, '5', 'Em Desenvolvimento', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (160, 34, '6', 'Liberar', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (161, 34, '7', 'Liberado', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (162, 34, '8', 'Não Desenvolver', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (163, 35, '1', 'Negada', 'A solicitação de autorização foi negada pela Unimed de origem do beneficiário', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (164, 35, '2', 'Aprovada', 'A solicitação de autorização foi aprovada pela Unimed de origem do beneficiário', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (165, 35, '3', 'Em estudo', 'A solicitação de autorização está em processo de análise na Unimed de origem do beneficiário', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (166, 35, '4', 'Cancelada', 'A solicitação de autorização foi cancelada pela Unimed de origem do beneficiário', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (168, 36, 'AAP', 'Arquivo aprovado', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (169, 36, 'ACL', 'Aguardando cliente', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (170, 36, 'ARE', 'Arquivo recusado', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (171, 36, 'ARP', 'Arquivo processado', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (172, 36, 'AUD', 'Em Auditoria', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (173, 36, 'CAN', 'Cancelado', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (174, 36, 'FIN', 'Finalizado', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (175, 36, 'PEN', 'Pendente', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (176, 36, 'VAL', 'Em validação', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (177, 37, 'A', 'Aberto', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (178, 37, 'C', 'Cancelado', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (179, 37, 'D', 'Devolvido', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (180, 37, 'E', 'Encaminhado', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (181, 37, 'R', 'Repassado', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (182, 37, 'S', 'Encerrado', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (183, 38, 'A', 'Aberto', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (184, 38, 'C', 'Cancelado', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (185, 38, 'D', 'Documento Excluído', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (186, 38, 'E', 'Encaminhado', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (187, 38, 'F', 'Finalizado', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (188, 38, 'I', 'Documento Incluído', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (189, 38, 'U', 'Documento Alterado', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (190, 39, '0', 'Rol UNimed / AMB / CBHPM', 'Rol UNimed / AMB / CBHPM', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (191, 39, '1', 'Serviços Hospitalares/Taxas/Complementos', 'Serviços Hospitalares/Taxas/Complementos (Códigos da tabela C)', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (192, 39, '2', 'Materiais', 'Materiais (Códigos da tabela E)', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (193, 39, '3', 'Medicamentos', 'Medicamentos (Códigos da tabela D)', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (194, 39, '4', 'Serviços com custo fechado / pacote', 'Serviços com custo fechado / pacote', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (195, 40, '00', 'Tabela Própria das Operadoras', 'Tabela Própria das Operadoras', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (196, 40, '18', 'TUSS - Taxas hospitalares, diárias e gases medicinais', 'TUSS _ Taxas hospitalares, diárias e gases medicinais', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (197, 40, '19', 'TUSS - Materiais', 'TUSS _ Materiais', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (198, 40, '20', 'TUSS - Medicamentos', 'TUSS - Medicamentos', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (199, 40, '22', 'TUSS - Procedimentos e eventos em saúde', 'TUSS _ Procedimentos e eventos em saúde (medicina, odonto e demais áreas de saúde)', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (200, 40, '90', 'Tabela Própria Pacote Odontológico', 'Tabela Própria Pacote Odontológico', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (201, 40, '98', 'Tabela Própria de Pacotes', 'Tabela Própria de Pacotes', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (202, 41, '01', 'Nacional', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (203, 41, '02', 'Estadual', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (204, 41, '03', 'Grupo de Estados', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (205, 41, '04', 'Municipal', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (206, 41, '05', 'Grupo de Municípios', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (207, 42, '02', 'QUARTO PRIVATIVO / PARTICULAR', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (208, 42, '09', 'APARTAMENTO DE LUXO DA MATERNIDADE', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (209, 42, '10', 'APARTAMENTO DE LUXO DE PSIQUIATRIA', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (210, 42, '11', 'APARTAMENTO DE LUXO', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (211, 42, '12', 'APARTAMENTO SIMPLES', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (212, 42, '13', 'APARTAMENTO STANDARD', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (213, 42, '14', 'APARTAMENTO SUÍTE', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (214, 42, '15', 'APARTAMENTO COM ALOJAMENTO CONJUNTO', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (215, 42, '16', 'APARTAMENTO PARA PACIENTE COM OBESIDADE MÓRBIDA', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (216, 42, '17', 'APARTAMENTO SIMPLES DA MATERNIDADE', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (217, 42, '18', 'APARTAMENTO SIMPLES DE PSIQUIATRIA', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (218, 42, '19', 'APARTAMENTO SUÍTE DA MATERNIDADE', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (219, 42, '20', 'APARTAMENTO SUÍTE DE PSIQUIATRIA', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (220, 42, '21', 'BERÇÁRIO NORMAL', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (221, 42, '22', 'BERÇÁRIO PATOLÓGICO / PREMATURO', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (222, 42, '25', 'ENFERMARIA DE 3 LEITOS DA MATERNIDADE', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (223, 42, '26', 'ENFERMARIA DE 4 OU MAIS LEITOS DA MATERNIDADE', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (224, 42, '27', 'HOSPITAL DIA APARTAMENTO', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (225, 42, '28', 'HOSPITAL DIA ENFERMARIA', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (226, 42, '29', 'HOSPITAL DIA PSIQUIATRIA', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (227, 42, '30', 'QUARTO COLETIVO DE 2 LEITOS DA MATERNIDADE', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (228, 42, '31', 'ENFERMARIA DE 3 LEITOS', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (229, 42, '32', 'ENFERMARIA DE 4 OU MAIS LEITOS', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (230, 42, '33', 'ENFERMARIA COM ALOJAMENTO CONJUNTO', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (231, 42, '36', 'QUARTO PRIVATIVO / PARTICULAR DA MATERNIDADE', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (232, 42, '37', 'QUARTO PRIVATIVO / PARTICULAR DE PSIQUIATRIA', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (233, 42, '38', 'SEMI UTI ADULTO GERAL', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (234, 42, '39', 'SEMI UTI CORONARIANA', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (235, 42, '40', 'SEMI UTI NEONATAL', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (236, 42, '41', 'QUARTO COLETIVO DE 2 LEITOS', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (237, 42, '43', 'QUARTO COM ALOJAMENTO CONJUNTO', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (238, 42, '44', 'SEMI UTI NEUROLÓGICA', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (239, 42, '45', 'SEMI UTI INFANTIL/PEDIÁTRICA', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (240, 42, '46', 'SEMI UTI QUEIMADOS', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (241, 42, '47', 'UNIDADE DE TRANSPLANTE DE MEDULA ÓSSEA', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (242, 42, '48', 'UNIDADE DE TRANSPLANTE EM GERAL', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (243, 42, '49', 'APARTAMENTO STANDARD DA MATERNIDADE', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (244, 42, '50', 'APARTAMENTO STANDARD DE PSIQUIATRIA', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (245, 42, '51', 'UTI ADULTO GERAL', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (246, 42, '52', 'UTI INFANTIL/PEDIÁTRICA', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (247, 42, '53', 'UTI NEONATAL', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (248, 42, '56', 'UNIDADE PARA TRATAMENTO RADIOATIVO', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (249, 42, '57', 'UTI CORONARIANA', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (250, 42, '58', 'UTI NEUROLÓGICA', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (251, 42, '59', 'UTI QUEIMADOS', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (252, 43, '01', 'Apartamento', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (253, 43, '02', 'Enfermaria', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (254, 43, '03', 'Ambulatorial', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (255, 44, 'A', 'Coletiva', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (256, 44, 'B', 'Individual', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (257, 44, 'C', 'Não se aplica', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (258, 45, 'P', 'Conclusão de processo', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (259, 45, 'R', 'Recuperação de senha', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (260, 46, 'OPME', 'OPME', 'Anexo de OPME', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (261, 46, 'QUIMIO', 'Quimioterapia', 'Anexo de Quimioterapia', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (262, 46, 'RADIO', 'Radioterapia', 'Anexo de Radioterapia', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (263, 47, 'C', 'Cabeçalho impressão de protocolo', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (264, 47, 'L', 'Logo tipo empresa', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (265, 47, 'P', 'Cabeçalho unimed', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (266, 48, '1', 'Lista de Valores', 'UniSelect', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (267, 48, '2', 'Texto', 'UniInput', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (268, 48, '3', 'Numérico', 'UniInput', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (269, 48, '4', 'Data', 'UniDatepicker', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (270, 48, '5', 'Lógico', 'UniInput', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (271, 49, 'C', 'Comercial', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (272, 49, 'M', 'Marketing', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (273, 49, 'O', 'Outras', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (274, 49, 'R', 'Relacionamento', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (275, 50, 'D', 'Data', 'UniDatepicker', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (276, 50, 'N', 'Número', 'UniInput', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (277, 50, 'O', 'Domínio', 'UniSelect', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (278, 50, 'T', 'Texto Livre', 'UniInput', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (279, 50, 'V', 'Valor Monetário', 'UniInput', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (280, 51, 'C', 'Caracteres em geral', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (281, 51, 'N', 'Números', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (284, 53, '1', 'Médicos Cooperados', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (285, 53, '10', 'Alterações Cadastrais', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (286, 53, '11', 'Estorno', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (287, 53, '12', 'Posição de Pagamento', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (288, 53, '13', 'IRPF', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (289, 53, '14', 'Parcerias/Doações', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (290, 53, '15', '2ª via de boleto', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (291, 53, '16', 'Envio de Cartão', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (292, 53, '17', 'Documentos', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (293, 53, '18', 'Guia Médico', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (294, 53, '19', 'Procedimento Médico', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (295, 53, '2', 'Hospitais/Clínicas Credenciadas', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (296, 53, '3', 'Hospitais/Clínicas Unimed', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (297, 53, '4', 'Operadora', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (298, 53, '5', 'Coberturas', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (299, 53, '6', 'Carência', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (300, 53, '7', 'Fatura', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (301, 53, '8', 'Cancelamento de Plano', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (302, 53, '9', 'Compra de Plano', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (303, 54, '1', 'Cidade', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (304, 54, '2', 'Logradouro', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (305, 54, '3', 'Especiais', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (306, 54, '4', 'Caixa postal comunitária', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (307, 54, '5', 'Unidade operacional - ag. Correios', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (308, 55, '<#', 'Menor que', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (309, 55, '<=#', 'Menor ou igual a', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (310, 55, '<>#', 'Diferente de', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (311, 55, '=#', 'Igual a', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (312, 55, '>#', 'Maior que', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (313, 55, '>=#', 'Maior ou igual a', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (314, 55, 'BETWEEN', 'Esteja entre', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (315, 55, 'IN (#)', 'Esteja em', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (316, 55, 'IS NOT NULL', 'Não é nulo', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (317, 55, 'IS NULL', 'É nulo', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (318, 55, 'LIKE ''#%''', 'Comece com', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (319, 55, 'LIKE ''%#%''', 'Contenha', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (320, 55, 'LIKE ''%#''', 'Termine com', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (321, 55, 'NOT BETWEEN', 'Não esteja entre', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (322, 55, 'NOT IN (#)', 'Não esteja em', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (323, 55, 'NOT LIKE ''#%''', 'Não comece com', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (324, 55, 'NOT LIKE ''%#%''', 'Não contenha', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (325, 55, 'NOT LIKE ''%#''', 'Não termine com', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (326, 56, 'CC', 'Conta Corrente', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (327, 56, 'CI', 'Conta Investimento', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (328, 56, 'CP', 'Conta Poupança', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (329, 57, '01', 'Individual/familiar', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (330, 57, '02', 'Empresarial', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (331, 57, '03', 'Coletivo por Adesão', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (332, 58, 'A', 'Alfanumérico', 'UniInput', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (333, 58, 'D', 'Data', 'UniDatepicker', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (334, 58, 'I', 'Inteiro', 'UniInput', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (335, 58, 'M', 'Domínio', 'UniSelect', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (336, 58, 'N', 'Numérico', 'UniInput', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (337, 58, 'P', 'Período', 'UniInput', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (338, 59, '1', 'Primeira parcela', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (339, 59, '2', 'Ratear entre as parcelas', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (340, 60, 'A', 'Atendimento', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (341, 60, 'C', 'Comercial', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (342, 60, 'E', 'Entrega', 'Endereço de entrega pedidos de compra', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (343, 60, 'R', 'Residencial', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (344, 61, 'E', 'Email', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (345, 61, 'W', 'WebSocket', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (346, 62, 'A', 'Diferença Pago x Faturado', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (347, 62, 'B', 'Diferença Local x Intercâmbio', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (348, 63, 'F', 'Fechada', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (349, 63, 'N', 'Negociação', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (350, 63, 'P', 'Perdida', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (351, 63, 'S', 'Proposta SGU', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (352, 64, '1', 'Clínica', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (353, 64, '2', 'Cirúrgica', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (354, 64, '3', 'Obstétrica', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (355, 64, '4', 'Pediátrica', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (356, 64, '5', 'Psiquiátrica', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (357, 65, '01', 'Internação clínica', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (358, 65, '02', 'Internação Cirúrgica', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (359, 65, '03', 'Internação Obstétrica', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (360, 65, '04', 'Internação Pediátrica', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (361, 65, '05', 'Internação Psiquiátrica', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (362, 66, '00', 'Honorário médico', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (363, 66, '01', 'Material', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (364, 66, '02', 'Medicamento', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (365, 66, '03', 'Diária e taxa', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (366, 66, '04', 'OPME', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (367, 66, '05', 'Pacote', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (368, 66, '06', 'SADT', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (369, 66, '07', 'Outros', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (370, 67, '100', 'Integração Bancária - EDI', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (371, 67, '200', 'Baixa Manual', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (372, 68, '1', 'Elogio', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (373, 68, '2', 'Reclamação', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (374, 68, '3', 'Denúncia', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (375, 68, '4', 'Sugestão', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (376, 68, '5', 'Dúvida', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (377, 68, '6', 'Solicitação', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (378, 69, 'DESPESA', 'Despesa', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (379, 69, 'FORMA_CONTATO', 'Forma de Contato', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (380, 69, 'OBJETIVO', 'Objetivo', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (381, 69, 'RESULTADO', 'Resultado', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (382, 70, 'A', 'Alerta', 'Ex.: "A conta contábil bloqueada possui lançamentos vigentes."', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (383, 70, 'C', 'Confirmação', 'Ex.: "Cadastro foi efetuado com sucesso."', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (384, 70, 'E', 'Erro', 'Ex.: "Não foi possível inserir o registro devido ao erro ..."', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (385, 70, 'I', 'Informativa', 'Ex.: "A execução do relatório X terminou."', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (386, 70, 'P', 'Pergunta', 'Ex.: "Confirma as alterações realizadas?"', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (387, 71, 'CO', 'Custo operacional', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (388, 71, 'COF', 'Fundações', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (389, 71, 'VD', 'Valor determinado', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (390, 72, 'A', 'Aberto', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (391, 72, 'C', 'Cancelar', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (392, 72, 'E', 'Encaminhar', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (393, 72, 'R', 'Repassar', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (394, 72, 'S', 'Encerrado', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (395, 72, 'U', 'Assumir', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (396, 72, 'V', 'Vincular', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (397, 72, 'Y', 'Trâmite', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (398, 73, 'D', 'Despesa', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (399, 73, 'R', 'Receita', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (400, 73, 'T', 'Totalizador', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (401, 74, 'A', 'Alteração', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (402, 74, 'E', 'Exclusão', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (403, 74, 'I', 'Inclusão', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (404, 75, 'AND', 'E', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (405, 75, 'OR', 'OU', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (406, 76, 'A', 'Auditor', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (407, 76, 'C', 'Cliente', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (408, 76, 'V', 'Validador', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (409, 77, '00', 'Cirurgião', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (410, 77, '01', '1º Auxiliar', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (411, 77, '02', '2º Auxiliar', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (412, 77, '03', '3º Auxiliar', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (413, 77, '04', '4º Auxiliar', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (414, 77, '05', 'Instrumentador', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (415, 77, '06', 'Anestesista', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (416, 77, '07', 'Auxiliar Anestesista', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (417, 77, '08', 'Consultor', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (418, 77, '09', 'Perfusionista', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (419, 77, '10', 'Pediatra Sala Parto', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (420, 77, '11', 'Auxiliar Sadt', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (421, 77, '12', 'Clínico', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (422, 77, '13', 'Intensivista', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (423, 78, 'F', 'Física', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (424, 78, 'J', 'Jurídica', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (425, 79, '00', 'Cooperado', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (426, 79, '01', 'Médico não cooperado', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (427, 79, '02', 'Hospital', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (428, 79, '03', 'Clínica', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (429, 79, '04', 'Outros', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (430, 80, 'C', 'Contratante', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (431, 80, 'F', 'Prestador', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (432, 80, 'G', 'Público geral', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (433, 80, 'I', 'Beneficiário', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (434, 80, 'O', 'Outros/Benef. Intercâmbio', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (435, 81, '1', 'Primeira linha', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (436, 81, '2', 'Segunda linha', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (437, 81, '3', 'Terceira linha', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (438, 81, '4', 'Outras linhas', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (439, 82, '01', 'IGPM', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (440, 82, '02', 'INPC', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (441, 82, '03', 'CH', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (442, 82, '04', 'IPCA', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (443, 82, '05', 'ANS', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (444, 82, '06', 'S/A', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (445, 83, 'I', 'Intercâmbio', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (446, 83, 'P', 'Rede Própria', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (447, 83, 'S', 'SUS', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (448, 84, '1', 'Básica', 'Formada pelos hospitais que disponibilizam acomodação coletiva e/ou individual', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (449, 84, '2', 'Especial (Tabela Própria)', 'Formada pelos hospitais da rede básica acrescidos aos hospitais de Tabela Própria', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (450, 84, '3', 'Master (Alto Custo)', 'Formada pelos hospitais da rede especial acrescidos aos hospitais de de Alto Custo', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (451, 85, '01', 'Ambulatorial', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (452, 85, '02', 'Hospitalar com Obstetrícia', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (453, 85, '03', 'Hospitalar sem Obstetrícia', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (454, 85, '04', 'Odonto', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (455, 85, '05', 'Referência', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (456, 85, '06', 'Ambulatorial + Hospitalar com Obstetrícia', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (457, 85, '07', 'Ambulatorial + Hospitalar sem Obstetrícia', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (458, 85, '08', 'Ambulatorial + Odonto', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (459, 85, '09', 'Hospitalar com Obstetrícia + Odonto', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (460, 85, '10', 'Hospitalar sem Obstetrícia + Odonto', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (461, 85, '11', 'Ambulatorial + Hospitalar com Obstetrícia + Odonto', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (462, 85, '12', 'Ambulatorial + Hospitalar sem Obstetrícia + Odonto', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (463, 86, 'A', 'Ação', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (464, 86, 'T', 'Tarefa', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (465, 87, 'QUIMIO', 'Quimioterapia', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (466, 87, 'RADIO', 'Radioterapia', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (467, 88, 'C', 'Confederação', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (468, 88, 'F', 'Federação', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (469, 88, 'S', 'Seccional', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (470, 88, 'U', 'Singular', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (471, 89, 'A', 'Atendente/Backoffice', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (472, 89, 'C', 'Coordenador', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (473, 89, 'G', 'Gerente', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (474, 89, 'R', 'Responsável', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (475, 89, 'S', 'Supervisor', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (476, 89, 'V', 'Vendedor', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (477, 90, '00', 'Outras', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (478, 90, '01', 'TUSS', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (479, 90, '02', 'TUNUM', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (480, 90, '03', 'Unimed', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (481, 90, '04', 'Tabela Própria', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (482, 91, '01', 'Titular', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (483, 91, '03', 'Cônjuge/companheiro', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (484, 91, '04', 'Filho', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (485, 91, '05', 'Filha', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (486, 91, '06', 'Enteado', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (487, 91, '07', 'Enteada', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (488, 91, '08', 'Pai', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (489, 91, '09', 'Mãe', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (490, 91, '10', 'Agregado/outros', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (491, 91, '11', 'Titular menor utilizando CPF do responsável', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (492, 92, 'ADE', 'Adesivo Transdérmico', 'ADES - Adesivo Transdérmico', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (493, 92, 'AMP', 'Ampola', 'AMP - Ampola', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (494, 92, 'BG', 'Bisnaga', 'BG - Bisnaga', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (495, 92, 'BLS', 'Bolsa', 'BOLS - Bolsa', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (496, 92, 'BUI', 'Bilhões de Unidades Internacionais', 'BUI - Bilhões de Unidades Internacionais', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (497, 92, 'CAP', 'Cápsula', 'CAP - Cápsula', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (498, 92, 'CAR', 'Carpule', 'CARP - Carpule', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (499, 92, 'CF', 'Comprimido Efervecente', 'COM EFEV - Comprimido Efervecente', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (500, 92, 'CGY', 'Centgray', 'CGY - Centgray', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (501, 92, 'CM', 'Centímetro', 'CM - Centímetro', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (502, 92, 'CNJ', 'Conjunto', 'CONJ - Conjunto', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (503, 92, 'COM', 'Comprimido Mastigável', 'COM MST - Comprimido Mastigável', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (504, 92, 'CP', 'Comprimido', 'COM - Comprimido', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (505, 92, 'CX', 'Caixa', 'CX - Caixa', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (506, 92, 'DOS', 'Dose', 'DOSE - Dose', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (507, 92, 'DRG', 'Drágea', 'DRG - Drágea', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (508, 92, 'ENV', 'Envelope', 'ENV - Envelope', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (509, 92, 'FA', 'Frasco Ampola', 'FA - Frasco Ampola', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (510, 92, 'FLA', 'Flaconete', 'FLAC - Flaconete', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (511, 92, 'FRS', 'Frasco', 'FR - Frasco', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (512, 92, 'GL', 'Galão', 'GAL - Galão', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (513, 92, 'GLO', 'Glóbulo', 'GLOB - Glóbulo', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (514, 92, 'GRA', 'Grama', 'G - Grama', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (515, 92, 'GTS', 'Gotas', 'GTS - Gotas', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (516, 92, 'GY', 'Gray', 'GY - Gray', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (517, 92, 'KG', 'Quilograma', 'KG - Quilograma', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (518, 92, 'KIT', 'Kit', 'KIT - Kit', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (519, 92, 'LAT', 'Lata', 'LT - Lata', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (520, 92, 'LTS', 'Litro', 'L - Litro', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (521, 92, 'MC', 'Maço', 'MÇ - Maço', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (522, 92, 'MCG', 'Microgramas', 'MCG - Microgramas', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (523, 92, 'MG', 'Miligrama', 'MG - Miligrama', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (524, 92, 'ML', 'Mililitro', 'ML - Mililitro', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (525, 92, 'MT', 'Metro', 'M - Metro', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (526, 92, 'MUI', 'Milhões de Unidades Internacionais', 'MUI - Milhões de Unidades Internacionais', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (527, 92, 'OVL', 'Óvulo', 'OVL - Óvulo', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (528, 92, 'PAR', 'Par', 'PAR - Par', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (529, 92, 'PAS', 'Pastilha', 'PAS - Pastilha', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (530, 92, 'PC', 'Peça', 'PÇ - Peça', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (531, 92, 'PCT', 'Pacote', 'PC - Pacote', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (532, 92, 'PER', 'Pérola', 'PER - Pérola', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (533, 92, 'PIL', 'Pílula', 'PIL - Pílula', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (534, 92, 'PT', 'Pote', 'PT - Pote', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (535, 92, 'ROL', 'Rolo', 'RL - Rolo', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (536, 92, 'SCH', 'Sache', 'SACHE - Sache', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (537, 92, 'SER', 'Seringa', 'SER - Seringa', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (538, 92, 'SUP', 'Supositório', 'SUP - Supositório', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (539, 92, 'TAB', 'Tablete', 'TABLE - Tablete', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (540, 92, 'TB', 'Tubo', 'TB - Tubo', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (541, 92, 'TUB', 'Tubete', 'TUB - Tubete', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (542, 92, 'UI', 'Unidade Internacional', 'UI - Unidade Internacional', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (543, 92, 'UND', 'Unidade', 'UN - Unidade', null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (544, 93, '01', 'Bucal', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (545, 93, '02', 'Capilar', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (546, 93, '03', 'Dermatológica', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (547, 93, '04', 'Epidural', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (548, 93, '05', 'Gastrostomia/jejunostomia', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (549, 93, '06', 'Inalatória', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (550, 93, '07', 'Intra- Óssea', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (551, 93, '08', 'Intra-arterial', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (552, 93, '09', 'Intra-articular', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (553, 93, '10', 'Intracardíaca', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (554, 93, '11', 'Intradérmica', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (555, 93, '12', 'Intralesional', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (556, 93, '13', 'Intramuscular', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (557, 93, '14', 'Intraperitonial', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (558, 93, '15', 'Intrapleural', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (559, 93, '16', 'Intratecal', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (560, 93, '17', 'Intratraqueal', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (561, 93, '18', 'Intrauterina', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (562, 93, '19', 'Intravenosa', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (563, 93, '20', 'Intravesical', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (564, 93, '21', 'Intravítrea', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (565, 93, '22', 'Irrigação', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (566, 93, '23', 'Nasal', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (567, 93, '24', 'Oftálmica', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (568, 93, '25', 'Oral', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (569, 93, '26', 'Otológica', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (570, 93, '27', 'Retal', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (571, 93, '28', 'Sonda enteral', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (572, 93, '29', 'Sonda gástrica', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (573, 93, '30', 'Subcutânea', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (574, 93, '31', 'Sublingual', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (575, 93, '32', 'Transdérmica', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (576, 93, '33', 'Uretral', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (577, 93, '34', 'Vaginal', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (578, 93, '35', 'Outras', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (579, 94, '11', 'Alta Curado', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (580, 94, '12', 'Alta Melhorado', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (581, 94, '14', 'Alta a pedido', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (582, 94, '15', 'Alta com previsão de retorno para acompanhamento do paciente', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (583, 94, '16', 'Alta por Evasão', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (584, 94, '17', 'Alta da Puérpera e recém-nascido', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (585, 94, '18', 'Alta por Outros motivos', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (586, 94, '21', 'Permanencia por características próprias da doença', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (587, 94, '22', 'Permanencia por Intercorrência', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (588, 94, '23', 'Permanencia por impossibilidade sócio-familiar', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (589, 94, '24', 'permanencia por Processo de doação de órgãos, tecidos e células - doador vivo', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (590, 94, '25', 'Permanencia por Processo de doação de órgãos, tecidos e células - doador morto', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (591, 94, '26', 'Permanencia por mudança de procedimento', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (592, 94, '27', 'Permanencia por re-operação', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (593, 94, '28', 'Permanencia por outros motivos', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (594, 94, '31', 'Transferido para outro estabelecimento', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (595, 94, '32', 'Transferencia para internação domiciliar', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (596, 94, '41', 'Óbito com declaração de óbito fornecida pelo médico assistente', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (597, 94, '42', 'Óbito com declaração de Óbito fornecida pelo Instituto Médico Legal - IML', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (598, 94, '43', 'Óbito com declaração de Óbito fornecida pelo Serviço de Verificação de Óbito - SVO.', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (599, 94, '51', 'ENCERRAMENTO ADMINISTRATIVO', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (600, 94, '61', 'Alta mãe/puerpera e do recem nascido', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (601, 94, '62', 'Alta mãe/puerpera e permanencia do recem-nascido', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (602, 94, '63', 'Alta mãe/puerpera e obito do recem-nascido', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (603, 94, '64', 'Alta mãe/puerpera com obito fetal', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (604, 94, '65', 'Óbito da gestante e do concepto', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (605, 94, '66', 'Óbito da mãe/puerpera e alta do recem-nascido', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (606, 94, '67', 'Obito da mae/puerpera e permanencia do recem nascido', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, valor, nome, descricao, data_inicio_vigencia, data_fim_vigencia)
values (607, 94, '19', 'Alta de Paciente Agudo em Psiquiatria', null, null, null);
insert into DOMINIO_ITEM (id, dominio_id, nome, valor, descricao, data_inicio_vigencia, data_fim_vigencia)
values (608, 95, 'Consulta', '01', 'Tipo de solicitação Consulta Eletiva.', null, null);
insert into DOMINIO_ITEM (id, dominio_id, nome, valor, descricao, data_inicio_vigencia, data_fim_vigencia)
values (609, 95, 'Exame', '02', 'Tipo de solicitação de Exames.', null, null);
insert into DOMINIO_ITEM (id, dominio_id, nome, valor, descricao, data_inicio_vigencia, data_fim_vigencia)
values (610, 95, 'Internação', '03', 'Tipo de solicitação de Internação.', null, null);
insert into DOMINIO_ITEM (id, dominio_id, nome, valor, descricao, data_inicio_vigencia, data_fim_vigencia)
values (611, 95, 'Prorrogação/Complementação', '04', 'Tipo de solicitação de Prorrogação/Complementação.', null, null);
