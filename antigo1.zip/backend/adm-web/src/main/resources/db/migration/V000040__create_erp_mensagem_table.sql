CREATE TABLE erp_mensagem (
    cod_msg           NUMBER(10) NOT NULL,
    tip_msg           VARCHAR2(1) NOT NULL,
    des_msg           VARCHAR2(200) NOT NULL,
    des_explic        VARCHAR2(2000),
    des_acao_cortva   VARCHAR2(2000)
);

COMMENT ON TABLE erp_mensagem is 'TERP0010: Mensagem do Sistema';
COMMENT ON COLUMN erp_mensagem.cod_msg is 'Código: Código da mensagem';
COMMENT ON COLUMN erp_mensagem.tip_msg is 'Tipo: Tipo da mensagem | TIPO_MENSAGEM_SISTEMA';
COMMENT ON COLUMN erp_mensagem.des_msg is 'Descrição: Descrição da mensagem';
COMMENT ON COLUMN erp_mensagem.des_explic is 'Explicação: Explicação sobre a mensgem apresentada';
COMMENT ON COLUMN erp_mensagem.des_acao_cortva is 'Ação corretiva: Ação corretiva referente a mensagem apresentada';

CREATE INDEX ix_pk_terp0010 ON erp_mensagem ( cod_msg );

ALTER TABLE erp_mensagem ADD CONSTRAINT cc_terp0010_cod_msg CHECK ( cod_msg > 100000 );

ALTER TABLE erp_mensagem
    ADD CONSTRAINT pk_terp0010 PRIMARY KEY ( cod_msg )
        USING INDEX ix_pk_terp0010;

