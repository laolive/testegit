insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1, 1, 'N', 'N�o', 16);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (2, 1, 'S', 'Sim', 17);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (83, 10, '1', 'Curativa', 84);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (84, 10, '2', 'Neoadjuvante', 85);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (85, 10, '3', 'Adjuvante', 86);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (86, 10, '4', 'Paliativa', 87);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (87, 10, '5', 'Controle', 88);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (88, 11, '5001', 'Nenhum registro encontrado', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (89, 11, '5002', 'Problemas no Processamento', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (90, 11, '5003', 'Unimed off-line n�o responde essa transa��o', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (100, 12, '2010', 'Serv. solic. n�o possui cobertura', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (101, 12, '2011', 'Servi�o inv�lido para o sexo do benefici�rio', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (102, 12, '2012', 'Procedimento solicitado inv�lido para a faixa et�ria do cliente', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (103, 12, '2013', 'Cobertura Benef. com idade inferior', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (104, 12, '2014', 'Quant. Serv. Solic. acima da permitida', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (105, 12, '2015', 'Quant. Serv. solic. acima coberta', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (106, 12, '2016', 'Benefici�rio est� cumprindo per�odo de car�ncia para o procedimento', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (107, 12, '2017', 'Cart�o Vencido', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (108, 12, '2021', 'Hospital n�o informado', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (109, 12, '2022', 'C�digo do CID inv�lido', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (110, 12, '2023', 'Acomoda��o n�o Informada', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (111, 12, '2024', 'Cliente n�o possui cobertura para acomoda��o solicitada', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (112, 12, '2028', 'Cart�o do benefici�rio com problemas', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (113, 12, '2030', 'Procedimentos mutuamente excludentes', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (114, 12, '2031', 'Servi�o n�o informado', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (115, 12, '2038', 'Benefici�rio c/data inclus�o futura', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (116, 12, '2039', 'Autoriza��o n�o � v�lida para complemento', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (117, 12, '2041', 'Situa��o da transa��o inv�lida', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (118, 12, '2042', 'Transa��o n�o pertence Unimed Solicit.', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (119, 12, '2044', 'Usu�rio exclu�do', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (120, 12, '2045', 'Cliente sem cobertura para prestador da rede M�ster', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (121, 12, '2046', 'Empresa na modalidade de Custo Operacional - Necessita de autoriza��o pr�via da contratante', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (122, 12, '2047', 'Benefici�rio est� cumprindo per�odo de Cobertura Parcial Tempor�ria para o procedimento', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (123, 12, '2049', 'Benefici�rio n�o est� cadastrado na operadora. Requer confer�ncia de dados', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (124, 12, '2050', 'N�o existem evid�ncias cient�ficas que o indique para o caso espec�fico do paciente', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (125, 12, '2051', 'Existem evid�ncias cient�ficas que n�o o indicam para o caso espec�fico do paciente', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (126, 12, '2052', 'Existem evid�ncias cient�ficas que o reconhecem como ineficaz para o caso espec�fico do paciente', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (127, 12, '2053', 'O medicamento solicitado n�o est� registrado e autorizado para o uso pela Ag�ncia de vigil�ncia Sanit�ria (ANVISA)', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (128, 12, '2054', 'O medicamento solicitado n�o est� autorizado. A pr�tica m�dica usual n�o recomenda o uso medicamento para o caso espec�fico do paciente', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (129, 12, '2055', 'O material m�dico n�o est� registrado e autorizado para o uso pela Ag�ncia de vigil�ncia Sanit�ria (ANVISA)', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (130, 12, '2056', 'O material m�dico solicitado n�o est� autorizado. A pr�tica m�dica usual n�o recomenda o uso material para o caso espec�fico do paciente', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (131, 12, '2057', 'Procedimento n�o previsto no rol de procedimentos editado pela Ag�ncia Nacional de Sa�de Suplementar - ANS', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (132, 12, '2058', 'Procedimento considerado experimental - Necess�rio parecer t�cnico', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (133, 12, '2059', 'Transa��o original n�o autorizada', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (134, 12, '2060', 'Transa��o original n�o encontrada', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (135, 12, '2061', 'Negado por aus�ncia de autoriza��o empresa contratante', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (136, 12, '2062', 'Negado por aus�ncia de informa��o t�cnica suficiente para an�lise da Auditoria M�dica', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (137, 12, '2063', 'Procedimento incluso no evento principal', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (138, 12, '2064', 'Aus�ncia de justificativa t�cnica', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (139, 12, '2065', 'Conforme delibera��o do Col�gio Nacional de Auditores', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (140, 12, '2066', 'Material n�o imprescind�vel ao evento', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (141, 12, '2067', 'Material de uso permanente', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (142, 12, '2068', 'Sem cobertura para o prestador informado ou prestador de alto custo', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (143, 12, '2069', 'Limite contratual excedido para terapias', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (144, 12, '2070', 'Cliente sem cobertura para a rede Especial', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (145, 12, '2071', 'Cliente fora da �rea de abrang�ncia contratual', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (146, 12, '2072', 'Via do cart�o inv�lida', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (91, 12, '2001', 'Unimed Solic. igual a Unimed Req', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (92, 12, '2002', 'Unimed Serv. n�o e'' a Unimed acess.', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (93, 12, '2003', 'Quant. Servi�o deve ser maior 0', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (94, 12, '2004', 'Cadastro benefici�rio com problemas', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (95, 12, '2005', 'Servi�o Solicitado � de pr�-exist�ncia', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (96, 12, '2006', 'Idade Benefic. acima idade limite', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (97, 12, '2007', 'Problemas com financeiro do cliente', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (98, 12, '2008', 'Benef. com atendimento Suspenso', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (99, 12, '2009', 'Servi�o informado inv�lido', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (147, 13, '01', 'Bucal', 544);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (148, 13, '02', 'Capilar', 545);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (149, 13, '03', 'Dermatol�gica', 546);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (150, 13, '04', 'Epidural', 547);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (151, 13, '05', 'Gastrostomia/jejunostomia', 548);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (152, 13, '06', 'Inalat�ria', 549);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (153, 13, '07', 'Intra- �ssea', 550);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (154, 13, '08', 'Intra-arterial', 551);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (155, 13, '09', 'Intra-articular', 552);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (156, 13, '10', 'Intracard�aca', 553);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (157, 13, '11', 'Intrad�rmica', 554);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (158, 13, '12', 'Intralesional', 555);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (159, 13, '13', 'Intramuscular', 556);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (160, 13, '14', 'Intraperitonial', 557);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (161, 13, '15', 'Intrapleural', 558);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (162, 13, '16', 'Intratecal', 559);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (163, 13, '17', 'Intratraqueal', 560);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (164, 13, '18', 'Intrauterina', 561);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (165, 13, '19', 'Intravenosa', 562);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (166, 13, '20', 'Intravesical', 563);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (167, 13, '21', 'Intrav�trea', 564);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (168, 13, '22', 'Irriga��o', 565);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (169, 13, '23', 'Nasal', 566);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (170, 13, '24', 'Oft�lmica', 567);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (171, 13, '25', 'Oral', 568);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (172, 13, '26', 'Otol�gica', 569);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (173, 13, '27', 'Retal', 570);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (174, 13, '28', 'Sonda enteral', 571);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (175, 13, '29', 'Sonda g�strica', 572);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (176, 13, '30', 'Subcut�nea', 573);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (177, 13, '31', 'Sublingual', 574);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (178, 13, '32', 'Transd�rmica', 575);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (179, 13, '33', 'Uretral', 576);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (180, 13, '34', 'Vaginal', 577);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (181, 13, '35', 'Outras', 578);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (182, 14, '1', 'M1', 20);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (183, 14, '2', 'M0', 21);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (184, 14, '3', 'Mx', 22);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (185, 14, '8', 'N�o se aplica', 23);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (186, 14, '9', 'Sem informa��o', 24);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (187, 15, '1', 'N1', 25);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (188, 15, '2', 'N2', 26);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (189, 15, '3', 'N3', 27);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (190, 15, '4', 'N0', 28);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (191, 15, '5', 'Nx', 29);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (192, 15, '8', 'N�o se aplica', 30);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (193, 15, '9', 'Sem informa��o', 31);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (194, 16, '1', 'T1', 32);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (195, 16, '2', 'T2', 33);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (196, 16, '3', 'T3', 34);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (197, 16, '4', 'T4', 35);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (198, 16, '5', 'T0', 36);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (199, 16, '6', 'Tis', 37);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (200, 16, '7', 'Tx', 38);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (201, 16, '8', 'N�o se aplica', 39);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (202, 16, '9', 'Sem informa��o', 40);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1422, 17, '5001', 'Nenhum registro encontrado', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1423, 17, '5002', 'Problemas no processamento', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1424, 17, '5003', 'Unimed Offline n�o responde esta transa��o', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1425, 17, '6001', 'Erro desconhecido ao recuperar o hist�rico de a��es do processo de baixa.', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1426, 17, '6002', 'Erro desconhecido ao processar a baixa.', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1427, 17, '6003', 'Tamanho do campo inv�lido', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1428, 17, '6004', 'O campo de CD_UNI_DES da mensagem de solicita��o de baixa dever� sempre ser preenchido com "999" - Unimed do Brasil', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1429, 17, '6005', 'Formato de dado incompat�vel com o tipo.', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1430, 17, '6006', 'Campo de preenchimento obrigat�rio', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1431, 17, '6007', 'C�digo da Unimed desconhecido.', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1432, 17, '6008', 'J� foi realizada uma opera��o de baixa para a fatura informada.', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1433, 17, '6009', 'A data de pagamento do documento n�o pode ser futura.', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1434, 17, '6010', 'Caso seja informada a baixa do Documento 2, todos os campos NUMERO_DOC_2, VALOR_PAGO_DOC_2, DATA_PAGAMENTO_DOC_2 e ENCONTRO_CONTAS_DOC_2 devem ser preenchidos.', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1435, 17, '6011', 'N�o foi encontrado o documento informado para realiza��o da baixa.', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1436, 17, '6012', 'O documento n�o pode ser marcado como Inadimplente antes do seu vencimento.', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1437, 17, '6013', 'A data de pagamento do documento n�o pode ser sido feita antes da postagem da fatura.', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1438, 17, '6014', 'O valor pago n�o pode ser maior que o valor total do documento.', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1439, 17, '6015', 'Quando houver uma constesta��o (A550) de pagamento parcial relacionado � fatura (A500) o valor pago informado n�o pode ser maior que a diferen�a entre o valor total do documento e o valor contestado.', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1440, 17, '6016', 'J� foi informado um valor para o encontro de contas que difere do que foi informado.', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1441, 17, '6017', 'Dever� ser informado a baixa do documento 2, sen�o, n�o ser� poss�vel a realiza��o da baixa do documento 1', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1442, 17, '6018', 'N�o � poss�vel realizar baixa em faturas canceladas ou devolvidas', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1443, 17, '6019', 'Fatura j� est� marcada como Inadimplente Total', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1444, 17, '6020', 'Erro Inesperado', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (203, 17, '4001', 'Layout PTU de requisi��o inv�lido', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (204, 17, '4002', 'Layout PTU de resposta inv�lido', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (205, 17, '4003', 'Erro na comunica��o do SCS com o autorizador da Unimed Destino', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (206, 17, '4004', 'Unimed Destino da comunica��o n�o est� configurada para responder On-Line', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (207, 17, '4005', 'A Unimed utiliza vers�o de PTU incompat�vel com a transa��o', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (208, 17, '4006', 'Falha de comunica��o SCS Origem ou Destino', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (209, 17, '4007', 'Falha de Comunica��o Socket, portas, TCP/IP', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (210, 17, '4008', 'Unimed destino configurada como on-line', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (211, 18, '0', '0', 64);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (212, 18, '1', 'I', 65);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (213, 18, '2', 'II', 66);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (214, 18, '3', 'III', 67);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (215, 18, '4', 'IV', 68);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (216, 18, '5', 'N�o se aplica', 69);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (217, 19, '1', 'Acidente de Trabalho', 111);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (218, 19, '2', 'Acidente de Transito', 112);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (219, 19, '3', 'Acidente Outros', 113);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (220, 19, '9', 'Nao acidente', 114);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (3, 2, '1', 'Eletiva', 16);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (4, 2, '2', 'Urg�ncia/Emerg�ncia', 17);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (221, 20, '1', 'Negado', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (222, 20, '2', 'Autorizado', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (223, 20, '3', 'Pendente para autoriza��o da empresa', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (224, 20, '4', 'Pendente para auditoria', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (225, 21, '1', 'Negado', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (226, 21, '2', 'Autorizado', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (227, 22, '1', 'Plano N�o Regulamentado', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (228, 22, '2', 'Plano Adaptado', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (229, 22, '3', 'Plano Regulamentado', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (230, 22, '9', 'Somente utilizado pelo WSD', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (231, 23, '1', 'Negado', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (232, 23, '2', 'Autorizado', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (233, 23, '3', 'Pendente para autoriza��o da empresa', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (234, 23, '4', 'Pendente para auditoria', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (235, 23, '5', 'Cancelado', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (236, 24, '1', 'Recusado', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (237, 24, '2', 'Aceita', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (238, 25, 'COREN', 'Conselho Regional de Enfermagem', 41);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (239, 25, 'CRAS', 'Conselho Regional de Assistentes Sociais', 42);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (240, 25, 'CREFITO', 'Conselho Regional de Fisioterapia e Terapia Ocupacional', 43);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (241, 25, 'CRF', 'Conselho Regional de Farm�cia', 44);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (242, 25, 'CRFA', 'Conselho Regional de Fonoaudioa', 45);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (243, 25, 'CRM', 'Conselho Regional de Medicina', 46);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (244, 25, 'CRN', 'Conselho Regional de Nutri��o', 47);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (245, 25, 'CRO', 'Conselho Regional de Odontologia', 48);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (246, 25, 'CRP', 'Conselho Regional de Psicologia', 49);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (247, 25, 'OUT', 'Outros Conselhos', 50);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1421, 26, 'X', 'Negada', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (248, 26, 'N', 'N�o', 89);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (249, 26, 'S', 'Sim', 90);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (250, 27, '1', 'Resposta Fornecida', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (251, 27, '2', 'Resposta Negada por aus�ncia de v�nculo', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (252, 27, '3', 'Data de Refer�ncia fora do per�odo previsto', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (253, 28, '1', 'Nacional', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (254, 28, '2', 'Regional A - Grupo de estados', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (255, 28, '3', 'Estadual', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (256, 28, '4', 'Regional B - Grupo de munc�pios', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (257, 28, '5', 'Municipal', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (258, 29, 'A', 'Coletiva', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (259, 29, 'B', 'Individual', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (260, 29, 'C', 'N�o se aplica', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (261, 29, 'X', 'Convers�o PTU', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (5, 3, '1', 'Negado', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (6, 3, '2', 'Autorizado', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (7, 3, '3', 'Cancelado pela operadora', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (262, 30, '1', 'Indicador de Quimioterapia', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (263, 30, '2', 'Indicador de Radioterapia', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (264, 30, '3', 'Indicador de OPME', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (265, 30, '9', 'N�o anexo', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (266, 31, '1', 'Unimed', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (267, 31, '2', 'WSD', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (268, 32, 'PORTAL', 'Mensagem enviada pela Interface Unica de Liberacoes', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (269, 32, 'PRESTADOR', 'Mensagem enviada pelo sistema de Captura dos Prestadores', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (270, 32, 'SYNC', 'Mensagem de sincronizacao entre WSD e Unimed/Interface Unica de Liberacoes', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (271, 32, 'UNIMED', 'Mensagem enviada pelo Sistema Gestor da Unimed', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (272, 32, 'WSD', 'Mensagem enviada pela WSD a Interface Unica de Liberacoes, para transacoes destinadas a Unimeds on-line mas que estejam operando temporariamente de forma off-line', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (273, 33, 'A', 'Alta', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (274, 33, 'I', 'In�cio interna��o', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (275, 34, '1', 'Confirmada', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (276, 34, '2', 'Guia inexistente', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (277, 34, '3', 'Situa��o inv�lida', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (278, 34, '4', 'Autorizado pelo WSD', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (279, 35, '1', 'Interna��o Cl�nica', 352);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (280, 35, '2', 'Interna��o Cir�rgica', 353);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (281, 35, '3', 'Interna��o Obst�trica', 354);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (282, 35, '6', 'Interna��o Pedi�trica', 355);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (283, 35, '7', 'Interna��o Psiqui�trica', 356);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (284, 36, '1', 'Primeira linha', 435);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (285, 36, '2', 'Segunda linha', 436);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (286, 36, '3', 'Terceira linha', 437);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (287, 36, '4', 'Outras linhas', 438);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (288, 37, '1', 'B�sica', 448);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (289, 37, '2', 'Especial (Tabela Pr�pria)', 449);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (290, 37, '3', 'Master (Alto Custo)', 450);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (291, 38, '1', 'Masculino', 147);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (292, 38, '3', 'Feminino', 146);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (293, 39, '0', 'Rol UNimed / AMB / CBHPM', 190);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (294, 39, '1', 'Servi�os Hospitalares/Taxas/Complementos (C�digos da tabela C)', 191);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (295, 39, '2', 'Materiais (C�digos da tabela E)', 192);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (296, 39, '3', 'Medicamentos (C�digos da tabela D)', 193);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (297, 39, '4', 'Servi�os com custo fechado / pacote', 194);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (8, 4, '1', 'Regra de Baixo Risco - Off-line (caso Origem Off-line)', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (9, 4, '2', 'Regra de Baixo Risco - Estudo (caso Origem On-line e resposta em estudo)', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (298, 40, '1', 'Primeira op��o de fabricante', 116);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (299, 40, '2', 'Segunda op��o de fabricante', 117);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (300, 40, '3', 'Terceira op��o de fabricante', 118);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (301, 41, '1', 'AMP - Ampola', 493);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (302, 41, '10', 'DRG - Dr�gea', 507);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (303, 41, '11', 'ENV - Envelope', 508);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (304, 41, '12', 'FLAC - Flaconete', 510);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (305, 41, '13', 'FR - Frasco', 511);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (306, 41, '14', 'FA - Frasco Ampola', 509);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (307, 41, '15', 'GAL - Gal�o', 512);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (308, 41, '16', 'GLOB - Gl�bulo', 513);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (309, 41, '17', 'GTS - Gotas', 515);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (310, 41, '18', 'G - Grama', 514);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (311, 41, '19', 'L - Litro', 520);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (312, 41, '2', 'BUI - Bilh�es de Unidades Internacionais', 496);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (313, 41, '20', 'MCG - Microgramas', 522);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (314, 41, '21', 'MUI - Milh�es de Unidades Internacionais', 526);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (315, 41, '22', 'MG - Miligrama', 523);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (316, 41, '23', 'ML - Mililitro', 524);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (317, 41, '24', 'OVL - �vulo', 527);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (318, 41, '25', 'PAS - Pastilha', 529);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (319, 41, '26', 'LT - Lata', 519);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (320, 41, '27', 'PER - P�rola', 532);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (321, 41, '28', 'PIL - P�lula', 533);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (322, 41, '29', 'PT - Pote', 534);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (323, 41, '3', 'BG - Bisnaga', 494);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (324, 41, '30', 'KG - Quilograma', 517);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (325, 41, '31', 'SER - Seringa', 537);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (326, 41, '32', 'SUP - Suposit�rio', 538);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (327, 41, '33', 'TABLE - Tablete', 539);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (328, 41, '34', 'TUB - Tubete', 541);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (329, 41, '35', 'TB - Tubo', 540);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (330, 41, '36', 'UN - Unidade', 543);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (331, 41, '37', 'UI - Unidade Internacional', 542);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (332, 41, '38', 'CM - Cent�metro', 501);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (333, 41, '39', 'CONJ - Conjunto', 502);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (334, 41, '4', 'BOLS - Bolsa', 495);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (335, 41, '40', 'KIT - Kit', 518);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (336, 41, '41', 'M� - Ma�o', 521);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (337, 41, '42', 'M - Metro', 525);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (338, 41, '43', 'PC - Pacote', 531);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (339, 41, '44', 'P� - Pe�a', 530);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (340, 41, '45', 'RL - Rolo', 535);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (341, 41, '46', 'GY - Gray', 516);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (342, 41, '47', 'CGY - Centgray', 500);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (343, 41, '48', 'PAR - Par', 528);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (344, 41, '49', 'ADES - Adesivo Transd�rmico', 492);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (345, 41, '5', 'CX - Caixa', 505);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (346, 41, '50', 'COM EFEV - Comprimido Efervecente', 499);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (347, 41, '51', 'COM MST - Comprimido Mastig�vel', 503);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (348, 41, '52', 'SACHE - Sache', 536);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (349, 41, '6', 'CAP - C�psula', 497);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (350, 41, '7', 'CARP - Carpule', 498);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (351, 41, '8', 'COM - Comprimido', 504);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (352, 41, '9', 'DOSE - Dose', 506);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (353, 42, '11', 'Rond�nia - RO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (354, 42, '12', 'Acre - AC', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (355, 42, '13', 'Amazonas - AM', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (356, 42, '14', 'Roraima - RR', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (357, 42, '15', 'Par� - PA', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (358, 42, '16', 'Amap� - AP', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (359, 42, '17', 'Tocantins - TO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (360, 42, '21', 'Maranh�o - MA', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (361, 42, '22', 'Piau� - PI', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (362, 42, '23', 'Cear� - CE', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (363, 42, '24', 'Rio Grande do Norte - RN', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (364, 42, '25', 'Para�ba - PB', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (365, 42, '26', 'Pernambuco - PE', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (366, 42, '27', 'Alagoas - AL', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (367, 42, '28', 'Sergipe - SE', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (368, 42, '29', 'Bahia - BA', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (369, 42, '31', 'Minas Gerais - MG', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (370, 42, '32', 'Esp�rito Santo - ES', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (371, 42, '33', 'Rio de Janeiro - RJ', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (372, 42, '35', 'S�o Paulo - SP', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (373, 42, '41', 'Paran� - PR', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (374, 42, '42', 'Santa Catarina - SC', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (375, 42, '43', 'Rio Grande do Sul - RS', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (376, 42, '50', 'Mato Grosso do Sul - MS', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (377, 42, '51', 'Mato Grosso - MT', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (378, 42, '52', 'Goi�s - GO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (379, 42, '53', 'Distrito Federal - DF', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (380, 42, '98', 'Pa�ses Estrangeiros - EX', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (381, 43, '1', 'CRAS - Conselho Regional de Assist�ncia Social', 42);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (382, 43, '10', 'OUT - Outros Conselhos', 50);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (383, 43, '2', 'COREN - Conselho Regional de Enfermagem', 41);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (384, 43, '3', 'CRF - Conselho Regional de Farm�cia', 44);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (385, 43, '4', 'CRFA - Conselho Regional de Fonoaudiologia', 45);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (386, 43, '5', 'CREFITO - Conselho Regional de Fisioterapia e Terapia Ocupacional', 43);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (387, 43, '6', 'CRM - Conselho Regional de Medicina', 46);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (388, 43, '7', 'CRN - Conselho Regional de Nutri��o', 47);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (389, 43, '8', 'CRO - Conselho Regional de Odontologia', 48);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (390, 43, '9', 'CRP - Conselho Regional de Psicologia', 49);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (391, 44, '1', 'D�bito', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (392, 44, '2', 'Cr�dito', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (393, 45, '01', 'IRRF', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (394, 45, '02', 'ISS', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (395, 45, '03', 'INSS', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (396, 45, '04', 'PIS', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (397, 45, '05', 'COFINS', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (398, 45, '06', 'CSLL', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (399, 45, '07', 'Descontos financeiros', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (400, 45, '08', 'Ajuste de pagamento anterior', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (401, 45, '09', 'Determinan��o judicial', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (402, 46, '1', 'Tomografia', 51);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (403, 46, '2', 'Resson�ncia Magn�tica', 52);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (404, 46, '3', 'Raio-X', 53);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (405, 46, '4', 'Outras', 54);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (406, 46, '5', 'Ultrassonografia', 55);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (407, 46, '6', 'PET', 56);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (408, 47, '0', 'Totalmente ativo', 57);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (409, 47, '1', 'N�o exerce atividade f�sica', 58);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (410, 47, '2', 'Caminha e � capaz de realizar atividade de autocuidado', 59);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (411, 47, '3', 'Capacidade de autocuidado limitada', 60);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (412, 47, '4', 'Completamente dependente', 61);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (413, 48, '1', 'I', 65);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (414, 48, '2', 'II', 66);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (415, 48, '3', 'III', 67);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (416, 48, '4', 'IV', 68);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (417, 48, '5', 'N�o se aplica', 69);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (418, 49, '1', 'Curativa', 84);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (419, 49, '2', 'Neoadjuvante', 85);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (420, 49, '3', 'Adjuvante', 86);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (421, 49, '4', 'Paliativa', 87);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (422, 49, '5', 'Controle', 88);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (10, 5, '1', 'Confirmado', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (11, 5, '2', 'Arquivo n�o dispon�vel', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (423, 50, '1', 'Dep�sito/transfer�ncia banc�ria', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (424, 50, '2', 'Carteira', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (425, 50, '3', 'Boleto Banc�rio / DDA', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (426, 50, '4', 'Dinheiro/cheque', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (427, 51, '00', 'Cirurgi�o', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (428, 51, '01', 'Primeiro Auxiliar', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (429, 51, '02', 'Segundo Auxiliar', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (430, 51, '03', 'Terceiro Auxiliar', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (431, 51, '04', 'Quarto Auxiliar', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (432, 51, '05', 'Instrumentador', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (433, 51, '06', 'Anestesista', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (434, 51, '07', 'Auxiliar de Anestesista', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (435, 51, '08', 'Consultor', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (436, 51, '09', 'Perfusionista', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (437, 51, '10', 'Pediatra na sala de parto', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (438, 51, '11', 'Auxiliar SADT', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (439, 51, '12', 'Cl�nico', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (440, 51, '13', 'Intensivista', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (441, 52, '0', 'Trabalho', 111);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (442, 52, '1', 'Tr�nsito', 112);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (443, 52, '2', 'Outros acidentes', 113);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (444, 52, '9', 'N�o acidentes', 114);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (445, 53, '1', 'CNPJ', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (446, 53, '2', 'CPF', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (447, 54, '1', 'M1', 20);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (448, 54, '2', 'M0', 21);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (449, 54, '3', 'Mx', 22);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (450, 54, '8', 'N�o se aplica', 23);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (451, 54, '9', 'Sem informa��o', 24);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (452, 55, '11', 'Alta Curado', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (453, 55, '12', 'Alta Melhorado', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (454, 55, '14', 'Alta a pedido', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (455, 55, '15', 'Alta com previs�o de retorno para acompanhamento do paciente', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (456, 55, '16', 'Alta por Evas�o', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (457, 55, '17', 'Alta da Pu�rpera e rec�m-nascido', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (458, 55, '18', 'Alta por Outros motivos', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (459, 55, '21', 'Permanencia por caracter�sticas pr�prias da doen�a', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (460, 55, '22', 'Permanencia por Intercorr�ncia', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (461, 55, '23', 'Permanencia por impossibilidade s�cio-familiar', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (462, 55, '24', 'permanencia por Processo de doa��o de �rg�os, tecidos e c�lulas - doador vivo', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (463, 55, '25', 'Permanencia por Processo de doa��o de �rg�os, tecidos e c�lulas - doador morto', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (464, 55, '26', 'Permanencia por mudan�a de procedimento', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (465, 55, '27', 'Permanencia por re-opera��o', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (466, 55, '28', 'Permanencia por outros motivos', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (467, 55, '31', 'Transferido para outro estabelecimento', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (468, 55, '32', 'Transferencia para interna��o domiciliar', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (469, 55, '41', '�bito com declara��o de �bito fornecida pelo m�dico assistente', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (470, 55, '42', '�bito com declara��o de �bito fornecida pelo Instituto M�dico Legal - IML', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (471, 55, '43', '�bito com declara��o de �bito fornecida pelo Servi�o de Verifica��o de �bito - SVO.', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (472, 55, '51', 'ENCERRAMENTO ADMINISTRATIVO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (473, 55, '61', 'Alta m�e/puerpera e do recem nascido', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (474, 55, '62', 'Alta m�e/puerpera e permanencia do recem-nascido', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (475, 55, '63', 'Alta m�e/puerpera e obito do recem-nascido', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (476, 55, '64', 'Alta m�e/puerpera com obito fetal', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (477, 55, '65', '�bito da gestante e do concepto', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (478, 55, '66', '�bito da m�e/puerpera e alta do recem-nascido', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (479, 55, '67', 'Obito da mae/puerpera e permanencia do recem nascido', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (480, 56, '41', '�bito com declara��o de �bito fornecida pelo m�dico assistente', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (481, 56, '42', '�bito com declara��o de �bito fornecida pelo Instituto M�dico Legal - IML', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (482, 56, '43', '�bito com declara��o de �bito fornecida pelo Servi�o de Verifica��o de �bito - SVO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (483, 57, '1', 'N1', 25);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (484, 57, '2', 'N2', 26);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (485, 57, '3', 'N3', 27);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (486, 57, '4', 'N0', 28);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (487, 57, '5', 'Nx', 29);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (488, 58, '1', 'Gr�vida', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (489, 58, '2', 'At� 42 dias ap�s t�rmino gesta��o', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (490, 58, '3', 'De 43 dias � 12 meses ap�s t�rmino gesta��o', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (491, 59, '1', 'Recurso de protocolo', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (492, 59, '2', 'Recurso de guia', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (12, 6, '1', 'Confirmada', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (13, 6, '2', 'Guia inexistente', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (14, 6, '3', 'Situa��o Inv�lida', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (15, 6, '4', 'Autorizado pelo WSD', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (493, 60, '1', 'Primeira op��o de fabricante', 116);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (494, 60, '2', 'Segunda op��o de fabricante', 117);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (495, 60, '3', 'Terceira op��o de fabricante', 118);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (496, 61, '1', 'Rede Contratada, referenciada ou credenciada', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (497, 61, '2', 'Rede Pr�pria - Cooperados', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (498, 61, '3', 'Rede Pr�pria - Demais prestadores', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (499, 61, '4', 'Reembolso ao benefici�rio', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (500, 62, '01', 'Gases medicinais', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (501, 62, '02', 'Medicamentos', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (502, 62, '03', 'Materiais', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (503, 62, '04', 'Taxas diversas', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (504, 62, '05', 'Di�rias', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (505, 62, '06', 'Alugu�is', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (506, 62, '07', 'Taxas e alugu�is', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (507, 62, '08', 'OPME', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (508, 63, '00', 'Cirurgi�o', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (509, 63, '01', 'Primeiro Auxiliar', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (510, 63, '02', 'Segundo Auxiliar', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (511, 63, '03', 'Terceiro Auxiliar', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (512, 63, '04', 'Quarto Auxiliar', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (513, 63, '05', 'Instrumentador', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (514, 63, '06', 'Anestesista', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (515, 63, '07', 'Auxiliar de Anestesista', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (516, 63, '08', 'Consultor', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (517, 63, '09', 'Perfusionista', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (518, 63, '10', 'Pediatra na sala de parto', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (519, 63, '11', 'Auxiliar SADT', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (520, 63, '12', 'Cl�nico', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (521, 63, '13', 'Intensivista', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (522, 64, '1', 'Hospitalar', 137);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (523, 64, '2', 'Hospital-Dia', 138);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (524, 64, '3', 'Domiciliar', 139);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (525, 65, '1', 'Masculino', 147);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (526, 65, '3', 'Feminino', 146);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (527, 66, 'N', 'N�o', 89);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (528, 66, 'S', 'Sim', 90);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (529, 67, '1', 'Cancelado com sucesso', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (530, 67, '2', 'N�o cancelado', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (531, 67, '3', 'Guia inexistente', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (532, 67, '4', 'Em an�lise', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (533, 68, 'B', 'Benefici�rio n�o reconhecido', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (534, 68, 'P', 'Processado', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (535, 69, '1', 'Recebido', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (536, 69, '2', 'Em an�lise', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (537, 69, '3', 'Liberado para pagamento', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (538, 69, '4', 'Encerrado sem pagamento', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (539, 69, '5', 'Analisado e aguardando libera��o para pagamento', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (540, 69, '6', 'Pagamento Efetuado', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (541, 69, '7', 'N�o Localizado', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (542, 69, '8', 'Aguardando informa��o complementar', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (16, 7, '1', 'Tomografia', 51);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (17, 7, '2', 'Resson�ncia Magn�tica', 52);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (18, 7, '3', 'Raios-X', 53);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (19, 7, '4', 'Outras', 54);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (20, 7, '5', 'Ultrassonografia', 55);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (21, 7, '6', 'PET', 56);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (543, 70, '1', 'Autorizado', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (544, 70, '2', 'Em an�lise', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (545, 70, '3', 'Negado', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (546, 70, '4', 'Aguardando justificativa t�cnica do solicitante', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (547, 70, '5', 'Aguardando documenta��o do prestador', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (548, 70, '6', 'Solicita��o cancelada', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (549, 70, '7', 'Autorizado parcialmente', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (550, 71, '00', 'Tabela Pr�pria das Operadoras', 195);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (551, 71, '18', 'TUSS _ Taxas hospitalares, di�rias e gases medicinais', 196);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (552, 71, '19', 'TUSS _ Materiais', 197);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (553, 71, '20', 'TUSS - Medicamentos', 198);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (554, 71, '22', 'TUSS _ Procedimentos e eventos em sa�de (medicina, odonto e demais �reas de sa�de)', 199);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (555, 71, '90', 'Tabela Pr�pria Pacote Odontol�gico', 200);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (556, 71, '98', 'Tabela Pr�pria de Pacotes', 201);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (557, 72, '00', 'Tabela Pr�pria das Operadoras', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (558, 72, '05', 'Tabela Bras�ndice', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (559, 72, '12', 'Tabela SIMPRO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (560, 72, '18', 'TUSS _ Taxas hospitalares, di�rias e gases medicinais', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (561, 72, '19', 'TUSS _ Materiais', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (562, 72, '20', 'TUSS - Medicamentos', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (563, 72, '22', 'TUSS _ Procedimentos e eventos em sa�de (medicina, odonto e demais �reas de sa�de)', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (564, 72, '23', 'Conselho profissional', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (565, 72, '24', 'Tipo de interna��o', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (566, 72, '25', 'Sexo', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (567, 72, '26', 'Regime de Interna��o', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (568, 72, '27', 'Tipo obst�trica', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (569, 72, '28', 'Tipo de consulta', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (570, 72, '29', 'Tipo de doen�a', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (571, 72, '30', 'Unidade de tempo de doen�a referida pelo paciente', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (572, 72, '31', 'Indicador de Acidente', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (573, 72, '32', 'Tipo de atendimento', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (574, 72, '33', 'Tipo de acomoda��o', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (575, 72, '34', 'Motivo de sa�da da interna��o', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (576, 72, '35', '�bito em mulher', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (577, 72, '36', 'Tipo de Faturamento', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (578, 72, '37', 'Via de acesso', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (579, 72, '38', 'T�cnica utilizada', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (580, 72, '39', 'Grau de participa��o', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (581, 72, '40', 'Faces do dente', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (582, 72, '41', 'Situa��o Inicial do Dente', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (583, 72, '42', 'Regi�es da Boca', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (584, 72, '43', 'Dentes', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (585, 72, '44', 'Status do protocolo', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (586, 72, '45', 'CBO-S (especialidade)', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (587, 72, '46', 'Glosas, negativas e demais mensagens', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (588, 72, '47', 'Unidade de Medida', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (589, 72, '48', 'Forma de Pagamento', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (590, 72, '49', 'Status do Cancelamento', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (591, 72, '50', 'Status da Solicita��o', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (592, 72, '51', 'Tipo de Demonstrativo', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (593, 72, '52', 'Escala de Capacidade Funcional (ECOG - Escala de Zubrod)', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (594, 72, '53', 'Car�ter do Atendimento', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (595, 72, '54', 'C�digo da Despesa', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (596, 72, '55', 'Finalidade do Tratamento', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (597, 72, '56', 'Met�stases', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (598, 72, '57', 'N�dulo', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (599, 72, '58', 'Diagn�stico por imagem', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (600, 72, '59', 'Tipo de Quimioterapia', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (601, 72, '60', 'Tumor', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (602, 72, '61', 'Via de administra��o', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (603, 72, '90', 'Tabela Pr�pria Pacote Odontol�gico', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (604, 72, '98', 'Tabela Pr�pria de Pacotes', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (605, 73, '1', 'Tomografia', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (606, 73, '2', 'Resson�ncia Magn�tica', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (607, 73, '3', 'Raio-X', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (608, 73, '4', 'Outras', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (609, 74, '1', 'Convencional', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (610, 74, '2', 'Videolaparoscopia', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (611, 74, '3', 'Rob�tica', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (612, 75, '02', 'QUARTO PRIVATIVO / PARTICULAR', 207);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (613, 75, '09', 'APARTAMENTO DE LUXO DA MATERNIDADE', 208);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (614, 75, '10', 'APARTAMENTO DE LUXO DE PSIQUIATRIA', 209);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (615, 75, '11', 'APARTAMENTO DE LUXO', 210);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (616, 75, '12', 'APARTAMENTO SIMPLES', 211);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (617, 75, '13', 'APARTAMENTO STANDARD', 212);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (618, 75, '14', 'APARTAMENTO SU�TE', 213);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (619, 75, '15', 'APARTAMENTO COM ALOJAMENTO CONJUNTO', 214);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (620, 75, '16', 'APARTAMENTO PARA PACIENTE COM OBESIDADE M�RBIDA', 215);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (621, 75, '17', 'APARTAMENTO SIMPLES DA MATERNIDADE', 216);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (622, 75, '18', 'APARTAMENTO SIMPLES DE PSIQUIATRIA', 217);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (623, 75, '19', 'APARTAMENTO SU�TE DA MATERNIDADE', 218);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (624, 75, '20', 'APARTAMENTO SU�TE DE PSIQUIATRIA', 219);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (625, 75, '21', 'BER��RIO NORMAL', 220);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (626, 75, '22', 'BER��RIO PATOL�GICO / PREMATURO', 221);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (627, 75, '25', 'ENFERMARIA DE 3 LEITOS DA MATERNIDADE', 222);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (628, 75, '26', 'ENFERMARIA DE 4 OU MAIS LEITOS DA MATERNIDADE', 223);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (629, 75, '27', 'HOSPITAL DIA APARTAMENTO', 224);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (630, 75, '28', 'HOSPITAL DIA ENFERMARIA', 225);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (631, 75, '29', 'HOSPITAL DIA PSIQUIATRIA', 226);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (632, 75, '30', 'QUARTO COLETIVO DE 2 LEITOS DA MATERNIDADE', 227);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (633, 75, '31', 'ENFERMARIA DE 3 LEITOS', 228);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (634, 75, '32', 'ENFERMARIA DE 4 OU MAIS LEITOS', 229);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (635, 75, '33', 'ENFERMARIA COM ALOJAMENTO CONJUNTO', 230);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (636, 75, '36', 'QUARTO PRIVATIVO / PARTICULAR DA MATERNIDADE', 231);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (637, 75, '37', 'QUARTO PRIVATIVO / PARTICULAR DE PSIQUIATRIA', 232);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (638, 75, '38', 'SEMI UTI ADULTO GERAL', 233);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (639, 75, '39', 'SEMI UTI CORONARIANA', 234);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (640, 75, '40', 'SEMI UTI NEONATAL', 235);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (641, 75, '41', 'QUARTO COLETIVO DE 2 LEITOS', 236);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (642, 75, '43', 'QUARTO COM ALOJAMENTO CONJUNTO', 237);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (643, 75, '44', 'SEMI UTI NEUROL�GICA', 238);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (644, 75, '45', 'SEMI UTI INFANTIL/PEDI�TRICA', 239);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (645, 75, '46', 'SEMI UTI QUEIMADOS', 240);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (646, 75, '47', 'UNIDADE DE TRANSPLANTE DE MEDULA �SSEA', 241);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (647, 75, '48', 'UNIDADE DE TRANSPLANTE EM GERAL', 242);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (648, 75, '49', 'APARTAMENTO STANDARD DA MATERNIDADE', 243);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (649, 75, '50', 'APARTAMENTO STANDARD DE PSIQUIATRIA', 244);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (650, 75, '51', 'UTI ADULTO GERAL', 245);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (651, 75, '52', 'UTI INFANTIL/PEDI�TRICA', 246);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (652, 75, '53', 'UTI NEONATAL', 247);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (653, 75, '56', 'UNIDADE PARA TRATAMENTO RADIOATIVO', 248);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (654, 75, '57', 'UTI CORONARIANA', 249);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (655, 75, '58', 'UTI NEUROL�GICA', 250);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (656, 75, '59', 'UTI QUEIMADOS', 251);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (657, 76, '01', 'Remo��o', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (658, 76, '02', 'Pequena Cirurgia', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (659, 76, '03', 'Terapias', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (660, 76, '04', 'Consulta', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (661, 76, '05', 'Exames (englobando exame radiol�gico)', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (662, 76, '06', 'Atendimento Domiciliar', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (663, 76, '07', 'Interna��o', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (664, 76, '08', 'Quimioterapia', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (665, 76, '09', 'Radioterapia', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (666, 76, '10', 'Terapia Renal Substitutiva (TRS)', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (667, 76, '11', 'Pronto Socorro', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (668, 76, '13', 'Pequenos atendimentos', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (669, 76, '14', 'Sa�de Ocupacional - Admissional', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (670, 76, '15', 'Sa�de Ocupacional - Demissional', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (671, 76, '16', 'Sa�de Ocupacional - Peri�dico', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (672, 76, '17', 'Sa�de Ocupacional - Retorno ao trabalho', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (673, 76, '18', 'Sa�de Ocupacional - Mudan�a de fun��o', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (674, 76, '19', 'Sa�de Ocupacional - Promo��o a sa�de', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (675, 76, '20', 'Sa�de Ocupacional - Benefici�rio novo', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (676, 76, '21', 'Sa�de Ocupacional - Assist�ncia a demitidos', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (677, 77, '1', 'Primeira', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (678, 77, '2', 'Seguimento', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (679, 77, '3', 'Pr�-Natal', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (680, 77, '4', 'Por encaminhamento', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (681, 78, '1', 'Demonstrativo de Pagamento', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (682, 78, '2', 'Demonstrativo de an�lise da conta m�dica', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (683, 78, '3', 'Demonstrativo de Pagamento - Odontologia', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (684, 79, '1', 'Demonstrativo de Pagamento', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (685, 79, '2', 'Demonstrativo de an�lise da conta m�dica', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (686, 79, '3', 'Demonstrativo de Pagamento - Odontologia', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (22, 8, '0', 'Totalmente ativo capaz de exercer, sem restri��es, todas as atividades que exercia antes do diagn�stico', 57);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (23, 8, '1', 'N�o exerce atividade f�sica extenuante, por�m � capaz de realizar um trabalho leve em casa ou no escrit�rio', 58);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (24, 8, '2', 'Caminha e � capaz de exercer as atividades de autocuidado, mas � incapaz de realizar qualquer atividade de trabalho.Permanece', 59);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (25, 8, '3', 'Capacidade de autocuidado limitada. Permanece no leito ou cadeira mais de 50% das horas de vig�lia', 60);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (26, 8, '4', 'Completamente dependente. N�o � capaz de exercer qualquer atividade de autocuidado. Totalmente confinado � cama ou cadeira', 61);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (687, 80, '1', 'A - Aguda', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (688, 80, '2', 'C - Cr�nica', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (689, 81, 'A', 'Alta', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (690, 81, 'I', 'Inicio Interna��o', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (691, 82, '1', 'Parcial', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (692, 82, '2', 'Final', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (693, 82, '3', 'Complementar', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (694, 82, '4', 'Total', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (695, 83, '1', 'Parcial', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (696, 83, '4', 'Total', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1000, 84, '2412', 'COBRAN�A DE TAXA DE RECUPERA��O ANEST�SICA N�O JUSTIFICADA PARA O PROCEDIMENTO.', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1001, 84, '2413', 'COBRAN�A DE TAXA INCLUSA NO PACOTE NEGOCIADO.', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1002, 84, '2414', 'COBRAN�A DE TAXA DE EQUIPAMENTO EM CONCOMIT�NCIA COM A COBRAN�A DE TAXA PARA O PROCEDIMENTO.', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1003, 84, '2415', 'TAXA EXIGE INFORMA��O DO VALOR NA GUIA.', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1004, 84, '2416', 'COBRAN�A DE TAXA DE RECUPERA��O ANEST�SICA PARA PACIENTES COM P�S-OPERAT�RIO IMEDIATO REALIZADO NA UTI/CTI.', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1005, 84, '2417', 'COBRAN�A DE TAXA DE RECUPERA��O ANEST�SICA SEM A PRESEN�A DO ANESTESISTA.', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1006, 84, '2418', 'COBRAN�A DE TAXA DE SALA INCOMPAT�VEL COM O PROCEDIMENTO.', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1007, 84, '2419', 'COBRAN�A DE TAXA DE OBSERVA��O PARA ATENDIMENTO QUE GEROU UMA INTERNA��O.', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1008, 84, '2420', 'COBRAN�A DE TAXA DE SALA CIR�RGICA COM PORTE ANEST�SICO DIFERENTE DO PROCEDIMENTO AUTORIZADO/REALIZADO.', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1009, 84, '2421', 'COBRAN�A DE TAXA EM QUANTIDADE INCORRETA.', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1010, 84, '2422', 'COBRAN�A DE TAXA POR USO DE EQUIPAMENTO DE USO OBRIGAT�RIO NA SALA DE CIRURGIA, CUJA TAXA DE SALA CIR�RGICA J� INCLUI SEU USO.', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1011, 84, '2423', 'COBRAN�A DE TAXA DE EQUIPAMENTOS DE USO OBRIGAT�RIO NO LOCAL DE ATENDIMENTO.', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1012, 84, '2424', 'COBRAN�A DE TAXA DE OBSERVA��O PARA ATENDIMENTO QUE GEROU UMA INTERNA��O.', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1013, 84, '2501', 'PROCEDIMENTO EM S�RIE INV�LIDO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1014, 84, '2502', 'COBRAN�A DE DUAS AVALIA��ES FISIOTER�PICAS', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1015, 84, '2503', 'COBRAN�A DE PSICOTERAPIA INDIVIDUAL, QUANDO O APLICADO � A COBRAN�A DE PSICOTERAPIA EM GRUPO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1016, 84, '2504', 'QUANTIDADE DE SESS�ES COBRADAS N�O CONDIZEM COM AS ASSINATURAS NO CONTROLE DE TRATAMENTO SERIADO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1017, 84, '2505', 'O C�DIGO COBRADO � DIFERENTE DO C�DIGO AUTORIZADO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1018, 84, '2506', 'A QUANTIDADE DE SESS�ES COBRADAS � DIFERENTE DA QUANTIDADE AUTORIZADA', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1019, 84, '2507', 'O C�DIGO AUTORIZADO EST� INCOMPAT�VEL COM A PRESCRI��O M�DICA SOLICITADA', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1020, 84, '2508', 'COBRAN�A DE SESS�ES SEM O DEVIDO PLANO DE TRATAMENTO E, OU, COM O PRAZO DE PAGAMENTO EXPIRADO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1021, 84, '2509', 'COBRAN�A DO PROCEDIMENTO SERIADO INCOMPAT�VEL COM O QUADRO CL�NICO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1022, 84, '2510', 'COBRAN�A DO PROCEDIMENTO SERIADO EM N�MERO DE SESS�ES ACIMA DA QUANTIDADE ESTABELECIDA', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1023, 84, '2511', 'AUS�NCIA DE EVOLU��O NO PRONTU�RIO M�DICO DO TRATAMENTO SERIADO REALIZADO.', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1024, 84, '2512', 'COBRAN�A DE SESS�ES DE FISIOTERAPIA EM DESACORDO COM AS EVOLU��ES DO PRONTU�RIO M�DICO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1025, 84, '2513', 'COBRAN�A DE TRATAMENTO SERIADO SEM JUSTIFICATIVA CL�NICA/T�CNICA', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1026, 84, '2514', 'SERVI�O N�O CONTRATADO PARA O PRESTADOR', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1027, 84, '2515', 'LOCAL DE ATENDIMENTO INADEQUADO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1028, 84, '2516', 'QUANTIDADE COBRADA DIFERENTE DA REALIZADA', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1029, 84, '2601', 'CODIFICA��O INCORRETA/INADEQUADA DO PROCEDIMENTO.', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1030, 84, '2602', 'COBRAN�A DE HONOR�RIO INCLUSO NO PROCEDIMENTO PRINCIPAL', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1031, 84, '2603', 'COBRAN�A DE HONOR�RIO SEM REGISTRO DA EFETIVA PARTICIPA��O DO PROFISSIONAL', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1032, 84, '2604', 'PROCEDIMENTO PRINCIPAL N�O REQUER EQUIPE M�DICA', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1033, 84, '2605', 'N�O CABE PAGAMENTO DO HONOR�RIO INTEGRAL POR SER A MESMA VIA DE ACESSO CIR�RGICO.', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1034, 84, '2606', 'COBRAN�A DO HONOR�RIO EM LOCAL DE ATENDIMENTO INCORRETO (INEXISTENTE).', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1035, 84, '2607', 'COBRAN�A DE HONOR�RIOS EM DUPLICIDADE.', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1036, 84, '2608', 'COBRAN�A DE CONSULTA INDEVIDA, QUANDO O PROCEDIMENTO PRINCIPAL J� EST� SENDO REMUNERADO.', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1037, 84, '2609', 'LOCAL DE ATENDIMENTO N�O INFORMADO.', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1038, 84, '2610', 'GRAU DE PARTICIPA��O DE AUXILIAR INCOMPAT�VEL COM PROCEDIMENTO COBRADO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1039, 84, '2611', 'COBRAN�A DE ESPECIALISTA N�O JUSTIFICADA NO EVENTO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1040, 84, '2612', 'COBRAN�A INDEVIDA DE EQUIPE "STAND-BY", J� QUE ANGIOPLASTIA SEGUIDA DE CIRURGIA CARD�ACA', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1041, 84, '2613', 'HONOR�RIO M�DICO DO ANESTESISTA J� LIBERADO NO PROCEDIMENTO CIR�RGICO, POIS "ANALGESIA POR DIA SUBSEQUENTE" COBRADA NA MESMA DATA DO EVENTO CIR�RGICO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1042, 84, '2614', 'COBRAN�A DE CADA PARTICIPANTE DA EQUIPE DEVE SER FEITA EM GUIAS DIFERENTES', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1043, 84, '2701', 'PROCEDIMENTO INV�LIDO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1044, 84, '2702', 'COBRAN�A DE EXAME N�O SOLICITADO PELO M�DICO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1045, 84, '2703', 'EXAME SEM REGISTRO DE EXECU��O', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1046, 84, '2704', 'COBRAN�A DE EXAME N�O CORRELACIONADO AO RELAT�RIO ESPEC�FICO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1047, 84, '2705', 'COBRAN�A DE PROCEDIMENTO/EXAME SEM JUSTIFICATIVA PARA REALIZA��O OU COM JUSTIFICATIVA INSUFICIENTE.', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1048, 84, '2706', 'COBRAN�A DE PROCEDIMENTO/EXAME COM DATA DE AUTORIZA��O POSTERIOR � DO ATENDIMENTO.', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1049, 84, '2707', 'EXAME N�O AUTORIZADO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1050, 84, '2708', 'COBRAN�A DE EXAME EM QUANTIDADE INCOMPAT�VEL COM O PROCEDIMENTO/EVOLU��O CL�NICA', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1051, 84, '2709', 'COBRAN�A DE PROCEDIMENTO INCLUSO NO PROCEDIMENTO PRINCIPAL', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1052, 84, '2710', 'COBRAN�A DE EXAME QUE EXIGE AUTORIZA��O PR�VIA', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1053, 84, '2711', 'COBRAN�A DE EXAME COM HIST�RIA CL�NICA/HIP�TESE DIAGN�STICA N�O COMPAT�VEL', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1054, 84, '2712', 'COBRAN�A DE EXAME EM QUANTIDADE ACIMA DA M�XIMA PERMITIDA/AUTORIZADA', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1055, 84, '2713', 'COBRAN�A DE EXAME N�O COMPAT�VEL COM A IDADE.', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1056, 84, '2714', 'COBRAN�A DE EXAME COM AUS�NCIA DE RESULTADO OU LAUDO T�CNICO.', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1057, 84, '2715', 'EXAME REALIZADO PELO MESMO PROFISSIONAL, NA MESMA ESPECIALIDADE, NO PRAZO INFERIOR AO ESTIPULADO SEM JUSTIFICATIVA ADEQUADA.', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1058, 84, '2716', 'EXAME COBRADO N�O CORRESPONDE AO EXAME EXECUTADO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1059, 84, '2717', 'COBRAN�A DE EXAME AMBULATORIAL COM DATA DE AUTORIZA��O POSTERIOR � DO ATENDIMENTO.', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1060, 84, '2718', 'EXAMES N�O JUSTIFICAM CAR�TER DE URG�NCIA', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1061, 84, '2801', 'PACOTE INV�LIDO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1062, 84, '2802', 'PACOTE INCOMPAT�VEL COM O SEXO DO BENEFICI�RIO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1063, 84, '2803', 'IDADE DO BENEFICI�RIO INCOMPAT�VEL COM O PACOTE', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1064, 84, '2804', 'VALOR TOTAL DO PACOTE DIFERENTE DO VALOR PROCESSADO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1065, 84, '2805', 'VALOR DO PACOTE SUPERIOR AO VALOR DOS ITENS', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1066, 84, '2806', 'COBRAN�A DE PACOTE N�O EXECUTADO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1067, 84, '2807', 'COBRAN�A DE PACOTE N�O SOLICITADO PELO M�DICO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1068, 84, '2808', 'PACOTE SEM REGISTRO DE EXECU��O', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1069, 84, '2809', 'COBRAN�A DE PACOTE N�O CORRELACIONADO AO RELAT�RIO ESPEC�FICO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1070, 84, '2810', 'COBRAN�A DE PACOTE SEM JUSTIFICATIVA PARA REALIZA��O OU COM JUSTIFICATIVA INSUFICIENTE.', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1071, 84, '2811', 'COBRAN�A DE PACOTE COM DATA DE AUTORIZA��O POSTERIOR � DO ATENDIMENTO.', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1072, 84, '2812', 'PACOTE N�O AUTORIZADO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1073, 84, '2813', 'COBRAN�A DE PACOTE EM QUANTIDADE INCOMPAT�VEL COM O PROCEDIMENTO/EVOLU��O CL�NICA', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1074, 84, '2814', 'ITENS DE COMPOSI��O DO PACOTE N�O REALIZADOS', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1075, 84, '2815', 'COBRAN�A DO PACOTE EXIGE AUTORIZA��O PR�VIA', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1076, 84, '2816', 'COBRAN�A DE PACOTE COM HIST�RIA CL�NICA/HIP�TESE DIAGN�STICA N�O COMPAT�VEL', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1077, 84, '2817', 'COBRAN�A DE PACOTE EM QUANTIDADE ACIMA DA M�XIMA PERMITIDA/AUTORIZADA', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1078, 84, '2818', 'COBRAN�A DE PACOTE N�O COMPAT�VEL COM A IDADE.', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1079, 84, '2819', 'COBRAN�A DE PACOTE COM AUS�NCIA DE RESULTADO OU LAUDO T�CNICO.', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1080, 84, '2820', 'PACOTE REALIZADO PELO MESMO PROFISSIONAL, NA MESMA ESPECIALIDADE, NO PRAZO INFERIOR AO ESTIPULADO SEM JUSTIFICATIVA ADEQUADA.', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1081, 84, '2821', 'PACOTE COBRADO N�O CORRESPONDE AO EXAME EXECUTADO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1082, 84, '2822', 'COBRAN�A DE PACOTE AMBULATORIAL COM DATA DE AUTORIZA��O POSTERIOR � DO ATENDIMENTO.', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1083, 84, '2901', 'REVIS�O DE GLOSA INV�LIDA', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1084, 84, '2902', 'GLOSA MANTIDA', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1085, 84, '2903', 'PEDIDO DE REVIS�O SEM JUSTIFICATIVA', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1086, 84, '2904', 'MAIS DE UM RECURSO DE GLOSA PARA A MESMA GUIA/PROTOCOLO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1087, 84, '2905', 'A GUIA N�O � DE REVIS�O', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1088, 84, '2906', 'N�MERO DA GUIA INV�LIDO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1089, 84, '2907', 'PRAZO DE 180 DIAS ULTRAPASSADO PARA SOLICITA��O DE REAN�LISE', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1090, 84, '2908', 'SOLICITA��O DE REAN�LISE EFETUADA DE FORMA INCORRETA', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1091, 84, '2909', 'PRAZO PARA SOLICITA��O DE RECURSO DE GLOSA PRESCRITO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1092, 84, '3001', 'PROCEDIMENTO ODONTOL�GICO INV�LIDO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1093, 84, '3002', 'COBRAN�A DE PROCEDIMENTO ODONTOL�GICO QUE EXIGE AUTORIZA��O PR�VIA', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1094, 84, '3003', 'IDADE DO BENEFICI�RIO INCOMPAT�VEL COM O PROCEDIMENTO ODONTOL�GICO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1095, 84, '3004', 'COBRAN�A DE PROCEDIMENTO ODONTOL�GICO EM QUANTIDADE ACIMA DA M�XIMA PERMITIDA/AUTORIZADA', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1096, 84, '3005', 'VALOR TOTAL DO PROCEDIMENTO DIFERENTE DO VALOR PROCESSADO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1097, 84, '3006', 'QUANTIDADE DE PROCEDIMENTO DEVE SER MAIOR QUE ZERO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1098, 84, '3007', 'PROCEDIMENTOS ODONTOL�GICOS DUPLICADOS', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1099, 84, '3008', 'PROCEDIMENTO ODONTOL�GICO INCLUSO NO PROCEDIMENTO PRINCIPAL', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1100, 84, '3009', 'COBRAN�A DE PROCEDIMENTO ODONTOL�GICO N�O EXECUTADO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1101, 84, '3010', 'COBRAN�A DE PROCEDIMENTO N�O SOLICITADO PELO CIRURGI�O-DENTISTA', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1102, 84, '3011', 'PROCEDIMENTO ODONTOL�GICO SEM REGISTRO DE EXECU��O', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1103, 84, '3012', 'COBRAN�A DE PROCEDIMENTO ODONTOL�GICO N�O CORRELACIONADO AO RELAT�RIO ESPEC�FICO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1104, 84, '3013', 'COBRAN�A DE PROCEDIMENTO ODONTOL�GICO SEM JUSTIFICATIVA PARA REALIZA��O OU COM JUSTIFICATIVA INSUFICIENTE.', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1105, 84, '3014', 'COBRAN�A DE PROCEDIMENTO ODONTOL�GICO COM DATA DE AUTORIZA��O POSTERIOR � DO ATENDIMENTO.', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1106, 84, '3015', 'COBRAN�A DE PROCEDIMENTO ODONTOL�GICO COM AUS�NCIA DE RESULTADO OU LAUDO T�CNICO.', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1107, 84, '3016', 'PROCEDIMENTO ODONTOL�GICO REALIZADO, NA MESMA ESPECIALIDADE, NO PRAZO INFERIOR AO ESTIPULADO, SEM JUSTIFICATIVA', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1108, 84, '3017', 'PROCEDIMENTO COBRADO N�O CORRESPONDE A PER�CIA (ESPECIFICAR).', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1109, 84, '3018', 'EVENTO GLOSADO POR AUDITORIA (ESPECIFICAR)', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1110, 84, '3019', 'EVENTO SOB AN�LISE T�CNICA, AGUARDANDO LIBERA��O DE CONFIRMA��O PARA POSTERIOR PAGAMENTO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1111, 84, '3020', 'CONFORME DOCUMENTA��O RADIOGR�FICA ENVIADA, EVENTO REALIZADO INADEQUADAMENTE', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1112, 84, '3021', 'FALHA EM INFORMA��O DE DADOS DE ARCADAS/HEMI-ARCOS', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1113, 84, '3022', 'FALHA EM INFORMA��O DE DADOS DE DENTE INICIAL E/OU FINAL', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1114, 84, '3023', 'FALHA EM INFORMA��O DE DADOS DE FACES DOS DENTES', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1115, 84, '3024', 'EVENTO S� POSS�VEL EM DENTES DEC�DUOS', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1116, 84, '3025', 'EVENTO S� POSS�VEL EM DENTES PERMANENTES', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1117, 84, '3026', 'ERRO NAS INFORMA��ES DE ORDEM DOS DENTES INICIAL E FINAL', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1118, 84, '3027', 'DESACORDO ENTRE O TIPO DE DENTE E O N�MERO DE CANAIS SOLICITADOS', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1119, 84, '3028', 'EVENTO RESTRITO � ESPECIALISTAS', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1120, 84, '3029', 'EVENTO N�O INDICADO PELA AUDITORIA INICIAL', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1121, 84, '3030', 'AUDITORIA FINAL CONSTA QUE A RESTAURA��O FOI REALIZADA EM OUTRO MATERIAL', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1122, 84, '3031', 'RADIOGRAFIA FORA DOS PADR�ES T�CNICOS', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1123, 84, '3032', 'INTERVALO DA �LTIMA MPP INFERIOR A TR�S MESES', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1124, 84, '3033', 'INTERVALO DA �LTIMA MPP INFERIOR A QUATRO MESES', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1125, 84, '3034', 'JUSTIFICATIVA TECNICAMENTE N�O SATISFAT�RIA', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1126, 84, '3035', 'PACIENTE EM TRATAMENTO COM O MESMO PROFISSIONAL', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1127, 84, '3036', 'PACIENTE EM TRATAMENTO COM OUTRO PROFISSIONAL', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1128, 84, '3037', 'PROCEDIMENTO COBRADO N�O � IGUAL AO EXECUTADO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1129, 84, '3038', 'RADIOGRAFIA INICIAL INCONGRUENTE COM A RADIOGRAFIA FINAL', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1130, 84, '3039', 'RADIOGRAFIA N�O CORRESPONDE AO PROCEDIMENTO COBRADO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1131, 84, '3040', 'GLOSA T�CNICA (ESPECIFICAR DETALHADAMENTE)', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1132, 84, '3041', 'AGUARDANDO DOCUMENTA��O DE ORTODONTIA', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1133, 84, '3042', 'AP�S AN�LISE DA RADIOGRAFIA INICIAL VERIFICOU-SE EXODONTIA DE INCLUSO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1134, 84, '3043', 'AP�S AN�LISE DA RADIOGRAFIA INICIAL VERIFICOU-SE EXODONTIA DE SEMI-INCLUSO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1135, 84, '3044', 'AP�S AN�LISE DA RADIOGRAFIA INICIAL VERIFICOU-SE EXODONTIA SIMPLES', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1136, 84, '3045', 'AP�S AN�LISE DA RADIOGRAFIA INICIAL, VERIFICOU-SE EXODONTIA DE FRAGMENTO RADICULAR', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1137, 84, '3046', 'AUDITORIA FINAL CONSTA QUE O PROCEDIMENTO FOI REALIZADO COM OUTRO MATERIAL', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1138, 84, '3047', 'AUS�NCIA DE IMAGEM/FOTO/RADIOGRAFIA/ DIAGN�STICO P�S PROCEDIMENTO ODONTOL�GICO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1139, 84, '3048', 'CANCELAMENTO DO PROCEDIMENTO ODONTOL�GICO POR SOLICITA��O DO BENEFICI�RIO.', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1140, 84, '3049', 'CANCELAMENTO DO PROCEDIMENTO ODONTOL�GICO POR SOLICITA��O DO PRESTADOR.', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1141, 84, '3050', 'COBRAN�A DE URG�NCIA/EMERG�NCIA NA VIG�NCIA DO TRATAMENTO ODONTOL�GICO.', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1142, 84, '3051', 'DOCUMENTA��O EM AN�LISE', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1143, 84, '3052', 'DOCUMENTA��O INCOMPLETA, INCORRETA OU AUSENTE', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1144, 84, '3053', 'ELEMENTOS PODEM SER VISUALIZADOS EM UMA MESMA PEL�CULA.', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1145, 84, '3054', 'IDENTIFICADO CONDUTO(S) N�O OBTURADO(S)', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1146, 84, '3055', 'IDENTIFICADO TRATAMENTO ENDOD�NTICO E N�O RETRATAMENTO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1147, 84, '3056', 'NA AUDITORIA FOI CONSTATADA DIVERG�NCIA NA QUANTIDADE DE FACES RESTAURADAS', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1148, 84, '3057', 'N�O APRESENTA A QUANTIDADE M�NIMA DE ELEMENTOS DENT�RIOS POR SEGMENTO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1149, 84, '3058', 'NECESS�RIA AUDITORIA FINAL', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1150, 84, '3059', 'NECESS�RIA AUDITORIA INICIAL', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1151, 84, '3060', 'NECESS�RIA AUDITORIA INTERMEDI�RIA', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1152, 84, '3061', 'NECESS�RIA AVALIA��O DO ESPECIALISTA', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1153, 84, '3062', 'NECESS�RIO ENVIAR LAUDO OU RELAT�RIO T�CNICO SOBRE O TRATAMENTO SOLICITADO.', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1154, 84, '3063', 'O PLANO DE TRATAMENTO AUTORIZADO SER� CANCELADO DEVIDO � TROCA DE PROFISSIONAL', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1155, 84, '3064', 'PROCEDIMENTO AUTORIZADO APENAS PARA DENTES TRATADOS ENDODONTICAMENTE', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1156, 84, '3065', 'PROCEDIMENTO AUTORIZADO SOMENTE PARA DENTES ANTERIORES', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1157, 84, '3066', 'PROCEDIMENTO EM DESACORDO COM O ANEXO GUIA TRATAMENTO ODONTOL�GICO SITUA��O INICIAL', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1158, 84, '3067', 'RADIOGRAFIA FINAL N�O ENVIADA', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1159, 84, '3068', 'RADIOGRAFIA FINAL SEM DISSOCIA��O DOS CONDUTOS', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1160, 84, '3069', 'RADIOGRAFIA INDICA A NECESSIDADE DE TRATAMENTO ENDODONTICO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1161, 84, '3070', 'RADIOGRAFIA INDICA A PRESEN�A DE RAIZ RESIDUAL NO ALVEOLO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1162, 84, '3071', 'RADIOGRAFIA INDICA AUSENCIA DE N�CLEO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1163, 84, '3072', 'RADIOGRAFIA INDICA CANAL(AIS) N�O OBTURADO(S)', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1164, 84, '3073', 'RADIOGRAFIA INDICA DESVIO DA TRAJETORIA DO CANAL', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1165, 84, '3074', 'RADIOGRAFIA INDICA EXCESSO DE MATERIAL', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1166, 84, '3075', 'RADIOGRAFIA INDICA FALHA NA OBTURA��O DO(S) CONDUTO(S)', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1167, 84, '3076', 'RADIOGRAFIA INDICA FALTA DE ADAPTA��O DA COROA/N�CLEO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1168, 84, '3077', 'RADIOGRAFIA INDICA FALTA DE ADAPTA��O DA COROA/PE�A PROT�TICA', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1169, 84, '3078', 'RADIOGRAFIA INDICA N�CLEO INADEQUADO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1170, 84, '3079', 'RADIOGRAFIA INDICA TRATAMENTO ENDOD�NTICO E N�O RETRATATAMENTO ENDOD�NTICO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1171, 84, '3080', 'RADIOGRAFIA INICIAL E FINAL N�O ENVIADA', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1172, 84, '3081', 'RADIOGRAFIA INICIAL N�O ENVIADA', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1173, 84, '3082', 'RADIOGRAFIA/IMAGEM INDICA FALHA NA RESTAURA��O', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1174, 84, '3083', 'REAVALIAR O PLANO DE TRATAMENTO OBSERVANDO CRIT�RIOS DE INDICA��O, OPORTUNIDADE E VIABILIDADE.', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1175, 84, '3084', 'RELAT�RIO ANALISE T�CNICA SEM CARIMBO/ASSINATURA DO PRESTADOR', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1176, 84, '3085', 'RADIOGRAFIA N�O CORRESPONDE AO PROCEDIMENTO SOLICITADO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1177, 84, '3086', 'TRATAMENTO ODONTOL�GICO N�O CARACTERIZADO COMO URG�NCIA.', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1178, 84, '3087', 'COBRAN�A INDEVIDA DE TAXA ADMINISTRATIVA', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1179, 84, '3088', 'VALOR ACATADO, CONFORME REAJUSTE RETROATIVO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1180, 84, '3089', 'QUANTIDADE DE ITENS INCOMPAT�VEL COM O PER�ODO DE INTERNA��O', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1181, 84, '3090', 'NECESS�RIO ENVIAR AS ETIQUETAS E SELOS HEMOTER�PICOS DO MATERIAL UTILIZADO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1182, 84, '3091', 'COBRAN�A FORA DO PRAZO ESTIPULADO NO CONTRATO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1183, 84, '3092', 'VALOR ACATADO POR GLOSA REALIZADA INDEVIDAMENTE, AP�S AVALIA��O DO RECURSO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1184, 84, '3093', 'VALOR ACATADO POR AUTORIZA��O ESPECIAL', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1185, 84, '3094', 'VALOR DA TAXA ADMINISTRATIVA ALTERADO EM RAZ�O DE GLOSAS', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1186, 84, '3095', 'RECURSO DE GLOSA ACATADO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1187, 84, '3096', 'ATENDIMENTO N�O CONFIRMADO PELO BENEFICI�RIO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1188, 84, '3097', 'TIPO DE ATENDIMENTO INCOMPAT�VEL COM A SEGMENTA��O ASSISTENCIAL CONTRATADA', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1189, 84, '3098', 'O PRESTADOR POSSUI PACOTE CONTRATADO PARA ESTE PROCEDIMENTO. VERIFIQUE O C�DIGO CORRESPONDENTE', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1190, 84, '3100', 'PARA LIBERAR ESTE ACESSO, ENTRE EM CONTATO COM A OPERADORA E SOLICITE O CADASTRAMENTO DO SEU C�DIGO DE ORIGEM', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1191, 84, '3101', 'O PROCEDIMENTO SOLICITADO � DE EXECU��O �NICA E J� FOI REALIZADO PELO BENEFICI�RIO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1192, 84, '3102', '� NECESS�RIO TER UM PROCEDIMENTO RELACIONADO � SOLICITA��O', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1193, 84, '3103', 'SOLICITA��O DE AUTORIZA��O FORA DO PRAZO ACORDADO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1194, 84, '3104', 'RECUSADO, CONFORME JUNTA M�DICA/ODONTOL�GICA', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1195, 84, '3105', 'ITEM COM UTILIZA��O SUSPENSA PELO �RG�O COMPETENTE', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1196, 84, '3106', 'REGISTRO ANVISA INV�LIDO OU N�O INFORMADO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1197, 84, '3107', 'ITEM CATEGORIZADO COMO N�O DESCART�VEL', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1198, 84, '3108', 'ITEM INCLUSO NO PACOTE NEGOCIADO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1199, 84, '3109', 'PROCEDIMENTO SOLICITADO N�O AUTORIZADO POR N�O CONSTAR DO ROL DE PROCEDIMENTOS E EVENTOS EM SA�DE DA ANS', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1200, 84, '3110', 'BLOQUEIO JUDICIAL', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1201, 84, '3111', 'CAMPO CONDICIONADO N�O PREENCHIDO OU INCORRETO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1202, 84, '3112', 'DESCONTO DE COPARTICIPA��O/FRANQUIA CONFORME CONTRATO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1203, 84, '3113', 'NECESS�RIO ENVIO DE RADIOGRAFIA PERIAPICAL DA REGI�O', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1204, 84, '3114', 'NECESS�RIO ENVIO DE RADIOGRAFIA INTERPROXIMAL DA REGI�O', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1205, 84, '3115', 'NECESS�RIO ENVIO DE RADIOGRAFIA OCLUSAL DA REGI�O', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1206, 84, '3116', 'REALIZA��O DE PROCEDIMENTO COM NECESSIDADE EST�TICA', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1207, 84, '3117', 'PROCEDIMENTO ODONTOL�GICO COM INDICA��O T�CNICA EM PROGN�STICO DESFAVOR�VEL', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1208, 84, '3118', 'NECESS�RIO ENVIAR TERMO DE CONSENTIMENTO INFORMADO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1209, 84, '3119', 'NECESS�RIO ENVIAR TERMO DE RESPONSABILIDADE PROFISSIONAL', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1210, 84, '3120', 'NECESS�RIO O ENVIO DO PEDIDO DO PROFISSIONAL SOLICITANTE', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1211, 84, '3121', 'ITEM AUTORIZADO E AINDA N�O INDENIZADO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1212, 84, '3122', 'SOLICITA��O DE REEMBOLSO EM PLANO SEM DIREITO � LIVRE ESCOLHA', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1213, 84, '3123', 'ITEM PARA A MESMA FINALIDADE J� AUTORIZADO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1214, 84, '3124', 'RADIOGRAFIA SUGERE INDICA��O DE EXODONTIA', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1215, 84, '3125', 'RADIOGRAFIA SUGERE INDICA��O DE RETRATAMENTO ENDODONTICO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1216, 84, '3126', 'COBRAN�A DE ITEM ANTERIOR � DATA DE REALIZA��O', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1217, 84, '3127', 'IMAGEM SUGERE ALTERA��O PATOL�GICA', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1218, 84, '3128', 'IMAGEM SUGERE PRESEN�A DE ARTEFATO DE IMAGEM', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1219, 84, '3129', 'IMAGEM SUGERE PRESEN�A DE CORPO ESTRANHO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1220, 84, '3130', 'IMAGEM SUGERE IMPLANTE EM PROCESSO DE OSSEOINTEGRA��O', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1221, 84, '3131', 'ENVIAR PLANO DE TRATAMENTO ORTOD�NTICO INICIAL', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1222, 84, '3132', 'ENVIAR PLANO DE TRATAMENTO ORTOD�NTICO INTERMEDI�RIO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1223, 84, '3133', 'TRATAMENTO ORTOD�NTICO CONCLU�DO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1224, 84, '3134', 'TRATAMENTO ORTOD�NTICO EM FASE DE CONTEN��O', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1225, 84, '3135', 'PROFISSIONAL INFORMADO PARA REEMBOLSO PERTENCE A REDE DA OPERADORA', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1226, 84, '3136', 'PROCEDIMENTO OU ITEM ASSISTENCIAL AUTORIZADO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1227, 84, '3137', 'PROCEDIMENTO PREV� COPARTICIPA��O/FRANQUIA CONFORME CONTRATO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1228, 84, '3138', 'CONDI��O CL�NICA INCOMPAT�VEL COM A SOLICITA��O', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1229, 84, '3139', 'TRATAMENTO ORTODONTICO SUSPENSO A PEDIDO DO DENTISTA', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1230, 84, '3140', 'ABANDONO DE TRATAMENTO PELO BENEFICI�RIO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1231, 84, '3141', 'BENEFICI�RIO N�O POSSUI COBERTURA PARA ASSIST�NCIA AMBULATORIAL', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1232, 84, '3142', 'ITEM N�O CONTRATADO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1233, 84, '3143', 'VALOR ACATADO POR DECIS�O JUDICIAL /LIMINAR', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1234, 84, '3144', 'N�O � NECESS�RIA AUTORIZA��O PR�VIA', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1235, 84, '3145', 'N�O AUTORIZADO POR MOTIVO T�CNICO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1236, 84, '3146', 'PRODUTO CONTRATADO N�O ADAPTADO � LEI 9.656/98, SEM COBERTURA CONTRATUAL PARA O ITEM SOLICITADO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1237, 84, '3147', 'MATERIAL PASS�VEL DE REPROCESSAMENTO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1238, 84, '3148', 'TIPO DE TRANSA��O INV�LIDO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1239, 84, '3149', 'INDICADOR DE ENVIO EM PAPEL INV�LIDO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1240, 84, '3150', 'C�DIGO DA TABELA INV�LIDO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1241, 84, '3151', 'O ESTABELECIMENTO DE SA�DE PARA O QUAL FOI SOLICITADA A INFORMA��O SOBRE PARTOS N�O POSSU�A V�NCULO COM A OPERADORA NO PER�ODO A QUE SE REFERE A INFORMA��O', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1242, 84, '3152', 'O PROFISSIONAL PARA O QUAL FOI SOLICITADA A INFORMA��O SOBRE PARTOS N�O POSSU�A V�NCULO COM A OPERADORA NO PER�ODO A QUE SE REFERE A INFORMA��O', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1243, 84, '3153', 'O ESTABELECIMENTO DE SA�DE PARA O QUAL FOI SOLICITADA A INFORMA��O SOBRE PARTOS N�O POSSUI V�NCULO COM A OPERADORA', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1244, 84, '3154', 'O PROFISSIONAL PARA O QUAL FOI SOLICITADA A INFORMA��O SOBRE PARTOS N�O POSSUI V�NCULO COM A OPERADORA', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1245, 84, '3155', 'PARTOGRAMA OU RELAT�RIO M�DICO N�O DISPON�VEL PARA CONSULTA DA OPERADORA', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1246, 84, '5001', 'MENSAGEM ELETR�NICA FORA DO PADR�O TISS', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1247, 84, '5002', 'N�O FOI POSS�VEL VALIDAR O ARQUIVO XML', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1248, 84, '5003', 'ENDERE�O DO REMETENTE INV�LIDO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1249, 84, '5004', 'ENDERE�O DO DESTINAT�RIO INV�LIDO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1250, 84, '5005', 'REMETENTE N�O IDENTIFICADO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1251, 84, '5006', 'DESTINAT�RIO N�O IDENTIFICADO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1252, 84, '5007', 'MENSAGEM INCONSISTENTE OU INCOMPLETA', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1253, 84, '5008', 'ESPA�O RESERVADO PARA A CAIXA DE SA�DA INSUFICIENTE', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1254, 84, '5009', 'ESPA�O RESERVADO PARA A CAIXA DE ENTRADA INSUFICIENTE', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1255, 84, '5010', 'ENVIO DE MENSAGEM N�O FOI TERMINADO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1256, 84, '5011', 'ENVIO DE MENSAGEM FINALIZADA', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1257, 84, '5012', 'RECEBIMENTO DE MENSAGEM N�O FINALIZADO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1258, 84, '5013', 'RECEBIMENTO DE MENSAGEM FINALIZADA', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1259, 84, '5014', 'C�DIGO HASH INV�LIDO. MENSAGEM PODE ESTAR CORROMPIDA.', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1260, 84, '5015', 'N�MERO DE GUIAS/DEMONSTRATIVOS DENTRO DA MENSAGEM SUPERIOR AO TAMANHO M�XIMO PERMITIDO.', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1261, 84, '5016', 'SEM NENHUMA OCORRENCIA DE MOVIMENTO NA COMPETENCIA PARA ENVIO A ANS', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1262, 84, '5017', 'ARQUIVO PROCESSADO PELA ANS', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1263, 84, '5018', 'CERTIFICADO DIGITAL INV�LIDO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1264, 84, '5019', 'CERTIFICADO DIGITAL VENCIDO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1265, 84, '5020', 'CERTIFICADO DIGITAL REVOGADO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1266, 84, '5021', 'CADEIA DE CERTIFICA��O INV�LIDA', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1267, 84, '5022', 'ASSINATURA DIGITAL N�O CONFERE', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1268, 84, '5023', 'COMPET�NCIA N�O EST� LIBERADA PARA ENVIO DE DADOS', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1269, 84, '5024', 'OPERADORA INATIVA NA COMPET�NCIA DOS DADOS', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1270, 84, '5025', 'DATA DE REGISTRO DA TRANSA��O INV�LIDA', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1271, 84, '5026', 'HORA DE REGISTRO DA TRANSA��O INV�LIDA', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1272, 84, '5027', 'REGISTRO ANS DA OPERADORA INV�LIDO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1273, 84, '5028', 'VERS�O DO PADR�O INV�LIDA', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1274, 84, '5029', 'INDICADOR INV�LIDO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1275, 84, '5030', 'C�DIGO DO MUN�CIPIO INV�LIDO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1276, 84, '5031', 'CAR�TER DE ATENDIMENTO INV�LIDO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1277, 84, '5032', 'INDICADOR DE REC�M-NATO INV�LIDO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1278, 84, '5033', 'MOTIVO DE ENCERRAMENTO INV�LIDO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1279, 84, '5034', 'VALOR N�O INFORMADO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1280, 84, '5035', 'C�DIGO DA TABELA DE REFER�NCIA N�O INFORMADO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1281, 84, '5036', 'C�DIGO DO GRUPO DO PROCEDIMENTO INV�LIDO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1282, 84, '5037', 'C�DIGO DO DENTE INV�LIDO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1283, 84, '5038', 'C�DIGO DA REGI�O DA BOCA INV�LIDO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1284, 84, '5039', 'C�DIGO DA FACE DO DENTE INV�LIDO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1285, 84, '5040', 'VALOR DEVE SER MAIOR QUE ZERO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1286, 84, '5041', 'QUANTIDADE N�O INFORMADA', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1287, 84, '5042', 'VALOR INFORMADO DA GUIA DIFERENTE DO SOMAT�RIO DO VALOR INFORMADO DOS ITENS', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1288, 84, '5043', 'MOTIVO INV�LIDO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1289, 84, '5044', 'J� EXISTEM INFORMA��ES NA ANS PARA A COMPET�NCIA INFORMADA', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1290, 84, '5045', 'COMPETENCIA ANTERIOR N�O ENVIADA', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1291, 84, '5046', 'COMPETENCIA INV�LIDA', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1292, 84, '5047', 'N�MERO DO LOTE N�O INFORMADO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1293, 84, '5048', 'DATA DE NASCIMENTO DO BENEFICI�RIO INV�LIDA', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1294, 84, '5049', 'VALOR TOTAL MENOR QUE ZERO NA GUIA', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1295, 84, '5050', 'VALOR INFORMADO INV�LIDO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1296, 84, '5051', 'COMPETENCIA DO ARQUIVO DIFERENTE DA COMPETENCIA DA DATA DE PROCESSAMENTO DO LAN�AMENTO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1297, 84, '5052', 'IDENTIFICADOR INEXISTENTE', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1298, 84, '5053', 'IDENTIFICADOR J� INFORMADO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1299, 84, '5054', 'IDENTIFICADOR N�O ENCONTRADO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1300, 84, '5055', 'IDENTIFICADOR J� INFORMADO NA COMPET�NCIA', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1301, 84, '5056', 'IDENTIFICADOR N�O INFORMADO NA COMPET�NCIA', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1302, 84, '5057', 'GUIA DE CONSULTA COM MAIS DE UM PROCEDIMENTO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1303, 84, '5058', 'PROCEDIMENTO INCOMPAT�VEL COM O TIPO DE GUIA', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1304, 84, '5059', 'EXCLUS�O INV�LIDA - EXISTEM LAN�AMENTOS VINCULADOS A ESTA FORMA DE CONTRATA��O', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1305, 84, '5060', 'VALOR TOTAL PAGO DIFERENTE DA SOMA DAS PARCELAS PAGAS NO LAN�AMENTO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (697, 84, '1001', 'N�MERO DA CARTEIRA INV�LIDO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (698, 84, '1002', 'N�MERO DO CART�O NACIONAL DE SA�DE INV�LIDO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (699, 84, '1003', 'A ADMISS�O DO BENEFICI�RIO NO PRESTADOR OCORREU ANTES DA INCLUS�O DO BENEFICI�RIO NA OPERADORA', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (700, 84, '1004', 'SOLICITA��O ANTERIOR � INCLUS�O DO BENEFICI�RIO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (701, 84, '1005', 'ATENDIMENTO ANTERIOR � INCLUS�O DO BENEFICI�RIO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (702, 84, '1006', 'ATENDIMENTO AP�S O DESLIGAMENTO DO BENEFICI�RIO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (703, 84, '1007', 'ATENDIMENTO DENTRO DA CAR�NCIA DO BENEFICI�RIO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (704, 84, '1008', 'ASSINATURA DIVERGENTE', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (705, 84, '1009', 'BENEFICI�RIO COM PAGAMENTO EM ABERTO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (706, 84, '1010', 'ASSINATURA DO TITULAR / RESPONS�VEL INEXISTENTE', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (707, 84, '1011', 'IDENTIFICA��O DO BENEFICI�RIO N�O CONSISTENTE', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (708, 84, '1012', 'SERVI�O PROFISSIONAL HOSPITALAR N�O � COBERTO PELO PLANO DO BENEFICI�RIO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (709, 84, '1013', 'CADASTRO DO BENEFICI�RIO COM PROBLEMAS', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (710, 84, '1014', 'BENEFICI�RIO COM DATA DE EXCLUS�O', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (711, 84, '1015', 'IDADE DO BENEFICI�RIO ACIMA IDADE LIMITE', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (712, 84, '1016', 'BENEFICI�RIO COM ATENDIMENTO SUSPENSO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (713, 84, '1017', 'DATA VALIDADE DA CARTEIRA VENCIDA', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (714, 84, '1018', 'EMPRESA DO BENEFICI�RIO SUSPENSA / EXCLU�DA', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (715, 84, '1019', 'FAM�LIA DO BENEFICI�RIO COM ATENDIMENTO SUSPENSO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (716, 84, '1020', 'VIA DE CART�O DO BENEFICI�RIO CANCELADA', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (717, 84, '1021', 'VIA DE CART�O DO BENEFICI�RIO N�O LIBERADA', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (718, 84, '1022', 'VIA DE CART�O DO BENEFICI�RIO N�O COMPAT�VEL', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (719, 84, '1023', 'NOME DO TITULAR INV�LIDO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (720, 84, '1024', 'PLANO N�O EXISTENTE', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (721, 84, '1025', 'BENEFICI�RIO N�O POSSUI COBERTURA PARA ASSIST�NCIA ODONTOL�GICA', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (722, 84, '1101', 'QUANTIDADE DE GUIAS INFORMADAS NO PROTOCOLO DIFERENTE DAS CADASTRADAS', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (723, 84, '1102', 'PROTOCOLO � DE RE-APRESENTA��O', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (724, 84, '1103', 'PROTOCOLO N�O � DE REAPRESENTA��O', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (725, 84, '1104', 'VALOR TOTAL DO PROTOCOLO DIFERENTE DO VALOR TOTAL DAS GUIAS', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (726, 84, '1201', 'ATENDIMENTO FORA DA VIG�NCIA DO CONTRATO COM O CREDENCIADO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (727, 84, '1202', 'N�MERO DO CNES INV�LIDO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (728, 84, '1203', 'C�DIGO PRESTADOR INV�LIDO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (729, 84, '1204', 'ADMISS�O ANTERIOR � INCLUS�O DO CREDENCIADO NA REDE', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (730, 84, '1205', 'ADMISS�O AP�S O DESLIGAMENTO DO CREDENCIADO DA REDE', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (731, 84, '1206', 'CPF / CNPJ INV�LIDO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (732, 84, '1207', 'CREDENCIADO N�O PERTENCE � REDE CREDENCIADA', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (733, 84, '1208', 'SOLICITA��O ANTERIOR � INCLUS�O DO CREDENCIADO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (734, 84, '1209', 'SOLICITA��O AP�S O DESLIGAMENTO DO CREDENCIADO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (735, 84, '1210', 'SOLICITANTE CREDENCIADO N�O CADASTRADO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (736, 84, '1211', 'ASSINATURA / CARIMBO DO CREDENCIADO INEXISTENTE', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (737, 84, '1212', 'ATENDIMENTO / REFER�NCIA FORA DA VIG�NCIA DO CONTRATO DO PRESTADOR', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (738, 84, '1213', 'CBO (ESPECIALIDADE) INV�LIDO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (739, 84, '1214', 'CREDENCIADO N�O HABILITADO A REALIZAR O PROCEDIMENTO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (740, 84, '1215', 'CREDENCIADO FORA DA ABRANG�NCIA GEOGR�FICA DO PLANO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (741, 84, '1216', 'ESPECIALIDADE N�O CADASTRADA', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (742, 84, '1217', 'ESPECIALIDADE N�O CADASTRADA PARA O PRESTADOR', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (743, 84, '1218', 'C�DIGO DE PRESTADOR IMCOMPATIVEL COM PROCEDIMENTO / EXAME COBRADO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (744, 84, '1301', 'TIPO GUIA INV�LIDO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (745, 84, '1302', 'C�DIGO TIPO GUIA PRINCIPAL E N�MERO GUIAS INCOMPAT�VEIS', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (746, 84, '1303', 'N�O EXISTE O N�MERO GUIA PRINCIPAL INFORMADO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (747, 84, '1304', 'COBRAN�A EM GUIA INDEVIDA', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (748, 84, '1305', 'ITEM PAGO EM OUTRA GUIA', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (749, 84, '1306', 'N�O EXISTE N�MERO GUIA PRINCIPAL E/OU C�DIGO GUIA PRINCIPAL', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (750, 84, '1307', 'N�MERO DA GUIA INV�LIDO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (751, 84, '1308', 'GUIA J� APRESENTADA', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (752, 84, '1309', 'PROCEDIMENTO CONTRATADO N�O EST� DE ACORDO COM O TIPO DE GUIA UTILIZADO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (753, 84, '1310', 'SERVI�O DO TIPO CIR�RGICO E INVASIVO. EQUIPE M�DICA N�O INFORMADA NA GUIA', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (754, 84, '1311', 'PRESTADOR EXECUTANTE N�O INFORMADO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (755, 84, '1312', 'PRESTADOR CONTRATADO N�O INFORMADO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (756, 84, '1313', 'GUIA COM RASURA', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (757, 84, '1314', 'GUIA SEM ASSINATURA E/OU CARIMBO DO CREDENCIADO.', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (758, 84, '1315', 'GUIA SEM DATA DO ATO CIR�RGICO.', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (759, 84, '1316', 'GUIA COM LOCAL DE ATENDIMENTO PREENCHIDO INCORRETAMENTE.', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (760, 84, '1317', 'GUIA SEM DATA DO ATENDIMENTO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (761, 84, '1318', 'GUIA COM C�DIGO DE SERVI�O PREENCHIDO INCORRETAMENTE.', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (762, 84, '1319', 'GUIA SEM ASSINATURA DO ASSISTIDO.', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (763, 84, '1320', 'IDENTIFICA��O DO ASSISTIDO INCOMPLETA', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (764, 84, '1321', 'VALIDADE DA GUIA EXPIRADA', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (765, 84, '1322', 'COMPROVANTE PRESENCIAL OU GTO N�O ENVIADO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (766, 84, '1323', 'DATA PREENCHIDA INCORRETAMENTE', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (767, 84, '1401', 'ACOMODA��O N�O AUTORIZADA', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (768, 84, '1402', 'PROCEDIMENTO N�O AUTORIZADO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (769, 84, '1403', 'N�O EXISTE INFORMA��O SOBRE A SENHA DE AUTORIZA��O DO PROCEDIMENTO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (770, 84, '1404', 'N�O EXISTE GUIA DE AUTORIZA��O RELACIONADA', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (771, 84, '1405', 'DATA DE VALIDADE DA SENHA � ANTERIOR A DATA DO ATENDIMENTO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (772, 84, '1406', 'N�MERO DA SENHA INFORMADO DIFERENTE DO LIBERADO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (773, 84, '1407', 'SERVI�O SOLICITADO N�O POSSUI COBERTURA', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (774, 84, '1408', 'QUANTIDADE SERVI�O SOLICITADA ACIMA DA AUTORIZADA', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (775, 84, '1409', 'QUANTIDADE SERVI�O SOLICITADA ACIMA COBERTA', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (776, 84, '1410', 'SERVI�O SOLICITADO EM CAR�NCIA', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (777, 84, '1411', 'SOLICITANTE N�O INFORMADO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (778, 84, '1412', 'PROBLEMAS NO SISTEMA AUTORIZADOR', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (779, 84, '1413', 'ACOMODA��O N�O POSSUI COBERTURA', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (780, 84, '1414', 'DATA DE VALIDADE DA SENHA EXPIRADA', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (781, 84, '1415', 'PROCEDIMENTO N�O AUTORIZADO PARA O BENEFICI�RIO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (782, 84, '1416', 'SOLICITANTE N�O CADASTRADO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (783, 84, '1417', 'SOLICITANTE N�O HABILITADO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (784, 84, '1418', 'SOLICITANTE SUSPENSO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (785, 84, '1419', 'SERVI�O SOLICITADO J� AUTORIZADO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (786, 84, '1420', 'SERVI�O SOLICITADO FORA DA COBERTURA', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (787, 84, '1421', 'SERVI�O SOLICITADO � DE PR�-EXIST�NCIA', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (788, 84, '1422', 'ESPECIALIDADE N�O CADASTRADA PARA O SOLICITANTE', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (789, 84, '1423', 'QUANTIDADE SOLICITADA ACIMA DA QUANTIDADE PERMITIDA', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (790, 84, '1424', 'QUANTIDADE AUTORIZADA ACIMA DA QUANTIDADE PERMITIDA', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (791, 84, '1425', 'NECESSITA PR�-AUTORIZA��O DA EMPRESA', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (792, 84, '1426', 'N�O AUTORIZADO PELA AUDITORIA', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (793, 84, '1427', 'NECESSIDADE DE AUDITORIA M�DICA', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (794, 84, '1428', 'FALTA DE AUTORIZA��O DA EMPRESA DE CONECTIVIDADE', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (795, 84, '1429', 'CBO-S (ESPECIALIDADE) N�O AUTORIZADO A REALIZAR O SERVI�O', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (796, 84, '1430', 'PROCEDIMENTO ODONTOL�GICO N�O AUTORIZADO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (797, 84, '1431', 'PROCEDIMENTO N�O AUTORIZADO NA FACE SOLICITADA', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (798, 84, '1432', 'PROCEDIMENTO N�O AUTORIZADO PARA DENTE/REGI�O SOLICITADA', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (799, 84, '1433', 'PROCEDIMENTO N�O AUTORIZADO, DENTE AUSENTE', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (800, 84, '1434', 'COBRAN�A DE CONTA DE CTI NEONATAL NA SENHA DO PARTO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (801, 84, '1435', 'VIG�NCIA DO ACORDO POSTERIOR � DATA DE REALIZA��O DO PROCEDIMENTO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (802, 84, '1436', 'CANCELAMENTO DO ACORDO ANTERIOR � DATA DE REALIZA��O DO PROCEDIMENTO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (803, 84, '1437', 'SENHA DE AUTORIZA��O CANCELADA', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (804, 84, '1438', 'PROCEDIMENTO SOLICITADO N�O AUTORIZADO POR N�O ATENDER A DIRETRIZ DE UTILIZA��O (DUT) DO ROL DE PROCEDIMENTOS E EVENTOS EM SA�DE DA ANS', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (805, 84, '1501', 'TEMPO DE EVOLU��O DA DOEN�A INV�LIDO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (806, 84, '1502', 'TIPO DE DOEN�A INV�LIDO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (807, 84, '1503', 'INDICADOR DE ACIDENTE INV�LIDO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (808, 84, '1504', 'CAR�TER DE INTERNA��O INV�LIDO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (809, 84, '1505', 'REGIME DA INTERNA��O INV�LIDO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (810, 84, '1506', 'TIPO DE INTERNA��O INV�LIDO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (811, 84, '1507', 'URG�NCIA/EMERG�NCIA N�O APLIC�VEL', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (812, 84, '1508', 'C�DIGO CID N�O INFORMADO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (813, 84, '1509', 'C�DIGO CID INV�LIDO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (814, 84, '1601', 'REINCID�NCIA NO ATENDIMENTO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (815, 84, '1602', 'TIPO DE ATENDIMENTO INV�LIDO OU N�O INFORMADO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (816, 84, '1603', 'TIPO DE CONSULTA INV�LIDO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (817, 84, '1604', 'TIPO DE SA�DA INV�LIDO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (818, 84, '1605', 'INTERVEN��O ANTERIOR A ADMISS�O', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (819, 84, '1606', 'FINAL DA INTERVEN��O ANTERIOR AO IN�CIO DA INTERVEN��O', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (820, 84, '1607', 'ALTA HOSPITALAR ANTERIOR AO FINAL DA INTERVEN��O', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (821, 84, '1608', 'ALTA ANTERIOR � DATA DE INTERNA��O', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (822, 84, '1609', 'MOTIVO SA�DA INV�LIDO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (823, 84, '1610', '�BITO MULHER INV�LIDO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (824, 84, '1611', 'INTERVEN��O ANTERIOR A INTERNA��O', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (825, 84, '1612', 'SERVI�O N�O PODE SER REALIZADO NO LOCAL ESPECIFICADO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (826, 84, '1613', 'CONSULTA N�O AUTORIZADA', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (827, 84, '1614', 'SERVI�O AMBULATORIAL N�O AUTORIZADO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (828, 84, '1615', 'INTERNA��O N�O AUTORIZADA', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (829, 84, '1701', 'COBRAN�A FORA DO PRAZO DE VALIDADE', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (830, 84, '1702', 'COBRAN�A DE PROCEDIMENTO EM DUPLICIDADE', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (831, 84, '1703', 'HOR�RIO DO ATENDIMENTO N�O EST� NA FAIXA DE URG�NCIA/EMERG�NCIA', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (832, 84, '1704', 'VALOR COBRADO SUPERIOR AO ACORDADO EM PACOTE', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (833, 84, '1705', 'VALOR APRESENTADO A MAIOR', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (834, 84, '1706', 'VALOR APRESENTADO A MENOR', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (835, 84, '1707', 'N�O EXISTE INFORMA��O SOBRE A TABELA QUE SER� UTILIZADA NA VALORA��O. VERIFIQUE O CONTRATO DO PRESTADOR', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (836, 84, '1708', 'N�O EXISTE VALOR PARA O PROCEDIMENTO REALIZADO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (837, 84, '1709', 'FALTA PRESCRI��O M�DICA', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (838, 84, '1710', 'FALTA VISTO DA ENFERMAGEM', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (839, 84, '1711', 'PROCEDIMENTO PERTENCE A UM PACOTE ACORDADO E J� COBRADO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (840, 84, '1712', 'ASSINATURA DO M�DICO RESPONS�VEL PELO EXAME INEXISTENTE', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (841, 84, '1713', 'FATURAMENTO INV�LIDO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (842, 84, '1714', 'VALOR DO SERVI�O SUPERIOR AO VALOR DE TABELA', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (843, 84, '1715', 'VALOR DO SERVI�O INFERIOR AO VALOR DE TABELA', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (844, 84, '1716', 'PERCENTUAL DE REDU��O/ACR�SCIMO FORA DOS VALORES DEFINIDOS EM TABELA', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (845, 84, '1717', 'PAGO CONFORME RELAT�RIO DE AUDITORIA EXTERNA - CONTA INICIAL', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (846, 84, '1718', 'REAN�LISE NEGADA, PAGO CONFORME RELAT�RIO AUDITORIA', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (847, 84, '1719', 'REAN�LISE NEGADA, AN�LISE CONFORME TABELA ACORDADA', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (848, 84, '1720', 'LIBERADOS 150% DE V�DEO, SEM COBERTURA PARA ADICIONAL DE ACOMODA��O', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (849, 84, '1721', 'C�DIGO COBRADO SUBSTITU�DO PELO C�DIGO PAGO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (850, 84, '1722', 'PAGO CONFORME NEGOCIA��O', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (851, 84, '1723', 'ADICIONAL DE URG�NCIA N�O PREVISTO PARA ATENDIMENTO CL�NICO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (852, 84, '1724', 'VISITA M�DICA COBRADA PELA EQUIPE CIR�RGICA INCLU�DA NO PER�ODO DE 10 DIAS AP�S REALIZA��O DO PROCEDIMENTO CIR�RGICO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (853, 84, '1725', 'VALOR PAGO A MAIOR REFERENTE � TAXA ADMINISTRATIVA', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (854, 84, '1726', 'VALOR APRESENTADO A MAIOR - PLANO INDIVIDUAL', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (855, 84, '1727', 'PAGO VALOR COMPATIVEL COM O PROCEDIMENTO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (856, 84, '1728', 'COBRAN�A DE MATERIAL INCLUSO NO PROCEDIMENTO / EXAME REALIZADO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (857, 84, '1729', 'COBRAN�A DE MATERIAL COM VALOR ACIMA DO PERMITIDO PARA PROCEDIMENTO/EXAME REALIZADO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (858, 84, '1730', 'FILME INCLUSO NO EXAME REALIZADO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (859, 84, '1731', 'TAXA INCOMPATIVEL PARA ATENDIMENTO AMBULATORIAL', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (860, 84, '1732', 'QT COM DATA DE EVENTO DIVERGENTE DA LIBERADA', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (861, 84, '1733', 'RECUPERA��O DE VALORES POR PAGAMENTO INDEVIDO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (862, 84, '1734', 'COBRADO CONTA ABERTA, PAGO O PACOTE CONFORME NEGOCIA��O', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (863, 84, '1735', 'COBRAN�A DE PACOTE N�O NEGOCIADO COM O PRESTADOR', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (864, 84, '1736', 'CONTA AGUARDANDO NEGOCIA��O PARA PAGAMENTO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (865, 84, '1737', 'DIFEREN�A DEVE SER COBRADA DO BENEFICI�RIO PELO PRESTADOR COMO FRANQUIA', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (866, 84, '1738', 'DOCUMENTO FISCAL N�O ENVIADO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (867, 84, '1739', 'DUPLICIDADE DE CONTA DEVIDO A PERIODO COBRADO J� EFETUADO EM OUTRA PARCIAL', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (868, 84, '1740', 'ESTORNO DO VALOR DE PROCEDIMENTO PAGO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (869, 84, '1741', 'HONOR�RIO OU PROCEDIMENTO J� PAGO A OUTRO PRESTADOR', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (870, 84, '1742', 'HONOR�RIO OU PROCEDIMENTO J� PAGO POR REEMBOLSO AO BENEFICI�RIO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (871, 84, '1743', 'N�O H� NEGOCIA��O PARA COBRAN�A DO KIT, DISCRIMINAR POR ITENS', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (872, 84, '1744', 'NEGOCIA��O DIFERENCIADA DEVIDO A LIMINAR', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (873, 84, '1745', 'PAGAMENTO DA EQUIPE CONFORME RELAT�RIO DO CIRURGI�O', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (874, 84, '1746', 'PERCENTUAL DE ACR�SCIMO DIFERENTE DO NEGOCIADO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (875, 84, '1747', 'PLANO DO BENEFICI�RIO E O TIPO DE ACOMODA��O N�O PERMITEM ACR�SCIMO DE HONOR�RIOS', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (876, 84, '1748', 'PROCEDIMENTO N�O CARACTERIZA URG�NCIA/EM�RGENCIA', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (877, 84, '1749', 'RELAT�RIO DE AUDITORIA N�O ENVIADO NA CONTA.', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (878, 84, '1801', 'PROCEDIMENTO INV�LIDO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (879, 84, '1802', 'PROCEDIMENTO INCOMPAT�VEL COM O SEXO DO BENEFICI�RIO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (880, 84, '1803', 'IDADE DO BENEFICI�RIO INCOMPAT�VEL COM O PROCEDIMENTO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (881, 84, '1804', 'N�MERO DE DIAS LIBERADOS / SESS�ES AUTORIZADAS N�O INFORMADAS', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (882, 84, '1805', 'VALOR TOTAL DO PROCEDIMENTO DIFERENTE DO VALOR PROCESSADO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (883, 84, '1806', 'QUANTIDADE DE PROCEDIMENTO DEVE SER MAIOR QUE ZERO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (884, 84, '1807', 'PROCEDIMENTOS M�DICOS DUPLICADOS', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (885, 84, '1808', 'PROCEDIMENTO N�O CONFORME COM CID', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (886, 84, '1809', 'COBRAN�A DE PROCEDIMENTO N�O EXECUTADO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (887, 84, '1810', 'COBRAN�A DE PROCEDIMENTO N�O SOLICITADO PELO M�DICO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (888, 84, '1811', 'PROCEDIMENTO SEM REGISTRO DE EXECU��O', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (889, 84, '1812', 'COBRAN�A DE PROCEDIMENTO N�O CORRELACIONADO AO RELAT�RIO ESPEC�FICO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (890, 84, '1813', 'COBRAN�A DE PROCEDIMENTO SEM JUSTIFICATIVA PARA REALIZA��O OU COM JUSTIFICATIVA INSUFICIENTE.', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (891, 84, '1814', 'COBRAN�A DE PROCEDIMENTO COM DATA DE AUTORIZA��O POSTERIOR � DO ATENDIMENTO.', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (892, 84, '1815', 'PROCEDIMENTO N�O AUTORIZADO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (893, 84, '1816', 'COBRAN�A DE PROCEDIMENTO EM QUANTIDADE INCOMPAT�VEL COM O PROCEDIMENTO/EVOLU��O CL�NICA', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (894, 84, '1817', 'COBRAN�A DE PROCEDIMENTO INCLUSO NO PROCEDIMENTO PRINCIPAL', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (895, 84, '1818', 'COBRAN�A DE PROCEDIMENTO QUE EXIGE AUTORIZA��O PR�VIA', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (896, 84, '1819', 'COBRAN�A DE PROCEDIMENTO COM HIST�RIA CL�NICA/HIP�TESE DIAGN�STICA N�O COMPAT�VEL', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (897, 84, '1820', 'COBRAN�A DE PROCEDIMENTO EM QUANTIDADE ACIMA DA M�XIMA PERMITIDA/AUTORIZADA', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (898, 84, '1821', 'COBRAN�A DE PROCEDIMENTO N�O COMPAT�VEL COM A IDADE.', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (899, 84, '1822', 'COBRAN�A DE PROCEDIMENTO COM AUS�NCIA DE RESULTADO OU LAUDO T�CNICO.', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (900, 84, '1823', 'PROCEDIMENTO REALIZADO PELO MESMO PROFISSIONAL, NA MESMA ESPECIALIDADE, NO PRAZO INFERIOR AO ESTIPULADO SEM JUSTIFICATIVA ADEQUADA.', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (901, 84, '1824', 'PROCEDIMENTO COBRADO N�O CORRESPONDE AO EXAME EXECUTADO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (902, 84, '1825', 'COBRAN�A DE PROCEDIMENTO AMBULATORIAL COM DATA DE AUTORIZA��O POSTERIOR � DO ATENDIMENTO.', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (903, 84, '1826', 'VIAS DE ACESSO DOS PROCEDIMENTOS COBRADOS N�O EST�O PREVISTAS NA LISTAGEM DE PROCEDIMENTOS M�LTIPLOS.', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (904, 84, '1827', 'COBRAN�A DE OUTRO PROCEDIMENTO EM OUTRA GUIA, NA MESMA DATA, PELO MESMO PROFISSIONAL COM MESMO GRAU DE PARTICIPA��O - LIBERADO VALOR REFERENTE � VIA DE ACESSO DO PROCEDIMENTO SECUND�RIO.', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (905, 84, '1828', 'ADICIONAL DE URG�NCIA N�O PREVISTO PARA PROCEDIMENTO CIR�RGICO ELETIVO.', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (906, 84, '1829', 'ADICIONAL DE V�DEO N�O PREVISTO PARA O PROCEDIMENTO.', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (907, 84, '1830', 'COBRAN�A DE PROCEDIMENTO SEM INFORMA��O DAS DATAS DE ATENDIMENTO-VISITA, PLANT�O, INTENSIVISTA, AVALIA��O ENTERAL/PARENTERAL', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (908, 84, '1831', 'LAUDO DO EXAME ENVIADO N�O JUSTIFICA A COBRAN�A DO PROCEDIMENTO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (909, 84, '1832', 'PROCEDIMENTO N�O PERMITE COBRAN�A DE AUXILIAR DE ANESTESISTA', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (910, 84, '1833', 'PROCEDIMENTO COBRADO N�O PERMITE ACR�SCIMO DE ACOMODA��O', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (911, 84, '1834', 'PORTE ANEST�SICO COBRADO INCOMPAT�VEL COM O PORTE DO PROCEDIMENTO REALIZADO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (912, 84, '1835', '"ANALGESIA POR DIA SUBSEQUENTE" N�O JUSTIFICADA EM RELAT�RIO M�DICO, PARA O PROCEDIMENTO REALIZADO E/OU DATA DO ATENDIMENTO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (913, 84, '1836', '"ANALGESIA POR DIA SUBSEQUENTE" INCOMPAT�VEL COM A VIA DE ADMINISTRA��O DO MEDICAMENTO - VO OU IV PERIF�RICA - SENDO LIBERADA VISITA HOSPITALAR', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (914, 84, '1837', 'N�O CABE PAGAMENTO DO HONOR�RIO INTEGRAL POR SER VIA DE ACESSO CIR�RGICO DIFERENTE', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (915, 84, '1838', 'GRAU DE PARTICIPA��O INFORMADO INCOMPAT�VEL COM EVENTO COBRADO.', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (916, 84, '1839', 'NECESS�RIO ENVIO DO RESULTADO DO EXAME AN�TOMO PATOL�GICO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (917, 84, '1840', 'PROCEDIMENTO EXECUTADO ANTES DA AUTORIZA��O', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (918, 84, '1901', 'ACOMODA��O INV�LIDA', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (919, 84, '1902', 'ACOMODA��O INFORMADA N�O EST� DE ACORDO COM ACOMODA��O CONTRATADA', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (920, 84, '1903', 'PERMAN�NCIA HOSPITALAR INCOMPAT�VEL COM A EVOLU��O CL�NICA', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (921, 84, '1904', 'PERMAN�NCIA HOSPITALAR INCOMPAT�VEL COM O PROCEDIMENTO AUTORIZADO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (922, 84, '1905', 'QUANTIDADE DE DI�RIAS DEVE SER MAIOR QUE ZERO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (923, 84, '1906', 'ACOMODA��O N�O INFORMADA', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (924, 84, '1907', 'QUANTIDADE UTI N�O PREVISTA PARA PROCEDIMENTO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (925, 84, '1908', 'USU�RIO N�O POSSUI COBERTURA DE UTI', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (926, 84, '1909', 'ACOMODA��O N�O AUTORIZADA', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (927, 84, '1910', 'COBRAN�A DE DI�RIAS EM LOCAIS DE ACOMODA��ES DIFERENTES, NO MESMO DIA.', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (928, 84, '1911', 'PERMAN�NCIA HOSPITALAR PARA INVESTIGA��O INJUSTIFICADA.', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (929, 84, '1912', 'EVOLU��O CL�NICA N�O COMPAT�VEL COM A PERMAN�NCIA EM UTI.', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (930, 84, '1913', 'C�DIGO DE DI�RIA INCOMPAT�VEL COM O LOCAL DE ATENDIMENTO.', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (931, 84, '1914', 'COBRAN�A DE DI�RIA EM QUANTIDADE INCOMPAT�VEL COM A PERMAN�NCIA HOSPITALAR.', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (932, 84, '1915', 'MUDAN�A DE ACOMODA��O SEM COMUNICA��O AO PACIENTE, FAMILIAR OU ACOMPANHANTE, OU SEM SOLICITA��O DESTES.', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (933, 84, '1916', 'COBRAN�A DE DI�RIAS DE UTI INCOMPAT�VEL COM DIAGN�STICO E EVOLU��O CL�NICA.', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (934, 84, '1917', 'FALTA PRORROGA��O PARA QUANTIDADE DE DI�RIAS COBRADAS.', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (935, 84, '1918', 'PLANO DO BENEFICI�RIO N�O CONTEMPLA DI�RIA DE ACOMPANHANTE', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (936, 84, '2001', 'MATERIAL INV�LIDO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (937, 84, '2002', 'MATERIAL SEM COBERTURA PARA ATENDIMENTO AMBULATORIAL', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (938, 84, '2003', 'MATERIAL N�O ESPECIFICADO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (939, 84, '2004', 'MATERIAL SEM NOTA FISCAL DO FORNECEDOR', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (940, 84, '2005', 'QUANTIDADE DE MATERIAL DEVE SER MAIOR QUE ZERO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (941, 84, '2006', 'MATERIAL INFORMADO N�O COBERTO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (942, 84, '2007', 'COBRAN�A DE MATERIAL EM QUANTIDADE INCOMPAT�VEL COM A PERMAN�NCIA.', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (943, 84, '2008', 'COBRAN�A DE MATERIAL EM QUANTIDADES INCOMPAT�VEIS COM O PROCEDIMENTO REALIZADO.', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (944, 84, '2009', 'QUANTIDADE DE MATERIAL SUPERIOR A QUANTIDADE COBERTA', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (945, 84, '2010', 'COBRAN�A DE MATERIAIS INCLUSOS NAS TAXAS', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (946, 84, '2011', 'COBRAN�A DE MATERIAL INCLUSO NO PACOTE NEGOCIADO.', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (947, 84, '2012', 'COBRAN�A DE MATERIAL INCOMPAT�VEL COM O RELAT�RIO T�CNICO.', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (948, 84, '2013', 'COBRAN�A DE MATERIAL EM PERMAN�NCIA HOSPITALAR N�O AUTORIZADA.', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (949, 84, '2014', 'COBRAN�A DE MATERIAL N�O UTILIZADO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (950, 84, '2015', 'MATERIAL N�O AUTORIZADO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (951, 84, '2101', 'MEDICAMENTO INV�LIDO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (952, 84, '2102', 'MEDICAMENTO SEM COBERTURA PARA ATENDIMENTO AMBULATORIAL', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (953, 84, '2103', 'MEDICAMENTO N�O ESPECIFICADO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (954, 84, '2104', 'MEDICAMENTO SEM NOTA FISCAL DO FORNECEDOR', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (955, 84, '2105', 'QUANTIDADE DE MEDICAMENTOS DEVE SER MAIOR QUE ZERO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (956, 84, '2106', 'MEDICAMENTO INFORMADO N�O COBERTO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (957, 84, '2107', 'COBRAN�A DE MEDICAMENTO EM QUANTIDADE INCOMPAT�VEL COM A PERMAN�NCIA.', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (958, 84, '2108', 'COBRAN�A DE MEDICAMENTO EM QUANTIDADES INCOMPAT�VEIS COM O PROCEDIMENTO REALIZADO.', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (959, 84, '2109', 'QUANTIDADE DE MEDICAMENTO SUPERIOR A QUANTIDADE COBERTA', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (960, 84, '2110', 'COBRAN�A DE MEDICAMENTO INCLUSOS NAS TAXAS', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (961, 84, '2111', 'COBRAN�A DE MEDICAMENTO INCLUSO NO PACOTE NEGOCIADO.', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (962, 84, '2112', 'COBRAN�A DE MEDICAMENTO INCOMPAT�VEL COM O RELAT�RIO T�CNICO.', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (963, 84, '2113', 'COBRAN�A DE MEDICAMENTO EM PERMAN�NCIA HOSPITALAR N�O AUTORIZADA.', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (964, 84, '2114', 'COBRAN�A DE MEDICAMENTO N�O UTILIZADO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (965, 84, '2115', 'MEDICAMENTO N�O AUTORIZADO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (966, 84, '2201', 'OPME INV�LIDO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (967, 84, '2202', 'OPME SEM COBERTURA PARA ATENDIMENTO AMBULATORIAL', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (968, 84, '2203', 'OPME SEM NOTA FISCAL DO FORNECEDOR', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (969, 84, '2204', 'QUANTIDADE DE OPME DEVE SER MAIOR QUE ZERO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (970, 84, '2205', 'OPME INFORMADO N�O COBERTO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (971, 84, '2206', 'OPME INFORMADO N�O AUTORIZADO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (972, 84, '2207', 'COBRAN�A DE OPME N�O UTILIZADO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (973, 84, '2208', 'COBRAN�A DE OPME NO ITEM MATERIAL E MEDICAMENTOS.', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (974, 84, '2209', 'COBRAN�A DE OPME EM DESACORDO COM RELAT�RIO T�CNICO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (975, 84, '2210', 'COBRAN�A DE OPME EM QUANTIDADE INCOMPAT�VEL COM O PROCEDIMENTO REALIZADO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (976, 84, '2211', 'COBRAN�A DE OPME INCLUSA NO PACOTE NEGOCIADO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (977, 84, '2212', 'OPME EM DESACORDO COM OS CRIT�RIOS T�CNICOS ADOTADOS PELA OPERADORA', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (978, 84, '2213', 'OPME PAGO A FORNECEDOR TERCEIRIZADO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (979, 84, '2301', 'GASES MEDICINAIS INV�LIDOS', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (980, 84, '2302', 'COBRAN�A DE OXIGENOTERAPIA SEM PRESCRI��O M�DICA.', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (981, 84, '2303', 'COBRAN�A DE OXIGENOTERAPIA COM QUANTITATIVO DE USO EM DIVERG�NCIA/PAGO VALOR CORRIGIDO.', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (982, 84, '2304', 'COBRAN�A DE OXIG�NIO INCLUSO NA TAXA DE NEBULIZA��O ESPECIFICADA.', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (983, 84, '2305', 'COBRAN�A DE OXIGENOTERAPIA EM USO PROLONGADO SEM JUSTIFICATIVA DE USO.', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (984, 84, '2306', 'COBRAN�A DE OXIGENOTERAPIA SEM REGISTRO DE CONTROLE DE USO (ENTRADA E SA�DA).', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (985, 84, '2307', 'COBRAN�A DE GASES EM QUANTIDADE SUPERIOR AO PER�ODO DE PERMAN�NCIA', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (986, 84, '2308', 'COBRAN�A DE CO2 NAS CIRURGIAS VIDEOLAPAROSC�PICAS DURANTE TODA A REALIZA��O DO PROCEDIMENTO (IN�CIO AO FIM).', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (987, 84, '2309', 'COBRAN�A DE AR COMPRIMIDO SEM REGISTRO NO BOLETIM ANEST�SICO E DURA��O DE USO.', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (988, 84, '2310', 'COBRAN�A DE GASES INCOMPAT�VEL COM O UTILIZADO/ PRESCRITO.', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (989, 84, '2401', 'TAXA / ALUGUEL INV�LIDO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (990, 84, '2402', 'COBRAN�A DE TAXA POR USO DE EQUIPAMENTO INCOMPAT�VEL COM O PROCEDIMENTO REALIZADO/USO PREVISTO NO PROCEDIMENTO.', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (991, 84, '2403', 'COBRAN�A DE TAXA DE USO DE BOMBA DE INFUS�O EM PACIENTE INTERNADO NA UTI', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (992, 84, '2404', 'COBRAN�A DE OUTRAS TAXAS ASSOCIADAS/INCLUSAS NA COBRAN�A DA TAXA DE SALA PREVISTA.', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (993, 84, '2405', 'COBRAN�A DE MAIS DE UMA TAXA DE SALA DE CIRURGIA, POR CONTA DO N�MERO DE PROCEDIMENTOS REALIZADOS NO MESMO TEMPO CIR�RGICO.', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (994, 84, '2406', 'COBRAN�A INDEVIDA DE TAXA DE SALA POR ADMINISTRA��O DE MEDICAMENTOS.', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (995, 84, '2407', 'COBRAN�A DE TAXAS, DE SERVI�OS REALIZADOS EM AMBIENTES INCOMPAT�VEIS COM O USO DE EQUIPAMENTOS.', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (996, 84, '2408', 'COBRAN�A DE TAXAS EM QUANTIDADE SUPERIOR AO TEMPO DE PERMAN�NCIA HOSPITALAR', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (997, 84, '2409', 'COBRAN�A DE TAXA DE OBSERVA��O EM PRONTO SOCORRO COM PERMAN�NCIA MENOR QUE O PER�ODO ESTIPULADO', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (998, 84, '2410', 'COBRAN�A DE TAXA DE OBSERVA��O EM PRONTO SOCORRO SEM O REGISTRO DA PERMAN�NCIA.', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (999, 84, '2411', 'COBRAN�A DE TAXA DE SALA DE PRONTO SOCORRO, PARA APLICA��O DE MEDICAMENTOS.', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1306, 85, '1', 'Solicita��o', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1307, 85, '2', 'Faturamento', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1308, 86, '1', 'Cl�nica', 352);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1309, 86, '2', 'Cir�rgica', 353);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1310, 86, '3', 'Obst�trica', 354);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1311, 86, '4', 'Pedi�trica', 355);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1312, 86, '5', 'Psiqui�trica', 356);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1313, 87, '1', 'D�bito', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1314, 87, '2', 'Cr�dito', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1315, 88, '1', '1� linha', 435);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1316, 88, '2', '2� linha', 436);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1317, 88, '3', '3� linha', 437);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1318, 88, '4', 'Outras Linhas', 438);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1319, 89, '1', 'T1', 32);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1320, 89, '2', 'T2', 33);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1321, 89, '3', 'T3', 34);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1322, 89, '4', 'T4', 35);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1323, 89, '5', 'T0', 36);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1324, 89, '6', 'Tis', 37);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1325, 89, '7', 'Tx', 38);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1326, 89, '8', 'N�o se aplica', 39);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1327, 89, '9', 'Sem informa��o', 40);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (27, 9, '11', 'Cirurgia do Aparelho Digestivo - CFM - 9 - Cirurgia Videolaparosc�pica, Endoscopia Digestiva e Nutri��o Parenteral e Enteral.', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (28, 9, '12', 'Cirurgia Pedi�trica - CFM - 12 - Sem �rea de atua��o', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (29, 9, '13', 'Cirurgia Pl�stica - CFM - 13 - Cirurgia Cr�nio-Maxilo-Facial e Tratamento de Queimados.', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (30, 9, '14', 'Cirurgia Geral - CFM - 10 - Cirurgia do Trauma e Cirurgia Videolaparosc�pica', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (31, 9, '17', 'Dermatologia - CFM - 18 - Cirurgia Dermatol�gica, Cosmiatria e Hansenologia', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (32, 9, '18', 'Endocrinologia e Metabologia - CFM - 19 - Endocrinologia Pedi�trica', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (33, 9, '2', 'Alergia e Imunologia - CFM - 2 - Alergia e Imunologia Pedi�trica', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (34, 9, '21', 'Gastroenterologia - CFM - 21 - Endoscopia Digestiva, Gastroenterologia Pedi�trica, Hepatologia e Nutri��o Parenteral e Enteral.', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (35, 9, '22', 'Gen�tica M�dica - CFM - 22 - Sem �rea de atua��o', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (36, 9, '23', 'Geriatria - CFM - 23 - Sem �rea de atua��o', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (37, 9, '26', 'Hematologia e Hemoterapia - CFM - 25 - Hematologia e Hemoterapia Pedi�trica e Transplante de medula �ssea.', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (38, 9, '28', 'Homeopatia - CFM - 26 - Sem �rea de atua��o', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (39, 9, '29', 'Infectologia - CFM - 27 - Infectologia hospitalar, Infectologia Pedi�trica e Hansenologia.', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (40, 9, '3', 'Anestesiologia - CFM - 3 - Dor', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (41, 9, '30', 'Medicina Intensiva - CFM - 35 - Medicina Intensiva Pedi�trica e Nutri��o Parenteral e Enteral.', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (42, 9, '31', 'Mastologia - CFM - 28 - Mamografia', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (43, 9, '32', 'Medicina Esportiva - CFM - 33 - Sem �rea de atua��o', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (44, 9, '33', 'Medicina F�sica e Reabilita��o - CFM - 34 - Neurofisiologia Cl�nica', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (45, 9, '34', 'Medicina Legal - CFM - 36 - Sem �rea de atua��o', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (46, 9, '35', 'Medicina do Trabalho - CFM - 31 - Sem �rea de atua��o', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (47, 9, '36', 'Medicina do Tr�fego - CFM - 32 - Sem �rea de atua��o', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (48, 9, '37', 'Nefrologia - CFM - 39 - Nefrologia Pedi�trica', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (49, 9, '38', 'Neurocirurgia - CFM - 40 - Cirurgia de Coluna, Neurofisiologia Cl�nica e Neurorradiologia.', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (50, 9, '40', 'Neurologia - CFM - 41 - Atua��o Dor, Neurofisiologia Cl�nica, Neurologia Pedi�trica, Hansenologia e Neurorradiologia', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (51, 9, '42', 'Nutrologia - CFM - 42 - Nutri��o Parenteral e Enteral, Nutrologia Pedi�trica e Nutri��o Parenteral e Enteral Pedi�trica.', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (52, 9, '43', 'Oftalmologia - CFM - 43 - Sem �rea de atua��o', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (53, 9, '44', 'Ortopedia e Traumatologia - CFM - 45 - Cirurgia da coluna e Densitometria �ssea', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (54, 9, '45', 'Otorrinolaringologia - CFM - 46 - Cirurgia Cr�nio-Maxilo-Facial e Foniatria', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (55, 9, '46', 'Patologia Cl�nica / Medicina Laboratorial - CFM - 48 - Sem �rea de atua��o', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (56, 9, '47', 'Patologia - CFM - 47 - Citopatologia', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (57, 9, '48', 'Pediatria - CFM - 49 - Alergia e Imunologia, Cardiologia, Endocrinologia, Gastroenterologia, Hematologia e Hemoterapia, Infectologia, Medicina do Adolescente, Medicina Intensiva, Nefrologia...', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (58, 9, '50', 'Psiquiatria - CFM - 51 - Psicogeriatria, Psicoterapia, Psiquiatria da Inf�ncia e da Adolesc�ncia e Psiquiatria Forense', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (59, 9, '51', 'Radiologia e Diagn�stico por Imagem - CFM - 52 - Neurorradiologia, Radiologia Intervencionista e Angiorradiologia, Angiorradiologia e Cirurgia Endovascular', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (60, 9, '52', 'Reumatologia - CFM - 54 - Reumatologia Pedi�trica e Densitometria �ssea', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (61, 9, '53', 'Urologia - CFM - 55 - Sem �rea de atua��o', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (62, 9, '54', 'Angiologia  - CFM - 4 - Angiorradiologia e Cirurgia Endovascular, Ecografia Vascular com DOPPLER, Radiologia Intervencionista e Angiorradiologia', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (63, 9, '56', 'Cir�rgia Tor�cica - CFM - 14 - Endoscopia Respirat�ria', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (64, 9, '60', 'Ginecologia e Obstetr�cia - CFM - 24 - Medicina Fetal, Reprodu��o Humana, Sexologia e Ultra-sonografia em ginecologia, Obstetr�cia, Endoscopia Ginecol�gica, Densitometria �ssea e Mamografia.', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (65, 9, '61', 'Medicina de Fam�lia e Comunidade - CFM - 30 - Hansenologia', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (66, 9, '62', 'Medicina Nuclear - CFM - 37 - Densitometria �ssea', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (67, 9, '63', 'Medicina Preventiva e Social - CFM - 38 - Hansenologia', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (68, 9, '66', 'Pneumologia - CFM - 50 - Endoscopia Respirat�ria e Pneumologia Pedi�trica', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (69, 9, '68', 'Radioterapia - CFM - 53 - Sem �rea de atua��o', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (70, 9, '7', 'Cardiologia - CFM - 5 - Cardiologia Pedi�trica, Ecocardiografia, Hemodin�mica, Cardiologia Intervencionista, Eletrofisiologia Cl�nica Invasiva e Ergonometria.', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (71, 9, '71', 'Acupuntura - CFM - 1 - Sem �rea de atua��o', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (72, 9, '74', 'Cl�nica M�dica - CFM - 16 - Hansenologia e Medicina de Urg�ncia', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (73, 9, '75', 'Coloproctologia - CFM - 17 - Cirurgia Videolaparosc�pica e  Endoscopia Digestiva', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (74, 9, '76', 'Cirurgia Vascular - CFM - 15 - Angiorradiologia e Cirurgia Endovascular, Ecografia Vascular com Doppler, Radiologia Intervencionista e Angiorradiologia', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (75, 9, '77', 'Endoscopia - CFM - 20 - Endoscopia Digestiva e Endoscopia Respirat�ria', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (76, 9, '78', 'Cirurgia da M�o - CFM - 7 - Sem �rea de atua��o', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (77, 9, '79', 'Medicina de emerg�ncia - CFM - 29', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (78, 9, '8', 'Cirurgia da Cabe�a e Pesco�o - CFM - 8 - Cirurgia Cr�nio-Maxilo-Facial', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (79, 9, '80', 'Cirurgia Oncol�gica - CFM - 11 - Cirurgia do Trauma e Cirurgia Videolaparosc�pica', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (80, 9, '81', 'Oncologia Cl�nica - CFM - 44', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (81, 9, '9', 'Cirurgia Cardiovascular - CFM - 6 - Sem �rea de atua��o', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (82, 9, '99', 'Demais M�dicos Cooperados', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1328, 90, '001', 'AMP - Ampola', 493);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1329, 90, '002', 'BUI - Bilh�es de Unidades Internacionais', 496);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1330, 90, '003', 'BG - Bisnaga', 494);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1331, 90, '004', 'BOLS - Bolsa', 495);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1332, 90, '005', 'CX - Caixa', 505);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1333, 90, '006', 'CAP - C�psula', 497);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1334, 90, '007', 'CARP - Carpule', 498);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1335, 90, '008', 'COM - Comprimido', 504);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1336, 90, '009', 'DOSE - Dose', 506);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1337, 90, '010', 'DRG - Dr�gea', 507);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1338, 90, '011', 'ENV - Envelope', 508);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1339, 90, '012', 'FLAC - Flaconete', 510);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1340, 90, '013', 'FR - Frasco', 511);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1341, 90, '014', 'FA - Frasco Ampola', 509);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1342, 90, '015', 'GAL - Gal�o', 512);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1343, 90, '016', 'GLOB - Gl�bulo', 513);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1344, 90, '017', 'GTS - Gotas', 515);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1345, 90, '018', 'G - Grama', 514);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1346, 90, '019', 'L - Litro', 520);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1347, 90, '020', 'MCG - Microgramas', 522);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1348, 90, '021', 'MUI - Milh�es de Unidades Internacionais', 526);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1349, 90, '022', 'MG - Miligrama', 523);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1350, 90, '023', 'ML - Mililitro', 524);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1351, 90, '024', 'OVL - �vulo', 527);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1352, 90, '025', 'PAS - Pastilha', 529);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1353, 90, '026', 'LT - Lata', 519);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1354, 90, '027', 'PER - P�rola', 532);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1355, 90, '028', 'PIL - P�lula', 533);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1356, 90, '029', 'PT - Pote', 534);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1357, 90, '030', 'KG - Quilograma', 517);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1358, 90, '031', 'SER - Seringa', 537);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1359, 90, '032', 'SUP - Suposit�rio', 538);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1360, 90, '033', 'TABLE - Tablete', 539);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1361, 90, '034', 'TUB - Tubete', 541);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1362, 90, '035', 'TB - Tubo', 540);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1363, 90, '036', 'UN - Unidade', 543);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1364, 90, '037', 'UI - Unidade Internacional', 542);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1365, 90, '038', 'CM - Cent�metro', 501);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1366, 90, '039', 'CONJ - Conjunto', 502);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1367, 90, '040', 'KIT - Kit', 518);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1368, 90, '041', 'M� - Ma�o', 521);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1369, 90, '042', 'M - Metro', 525);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1370, 90, '043', 'PC - Pacote', 531);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1371, 90, '044', 'P� - Pe�a', 530);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1372, 90, '045', 'RL - Rolo', 535);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1373, 90, '046', 'GY - Gray', 516);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1374, 90, '047', 'CGY - Centgray', 500);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1375, 90, '048', 'PAR - Par', 528);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1376, 90, '049', 'ADES - Adesivo Transd�rmico', 492);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1377, 90, '050', 'COM EFEV - Comprimido Efervecente', 499);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1378, 90, '051', 'COM MST - Comprimido Mastig�vel', 503);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1379, 90, '052', 'SACHE - Sache', 536);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1380, 91, '1', 'Hora', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1381, 91, '2', 'Dia', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1382, 91, '3', 'M�s', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1383, 92, '01', 'Bucal', 544);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1384, 92, '02', 'Capilar', 545);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1385, 92, '03', 'Dermatol�gica', 546);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1386, 92, '04', 'Epidural', 547);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1387, 92, '05', 'Gastrostomia/jejunostomia', 548);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1388, 92, '06', 'Inalat�ria', 549);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1389, 92, '07', 'Intra- �ssea', 550);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1390, 92, '08', 'Intra-arterial', 551);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1391, 92, '09', 'Intra-articular', 552);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1392, 92, '10', 'Intracard�aca', 553);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1393, 92, '11', 'Intrad�rmica', 554);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1394, 92, '12', 'Intralesional', 555);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1395, 92, '13', 'Intramuscular', 556);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1396, 92, '14', 'Intraperitonial', 557);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1397, 92, '15', 'Intrapleural', 558);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1398, 92, '16', 'Intratecal', 559);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1399, 92, '17', 'Intratraqueal', 560);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1400, 92, '18', 'Intrauterina', 561);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1401, 92, '19', 'Intravenosa', 562);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1402, 92, '20', 'Intravesical', 563);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1403, 92, '21', 'Intrav�trea', 564);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1404, 92, '22', 'Irriga��o', 565);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1405, 92, '23', 'Nasal', 566);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1406, 92, '24', 'Oft�lmica', 567);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1407, 92, '25', 'Oral', 568);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1408, 92, '26', 'Otol�gica', 569);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1409, 92, '27', 'Retal', 570);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1410, 92, '28', 'Sonda enteral', 571);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1411, 92, '29', 'Sonda g�strica', 572);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1412, 92, '30', 'Subcut�nea', 573);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1413, 92, '31', 'Sublingual', 574);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1414, 92, '32', 'Transd�rmica', 575);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1415, 92, '33', 'Uretral', 576);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1416, 92, '34', 'Vaginal', 577);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1417, 92, '35', 'Outras', 578);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1418, 93, '1', '�nica', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1419, 93, '2', 'Mesma via', null);
insert into TERMINOL_PROT_COMUNIC_ITEM (id, terminologia_prot_comunic_id, valor, descricao, dominio_item_id)
values (1420, 93, '3', 'Diferentes vias', null);
