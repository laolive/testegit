package br.com.unimedsc.controller;

import br.com.unimedsc.core.annotation.UFTansactionHijacker;
import br.com.unimedsc.core.controller.AbstractController;
import br.com.unimedsc.core.entity.pk.SimplePK;
import br.com.unimedsc.core.service.Service;
import br.com.unimedsc.core.utils.SessionUtil;
import br.com.unimedsc.entities.erp.Transaction;
import br.com.unimedsc.service.TransactionService;
import org.springframework.stereotype.Component;

import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@Component
@Path("transaction")
public class TransactionController extends AbstractController<Long, SimplePK<Long>, Transaction> {

	@Inject
	private TransactionService transactionService;

	@Override
	public Transaction newEntity() {
		return new Transaction();
	}

	@Override
	public Service<SimplePK<Long>, Transaction> getRootService() {
		return transactionService;
	}

	@Override
	public SimplePK<Long> newEntityPK() {
		return new SimplePK<Long>();
	}

	@GET
	@Path("permission")
	@Produces(MediaType.APPLICATION_JSON)
	@UFTansactionHijacker("TransactionController.getPermission")
	public Object getPermission() throws Exception {
		return transactionService.getPermissionByUser(SessionUtil.getInstance().getUserId());
	}
}
