package br.com.unimedsc.controller;

import javax.inject.Inject;
import javax.ws.rs.Path;

import org.springframework.stereotype.Component;

import br.com.unimedsc.core.controller.AbstractController;
import br.com.unimedsc.core.entity.pk.SimplePK;
import br.com.unimedsc.core.service.Service;
import br.com.unimedsc.entities.erp.ParameterGroup;
import br.com.unimedsc.service.ParameterGroupService;

@Component
@Path("parameterGroup")
public class ParameterGroupController extends AbstractController<String, SimplePK<String>, ParameterGroup>{
	@Inject
	ParameterGroupService parameterGroupService;
	
	@Override
	public ParameterGroup newEntity() {
		return new ParameterGroup();
	}

	@Override
	public Service<SimplePK<String>, ParameterGroup> getRootService() {	
		return parameterGroupService;
	}
	
	@Override
	public SimplePK<String> newEntityPK() {
		return new SimplePK<String>();
	}
}
