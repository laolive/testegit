package br.com.unimedsc.controller;

import javax.inject.Inject;
import javax.ws.rs.Path;

import org.springframework.stereotype.Component;

import br.com.unimedsc.core.controller.AbstractController;
import br.com.unimedsc.core.entity.pk.SimplePK;
import br.com.unimedsc.core.service.Service;
import br.com.unimedsc.entities.erp.AuditData;
import br.com.unimedsc.service.AuditDataService;

@Component
@Path("auditData")
public class AuditDataController extends AbstractController<Long, SimplePK<Long>, AuditData> {
	@Inject
	AuditDataService service;

	@Override
	public AuditData newEntity() {
		return new AuditData();
	}

	@Override
	public Service<SimplePK<Long>, AuditData> getRootService() {
		return service;
	}

	@Override
	public SimplePK<Long> newEntityPK() {
		return new SimplePK<Long>();
	}

}