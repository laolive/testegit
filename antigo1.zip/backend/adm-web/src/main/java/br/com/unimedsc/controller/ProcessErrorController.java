package br.com.unimedsc.controller;

import javax.inject.Inject;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.springframework.stereotype.Component;

import br.com.unimedsc.core.annotation.UFTansactionHijacker;
import br.com.unimedsc.core.controller.AbstractController;
import br.com.unimedsc.core.service.Service;
import br.com.unimedsc.core.utils.CommonsHelper;
import br.com.unimedsc.entities.erp.ProcessError;
import br.com.unimedsc.entities.erp.dto.ProcessParamsDTO;
import br.com.unimedsc.entities.pk.ProcessCompositePK;
import br.com.unimedsc.service.ProcessErrorService;

@Component
@Path("processError")
public class ProcessErrorController extends AbstractController<Long, ProcessCompositePK<Long>, ProcessError> {
	@Inject
	ProcessErrorService service;

	@Override
	public ProcessError newEntity() {
		return new ProcessError();
	}

	@Override
	public Service<ProcessCompositePK<Long>, ProcessError> getRootService() {
		return service;
	}

	@Override
	public ProcessCompositePK<Long> newEntityPK() {
		return new ProcessCompositePK<Long>();
	}
    @POST
    @Path(value = "generateError")
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    @UFTansactionHijacker("ProcessErrorController.generateError")
    public Object generateError(ProcessParamsDTO processParamsDTO) throws Exception {
        return CommonsHelper.getInstance().DynamicItemVO(super.request, null, service.generateError(processParamsDTO), false);
    }
}