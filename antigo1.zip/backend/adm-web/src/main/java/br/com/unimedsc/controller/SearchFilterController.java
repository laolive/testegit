package br.com.unimedsc.controller;

import javax.inject.Inject;
import javax.ws.rs.Path;

import org.springframework.stereotype.Component;

import br.com.unimedsc.core.controller.AbstractController;
import br.com.unimedsc.core.service.Service;
import br.com.unimedsc.entities.cfg.SearchFilter;
import br.com.unimedsc.entities.pk.SearchCompositePK;
import br.com.unimedsc.service.SearchFilterService;

@Component
@Path("searchFilter")
public class SearchFilterController extends AbstractController<Long, SearchCompositePK<Long>, SearchFilter> {

	@Inject
	private SearchFilterService searchFilterService;

	@Override
	public Service<SearchCompositePK<Long>, SearchFilter> getRootService() {
		return searchFilterService;
	}

	@Override
	public SearchFilter newEntity() {
		return new SearchFilter();
	}

	@Override
	public SearchCompositePK<Long> newEntityPK() {
		return new SearchCompositePK<Long>();
	}

}
