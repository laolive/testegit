package br.com.unimedsc.controller;

import javax.inject.Inject;
import javax.ws.rs.Path;

import org.springframework.stereotype.Component;

import br.com.unimedsc.core.controller.AbstractController;
import br.com.unimedsc.core.service.Service;
import br.com.unimedsc.entities.erp.ProcessFile;
import br.com.unimedsc.entities.pk.ProcessCompositePK;
import br.com.unimedsc.service.ProcessFileService;

@Component
@Path("processFile")
public class ProcessFileController extends AbstractController<Long, ProcessCompositePK<Long>, ProcessFile> {
	@Inject
	ProcessFileService service;

	@Override
	public ProcessFile newEntity() {
		return new ProcessFile();
	}

	@Override
	public Service<ProcessCompositePK<Long>, ProcessFile> getRootService() {
		return service;
	}

	@Override
	public ProcessCompositePK<Long> newEntityPK() {
		return new ProcessCompositePK<Long>();
	}

}