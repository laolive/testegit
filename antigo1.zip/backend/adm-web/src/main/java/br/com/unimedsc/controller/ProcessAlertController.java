package br.com.unimedsc.controller;

import javax.inject.Inject;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.springframework.stereotype.Component;

import br.com.unimedsc.core.annotation.UFTansactionHijacker;
import br.com.unimedsc.core.controller.AbstractController;
import br.com.unimedsc.core.service.Service;
import br.com.unimedsc.core.utils.CommonsHelper;
import br.com.unimedsc.entities.erp.ProcessAlert;
import br.com.unimedsc.entities.erp.dto.ProcessParamsDTO;
import br.com.unimedsc.entities.pk.ProcessCompositePK;
import br.com.unimedsc.service.ProcessAlertService;

@Component
@Path("processAlert")
public class ProcessAlertController extends AbstractController<Long, ProcessCompositePK<Long>, ProcessAlert> {
    @Inject
    ProcessAlertService service;

    @Override
    public ProcessAlert newEntity() {
        return new ProcessAlert();
    }

    @Override
    public Service<ProcessCompositePK<Long>, ProcessAlert> getRootService() {
        return service;
    }

    @Override
    public ProcessCompositePK<Long> newEntityPK() {
        return new ProcessCompositePK<Long>();
    }
    
    @POST
    @Path(value = "generateAlert")
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    @UFTansactionHijacker("ProcessAlertController.generateWarning")
    public Object generateAlert(ProcessParamsDTO processParamsDTO) throws Exception {
        return CommonsHelper.getInstance().DynamicItemVO(super.request, null, service.generateAlert(processParamsDTO), false);
    }
}