package br.com.unimedsc.controller;

import javax.inject.Inject;
import javax.ws.rs.Path;

import org.springframework.stereotype.Component;

import br.com.unimedsc.core.controller.ServiceControllerAbstract;
import br.com.unimedsc.core.entity.pk.CompositeEnterprisePK;
import br.com.unimedsc.core.entity.pk.SimplePK;
import br.com.unimedsc.core.service.Service;
import br.com.unimedsc.entities.erp.Parameter;
import br.com.unimedsc.service.ParameterService;

@Component
@Path("parameter")
public class ParameterController extends ServiceControllerAbstract<String, SimplePK<String>, Parameter>{
	@Inject
	ParameterService parameterService;
	
	@Override
	public Parameter newEntity() {
		return new Parameter();
	}

	@Override
	public Service<SimplePK<String>, Parameter> getRootService() {	
		return parameterService;
	}
	
	@Override
	public CompositeEnterprisePK<String> newEntityPK() {
		return new CompositeEnterprisePK<String>();
	}
}
