package br.com.unimedsc.controller;

import javax.inject.Inject;
import javax.ws.rs.Path;

import org.springframework.stereotype.Component;

import br.com.unimedsc.core.controller.ServiceControllerAbstract;
import br.com.unimedsc.core.service.Service;
import br.com.unimedsc.entities.erp.RoutineOption;
import br.com.unimedsc.entities.pk.RoutineCompositePK;
import br.com.unimedsc.service.RoutineOptionService;

@Component
@Path("routineOption")
public class RoutineOptionController extends ServiceControllerAbstract<Long, RoutineCompositePK<Long>, RoutineOption> {

	@Inject
	private RoutineOptionService routineOptionService;

	@Override
	public RoutineOption newEntity() {
		return new RoutineOption();
	}

	@Override
	public Service<RoutineCompositePK<Long>, RoutineOption> getRootService() {
		return routineOptionService;
	}

	@Override
	public RoutineCompositePK<Long> newEntityPK() {
		return new RoutineCompositePK<Long>();
	}

}
