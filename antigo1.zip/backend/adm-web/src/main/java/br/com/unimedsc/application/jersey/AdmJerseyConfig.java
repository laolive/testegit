package br.com.unimedsc.application.jersey;

import java.util.Map;

import javax.annotation.PostConstruct;
import javax.ws.rs.ApplicationPath;
import javax.ws.rs.Path;

import org.glassfish.jersey.logging.LoggingFeature;
import org.glassfish.jersey.server.ResourceConfig;
import org.glassfish.jersey.server.spring.scope.RequestContextFilter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

import br.com.unimedsc.core.utils.ApplicationUtil;

@Component
@ApplicationPath("/")
public class AdmJerseyConfig extends ResourceConfig {
	@Autowired
    ApplicationContext applicationContext;
	
	public AdmJerseyConfig() {
        register(RequestContextFilter.class);
        register(LoggingFeature.class);
	}    

    @PostConstruct
    public void setup() {
    	
        Map<String,Object> beans = applicationContext.getBeansWithAnnotation(Path.class);
       
        for (Map.Entry<String, Object> entry : beans.entrySet()) {
        	register(entry.getValue());
        	
        	Class<?> clazz = applicationContext.getBeansWithAnnotation(Path.class).get(entry.getKey()).getClass();
        	String annotatioValue = applicationContext.findAnnotationOnBean(entry.getKey(), Path.class).value();
        	if (annotatioValue != null && !annotatioValue.trim().isEmpty()) {
        		ApplicationUtil.getInstance().addContrller(annotatioValue, clazz);
        	}
        }
        ApplicationUtil.getInstance().getControllers();
    }
}