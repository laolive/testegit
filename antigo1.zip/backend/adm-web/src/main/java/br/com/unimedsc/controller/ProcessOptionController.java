package br.com.unimedsc.controller;

import javax.inject.Inject;
import javax.ws.rs.Path;

import org.springframework.stereotype.Component;

import br.com.unimedsc.core.controller.AbstractController;
import br.com.unimedsc.core.service.Service;
import br.com.unimedsc.entities.erp.ProcessOption;
import br.com.unimedsc.entities.pk.ProcessCompositePK;
import br.com.unimedsc.service.ProcessOptionService;

@Component
@Path("processOption")
public class ProcessOptionController extends AbstractController<Long, ProcessCompositePK<Long>, ProcessOption> {
	@Inject
	ProcessOptionService service;

	@Override
	public ProcessOption newEntity() {
		return new ProcessOption();
	}

	@Override
	public Service<ProcessCompositePK<Long>, ProcessOption> getRootService() {
		return service;
	}

	@Override
	public ProcessCompositePK<Long> newEntityPK() {
		return new ProcessCompositePK<Long>();
	}

}