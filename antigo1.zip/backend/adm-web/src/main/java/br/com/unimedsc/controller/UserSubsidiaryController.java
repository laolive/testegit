package br.com.unimedsc.controller;

import br.com.unimedsc.core.annotation.UFOperationPermission;
import br.com.unimedsc.core.annotation.UFTansactionHijacker;
import br.com.unimedsc.core.controller.ServiceControllerAbstract;
import br.com.unimedsc.core.entity.pk.SimplePK;
import br.com.unimedsc.core.service.Service;
import br.com.unimedsc.entities.adm.UserSubsidiary;
import br.com.unimedsc.entities.pk.SubsidiaryCompositePK;
import br.com.unimedsc.service.UserSubsidiaryService;
import br.com.unimedsc.system.Operation;
import org.springframework.stereotype.Component;

import javax.inject.Inject;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@Component
@Path("userSubsidiary")
public class UserSubsidiaryController extends ServiceControllerAbstract<Long, SubsidiaryCompositePK<Long>, UserSubsidiary> {

	@Inject
	private UserSubsidiaryService userSubsidiaryService;

	@Override
	public Service<SubsidiaryCompositePK<Long>, UserSubsidiary> getRootService() {
		return userSubsidiaryService;
	}

	@Override
	public UserSubsidiary newEntity() {
		return new UserSubsidiary();
	}

	@Override
	public SubsidiaryCompositePK<Long> newEntityPK() {
		return new SubsidiaryCompositePK<Long>();
	}

	@POST
	@Path("findByUserId")
	@Produces(MediaType.APPLICATION_JSON)
	@UFTansactionHijacker("UserSubsidiaryController.findByUserId")
	@UFOperationPermission(operation = Operation.FIND)
	public Object findByUserId(SimplePK<Long> userId) throws Exception {

		return returnDefault(userSubsidiaryService.findByUserId(userId.getId()));
	}

	@POST
	@Path("findSubsidiariesByUser")
	@Produces(MediaType.APPLICATION_JSON)
	@UFTansactionHijacker("UserSubsidiaryController.findSubsidiaries")
	@UFOperationPermission(operation = Operation.FIND)
	public Object findSubsidiaries(SimplePK<Long> userId) throws Exception {
		return returnDefault(userSubsidiaryService.findByUserId(userId.getId()));
	}

}