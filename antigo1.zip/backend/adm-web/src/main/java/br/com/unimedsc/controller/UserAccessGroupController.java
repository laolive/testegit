package br.com.unimedsc.controller;

import javax.inject.Inject;
import javax.ws.rs.Path;

import org.springframework.stereotype.Component;

import br.com.unimedsc.core.controller.ServiceControllerAbstract;
import br.com.unimedsc.core.service.Service;
import br.com.unimedsc.entities.adm.UserAccessGroup;
import br.com.unimedsc.entities.pk.AccessGroupCompositePK;
import br.com.unimedsc.service.UserAccessGroupService;

@Component
@Path("userAccessGroup")
public class UserAccessGroupController extends ServiceControllerAbstract<String, AccessGroupCompositePK<String>, UserAccessGroup> {

	@Inject
	private UserAccessGroupService service;

	@Override
	public UserAccessGroup newEntity() {
		return new UserAccessGroup();
	}

	@Override
	public Service<AccessGroupCompositePK<String>, UserAccessGroup> getRootService() {
		return service;
	}

	@Override
	public AccessGroupCompositePK<String> newEntityPK() {
		return new AccessGroupCompositePK<String>();
	}
}