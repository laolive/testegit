package br.com.unimedsc.controller;

import javax.inject.Inject;
import javax.ws.rs.Path;

import org.springframework.stereotype.Component;

import br.com.unimedsc.core.controller.ServiceControllerAbstract;
import br.com.unimedsc.core.service.Service;
import br.com.unimedsc.entities.adm.UserParameter;
import br.com.unimedsc.entities.pk.UserParameterCompositePK;
import br.com.unimedsc.service.UserParameterService;

@Component
@Path("userParameter")
public class UserParameterController extends ServiceControllerAbstract<String, UserParameterCompositePK<String>, UserParameter> {
	
	@Inject
	private UserParameterService userParameterService;

	@Override
	public Service<UserParameterCompositePK<String>, UserParameter> getRootService() {
		return userParameterService;
	}

	@Override
	public UserParameter newEntity() {
		return new UserParameter();
	}

	@Override
	public UserParameterCompositePK<String> newEntityPK() {
		return new UserParameterCompositePK<String>();
	}

}
