package br.com.unimedsc.controller;

import br.com.unimedsc.core.annotation.UFTansactionHijacker;
import br.com.unimedsc.core.controller.ServiceControllerAbstract;
import br.com.unimedsc.core.entity.pk.CompositeEnterprisePK;
import br.com.unimedsc.core.entity.pk.SimplePK;
import br.com.unimedsc.core.service.Service;
import br.com.unimedsc.core.utils.CommonsHelper;
import br.com.unimedsc.core.utils.SessionUtil;
import br.com.unimedsc.entities.adm.AccessGroup;
import br.com.unimedsc.entities.erp.Menu;
import br.com.unimedsc.service.AccessGroupService;
import br.com.unimedsc.service.MenuService;
import org.springframework.stereotype.Component;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import java.util.*;

@Component
@Path("menu")
public class MenuController extends ServiceControllerAbstract<Long, SimplePK<Long>, Menu> {

	@Inject
	private AccessGroupService profileService;

	@Inject
	private MenuService menuService;

	@Override
	public Menu newEntity() {
		return new Menu();
	}

	@Override
	public Service<SimplePK<Long>, Menu> getRootService() {
		return menuService;
	}

	@Override
	public SimplePK<Long> newEntityPK() {
		return new SimplePK<Long>();
	}

	@GET
	@Path("userMenu")
	@Produces(MediaType.APPLICATION_JSON)
	@UFTansactionHijacker("EnterpriseController.userMenu")
	public Object getMenuByUser(@Context HttpServletRequest request) throws Exception {
		SessionUtil sessionUtil = SessionUtil.getInstance();

            List<Object> menus = new ArrayList<Object>(
                    menuService.getMenuByUser(sessionUtil.getUserId(), sessionUtil.getEnterpriseId()));

		return CommonsHelper.getInstance().DynamicListVO(super.request, null, menus, true);
	}

	@GET
	@Path("fullMenu")
	@Produces(MediaType.APPLICATION_JSON)
	@UFTansactionHijacker("MenuController.getFullMenu")
	public Object getFullMenu() throws Exception {
		Set<String> fields = new HashSet<>(Arrays.asList(new String[] { "domainEnable" }));
		List<Object> menus = new ArrayList<Object>(menuService.getFullMenu());

		return CommonsHelper.getInstance().DynamicListVO(super.request, fields, menus, false);
	}

	@POST
	@Path("treeView")
	@Produces(MediaType.APPLICATION_JSON)
	@UFTansactionHijacker("MenuController.menuFindParents")
	public Object menuFindParents(CompositeEnterprisePK<Long> pk) throws Exception {
		AccessGroup profile = profileService.findById(pk);
		return returnDefault(menuService.getMenuByProfile(profile));

	}
}
