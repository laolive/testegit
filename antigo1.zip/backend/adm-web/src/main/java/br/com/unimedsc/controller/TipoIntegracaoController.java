package br.com.unimedsc.controller;

import javax.inject.Inject;
import javax.ws.rs.Path;

import org.springframework.stereotype.Component;

import br.com.unimedsc.core.controller.ServiceControllerAbstract;
import br.com.unimedsc.core.entity.pk.SimplePK;
import br.com.unimedsc.core.service.Service;
import br.com.unimedsc.entities.erp.TipoIntegracao;
import br.com.unimedsc.service.TipoIntegracaoService;

@Component
@Path("tipoIntegracoes")
public class TipoIntegracaoController extends ServiceControllerAbstract<Integer, SimplePK<Integer>, TipoIntegracao> {

    @Inject
    private TipoIntegracaoService tipoIntegracaoService;

    @Override
    public TipoIntegracao newEntity() {
        return new TipoIntegracao();
    }

    @Override
    public Service<SimplePK<Integer>, TipoIntegracao> getRootService() {
        return tipoIntegracaoService;
    }

    @Override
    public SimplePK<Integer> newEntityPK() {
        return new SimplePK<Integer>();
    }
}
