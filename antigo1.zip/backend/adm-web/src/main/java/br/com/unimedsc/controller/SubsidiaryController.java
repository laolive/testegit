package br.com.unimedsc.controller;

import javax.inject.Inject;
import javax.ws.rs.Path;

import org.springframework.stereotype.Component;

import br.com.unimedsc.core.controller.ServiceControllerAbstract;
import br.com.unimedsc.core.entity.pk.CompositeEnterprisePK;
import br.com.unimedsc.core.service.Service;
import br.com.unimedsc.entities.erp.Subsidiary;
import br.com.unimedsc.service.SubsidiaryService;

@Component
@Path("subsidiary")
public class SubsidiaryController extends ServiceControllerAbstract<Long, CompositeEnterprisePK<Long>, Subsidiary> {

	@Inject
	private SubsidiaryService service;

	@Override
	public Subsidiary newEntity() {
		return new Subsidiary();
	}

	@Override
	public Service<CompositeEnterprisePK<Long>, Subsidiary> getRootService() {
		return service;
	}

	@Override
	public CompositeEnterprisePK<Long> newEntityPK() {
		return new CompositeEnterprisePK<>();
	}
}
