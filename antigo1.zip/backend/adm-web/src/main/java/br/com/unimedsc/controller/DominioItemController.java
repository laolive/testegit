package br.com.unimedsc.controller;

import javax.inject.Inject;
import javax.ws.rs.Path;

import org.springframework.stereotype.Component;

import br.com.unimedsc.core.controller.ServiceControllerAbstract;
import br.com.unimedsc.core.entity.pk.SimplePK;
import br.com.unimedsc.core.service.Service;
import br.com.unimedsc.entities.adm.DominioItem;
import br.com.unimedsc.service.DominioItemService;

@Component
@Path("dominioItem")
public class DominioItemController extends ServiceControllerAbstract<Integer, SimplePK<Integer>, DominioItem> {

    @Inject
    DominioItemService dominioItemService;
    
    @Override
    public DominioItem newEntity() {
        return new DominioItem();
    }

    @Override
    public Service<SimplePK<Integer>, DominioItem> getRootService() {
        return dominioItemService;
    }

    @Override
    public SimplePK<Integer> newEntityPK() {
        return new SimplePK<Integer>();
    }
}
