package br.com.unimedsc.controller;

import javax.inject.Inject;
import javax.ws.rs.Consumes;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Component;

import br.com.unimedsc.core.annotation.UFOperationPermission;
import br.com.unimedsc.core.annotation.UFTansactionHijacker;
import br.com.unimedsc.core.controller.ServiceControllerAbstract;
import br.com.unimedsc.core.entity.pk.SimplePK;
import br.com.unimedsc.core.exception.UFException;
import br.com.unimedsc.core.service.Service;
import br.com.unimedsc.core.utils.CommonsHelper;
import br.com.unimedsc.entities.adm.User;
import br.com.unimedsc.service.UserService;
import br.com.unimedsc.system.Operation;
import br.com.unimedsc.vo.UserUpdatePasswordVO;

@Component
@Path("user")
public class UserController extends ServiceControllerAbstract<Long, SimplePK<Long>, User> {

	@Inject
	private UserService userService;

	@Override
	public User newEntity() {
		return new User();
	}

	@Override
	public Service<SimplePK<Long>, User> getRootService() {
		return userService;
	}

	@Override
	public SimplePK<Long> newEntityPK() {
		return new SimplePK<Long>();
	}

	@Override
	@UFTansactionHijacker("UserController.insert")
	@UFOperationPermission(operation = Operation.INSERT)
	public Object insert(User entity) throws Exception {
	    String passwordEncrypt = new BCryptPasswordEncoder().encode(entity.getPassword());
		entity.setPassword(passwordEncrypt);
		User user = getRootService().insert(entity);

		return returnDefault(user);
	}

	@PUT
	@Path("updatePassword")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes({ MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
	@UFTansactionHijacker("UserController.updatePassword")
	@UFOperationPermission(operation = Operation.INSERT)
	public Object updatePassword(UserUpdatePasswordVO updatePasswordVO) throws Exception {
		try {
			userService.updatePassword(updatePasswordVO);
		} catch (UFException e) {
			return CommonsHelper.getInstance().DynamicItemVO(super.request, null, e.getReturnError(), false);
		}

		return null;
	}

	@POST
	@Path("findByLogin")
	@Produces(MediaType.APPLICATION_JSON)
	@UFTansactionHijacker("UserController.findByLogin")
	@UFOperationPermission(operation = Operation.FIND)
	public Object findByLogin(@FormParam("login") String login) throws Exception {
		User user = userService.findByLogin(login);

		return returnDefault(user);
	}

	@GET
	@Path("recoverPassword/{login}/{email}")
	@Produces(MediaType.APPLICATION_JSON)
	@UFTansactionHijacker("UserController.validateToken")
	public Object recoverPassword(@PathParam("login") String login, @PathParam("email") String email) throws Exception {
		return userService.recoverPassword(request, login, email);
	}

	@PUT
	@Path("recoverPassword/validToken")
	@Produces(MediaType.APPLICATION_JSON)
	@UFTansactionHijacker("UserController.validateToken")
	public Object validateToken(UserUpdatePasswordVO updatePasswordVO) throws Exception {
		return userService.validateToken(updatePasswordVO);
	}

}
