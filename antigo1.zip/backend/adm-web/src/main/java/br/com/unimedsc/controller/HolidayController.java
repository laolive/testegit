package br.com.unimedsc.controller;

import br.com.unimedsc.core.controller.AbstractController;
import br.com.unimedsc.core.entity.pk.CompositeEnterprisePK;
import br.com.unimedsc.core.service.Service;
import br.com.unimedsc.core.utils.CommonsHelper;
import br.com.unimedsc.entities.adm.Holiday;
import br.com.unimedsc.entities.vo.HolidayReturnVO;
import br.com.unimedsc.service.HolidayService;
import br.com.unimedsc.system.ReturnDefault;
import br.com.unimedsc.vo.HolidayParamsVO;
import org.springframework.stereotype.Component;

import javax.inject.Inject;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import java.io.IOException;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component
@Path("holiday")
public class HolidayController extends AbstractController<Calendar, CompositeEnterprisePK<Calendar>, Holiday> {

    @Inject
    HolidayService service;

    @Override
    public Service<CompositeEnterprisePK<Calendar>, Holiday> getRootService() {
        return service;
    }

    @Override
    public Holiday newEntity() {
        return new Holiday();
    }

    @Override
    public CompositeEnterprisePK<Calendar> newEntityPK() {
        return new CompositeEnterprisePK<Calendar>();
    }

    @Path("findHolidayAnnual")
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    public Object findHolidayAnnual(HolidayParamsVO holidayParamsVO) throws IOException, IllegalAccessException {
        Map<String, Object> holidayMap = new HashMap<>();
        holidayMap.put("code", 200);
        holidayMap.put("entity", service.findHolidayAnnual(holidayParamsVO));
        return CommonsHelper.getInstance().DynamicItemVO(request, null, holidayMap);
    }
}
