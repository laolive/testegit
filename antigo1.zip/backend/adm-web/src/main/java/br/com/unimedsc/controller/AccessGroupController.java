package br.com.unimedsc.controller;

import javax.inject.Inject;
import javax.ws.rs.Path;

import org.springframework.stereotype.Component;

import br.com.unimedsc.core.controller.AbstractController;
import br.com.unimedsc.core.entity.pk.CompositeEnterprisePK;
import br.com.unimedsc.core.service.Service;
import br.com.unimedsc.entities.adm.AccessGroup;
import br.com.unimedsc.service.AccessGroupService;

@Component
@Path("accessGroup")
public class AccessGroupController extends AbstractController<Long, CompositeEnterprisePK<Long>, AccessGroup> {

	@Inject
	private AccessGroupService accessGroupService;

	@Override
	public AccessGroup newEntity() {
		return new AccessGroup();
	}

	@Override
	public Service<CompositeEnterprisePK<Long>, AccessGroup> getRootService() {
		return accessGroupService;
	}

	@Override
	public CompositeEnterprisePK<Long> newEntityPK() {
		return new CompositeEnterprisePK<Long>();
	}
}
