package br.com.unimedsc.controller;

import javax.inject.Inject;
import javax.ws.rs.Path;

import org.springframework.stereotype.Component;

import br.com.unimedsc.core.controller.AbstractController;
import br.com.unimedsc.core.service.Service;
import br.com.unimedsc.entities.adm.AccessGroupMenu;
import br.com.unimedsc.entities.pk.AccessGroupCompositePK;
import br.com.unimedsc.service.AccessGroupMenuService;

@Component
@Path("accessGroupMenu")
public class AccessGroupMenuController extends AbstractController<Long, AccessGroupCompositePK<Long>, AccessGroupMenu> {

	@Inject
	private AccessGroupMenuService accessGroupMenuService;

	@Override
	public AccessGroupMenu newEntity() {
		return new AccessGroupMenu();
	}

	@Override
	public Service<AccessGroupCompositePK<Long>, AccessGroupMenu> getRootService() {
		return accessGroupMenuService;
	}

	@Override
	public AccessGroupCompositePK<Long> newEntityPK() {
		return new AccessGroupCompositePK<Long>();
	}
}