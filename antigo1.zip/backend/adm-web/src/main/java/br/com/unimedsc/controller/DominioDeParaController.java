package br.com.unimedsc.controller;

import br.com.unimedsc.core.annotation.UFTansactionHijacker;
import br.com.unimedsc.core.controller.ServiceControllerAbstract;
import br.com.unimedsc.core.exception.UFException;
import br.com.unimedsc.core.service.Service;
import br.com.unimedsc.core.utils.CommonsHelper;
import br.com.unimedsc.entities.adm.DominioDePara;
import br.com.unimedsc.entities.pk.DominioDeParaPK;
import br.com.unimedsc.service.DominioDeParaService;
import org.springframework.stereotype.Component;

import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@Component
@Path("dominioDePara")
public class DominioDeParaController extends ServiceControllerAbstract<Long, DominioDeParaPK<Long, Long, Long, Long>, DominioDePara> {

    @Inject
    DominioDeParaService dominioDeParaService;

    @Override
    public DominioDePara newEntity() {
        return new DominioDePara();
    }

    @Override
    public Service<DominioDeParaPK<Long, Long, Long, Long>, DominioDePara> getRootService() {
        return dominioDeParaService;
    }

    @Override
    public DominioDeParaPK<Long, Long, Long, Long> newEntityPK() {
        return new DominioDeParaPK<Long, Long, Long, Long>();
    }

    @GET
    @Path("/findByDominioItemIdDe/{dominioItemIdDe}")
    @Produces(MediaType.APPLICATION_JSON)
    @UFTansactionHijacker("DominioDeParaController.getItem")
    public Object getItemDe(@PathParam("dominioItemIdDe") Long dominioItemIdDe) throws Exception {
        DominioDePara dominioDePara = dominioDeParaService.findByDominioItemIdDe(dominioItemIdDe);

        if (dominioDePara == null) {
            throw new UFException(String.format("Domínio de para Id '%s' não encontrado", dominioItemIdDe));
        }

        return CommonsHelper.getInstance().DynamicItemVO(super.request, null, dominioDePara, false);
    }

    @GET
    @Path("/findByDominioItemIdPara/{dominioItemIdPara}")
    @Produces(MediaType.APPLICATION_JSON)
    @UFTansactionHijacker("DominioDeParaController.getItem")
    public Object getItemPara(@PathParam("dominioItemIdPara") Long dominioItemIdPara) throws Exception {
        DominioDePara dominioParaDe = dominioDeParaService.findByDominioItemIdPara(dominioItemIdPara);

        if (dominioParaDe == null) {
            throw new UFException(String.format("Domínio de para Id '%s' não encontrado", dominioItemIdPara));
        }

        return CommonsHelper.getInstance().DynamicItemVO(super.request, null, dominioParaDe, false);
    }
}
