package br.com.unimedsc.controller;

import javax.inject.Inject;
import javax.ws.rs.Path;

import org.springframework.stereotype.Component;

import br.com.unimedsc.core.controller.AbstractController;
import br.com.unimedsc.core.entity.pk.SimplePK;
import br.com.unimedsc.core.service.Service;
import br.com.unimedsc.entities.erp.Module;
import br.com.unimedsc.service.ModuleService;

@Component
@Path("module")
public class ModuleController extends AbstractController<String, SimplePK<String>, Module>{
	@Inject
	ModuleService moduleService;
	
	@Override
	public Module newEntity() {
		return new Module();
	}

	@Override
	public Service<SimplePK<String>, Module> getRootService() {	
		return moduleService;
	}
	
	@Override
	public SimplePK<String> newEntityPK() {
		return new SimplePK<String>();
	}
}
