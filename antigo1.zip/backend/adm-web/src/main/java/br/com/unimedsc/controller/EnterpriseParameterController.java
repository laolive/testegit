package br.com.unimedsc.controller;

import javax.inject.Inject;
import javax.ws.rs.Path;

import org.springframework.stereotype.Component;

import br.com.unimedsc.core.controller.ServiceControllerAbstract;
import br.com.unimedsc.core.entity.pk.CompositeEnterprisePK;
import br.com.unimedsc.core.service.Service;
import br.com.unimedsc.entities.adm.EnterpriseParameter;
import br.com.unimedsc.service.EnterpriseParameterService;

@Component
@Path("enterpriseParameter")
public class EnterpriseParameterController extends ServiceControllerAbstract<String, CompositeEnterprisePK<String>, EnterpriseParameter> {
	
	@Inject
	private EnterpriseParameterService enterpriseParameterService;

	@Override
	public Service<CompositeEnterprisePK<String>, EnterpriseParameter> getRootService() {
		return enterpriseParameterService;
	}

	@Override
	public EnterpriseParameter newEntity() {
		return new EnterpriseParameter();
	}

	@Override
	public CompositeEnterprisePK<String> newEntityPK() {
		return new CompositeEnterprisePK<String>();
	}

}
