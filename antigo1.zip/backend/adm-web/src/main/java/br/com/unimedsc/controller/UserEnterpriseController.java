package br.com.unimedsc.controller;

import javax.inject.Inject;
import javax.ws.rs.Path;

import org.springframework.stereotype.Component;

import br.com.unimedsc.core.controller.ServiceControllerAbstract;
import br.com.unimedsc.core.entity.pk.CompositeEnterprisePK;
import br.com.unimedsc.core.service.Service;
import br.com.unimedsc.entities.adm.UserEnterprise;
import br.com.unimedsc.service.UserEnterpriseService;

@Component
@Path("userEnterprise")
public class UserEnterpriseController extends ServiceControllerAbstract<Long, CompositeEnterprisePK<Long>, UserEnterprise>{
	
	@Inject
	private UserEnterpriseService userEnterpriseService;

	@Override
	public Service<CompositeEnterprisePK<Long>, UserEnterprise> getRootService() {
		return userEnterpriseService;
	}

	@Override
	public UserEnterprise newEntity() {
		return new UserEnterprise();
	}

	@Override
	public CompositeEnterprisePK<Long> newEntityPK() {
		return new CompositeEnterprisePK<Long>();
	}

}
