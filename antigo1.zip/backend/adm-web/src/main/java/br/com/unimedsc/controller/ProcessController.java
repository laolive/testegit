package br.com.unimedsc.controller;

import javax.inject.Inject;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.springframework.stereotype.Component;

import br.com.unimedsc.core.annotation.UFTansactionHijacker;
import br.com.unimedsc.core.controller.ServiceControllerAbstract;
import br.com.unimedsc.core.entity.pk.SimplePK;
import br.com.unimedsc.core.service.Service;
import br.com.unimedsc.core.utils.CommonsHelper;
import br.com.unimedsc.entities.erp.Process;
import br.com.unimedsc.entities.erp.dto.ProcessParamsDTO;
import br.com.unimedsc.service.ProcessService;

@Component
@Path("process")
public class ProcessController extends ServiceControllerAbstract<Long, SimplePK<Long>, Process> {
	@Inject
	ProcessService service;

	@Override
	public Process newEntity() {
		return new Process();
	}

	@Override
	public Service<SimplePK<Long>, Process> getRootService() {
		return service;
	}

	@Override
	public SimplePK<Long> newEntityPK() {
		return new SimplePK<Long>();
	}

	
	@POST
	@Path(value = "startProcess")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	@UFTansactionHijacker("ProcessController.startProcess")
	public Object startProcess(ProcessParamsDTO processParamsDTO) throws Exception {
		return CommonsHelper.getInstance().DynamicItemVO(super.request, null, service.startProcess(processParamsDTO), false);
	}
	
	@POST
	@Path(value = "updateProcessPercentual")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	@UFTansactionHijacker("ProcessController.updateProcessPercentual")
	public Object updateProcessPercentual(ProcessParamsDTO processParamsDTO) throws Exception {
		return CommonsHelper.getInstance().DynamicItemVO(super.request, null, service.updateProcessPercentual(processParamsDTO), false);
	}
	
	@POST
	@Path(value = "finishProcess")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	@UFTansactionHijacker("ProcessController.finishProcess")
	public Object finishProcess(ProcessParamsDTO processParamsDTO) throws Exception {
		return CommonsHelper.getInstance().DynamicItemVO(super.request, null, service.finishProcess(processParamsDTO), false);
	}

}