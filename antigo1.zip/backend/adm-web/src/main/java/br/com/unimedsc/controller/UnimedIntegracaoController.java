package br.com.unimedsc.controller;

import javax.inject.Inject;
import javax.ws.rs.Path;

import org.springframework.stereotype.Component;

import br.com.unimedsc.core.controller.AbstractController;
import br.com.unimedsc.core.entity.pk.SimplePK;
import br.com.unimedsc.core.service.Service;
import br.com.unimedsc.entities.erp.UnimedIntegracao;
import br.com.unimedsc.service.UnimedIntegracaoService;

@Component
@Path("unimedIntegracoes")
public class UnimedIntegracaoController extends AbstractController<Long, SimplePK<Long>, UnimedIntegracao> {

    @Inject
    private UnimedIntegracaoService unimedIntegracaoService;

    @Override
    public UnimedIntegracao newEntity() {
        return new UnimedIntegracao();
    }

    @Override
    public Service<SimplePK<Long>, UnimedIntegracao> getRootService() {
        return unimedIntegracaoService;
    }

    @Override
    public SimplePK<Long> newEntityPK() {
        return new SimplePK<Long>();
    }
}
