package br.com.unimedsc.controller;

import javax.inject.Inject;
import javax.ws.rs.Path;

import org.springframework.stereotype.Component;

import br.com.unimedsc.core.controller.AbstractController;
import br.com.unimedsc.core.service.Service;
import br.com.unimedsc.entities.cfg.Search;
import br.com.unimedsc.entities.pk.PanelCompositePK;
import br.com.unimedsc.service.SearchService;

@Component
@Path("search")
public class SearchController extends AbstractController<Long, PanelCompositePK<Long>, Search> {

	@Inject
	private SearchService searchService;

	@Override
	public Service<PanelCompositePK<Long>, Search> getRootService() {
		return searchService;
	}

	@Override
	public Search newEntity() {
		return new Search();
	}

	@Override
	public PanelCompositePK<Long> newEntityPK() {
		return new PanelCompositePK<Long>();
	}

}
