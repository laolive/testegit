package br.com.unimedsc.controller;

import br.com.unimedsc.core.annotation.UFTansactionHijacker;
import br.com.unimedsc.core.controller.ServiceControllerAbstract;
import br.com.unimedsc.core.entity.pk.SimplePK;
import br.com.unimedsc.core.exception.UFException;
import br.com.unimedsc.core.service.Service;
import br.com.unimedsc.core.utils.CommonsHelper;
import br.com.unimedsc.entities.adm.Dominio;
import br.com.unimedsc.entities.adm.DominioItem;
import br.com.unimedsc.service.DominioItemService;
import br.com.unimedsc.service.DominioService;
import org.springframework.stereotype.Component;

import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import java.util.ArrayList;
import java.util.List;

@Component
@Path("dominios")
public class DominioController extends ServiceControllerAbstract<Integer, SimplePK<Integer>, Dominio> {

    @Inject
    private DominioService dominioService;

    @Inject
    private DominioItemService dominioItemService;

    @Override
    public Dominio newEntity() {
        return new Dominio();
    }

    @Override
    public Service<SimplePK<Integer>, Dominio> getRootService() {
        return dominioService;
    }

    @Override
    public SimplePK<Integer> newEntityPK() {
        return new SimplePK<Integer>();
    }

    @GET
    @Path("{nome}")
    @Produces(MediaType.APPLICATION_JSON)
    @UFTansactionHijacker("DominioController.getItems")
    public Object getItems(@PathParam("nome") String nome) throws Exception {
        Dominio dominio = dominioService.findByNome(nome);

        if (dominio == null) {
            throw new UFException(String.format("Domínio '%s' não encontrado", nome));
        }

        List<DominioItem> dominioItems = dominioItemService.findAllByDominio(dominio);

        List<Object> dominioItemsObject = new ArrayList<>(dominioItems);

        return CommonsHelper.getInstance().DynamicListVO(super.request, null, dominioItemsObject, false);
    }

    @GET
    @Path("{nome}/{valor}")
    @Produces(MediaType.APPLICATION_JSON)
    @UFTansactionHijacker("DominioController.getItem")
    public Object getItem(@PathParam("nome") String nome, @PathParam("valor") String valor) throws Exception {
        Dominio dominio = dominioService.findByNome(nome);

        if (dominio == null) {
            throw new UFException(String.format("Domínio '%s' não encontrado", nome));
        }

        DominioItem dominioItem = dominioItemService.findByValor(dominio, valor);

        if (dominioItem == null) {
            return null;
        }

        return CommonsHelper.getInstance().DynamicItemVO(super.request, null, dominioItem, false);
    }

    @GET
    @Path("/findById/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    @UFTansactionHijacker("DominioController.getItemId")
    public Object getItemId(@PathParam("id") Integer id) throws Exception {
        SimplePK<Integer> pk = new SimplePK<Integer>();
        pk.setId(id);

        DominioItem dominioItem = dominioItemService.findById(pk);

        if (dominioItem == null) {
            throw new UFException(String.format("Item '%s' não encontrado", id));
        }

        return CommonsHelper.getInstance().DynamicItemVO(super.request, null, dominioItem, false);
    }

    @GET
    @Path("/getAll")
    @Produces(MediaType.APPLICATION_JSON)
    @UFTansactionHijacker("DominioController.getAll")
    public Object getAll() throws Exception {
        return this.returnDefault(dominioService.findAll());
    }
}
