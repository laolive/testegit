package br.com.unimedsc.controller;

import javax.inject.Inject;
import javax.ws.rs.Path;

import org.springframework.stereotype.Component;

import br.com.unimedsc.core.controller.ServiceControllerAbstract;
import br.com.unimedsc.core.service.Service;
import br.com.unimedsc.entities.erp.RoutineFilter;
import br.com.unimedsc.entities.pk.RoutineCompositePK;
import br.com.unimedsc.service.RoutineFilterService;

@Component
@Path("routineFilter")
public class RoutineFilterController extends ServiceControllerAbstract<Long, RoutineCompositePK<Long>, RoutineFilter> {

	@Inject
	private RoutineFilterService routineFilterService;

	@Override
	public RoutineFilter newEntity() {
		return new RoutineFilter();
	}

	@Override
	public Service<RoutineCompositePK<Long>, RoutineFilter> getRootService() {
		return routineFilterService;
	}

	@Override
	public RoutineCompositePK<Long> newEntityPK() {
		return new RoutineCompositePK<Long>();
	}

}
