package br.com.unimedsc.controller;

import javax.inject.Inject;
import javax.ws.rs.Path;

import org.springframework.stereotype.Component;

import br.com.unimedsc.core.controller.ServiceControllerAbstract;
import br.com.unimedsc.core.entity.pk.CompositeEnterprisePK;
import br.com.unimedsc.core.service.Service;
import br.com.unimedsc.entities.erp.EnterpriseArchive;
import br.com.unimedsc.service.EnterpriseArchiveService;

@Component
@Path("enterpriseArchive")
public class EnterpriseArchiveController extends ServiceControllerAbstract<Long, CompositeEnterprisePK<Long>, EnterpriseArchive> {

	@Inject
	private EnterpriseArchiveService enterpriseArchiveService;

	@Override
	public EnterpriseArchive newEntity() {
		return new EnterpriseArchive();
	}

	@Override
	public Service<CompositeEnterprisePK<Long>, EnterpriseArchive> getRootService() {
		return enterpriseArchiveService;
	}

	@Override
	public CompositeEnterprisePK<Long> newEntityPK() {
		return new CompositeEnterprisePK<Long>();
	}
}
