package br.com.unimedsc.controller;

import javax.inject.Inject;
import javax.ws.rs.Path;

import org.springframework.stereotype.Component;

import br.com.unimedsc.core.controller.ServiceControllerAbstract;
import br.com.unimedsc.core.entity.pk.DoubleCompositePK;
import br.com.unimedsc.core.service.Service;
import br.com.unimedsc.entities.erp.Domain;
import br.com.unimedsc.service.DomainService;

@Component
@Path("domain")
public class DomainController extends ServiceControllerAbstract<String, DoubleCompositePK<String, String>, Domain> {

	@Inject
	DomainService domainService;

	@Override
	public Domain newEntity() {
		return new Domain();
	}

	@Override
	public Service<DoubleCompositePK<String, String>, Domain> getRootService() {
		return domainService;
	}

	@Override
	public DoubleCompositePK<String, String> newEntityPK() {
		return new DoubleCompositePK<String, String>();
	}

}
