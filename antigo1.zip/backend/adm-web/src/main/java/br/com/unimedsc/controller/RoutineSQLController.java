package br.com.unimedsc.controller;

import javax.inject.Inject;
import javax.ws.rs.Path;

import org.springframework.stereotype.Component;

import br.com.unimedsc.core.controller.ServiceControllerAbstract;
import br.com.unimedsc.core.entity.pk.SimplePK;
import br.com.unimedsc.core.service.Service;
import br.com.unimedsc.entities.erp.RoutineSQL;
import br.com.unimedsc.service.RoutineSQLService;

@Component
@Path("routineSQL")
public class RoutineSQLController extends ServiceControllerAbstract<Long, SimplePK<Long>, RoutineSQL> {

	@Inject
	private RoutineSQLService routineSQLService;

	@Override
	public RoutineSQL newEntity() {
		return new RoutineSQL();
	}

	@Override
	public Service<SimplePK<Long>, RoutineSQL> getRootService() {
		return routineSQLService;
	}

	@Override
	public SimplePK<Long> newEntityPK() {
		return new SimplePK<Long>();
	}

}
