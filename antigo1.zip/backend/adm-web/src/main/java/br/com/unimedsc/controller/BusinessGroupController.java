package br.com.unimedsc.controller;

import javax.inject.Inject;
import javax.ws.rs.Path;

import org.springframework.stereotype.Component;

import br.com.unimedsc.core.controller.AbstractController;
import br.com.unimedsc.core.entity.pk.SimplePK;
import br.com.unimedsc.core.service.Service;
import br.com.unimedsc.entities.erp.BusinessGroup;
import br.com.unimedsc.service.BusinessGroupService;

@Component
@Path("businessGroup")
public class BusinessGroupController extends AbstractController<Long, SimplePK<Long>, BusinessGroup> {

	@Inject
	private BusinessGroupService service;

	@Override
	public BusinessGroup newEntity() {
		return new BusinessGroup();
	}

	@Override
	public Service<SimplePK<Long>, BusinessGroup> getRootService() {
		return service;
	}

	@Override
	public SimplePK<Long> newEntityPK() {
		return new SimplePK<Long>();
	}
}
