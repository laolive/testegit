package br.com.unimedsc.controller;

import java.io.IOException;

import javax.inject.Inject;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.JsonMappingException;

import br.com.unimedsc.core.annotation.UFTansactionHijacker;
import br.com.unimedsc.core.controller.ServiceControllerAbstract;
import br.com.unimedsc.core.entity.pk.SimplePK;
import br.com.unimedsc.core.service.Service;
import br.com.unimedsc.core.utils.CommonsHelper;
import br.com.unimedsc.entities.erp.Routine;
import br.com.unimedsc.service.RoutineService;
import br.com.unimedsc.vo.RoutineParamsVO;

@Component
@Path("routine")
public class RoutineController extends ServiceControllerAbstract<Long, SimplePK<Long>, Routine> {

	@Inject
	private RoutineService routineService;

	@Override
	public Routine newEntity() {
		return new Routine();
	}

	@Override
	public Service<SimplePK<Long>, Routine> getRootService() {
		return routineService;
	}

	@Override
	public SimplePK<Long> newEntityPK() {
		return new SimplePK<Long>();
	}

	@POST
	@Path(value = "confirmRoutine")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	@UFTansactionHijacker("RoutineController.confirmRoutine")
	public Object confirmRoutine(RoutineParamsVO routineParamsVO) throws JsonGenerationException, JsonMappingException,
			IllegalArgumentException, IllegalAccessException, IOException, Exception {
		return CommonsHelper.getInstance().DynamicItemVO(super.request, null, routineService.confirmRoutine(routineParamsVO), false);

	}
}
