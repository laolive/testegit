package br.com.unimedsc.controller;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;

import javax.inject.Inject;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.commons.fileupload.FileUploadException;
import org.springframework.stereotype.Component;

import br.com.unimedsc.core.annotation.UFOperationPermission;
import br.com.unimedsc.core.controller.AbstractController;
import br.com.unimedsc.core.entity.pk.CompositeEnterprisePK;
import br.com.unimedsc.core.entity.pk.SimplePK;
import br.com.unimedsc.core.exception.UFException;
import br.com.unimedsc.core.filter.FilterHelper;
import br.com.unimedsc.core.filter.Junction;
import br.com.unimedsc.core.filter.Node;
import br.com.unimedsc.core.filter.Operator;
import br.com.unimedsc.core.filter.Value;
import br.com.unimedsc.core.service.Service;
import br.com.unimedsc.core.utils.SessionUtil;
import br.com.unimedsc.entities.erp.Archive;
import br.com.unimedsc.service.ArchiveService;
import br.com.unimedsc.system.Operation;
import io.minio.MinioClient;
import io.minio.ObjectStat;

@Component
@Path("archive")
public class ArchiveController extends AbstractController<Long, SimplePK<Long>, Archive> {

    private static final int BUFFER_SIZE = 10 * 1024 * 1024;

    @org.springframework.beans.factory.annotation.Value("${minio.host}")
    private String minioHost;

    @org.springframework.beans.factory.annotation.Value("${minio.username}")
    private String minioUsername;

    @org.springframework.beans.factory.annotation.Value("${minio.password}")
    private String minioPassword;

    @Inject
    private ArchiveService archiveService;

    @Override
    public Service<SimplePK<Long>, Archive> getRootService() {
        return archiveService;
    }

    @Override
    public Archive newEntity() {
        return new Archive();
    }

    @Override
    public CompositeEnterprisePK<Long> newEntityPK() {
        return new CompositeEnterprisePK<Long>();
    }

    @POST
    @Path("send")
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes({MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA})
    public Response upload(@QueryParam("nameBucket")String nameBucket, @QueryParam("path")String path) throws Exception {        
        try {
            return Response.ok(super.returnDefault(archiveService.uploadFile(request,
                    SessionUtil.getInstance().getUserId(),
                    SessionUtil.getInstance().getEnterpriseId(),
                    nameBucket,
                    path)),
                    MediaType.APPLICATION_JSON).build();
        } catch (UFException | FileUploadException | IOException e) {
            return Response.ok(e.getMessage(), MediaType.APPLICATION_JSON).build();
        }
    }

    @POST
    @Path("getById")
    @UFOperationPermission(operation = Operation.FIND)
    public void downloadById(@Context HttpServletResponse response, CompositeEnterprisePK<Long> pk) throws Exception {
        Archive archive = archiveService.findById(pk);
        this.getFile(response, archive);
    }

    @GET
    @Path("getByUUID/{uuid}")
    public void downloadById(@Context HttpServletResponse response, @PathParam("uuid") String uuid) throws Exception {

        Node node = FilterHelper.createTree(Junction.AND);
        FilterHelper.addCondition(node, "identifier", Operator.EQUAL, new Value<String>(uuid));

        List<Archive> upload = archiveService.findAllByFilter(node, null);

        if (upload != null && upload.size() > 0)
            this.getFile(response, upload.get(0));
    }

    private void getFile(HttpServletResponse response, Archive archive) throws Exception {

        MinioClient minio = new MinioClient(minioHost, minioUsername, minioPassword);

        ObjectStat objectStat = minio.statObject(archive.getNameBucket(), archive.getIdentifier());

        InputStream stream = minio.getObject(archive.getNameBucket(), archive.getIdentifier());

        String mimeType = archive.getExtension();

        response.setContentType(mimeType);
        response.setHeader("Content-Length", String.valueOf(objectStat.length()));

        String headerKey = "Content-Disposition";
        String headerValue = String.format("attachment; filename=\"%s\"", archive.getFileName());
        response.setHeader(headerKey, headerValue);

        OutputStream outStream = response.getOutputStream();

        byte[] buffer = new byte[BUFFER_SIZE];
        int bytesRead = -1;

        while ((bytesRead = stream.read(buffer)) != -1) {
            outStream.write(buffer, 0, bytesRead);
        }

        stream.close();
        outStream.close();
    }
}
