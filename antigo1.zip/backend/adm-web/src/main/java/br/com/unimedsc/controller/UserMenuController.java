package br.com.unimedsc.controller;

import javax.inject.Inject;
import javax.ws.rs.Path;

import org.springframework.stereotype.Component;

import br.com.unimedsc.core.controller.ServiceControllerAbstract;
import br.com.unimedsc.core.service.Service;
import br.com.unimedsc.entities.adm.UserMenu;
import br.com.unimedsc.entities.pk.MenuCompositePK;
import br.com.unimedsc.service.MenuService;
import br.com.unimedsc.service.UserMenuService;

@Component
@Path("userMenu")
public class UserMenuController extends ServiceControllerAbstract<Long, MenuCompositePK<Long>, UserMenu> {

	@Inject
	private UserMenuService userMenuService;
	
	@Inject MenuService menuService;

	@Override
	public Service<MenuCompositePK<Long>, UserMenu> getRootService() {
		return userMenuService;
	}

	@Override
	public UserMenu newEntity() {
		return new UserMenu();
	}

	@Override
	public MenuCompositePK<Long> newEntityPK() {
		return new MenuCompositePK<Long>();
	}
}