package br.com.unimedsc.controller;

import javax.inject.Inject;
import javax.ws.rs.Path;

import org.springframework.stereotype.Component;

import br.com.unimedsc.core.controller.ServiceControllerAbstract;
import br.com.unimedsc.core.entity.pk.CompositeEnterprisePK;
import br.com.unimedsc.core.service.Service;
import br.com.unimedsc.entities.erp.UnimedEnterprise;
import br.com.unimedsc.service.UnimedEnterpriseService;

@Component
@Path("unimedEnterprise")
public class UnimedEnterpriseController extends ServiceControllerAbstract<Long, CompositeEnterprisePK<Long>, UnimedEnterprise> {

	@Inject
	UnimedEnterpriseService unimedEnterpriseService;

	@Override
	public UnimedEnterprise newEntity() {
		return new UnimedEnterprise();
	}

	@Override
	public Service<CompositeEnterprisePK<Long>, UnimedEnterprise> getRootService() {
		return unimedEnterpriseService;
	}

	@Override
	public CompositeEnterprisePK<Long> newEntityPK() {
		return new CompositeEnterprisePK<Long>();
	}

}
