package br.com.unimedsc.controller;

import javax.inject.Inject;
import javax.ws.rs.Path;

import org.springframework.stereotype.Component;

import br.com.unimedsc.core.controller.ServiceControllerAbstract;
import br.com.unimedsc.core.entity.pk.SimplePK;
import br.com.unimedsc.core.service.Service;
import br.com.unimedsc.entities.erp.Unimed;
import br.com.unimedsc.service.UnimedService;

@Component
@Path("unimed")
public class UnimedController extends ServiceControllerAbstract<Long, SimplePK<Long>, Unimed> {

	@Inject
	UnimedService unimedService;

	@Override
	public Unimed newEntity() {
		return new Unimed();
	}

	@Override
	public Service<SimplePK<Long>, Unimed> getRootService() {
		return unimedService;
	}

	@Override
	public SimplePK<Long> newEntityPK() {
		return new SimplePK<Long>();
	}

}
