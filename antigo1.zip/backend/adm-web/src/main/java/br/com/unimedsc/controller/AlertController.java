package br.com.unimedsc.controller;

import javax.inject.Inject;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.springframework.stereotype.Component;

import br.com.unimedsc.core.annotation.UFOperationPermission;
import br.com.unimedsc.core.annotation.UFTansactionHijacker;
import br.com.unimedsc.core.controller.AbstractController;
import br.com.unimedsc.core.entity.pk.SimplePK;
import br.com.unimedsc.core.service.Service;
import br.com.unimedsc.dto.AlertDTO;
import br.com.unimedsc.entities.erp.Alert;
import br.com.unimedsc.service.AlertService;
import br.com.unimedsc.system.Operation;

@Component
@Path("alert")
public class AlertController extends AbstractController<Long, SimplePK<Long>, Alert> {

	@Inject
	private AlertService alertService;

	@Override
	public Service<SimplePK<Long>, Alert> getRootService() {
		return alertService;
	}

	@Override
	public Alert newEntity() {
		return new Alert();
	}

	@Override
	public SimplePK<Long> newEntityPK() {
		return new SimplePK<Long>();
	}

	@POST
	@Path("newAlert")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes({ MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
	@UFTansactionHijacker(value = "AbstractController.newAlert")
	@UFOperationPermission(operation = Operation.INSERT)
	public Object newAlert(AlertDTO alert) throws Exception {
		return alertService.newAlert(alert);
	}

}
