package br.com.unimedsc.controller;

import br.com.unimedsc.core.utils.CommonsHelper;
import br.com.unimedsc.core.utils.SessionUtil;
import br.com.unimedsc.dto.MenuDTO;
import br.com.unimedsc.dto.TransactionDTO;
import br.com.unimedsc.entities.erp.Menu;
import br.com.unimedsc.entities.erp.Transaction;
import br.com.unimedsc.service.MenuService;
import br.com.unimedsc.service.TransactionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component
@Path("login")
public class LoginController {

    @Inject
    private MenuService menuService;

    @Autowired
    private TransactionService transactionService;

    @GET
    @Path("/loadParameter")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response login(@Context final HttpServletRequest request) throws Exception {
        Long userId = SessionUtil.getInstance().getUserId();
        Long enterpriseId = SessionUtil.getInstance().getEnterpriseId();

        Map<String, Object> loadParam = new HashMap<>();
        loadParam.put("menu", menuService.getMenuByUser(userId, enterpriseId));
        loadParam.put("permission", transactionService.getPermissionByUser(userId));

        return Response.status(Response.Status.OK)
                .entity(CommonsHelper.getInstance().DynamicItemVO(request, null, loadParam, true)).build();
    }

    private List<MenuDTO> parseMenu2MenuDTO(List<Menu> menus) {
        if (menus == null) return null;

        List<MenuDTO> menuDTOs = new ArrayList<>();

        for (Menu m : menus) {
            menuDTOs.add(parseMenu2MenuDTO(m));
        }

        return menuDTOs;
    }

    private MenuDTO parseMenu2MenuDTO(Menu menu) {
        if (menu == null) return null;

        return new MenuDTO(menu.getPk(), menu.getNameMenu(), menu.getHelpMenu(), menu.getDomainEnable(),
                null, menu.getOrderNumber(),
                parseTransaction2TransactionDTO(menu.getTrasaction()), menu.getParameterList(), menu.getKeyWord(),
                parseMenu2MenuDTO(menu.getChildren()));
    }

    private TransactionDTO parseTransaction2TransactionDTO(Transaction transaction) {
        if (transaction == null) return null;

        return new TransactionDTO(transaction.getPk().getId(),
                transaction.getTransactionName(), transaction.getTransactionRoute(), transaction.getAllowInsert(),
                transaction.getAllowUpdate(), transaction.getAllowDelete());
    }
}
