package br.com.unimedsc.controller;

import javax.inject.Inject;
import javax.ws.rs.Path;

import org.springframework.stereotype.Component;

import br.com.unimedsc.core.controller.ServiceControllerAbstract;
import br.com.unimedsc.core.service.Service;
import br.com.unimedsc.entities.adm.AccessGroupTransaction;
import br.com.unimedsc.entities.pk.AccessGroupCompositePK;
import br.com.unimedsc.service.AccessGroupTransactionService;

@Component
@Path("accessGroupTransaction")
public class AccessGroupTransactionController extends ServiceControllerAbstract<Long, AccessGroupCompositePK<Long>, AccessGroupTransaction> {

	@Inject
	private AccessGroupTransactionService accessGroupTransactionService;

	@Override
	public AccessGroupTransaction newEntity() {
		return new AccessGroupTransaction();
	}

	@Override
	public Service<AccessGroupCompositePK<Long>, AccessGroupTransaction> getRootService() {
		return accessGroupTransactionService;
	}

	@Override
	public AccessGroupCompositePK<Long> newEntityPK() {
		return new AccessGroupCompositePK<Long>();
	}
}