package br.com.unimedsc.controller;

import javax.inject.Inject;
import javax.ws.rs.Path;

import org.springframework.stereotype.Component;

import br.com.unimedsc.core.controller.AbstractController;
import br.com.unimedsc.core.controller.ServiceControllerAbstract;
import br.com.unimedsc.core.service.Service;
import br.com.unimedsc.entities.adm.AccessGroupParameter;
import br.com.unimedsc.entities.pk.AccessGroupCompositePK;
import br.com.unimedsc.service.AccessGroupParameterService;

@Component
@Path("accessGroupParameter")
public class AccessGroupParameterController extends ServiceControllerAbstract<String, AccessGroupCompositePK<String>, AccessGroupParameter> {
	
	@Inject
	private AccessGroupParameterService accessGroupParameterService;

	@Override
	public Service<AccessGroupCompositePK<String>, AccessGroupParameter> getRootService() {
		return accessGroupParameterService;
	}

	@Override
	public AccessGroupParameter newEntity() {
		return new AccessGroupParameter();
	}

	@Override
	public AccessGroupCompositePK<String> newEntityPK() {
		return new AccessGroupCompositePK<String>();
	}

}
