package br.com.unimedsc.controller;

import br.com.unimedsc.core.annotation.UFOperationPermission;
import br.com.unimedsc.core.annotation.UFTansactionHijacker;
import br.com.unimedsc.core.controller.ServiceControllerAbstract;
import br.com.unimedsc.core.entity.pk.SimplePK;
import br.com.unimedsc.core.service.Service;
import br.com.unimedsc.core.utils.CommonsHelper;
import br.com.unimedsc.core.utils.SessionUtil;
import br.com.unimedsc.entities.erp.Enterprise;
import br.com.unimedsc.service.EnterpriseService;
import br.com.unimedsc.system.Operation;
import org.springframework.stereotype.Component;

import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import java.util.ArrayList;

@Component
@Path("enterprise")
public class EnterpriseController extends ServiceControllerAbstract<Long, SimplePK<Long>, Enterprise> {

	@Inject
	EnterpriseService enterpriseService;

	@Override
	public Enterprise newEntity() {
		return new Enterprise();
	}

	@Override
	public Service<SimplePK<Long>, Enterprise> getRootService() {
		return enterpriseService;
	}

	@Override
	public SimplePK<Long> newEntityPK() {
		return new SimplePK<Long>();
	}

	@GET
	@Path("findAllbyUser")
	@Produces(MediaType.APPLICATION_JSON)
	@UFTansactionHijacker("EnterpriseController.findByUser")
	@UFOperationPermission(operation = Operation.FIND)
	public Object findByUser() throws Exception {
		return CommonsHelper.getInstance().DynamicListVO(super.request, null,
				new ArrayList<Object>(enterpriseService.findAllByUser(SessionUtil.getInstance().getUserId())), false);
	}

	@GET
	@Path("loggedEnterprise")
	@Produces(MediaType.APPLICATION_JSON)
	@UFTansactionHijacker("EnterpriseController.loggedEnterprise")
	@UFOperationPermission(operation = Operation.FIND)
	public Long loggedEnterprise() throws Exception {
		return SessionUtil.getInstance().getEnterpriseId();
	}
}
