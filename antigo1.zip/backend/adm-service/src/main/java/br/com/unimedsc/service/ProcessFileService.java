package br.com.unimedsc.service;

import br.com.unimedsc.core.service.Service;
import br.com.unimedsc.entities.erp.ProcessFile;
import br.com.unimedsc.entities.pk.ProcessCompositePK;

public interface ProcessFileService extends Service<ProcessCompositePK<Long>, ProcessFile> {

}
