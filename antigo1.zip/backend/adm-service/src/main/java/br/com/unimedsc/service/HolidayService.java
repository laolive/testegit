package br.com.unimedsc.service;

import br.com.unimedsc.core.entity.pk.CompositeEnterprisePK;
import br.com.unimedsc.core.service.Service;
import br.com.unimedsc.entities.adm.Holiday;
import br.com.unimedsc.entities.vo.HolidayReturnVO;
import br.com.unimedsc.vo.HolidayParamsVO;

import java.util.Calendar;
import java.util.List;

public interface HolidayService extends Service<CompositeEnterprisePK<Calendar>, Holiday> {
    List<HolidayReturnVO> findHolidayAnnual(HolidayParamsVO holidayParamsVO);
}
