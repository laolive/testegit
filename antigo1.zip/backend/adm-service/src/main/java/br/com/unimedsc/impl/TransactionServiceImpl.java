package br.com.unimedsc.impl;

import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import br.com.unimedsc.core.entity.pk.SimplePK;
import br.com.unimedsc.core.service.impl.ServiceImpl;
import br.com.unimedsc.dao.TransactionDAO;
import br.com.unimedsc.dto.TransactionDTO;
import br.com.unimedsc.entities.erp.Transaction;
import br.com.unimedsc.service.TransactionService;

@Service
public class TransactionServiceImpl extends ServiceImpl<SimplePK<Long>, Transaction, TransactionDAO>
		implements TransactionService {

	private static final long serialVersionUID = 1944544508181252600L;

	@Inject
	protected TransactionServiceImpl(TransactionDAO dao) {
		super(dao);
	}

	@Override
	public List<TransactionDTO> getPermissionByUser(Long userId) throws Exception {
		return dao.getPermissionByUser(userId);
	}
}
