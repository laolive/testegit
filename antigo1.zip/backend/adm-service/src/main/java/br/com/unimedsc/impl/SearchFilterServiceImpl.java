package br.com.unimedsc.impl;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import br.com.unimedsc.core.service.impl.ServiceImpl;
import br.com.unimedsc.dao.SearchFilterDAO;
import br.com.unimedsc.entities.cfg.SearchFilter;
import br.com.unimedsc.entities.pk.SearchCompositePK;
import br.com.unimedsc.service.SearchFilterService;

@Service
public class SearchFilterServiceImpl extends ServiceImpl<SearchCompositePK<Long>, SearchFilter, SearchFilterDAO>
		implements SearchFilterService {

	private static final long serialVersionUID = -5666614171883706130L;

	@Inject
	protected SearchFilterServiceImpl(SearchFilterDAO dao) {
		super(dao);
	}

}
