package br.com.unimedsc.impl;

import br.com.unimedsc.core.entity.pk.SimplePK;
import br.com.unimedsc.core.filter.*;
import br.com.unimedsc.core.service.impl.ServiceImpl;
import br.com.unimedsc.dao.DominioDAO;
import br.com.unimedsc.entities.adm.Dominio;
import br.com.unimedsc.service.DominioService;
import org.springframework.stereotype.Service;

import javax.inject.Inject;
import java.util.List;

@Service
public class DominioServiceImpl extends ServiceImpl<SimplePK<Integer>, Dominio, DominioDAO> implements DominioService {

    @Inject
    protected DominioServiceImpl(DominioDAO dao) {
        super(dao);
    }

    @Override
    public Dominio findByNome(String nome) throws Exception {
        Node node = FilterHelper.createTree(Junction.AND);
        FilterHelper.addCondition(node, "nome", Operator.EQUAL, new Value<>(nome.toUpperCase()));

        List<Dominio> dominios = super.findAllByFilter(node, null);

        Dominio dominio = null;

        if (!dominios.isEmpty()) {
            dominio = dominios.get(0);
        }

        return dominio;
    }

    @Override
    public List<Dominio> findAll() throws Exception {
        return super.findAll();
    }
}
