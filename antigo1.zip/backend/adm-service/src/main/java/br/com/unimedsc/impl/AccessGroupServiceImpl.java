package br.com.unimedsc.impl;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import br.com.unimedsc.core.entity.pk.CompositeEnterprisePK;
import br.com.unimedsc.core.service.impl.ServiceImpl;
import br.com.unimedsc.dao.AccessGroupDAO;
import br.com.unimedsc.entities.adm.AccessGroup;
import br.com.unimedsc.service.AccessGroupService;

@Service
public class AccessGroupServiceImpl extends ServiceImpl<CompositeEnterprisePK<Long>, AccessGroup, AccessGroupDAO> implements AccessGroupService {
	
	private static final long serialVersionUID = 2323390113201578548L;

	@Inject
	protected AccessGroupServiceImpl(AccessGroupDAO dao) {
		super(dao);
	}
}
