package br.com.unimedsc.dao;

import java.util.Calendar;

import org.springframework.stereotype.Component;

import br.com.unimedsc.core.dao.DAO;
import br.com.unimedsc.core.entity.pk.CompositeEnterprisePK;
import br.com.unimedsc.entities.adm.Holiday;

@Component
public class HolidayDAO extends DAO<CompositeEnterprisePK<Calendar>, Holiday> {

}
