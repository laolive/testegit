package br.com.unimedsc.impl;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import br.com.unimedsc.core.service.impl.ServiceImpl;
import br.com.unimedsc.dao.SearchDAO;
import br.com.unimedsc.entities.cfg.Search;
import br.com.unimedsc.entities.pk.PanelCompositePK;
import br.com.unimedsc.service.SearchService;

@Service
public class SearchServiceImpl extends ServiceImpl<PanelCompositePK<Long>, Search, SearchDAO>
		implements SearchService {

	private static final long serialVersionUID = 6689006427863265486L;

	@Inject
	protected SearchServiceImpl(SearchDAO dao) {
		super(dao);
	}

}
