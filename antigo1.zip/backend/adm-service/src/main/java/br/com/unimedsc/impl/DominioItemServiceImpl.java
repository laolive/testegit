package br.com.unimedsc.impl;

import br.com.unimedsc.core.entity.pk.SimplePK;
import br.com.unimedsc.core.filter.*;
import br.com.unimedsc.core.order.Order;
import br.com.unimedsc.core.service.impl.ServiceImpl;
import br.com.unimedsc.dao.DominioItemDAO;
import br.com.unimedsc.entities.adm.Dominio;
import br.com.unimedsc.entities.adm.DominioItem;
import br.com.unimedsc.service.DominioItemService;
import org.springframework.stereotype.Service;

import javax.inject.Inject;
import java.util.LinkedHashMap;
import java.util.List;

@Service
public class DominioItemServiceImpl extends ServiceImpl<SimplePK<Integer>, DominioItem, DominioItemDAO>
        implements DominioItemService {

    @Inject
    protected DominioItemServiceImpl(DominioItemDAO dao) {
        super(dao);
    }

    @Override
    public DominioItem findByValor(Dominio dominio, String valor) throws Exception {
        Node node = FilterHelper.createTree(Junction.AND);
        FilterHelper.addCondition(node, "dominio.id.id", Operator.EQUAL, new Value<>(dominio.getPk().getId()));
        FilterHelper.addCondition(node, "valor", Operator.EQUAL, new Value<>(valor));

        List<DominioItem> dominioItems = super.findAllByFilter(node, null);

        if (dominioItems.isEmpty()) {
            return null;
        }

        return dominioItems.get(0);
    }

    @Override
    public List<DominioItem> findAllByDominio(Dominio dominio) throws Exception {
        Node node = FilterHelper.createTree(Junction.AND);
        FilterHelper.addCondition(node, "dominio.id.id", Operator.EQUAL, new Value<>(dominio.getPk().getId()));

        LinkedHashMap<String, String> orderBy = new LinkedHashMap<>();
        orderBy.put("id", "ASC");

        return super.findAllByFilter(node, new Order(orderBy));
    }
}
