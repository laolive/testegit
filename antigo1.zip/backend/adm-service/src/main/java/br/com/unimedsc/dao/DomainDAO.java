package br.com.unimedsc.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.Query;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Component;

import br.com.unimedsc.common.DomainHelper;
import br.com.unimedsc.core.dao.DAO;
import br.com.unimedsc.core.entity.pk.DoubleCompositePK;
import br.com.unimedsc.core.utils.Pagination;
import br.com.unimedsc.entities.erp.Domain;


@Component
public class DomainDAO extends DAO<DoubleCompositePK<String, String>, Domain> {
	
	private String getDomainsFromTable(String tableName) throws Exception {
		StringBuilder result = new StringBuilder();
		
		String qryString = "SELECT DISTINCT "
				+ "REPLACE(SUBSTRB(UCC.COMMENTS,INSTR(UCC.COMMENTS, '|'),LENGTH(UCC.COMMENTS) - (INSTR(UCC.COMMENTS, '|') - 2)), '| ', '')"
				+ "FROM USER_COL_COMMENTS UCC "
				+ "WHERE UCC.TABLE_NAME NOT LIKE 'SGU30%' "
				+ "AND UCC.TABLE_NAME NOT LIKE 'BS%' "
				+ "AND UCC.COMMENTS           IS NOT NULL "
				+ "AND INSTR(UCC.COMMENTS,'|') > 0 "
				+ "AND UCC.TABLE_NAME = upper('" + tableName + "')";
		
		Query query = getEntityManager().createNativeQuery(qryString);
		
		for (Object domain : query.getResultList()) {
			if (result.length() > 0)
				result.append(" , ");
			
			result.append("'" + domain.toString() + "'");
		}
		
		return result.toString();
	}
	
	public List<Domain> findDomainByTableName(String tableName) throws Exception {

		String hql = super.dynamicQuery();
		
		hql = hql + " WHERE i.nameDomain IN (" + this.getDomainsFromTable(tableName) + ")";

		return super.findAllByQuery(hql.toString(), null);
	}
	public List<String> findAll(String querySearch) throws Exception{

		StringBuilder hql = new StringBuilder();
		hql.append("SELECT DISTINCT m.nameDomain FROM " + Domain.class.getName() + " m WHERE m.nameDomain LIKE '%" + querySearch.toUpperCase() +"%' "
				+ "OR m.maskDescriptionValue LIKE '%" + querySearch.toUpperCase() +"%'" );

		Map<String, Object> params = new HashMap<String, Object>();

		return super.findAllByQuery(hql.toString(), params);
	}

	public List<Domain> findDomainByName(String domainName) throws Exception{

		CriteriaBuilder cb = super.getEntityManager().getCriteriaBuilder();
		CriteriaQuery<Domain> query = cb.createQuery(Domain.class);
		Root<Domain> root = query.from(Domain.class);
		query.select(root);
		query.where(cb.equal(root.<String>get("nameDomain"), domainName));

		List<Domain> domainVOList = super.getEntityManager().createQuery(query).getResultList();

		return domainVOList;
	}

	public Pagination<Domain> getItensByPage(Pagination<Domain> pagination, String order, String ascDesc, String nameDomain) throws Exception {

		CriteriaBuilder cb = super.getEntityManager().getCriteriaBuilder();

		CriteriaQuery<Domain> queryDomain = cb.createQuery(Domain.class);
		Root<Domain> rootDomain = queryDomain.from(Domain.class);
		queryDomain.select(rootDomain);

		if(nameDomain != null){
			queryDomain.where(cb.or(cb.like(cb.upper(rootDomain.<String>get("nameDomain")), "%" + nameDomain.toUpperCase() + "%"),
					cb.like(cb.upper(rootDomain.<String>get("valueDescription")), "%" + nameDomain.toUpperCase() + "%"),
					cb.like(cb.upper(rootDomain.<String>get("maskDescriptionValue")), "%" + nameDomain.toUpperCase() + "%")));
		}

		if(ascDesc == "desc"){
			queryDomain.orderBy(cb.desc(rootDomain.get(order)));
		} else {
			queryDomain.orderBy(cb.asc(rootDomain.get(order)));
		}

		List<Domain> domain = super.getEntityManager().createQuery(queryDomain)
				.setFirstResult(pagination.getFirstResult())
				.setMaxResults(pagination.getPageSize())
				.getResultList();

		pagination.setItems(domain);
		pagination.setCountResults(countItensPages(nameDomain).intValue());
		return pagination;
	}

	public Long countItensPages(String nameDomain) throws Exception{

		CriteriaBuilder cb = super.getEntityManager().getCriteriaBuilder();
		CriteriaQuery<Long> query = cb.createQuery(Long.class);

		Root<Domain> root = query.from(Domain.class);
		query.select(cb.count(root));

		if(nameDomain != null){
			query.where(cb.like(root.<String>get("nameDomain"), nameDomain));
		}

		return super.getEntityManager().createQuery(query).getSingleResult();	
	}
	
	private Map<String, Map<String, Domain>> loadMapDomains() throws Exception {

		Map<String, Map<String, Domain>> mapDomains = new HashMap<String, Map<String, Domain>>();

		for (Domain domain : this.findAll()) {
			if (!mapDomains.containsKey(domain.getNameDomain())) {
				mapDomains.put(domain.getNameDomain(), new HashMap<String, Domain>());
			}
			if (!mapDomains.get(domain.getNameDomain()).containsKey(domain.getValueDescription())) {
				mapDomains.get(domain.getNameDomain()).put(domain.getValueDescription(), domain);
			}
		}

		return mapDomains;
	}
	
	public Map<String, Map<String, Domain>> getDomains() throws Exception {
		if (DomainHelper.getInstance().domains == null)
			DomainHelper.getInstance().domains = this.loadMapDomains();

		return DomainHelper.getInstance().domains;
	}

	public Map<String, Domain> getDomains(String domainKey) throws Exception {
		return getDomains().get(domainKey);
	}

	public Domain getDomains(String domainKey, String domainValueKey) throws Exception {

		if (getDomains(domainKey) == null)
			return null;

		return getDomains(domainKey).get(domainValueKey);

	}
	
	public List<Domain> getListValuesDomains(String domainKey) throws Exception {
		Map<String, Domain> domains = getDomains(domainKey);
		if(domains == null)
			return null;
		return new ArrayList<Domain>(domains.values());

	}

}