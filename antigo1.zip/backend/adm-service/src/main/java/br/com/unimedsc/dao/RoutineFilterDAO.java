package br.com.unimedsc.dao;

import org.springframework.stereotype.Component;

import br.com.unimedsc.core.dao.DAO;
import br.com.unimedsc.entities.erp.RoutineFilter;
import br.com.unimedsc.entities.pk.RoutineCompositePK;

@Component
public class RoutineFilterDAO extends DAO<RoutineCompositePK<Long>, RoutineFilter> {


}
