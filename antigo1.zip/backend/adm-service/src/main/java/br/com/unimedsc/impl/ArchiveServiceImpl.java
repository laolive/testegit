package br.com.unimedsc.impl;

import br.com.unimedsc.core.entity.pk.SimplePK;
import br.com.unimedsc.core.exception.UFException;
import br.com.unimedsc.core.service.impl.ServiceImpl;
import br.com.unimedsc.dao.ArchiveDAO;
import br.com.unimedsc.entities.adm.User;
import br.com.unimedsc.entities.erp.Archive;
import br.com.unimedsc.entities.erp.Enterprise;
import br.com.unimedsc.service.ArchiveService;
import br.com.unimedsc.service.DomainService;
import io.minio.MinioClient;
import org.apache.commons.fileupload.FileItemIterator;
import org.apache.commons.fileupload.FileItemStream;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;

@Service
public class ArchiveServiceImpl extends ServiceImpl<SimplePK<Long>, Archive, ArchiveDAO> implements ArchiveService {

    @org.springframework.beans.factory.annotation.Value("${minio.host}")
    private String minioHost;

    @org.springframework.beans.factory.annotation.Value("${minio.username}")
    private String minioUsername;

    @org.springframework.beans.factory.annotation.Value("${minio.password}")
    private String minioPassword;

    @org.springframework.beans.factory.annotation.Value("${upload.path.root}")
    private String varPath;

    private static final String[] blockedTypes = new String[]{"application/javascript",
            "application/sql", "application/vnd.debian.binary-package", "application/x-java-archive",
            "application/x-shellscript", "text/x-java", "application/x-ms-dos-executable"};

    @Inject
    private DomainService domainService;

    @Inject
    protected ArchiveServiceImpl(ArchiveDAO dao) {
        super(dao);
    }

    @Transactional(readOnly = false)
    public List<Archive> uploadFile(HttpServletRequest request, Long userId, Long enterpriseId, String nameBucket, String path) throws Exception {
        boolean isMultipart = ServletFileUpload.isMultipartContent(request);

        if (!isMultipart) {
            throw new UFException("Nenhum arquivo pra upload");
        }

        ServletFileUpload upload = new ServletFileUpload();
        FileItemIterator iter = upload.getItemIterator(request);

        List<Archive> files = new ArrayList<Archive>();

        while (iter.hasNext()) {
            FileItemStream item = iter.next();

            if (Arrays.asList(blockedTypes).contains(item.getContentType())) {
                throw new UFException("Tipo de arquivo inválido!");
            }

            InputStream stream = item.openStream();

            if (!item.isFormField()) {
                String filename = item.getName();
                String identifier = UUID.randomUUID().toString();

                MinioClient minio = new MinioClient(minioHost, minioUsername, minioPassword);

                Boolean bucketExists = minio.bucketExists(nameBucket);

                if (!bucketExists) {
                    minio.makeBucket(nameBucket);
                }

                minio.putObject(nameBucket, identifier, stream, item.getContentType());

                Archive uploadFile = new Archive();
                uploadFile.setExtension(item.getContentType());
                uploadFile.setFileName(filename);
                uploadFile.setIdentifier(identifier);
                uploadFile.setPk(new SimplePK<Long>());
                uploadFile.setNameBucket(nameBucket);
                uploadFile.setPath(path);
                uploadFile.setDomainEntry(domainService.getDomains("FLAG", "S").getValueDescription());

                uploadFile.setUser(new User());
                uploadFile.getUser().setPk(new SimplePK<>());
                uploadFile.getUser().getPk().setId(userId);

                uploadFile.setEnterprise(new Enterprise());
                uploadFile.getEnterprise().setPk(new SimplePK<Long>());
                uploadFile.getEnterprise().getPk().setId(enterpriseId);

                uploadFile = super.insert(uploadFile);

                files.add(uploadFile);

                stream.close();
            }
        }

        return files;
    }
}
