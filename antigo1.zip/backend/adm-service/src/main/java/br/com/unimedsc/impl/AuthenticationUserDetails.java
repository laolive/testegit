package br.com.unimedsc.impl;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.User;

import java.util.Collection;

public class AuthenticationUserDetails extends User {

    private Long userId;

    private Long enterpriseId;

    public AuthenticationUserDetails(String username, String password,
                                     Collection<? extends GrantedAuthority> authorities, Long userId, Long enterpriseId) {
        super(username, password, authorities);
        this.setUserId(userId);
        this.setEnterpriseId(enterpriseId);
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public Long getEnterpriseId() {
        return enterpriseId;
    }

    public void setEnterpriseId(Long enterpriseId) {
        this.enterpriseId = enterpriseId;
    }
}
