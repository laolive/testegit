package br.com.unimedsc.service;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.fileupload.FileUploadException;

import br.com.unimedsc.core.entity.pk.SimplePK;
import br.com.unimedsc.core.exception.UFException;
import br.com.unimedsc.core.service.Service;
import br.com.unimedsc.entities.erp.Archive;

public interface ArchiveService extends Service<SimplePK<Long>, Archive> {

	public List<Archive> uploadFile(HttpServletRequest request, Long userId, Long enterpriseId, String nameBucket, String path)
			throws UFException, FileUploadException, IOException, Exception;

}