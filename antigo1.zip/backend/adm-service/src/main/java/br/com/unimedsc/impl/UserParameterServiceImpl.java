package br.com.unimedsc.impl;

import org.springframework.stereotype.Service;

import br.com.unimedsc.core.service.impl.ServiceImpl;
import br.com.unimedsc.dao.UserParamaterDAO;
import br.com.unimedsc.entities.adm.UserParameter;
import br.com.unimedsc.entities.pk.UserParameterCompositePK;
import br.com.unimedsc.service.UserParameterService;

@Service
public class UserParameterServiceImpl extends ServiceImpl<UserParameterCompositePK<String>, UserParameter, UserParamaterDAO> implements UserParameterService {
	private static final long serialVersionUID = 3285162032696600649L;

	protected UserParameterServiceImpl(UserParamaterDAO dao) {
		super(dao);
	}
}
