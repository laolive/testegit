package br.com.unimedsc.service;

import br.com.unimedsc.core.service.Service;
import br.com.unimedsc.entities.erp.ProcessFilter;
import br.com.unimedsc.entities.pk.ProcessCompositePK;

public interface ProcessFilterService extends Service<ProcessCompositePK<Long>, ProcessFilter> {

}
