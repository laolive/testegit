package br.com.unimedsc.dao;

import org.springframework.stereotype.Component;

import br.com.unimedsc.core.dao.DAO;
import br.com.unimedsc.core.entity.pk.SimplePK;
import br.com.unimedsc.entities.adm.Dominio;

@Component
public class DominioDAO extends DAO<SimplePK<Integer>, Dominio> {

}
