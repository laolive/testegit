package br.com.unimedsc.dao;

import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Component;

import br.com.unimedsc.core.dao.DAO;
import br.com.unimedsc.core.entity.pk.SimplePK;
import br.com.unimedsc.entities.adm.User;

@Component
public class UserDAO extends DAO<SimplePK<Long>, User> {

	public void updatePassword(SimplePK<Long> pk, String password, Calendar dateLastAccess) {

		String hql = "UPDATE " + getTypeClass().getSimpleName()
				+ " SET password = :password, dateLastAccess = :dateLastAccess WHERE pk = :pk";
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("password", new BCryptPasswordEncoder().encode(password));
		params.put("dateLastAccess", dateLastAccess);
		params.put("pk", pk);

		try {
			super.executeHQL(hql, params);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
