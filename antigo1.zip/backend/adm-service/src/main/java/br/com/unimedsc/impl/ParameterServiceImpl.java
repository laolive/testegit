package br.com.unimedsc.impl;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import br.com.unimedsc.core.entity.pk.SimplePK;
import br.com.unimedsc.core.service.impl.ServiceImpl;
import br.com.unimedsc.dao.ParameterDAO;
import br.com.unimedsc.entities.erp.Parameter;
import br.com.unimedsc.service.ParameterService;

@Service
public class ParameterServiceImpl extends ServiceImpl<SimplePK<String>, Parameter, ParameterDAO> 
		implements ParameterService {

	private static final long serialVersionUID = -1852839471119535221L;

	@Inject
	protected ParameterServiceImpl(ParameterDAO dao) {
		super(dao);
	}
}
