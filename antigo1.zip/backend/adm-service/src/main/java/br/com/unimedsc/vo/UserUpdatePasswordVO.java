package br.com.unimedsc.vo;

import java.util.Calendar;

import br.com.unimedsc.core.entity.pk.SimplePK;

public class UserUpdatePasswordVO {

	public SimplePK<Long> pk;

	public String oldPassword;

	public String newPassword;

	public String confirmPassword;

	public Calendar dateLastAccess;

	private Boolean admin;

	public SimplePK<Long> getPk() {
		return pk;
	}

	public void setPk(SimplePK<Long> pk) {
		this.pk = pk;
	}

	public String getOldPassword() {
		return oldPassword;
	}

	public void setOldPassword(String oldPassword) {
		this.oldPassword = oldPassword;
	}

	public String getNewPassword() {
		return newPassword;
	}

	public void setNewPassword(String newPassword) {
		this.newPassword = newPassword;
	}

	public String getConfirmPassword() {
		return confirmPassword;
	}

	public void setConfirmPassword(String confirmPassword) {
		this.confirmPassword = confirmPassword;
	}

	public Calendar getDateLastAccess() {
		return dateLastAccess;
	}

	public void setDateLastAccess(Calendar dateLastAccess) {
		this.dateLastAccess = dateLastAccess;
	}

    public Boolean getAdmin() {
        return admin;
    }

    public void setAdmin(Boolean admin) {
        this.admin = admin;
    }
}