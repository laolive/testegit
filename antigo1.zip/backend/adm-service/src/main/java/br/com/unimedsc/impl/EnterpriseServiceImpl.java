package br.com.unimedsc.impl;

import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.com.unimedsc.core.entity.pk.SimplePK;
import br.com.unimedsc.core.service.impl.ServiceImpl;
import br.com.unimedsc.dao.EnterpriseDAO;
import br.com.unimedsc.entities.erp.Enterprise;
import br.com.unimedsc.service.EnterpriseService;

@Service
public class EnterpriseServiceImpl extends ServiceImpl<SimplePK<Long>, Enterprise, EnterpriseDAO> implements EnterpriseService {
	private static final long serialVersionUID = -4763183141641518890L;
	
	@Inject
	protected EnterpriseServiceImpl(EnterpriseDAO dao) {
		super(dao);
	}
	
	@Override
	@Transactional(readOnly = true)
	public List<Enterprise> findAllByUser(Long userId) throws Exception {
		return dao.findAllByUser(userId);
	}
}
