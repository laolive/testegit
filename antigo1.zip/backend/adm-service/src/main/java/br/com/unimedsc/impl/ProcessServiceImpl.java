package br.com.unimedsc.impl;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import javax.inject.Inject;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.com.unimedsc.core.entity.pk.SimplePK;
import br.com.unimedsc.core.service.impl.ServiceImpl;
import br.com.unimedsc.core.utils.SessionUtil;
import br.com.unimedsc.dao.ProcessDAO;
import br.com.unimedsc.entities.adm.User;
import br.com.unimedsc.entities.erp.Enterprise;
import br.com.unimedsc.entities.erp.Process;
import br.com.unimedsc.entities.erp.Routine;
import br.com.unimedsc.entities.erp.dto.ProcessParamsDTO;
import br.com.unimedsc.service.ProcessService;

@Service
public class ProcessServiceImpl extends ServiceImpl<SimplePK<Long>, Process, ProcessDAO>
        implements ProcessService {

    private static final long serialVersionUID = -8391514467843461836L;

    @Inject
    protected ProcessServiceImpl(ProcessDAO dao) {
        super(dao);
    }
    
    private Calendar getCalendar (String stringDate) throws ParseException {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        Date date = sdf.parse(stringDate);
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        return calendar; 
    }
        
    @Transactional(readOnly = false)
    public Process startProcess(ProcessParamsDTO processParamsDTO) throws Exception {

        Process process = new Process();
        SimplePK<Long> pk = new SimplePK<Long>();
        pk.setId(null);
        process.setPk(pk);

        Routine routine = new Routine();
        SimplePK<Long> routinePk = new SimplePK<Long>();
        routinePk.setId(processParamsDTO.getRoutineId());
        routine.setPk(routinePk);
        process.setRoutine(routine);
        
        User user = new User();
        SimplePK<Long> userPk = new SimplePK<Long>();
        userPk.setId(SessionUtil.getInstance().getUserId());
        user.setPk(userPk);
        process.setUserRequesting(user);
        
        Enterprise enterprise = new Enterprise();
        SimplePK<Long> enterprisePk = new SimplePK<Long>();
        enterprisePk.setId(SessionUtil.getInstance().getEnterpriseId());
        enterprise.setPk(enterprisePk);
        process.setEnterprise(enterprise);
        
        process.setDateStartPreview(getCalendar(processParamsDTO.getDateStartPreview()));
        process.setDateStartReal(Calendar.getInstance());
        process.setDomainSchedulingType(processParamsDTO.getDomainSchedulingType());
        process.setDomainOpen("N");
        process.setDomainArchive("N");
        process.setDomainAlert("N");
        process.setDomainError("N");
        process.setDateRequested(Calendar.getInstance());
        process.setPercentual(0);
        
        insert(process);
        
        return process;
    }
    
    @Transactional(readOnly = false)
    public Process updateProcessPercentual(ProcessParamsDTO processParamsDTO) throws Exception {

        SimplePK<Long> pk = new SimplePK<Long>();
        pk.setId(processParamsDTO.getProcessId());
        Process process = findById(pk);
        
        process.setPercentual(processParamsDTO.getPercentual());
        
        update(process);
        
        return process;
    }
    
    @Transactional(readOnly = false)
    public Process finishProcess(ProcessParamsDTO processParamsDTO) throws Exception {

        SimplePK<Long> pk = new SimplePK<Long>();
        pk.setId(processParamsDTO.getProcessId());
        Process process = findById(pk);
        
        process.setDateEndReal(Calendar.getInstance());
        process.setPercentual(100);
        
        update(process);
        
        return process;
    }
}
