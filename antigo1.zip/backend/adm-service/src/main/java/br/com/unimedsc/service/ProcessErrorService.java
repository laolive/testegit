package br.com.unimedsc.service;

import br.com.unimedsc.core.service.Service;
import br.com.unimedsc.entities.erp.ProcessError;
import br.com.unimedsc.entities.erp.dto.ProcessParamsDTO;
import br.com.unimedsc.entities.pk.ProcessCompositePK;

public interface ProcessErrorService extends Service<ProcessCompositePK<Long>, ProcessError> {
    ProcessError generateError(ProcessParamsDTO processParamsDTO) throws Exception;
}
