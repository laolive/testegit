package br.com.unimedsc.impl;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import br.com.unimedsc.core.entity.pk.SimplePK;
import br.com.unimedsc.core.service.impl.ServiceImpl;
import br.com.unimedsc.dao.PathDAO;
import br.com.unimedsc.entities.erp.Path;
import br.com.unimedsc.service.PathService;

@Service
public class PathServiceImpl extends ServiceImpl<SimplePK<String>, Path, PathDAO> implements PathService {

	private static final long serialVersionUID = 5787724484692187438L;

	@Inject
	protected PathServiceImpl(PathDAO dao) {
		super(dao);
	}

}