package br.com.unimedsc.impl;


import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.com.unimedsc.core.service.impl.ServiceImpl;
import br.com.unimedsc.dao.UserSubsidiaryDAO;
import br.com.unimedsc.entities.adm.UserSubsidiary;
import br.com.unimedsc.entities.pk.SubsidiaryCompositePK;
import br.com.unimedsc.service.UserSubsidiaryService;

@Service
public class UserSubsidiaryServiceImpl extends ServiceImpl<SubsidiaryCompositePK<Long>, UserSubsidiary, UserSubsidiaryDAO> implements UserSubsidiaryService {

	private static final long serialVersionUID = 2333572930556188532L;

	protected UserSubsidiaryServiceImpl(UserSubsidiaryDAO dao) {
		super(dao);
	}

	@Override
	@Transactional(readOnly = true)
	public List<UserSubsidiary> findByUserId(Long userId) throws Exception {
		return dao.findByUserId(userId);
	}
	
	@Override
	@Transactional
	public UserSubsidiary setDefault(Long userId, Long subsidiaryId) throws Exception {
		dao.setDefualt(userId, subsidiaryId);
		dao.setAllToNoDefualt(userId, subsidiaryId);
		return dao.findByUserAndSubsidiary(userId, subsidiaryId);
	}
}
