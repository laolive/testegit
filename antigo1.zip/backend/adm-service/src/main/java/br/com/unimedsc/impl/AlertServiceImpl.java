package br.com.unimedsc.impl;

import java.util.Calendar;
import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.com.unimedsc.core.entity.pk.SimplePK;
import br.com.unimedsc.core.filter.FilterHelper;
import br.com.unimedsc.core.filter.Junction;
import br.com.unimedsc.core.filter.Node;
import br.com.unimedsc.core.filter.Operator;
import br.com.unimedsc.core.filter.Value;
import br.com.unimedsc.core.service.impl.ServiceImpl;
import br.com.unimedsc.dao.AlertDAO;
import br.com.unimedsc.dto.AlertDTO;
import br.com.unimedsc.entities.adm.User;
import br.com.unimedsc.entities.erp.Alert;
import br.com.unimedsc.entities.erp.Enterprise;
import br.com.unimedsc.service.AlertService;
import br.com.unimedsc.service.EnterpriseService;
import br.com.unimedsc.service.UserService;

@Service
public class AlertServiceImpl extends ServiceImpl<SimplePK<Long>, Alert, AlertDAO> implements AlertService {

	private static final long serialVersionUID = 4762999451111522870L;

	@Inject
	private UserService userService;

	@Inject
	private EnterpriseService enterpriseService;

	@Inject
	protected AlertServiceImpl(AlertDAO dao) {
		super(dao);
	}

	@Override
	public List<Alert> findEmailsOpen() throws Exception {

		Node node = FilterHelper.createTree(Junction.AND);
		FilterHelper.addCondition(node, "domainSendType", Operator.EQUAL, new Value<String>("E"));
		FilterHelper.addCondition(node, "domainOpen", Operator.EQUAL, new Value<String>("S"));

		return dao.findAllByFilter(node, null);

	}

	@Override
	@Transactional(readOnly = false)
	public Alert newAlert(AlertDTO alert) throws Exception {

		User destinationUser = userService.findById(new SimplePK<Long>(alert.getUserIdDestination()));
		User creationUser = userService.findById(new SimplePK<Long>(alert.getUserIdSender()));
		Enterprise enterprise = enterpriseService.findById(new SimplePK<Long>(alert.getEnterpriseId()));

		Alert newAlert = new Alert();

		newAlert.setAlertDescription(alert.getText());
		newAlert.setCreationDate(Calendar.getInstance());
		newAlert.setCreationUser(creationUser);
		newAlert.setDestinationUser(destinationUser);
		newAlert.setDomainAlertType("R");
		newAlert.setDomainOpen("S");
		newAlert.setDomainSendType("E");
		newAlert.setEnterprise(enterprise);
		newAlert.setSubject(alert.getSubject());
		newAlert.setPk(new SimplePK<Long>());

		return super.insert(newAlert);
	}

}
