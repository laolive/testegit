package br.com.unimedsc.dao;

import org.springframework.stereotype.Component;

import br.com.unimedsc.core.dao.DAO;
import br.com.unimedsc.entities.adm.AccessGroupParameter;
import br.com.unimedsc.entities.pk.AccessGroupCompositePK;

@Component
public class AccessGroupParameterServiceDAO extends DAO<AccessGroupCompositePK<String>, AccessGroupParameter> {
}
