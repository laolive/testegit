package br.com.unimedsc.impl;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import br.com.unimedsc.core.entity.pk.SimplePK;
import br.com.unimedsc.core.service.impl.ServiceImpl;
import br.com.unimedsc.dao.TipoIntegracaoDAO;
import br.com.unimedsc.entities.erp.TipoIntegracao;
import br.com.unimedsc.service.TipoIntegracaoService;

@Service
public class TipoIntegracaoServiceImpl extends ServiceImpl<SimplePK<Integer>, TipoIntegracao, TipoIntegracaoDAO> implements TipoIntegracaoService {

    @Inject
    protected TipoIntegracaoServiceImpl(TipoIntegracaoDAO dao) {
        super(dao);
    }
}
