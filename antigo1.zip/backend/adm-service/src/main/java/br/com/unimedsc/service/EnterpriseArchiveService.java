package br.com.unimedsc.service;

import br.com.unimedsc.core.entity.pk.CompositeEnterprisePK;
import br.com.unimedsc.core.service.Service;
import br.com.unimedsc.entities.erp.EnterpriseArchive;

public interface EnterpriseArchiveService extends Service<CompositeEnterprisePK<Long>, EnterpriseArchive> {

}
