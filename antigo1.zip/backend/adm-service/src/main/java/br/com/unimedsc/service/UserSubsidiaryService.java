package br.com.unimedsc.service;


import java.util.List;

import br.com.unimedsc.core.service.Service;
import br.com.unimedsc.entities.adm.UserSubsidiary;
import br.com.unimedsc.entities.pk.SubsidiaryCompositePK;

public interface UserSubsidiaryService extends Service<SubsidiaryCompositePK<Long>, UserSubsidiary> {

	public List<UserSubsidiary> findByUserId(Long userId) throws Exception;

	public UserSubsidiary setDefault(Long userId, Long subsidiaryId) throws Exception;

}

