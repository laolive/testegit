package br.com.unimedsc.impl;

import br.com.unimedsc.core.entity.pk.DoubleCompositePK;
import br.com.unimedsc.core.service.impl.ServiceImpl;
import br.com.unimedsc.core.utils.Pagination;
import br.com.unimedsc.dao.DomainDAO;
import br.com.unimedsc.entities.erp.Domain;
import br.com.unimedsc.service.DomainService;
import org.springframework.stereotype.Service;

import javax.persistence.Table;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.logging.Level;

@Service
public class DomainServiceImpl extends ServiceImpl<DoubleCompositePK<String, String>, Domain, DomainDAO> implements DomainService {
    private static final long serialVersionUID = 5508531582757670489L;

    protected DomainServiceImpl(DomainDAO dao) {
        super(dao);
    }

    @Override
    public List<Domain> findDomainByTableName(Class<?> clazz) throws Exception {
        Table table = clazz.getAnnotation(Table.class);
        return dao.findDomainByTableName(table.name());
    }

    @Override
    public Set<Domain> findDomainByTable(Class<?> clazz) throws Exception {
        return new TreeSet<Domain>(this.findDomainByTableName(clazz));
    }

    @Override
    public List<String> findAll(String querySearch) throws Exception {
        return dao.findAll(querySearch);
    }

    @Override
    public Pagination<Domain> getItensByPage(Pagination<Domain> pagination, String order, String ascDesc,
                                             String nameDomain) {
        try {
            return dao.getItensByPage(pagination, order, ascDesc, nameDomain);
        } catch (Exception e) {
            log.log(Level.WARNING, e.getMessage(), e);
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public Set<Domain> findDomainByName(String domainName) throws Exception {

        return new TreeSet<Domain>(dao.findDomainByName(domainName));
    }

    public Map<String, Map<String, Domain>> getDomains() throws Exception {
        return dao.getDomains();
    }

    @Override
    public Map<String, Domain> getDomains(String domainKey) throws Exception {
        return dao.getDomains(domainKey);
    }

    @Override
    public Domain getDomains(String domainKey, String domainValueKey) throws Exception {
        return dao.getDomains(domainKey, domainValueKey);
    }

    @Override
    public List<Domain> getListValuesDomains(String domainKey) throws Exception {
        return dao.getListValuesDomains(domainKey);
    }

}
