package br.com.unimedsc.impl;

import br.com.unimedsc.core.entity.pk.CompositeEnterprisePK;
import br.com.unimedsc.core.service.impl.ServiceImpl;
import br.com.unimedsc.core.utils.SessionUtil;
import br.com.unimedsc.dao.HolidayDAO;
import br.com.unimedsc.entities.adm.Holiday;
import br.com.unimedsc.entities.repository.HolidayRepository;
import br.com.unimedsc.entities.vo.HolidayReturnVO;
import br.com.unimedsc.service.HolidayService;
import br.com.unimedsc.vo.HolidayParamsVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.inject.Inject;
import java.util.Calendar;
import java.util.List;

@Service
public class HolidayServiceImpl extends ServiceImpl<CompositeEnterprisePK<Calendar>, Holiday, HolidayDAO> implements HolidayService {

    @Autowired
    private HolidayRepository holidayRepository;

    @Inject
    protected HolidayServiceImpl(HolidayDAO dao) {
        super(dao);
    }

    public List<HolidayReturnVO> findHolidayAnnual(HolidayParamsVO holidayParamsVO) {
        Long enterpriseId = SessionUtil.getInstance().getEnterpriseId();
        Integer year = null;

        if (holidayParamsVO.getEnterpriseId() != null) {
            enterpriseId = holidayParamsVO.getEnterpriseId();
        }

        if (holidayParamsVO.getYear() != null) {
            year = Integer.valueOf(holidayParamsVO.getYear());
        }

        Calendar starDate = createDateBetweenYear(year, true);
        Calendar endDate = createDateBetweenYear(year, false);

        return holidayRepository.findHolidayAnnual(enterpriseId, starDate, endDate);
    }

    private Calendar createDateBetweenYear(Integer year, Boolean startDate) {
        Calendar date = Calendar.getInstance();
        date.set(Calendar.YEAR, year);

        if (startDate) {
            date.set(Calendar.MONTH, Calendar.JANUARY);
            date.set(Calendar.DAY_OF_MONTH, date.getActualMinimum(Calendar.DAY_OF_MONTH));
            date.set(Calendar.HOUR_OF_DAY, 0);
            date.set(Calendar.HOUR, 0);
            date.set(Calendar.MINUTE, 0);
            date.set(Calendar.SECOND, 0);
            date.set(Calendar.MILLISECOND, 0);
        } else {
            date.set(Calendar.MONTH, Calendar.DECEMBER);
            date.set(Calendar.DAY_OF_MONTH, date.getActualMaximum(Calendar.DAY_OF_MONTH));
            date.set(Calendar.HOUR_OF_DAY, 22);
            date.set(Calendar.HOUR, 22);
            date.set(Calendar.MINUTE, 59);
        }

        return date;
    }
}
