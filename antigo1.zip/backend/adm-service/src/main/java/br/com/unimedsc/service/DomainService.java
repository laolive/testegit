package br.com.unimedsc.service;

import java.util.List;
import java.util.Map;
import java.util.Set;

import br.com.unimedsc.core.entity.pk.DoubleCompositePK;
import br.com.unimedsc.core.service.Service;
import br.com.unimedsc.core.utils.Pagination;
import br.com.unimedsc.entities.erp.Domain;

public interface DomainService extends Service<DoubleCompositePK<String, String>, Domain> {

	public List<Domain> findDomainByTableName(Class<?> clazz) throws Exception;
	
	public Set<Domain> findDomainByTable(Class<?> clazz) throws Exception;
	
	public Set<Domain> findDomainByName(String domainName) throws Exception;

	public List<String> findAll(String querySearch) throws Exception;

	public Pagination<Domain> getItensByPage(Pagination<Domain> pagination, String order, String ascDesc, String nameDomain);
	
	public Map<String, Map<String, Domain>> getDomains() throws Exception;
	
	public Map<String, Domain> getDomains(String domainKey) throws Exception;
	
	public Domain getDomains(String domainKey, String domainValueKey) throws Exception;

	public List<Domain> getListValuesDomains(String domainKey) throws Exception;
}