package br.com.unimedsc.service;

import br.com.unimedsc.core.service.Service;
import br.com.unimedsc.entities.erp.ProcessOption;
import br.com.unimedsc.entities.pk.ProcessCompositePK;

public interface ProcessOptionService extends Service<ProcessCompositePK<Long>, ProcessOption> {

}
