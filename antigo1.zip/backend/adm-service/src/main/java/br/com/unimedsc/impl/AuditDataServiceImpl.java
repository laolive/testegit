package br.com.unimedsc.impl;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import br.com.unimedsc.core.entity.pk.SimplePK;
import br.com.unimedsc.core.service.impl.ServiceImpl;
import br.com.unimedsc.dao.AuditDataDAO;
import br.com.unimedsc.entities.erp.AuditData;
import br.com.unimedsc.service.AuditDataService;

@Service
public class AuditDataServiceImpl extends ServiceImpl<SimplePK<Long>, AuditData, AuditDataDAO>
		implements AuditDataService {

	private static final long serialVersionUID = 7040874220350720728L;

	@Inject
	protected AuditDataServiceImpl(AuditDataDAO dao) {
		super(dao);
	}
}
