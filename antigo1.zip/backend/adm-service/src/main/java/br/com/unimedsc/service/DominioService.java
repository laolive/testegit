package br.com.unimedsc.service;

import br.com.unimedsc.core.entity.pk.SimplePK;
import br.com.unimedsc.core.service.Service;
import br.com.unimedsc.entities.adm.Dominio;

import java.util.List;

public interface DominioService extends Service<SimplePK<Integer>, Dominio> {

    Dominio findByNome(String nome) throws Exception;

    List<Dominio> findAll() throws Exception;
}
