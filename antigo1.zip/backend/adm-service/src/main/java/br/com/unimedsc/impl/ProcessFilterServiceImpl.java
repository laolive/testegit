package br.com.unimedsc.impl;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import br.com.unimedsc.core.service.impl.ServiceImpl;
import br.com.unimedsc.dao.ProcessFilterDAO;
import br.com.unimedsc.entities.erp.ProcessFilter;
import br.com.unimedsc.entities.pk.ProcessCompositePK;
import br.com.unimedsc.service.ProcessFilterService;

@Service
public class ProcessFilterServiceImpl extends ServiceImpl<ProcessCompositePK<Long>, ProcessFilter, ProcessFilterDAO>
		implements ProcessFilterService {

	private static final long serialVersionUID = -113901062015683755L;

	@Inject
	protected ProcessFilterServiceImpl(ProcessFilterDAO dao) {
		super(dao);
	}
}
