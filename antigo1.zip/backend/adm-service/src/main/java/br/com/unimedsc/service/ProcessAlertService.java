package br.com.unimedsc.service;

import br.com.unimedsc.core.service.Service;
import br.com.unimedsc.entities.erp.ProcessAlert;
import br.com.unimedsc.entities.erp.dto.ProcessParamsDTO;
import br.com.unimedsc.entities.pk.ProcessCompositePK;

public interface ProcessAlertService extends Service<ProcessCompositePK<Long>, ProcessAlert> {
    ProcessAlert generateAlert(ProcessParamsDTO processParamsDTO) throws Exception;
}
