package br.com.unimedsc.impl;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import br.com.unimedsc.core.service.impl.ServiceImpl;
import br.com.unimedsc.dao.ProcessOptionDAO;
import br.com.unimedsc.entities.erp.ProcessOption;
import br.com.unimedsc.entities.pk.ProcessCompositePK;
import br.com.unimedsc.service.ProcessOptionService;

@Service
public class ProcessOptionServiceImpl extends ServiceImpl<ProcessCompositePK<Long>, ProcessOption, ProcessOptionDAO>
		implements ProcessOptionService {

	private static final long serialVersionUID = 978390698740707041L;

	@Inject
	protected ProcessOptionServiceImpl(ProcessOptionDAO dao) {
		super(dao);
	}
}
