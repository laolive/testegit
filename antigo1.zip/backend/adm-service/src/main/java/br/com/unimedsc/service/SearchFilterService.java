package br.com.unimedsc.service;

import br.com.unimedsc.core.service.Service;
import br.com.unimedsc.entities.cfg.SearchFilter;
import br.com.unimedsc.entities.pk.SearchCompositePK;

public interface SearchFilterService extends Service<SearchCompositePK<Long>, SearchFilter> {

}
