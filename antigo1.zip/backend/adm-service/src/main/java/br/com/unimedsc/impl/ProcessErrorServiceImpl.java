package br.com.unimedsc.impl;

import javax.inject.Inject;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.com.unimedsc.core.entity.pk.SimplePK;
import br.com.unimedsc.core.service.impl.ServiceImpl;
import br.com.unimedsc.dao.ProcessErrorDAO;
import br.com.unimedsc.entities.erp.Process;
import br.com.unimedsc.entities.erp.ProcessError;
import br.com.unimedsc.entities.erp.dto.ProcessParamsDTO;
import br.com.unimedsc.entities.pk.ProcessCompositePK;
import br.com.unimedsc.service.ProcessErrorService;
import br.com.unimedsc.service.ProcessService;

@Service
public class ProcessErrorServiceImpl extends ServiceImpl<ProcessCompositePK<Long>, ProcessError, ProcessErrorDAO>
		implements ProcessErrorService {

	private static final long serialVersionUID = -5894919520796239973L;

	@Inject
	protected ProcessErrorServiceImpl(ProcessErrorDAO dao) {
		super(dao);
	}
	
	@Inject
	protected ProcessService processService;

	@Transactional(readOnly = false)
    public ProcessError generateError(ProcessParamsDTO processParamsDTO) throws Exception {
    	
    	ProcessError processError = new ProcessError();
    	ProcessCompositePK<Long> pk = new ProcessCompositePK<Long>();
    	pk.setProcessId(processParamsDTO.getProcessId());
    	pk.setId(null);
    	
    	processError.setPk(pk);
    	processError.setErrorMessage(processParamsDTO.getDescriptionError());
    	processError.setKey(processParamsDTO.getDescriptionKey());
    	
    	insert(processError);
    	
        SimplePK<Long> processPk = new SimplePK<Long>();
        processPk.setId(processParamsDTO.getProcessId());
        
        Process process = processService.findById(processPk);
        process.setDomainError("S");
        
        processService.update(process);
        
        return processError;
    }
}
