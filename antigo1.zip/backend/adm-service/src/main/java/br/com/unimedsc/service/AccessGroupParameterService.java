package br.com.unimedsc.service;

import br.com.unimedsc.core.service.Service;
import br.com.unimedsc.entities.adm.AccessGroupParameter;
import br.com.unimedsc.entities.pk.AccessGroupCompositePK;

public interface AccessGroupParameterService extends Service<AccessGroupCompositePK<String>, AccessGroupParameter> {

}
