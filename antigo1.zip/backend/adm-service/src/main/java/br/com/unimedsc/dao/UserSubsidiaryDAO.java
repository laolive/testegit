package br.com.unimedsc.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import br.com.unimedsc.core.dao.DAO;
import br.com.unimedsc.core.filter.FilterHelper;
import br.com.unimedsc.core.filter.Junction;
import br.com.unimedsc.core.filter.Node;
import br.com.unimedsc.core.filter.Operator;
import br.com.unimedsc.core.filter.Value;
import br.com.unimedsc.entities.adm.UserSubsidiary;
import br.com.unimedsc.entities.pk.SubsidiaryCompositePK;

@Component
public class UserSubsidiaryDAO extends DAO<SubsidiaryCompositePK<Long>, UserSubsidiary> {

	@Transactional(readOnly = true)
	public List<UserSubsidiary> findByUserId(Long userId) throws Exception {
		String hql = super.dynamicQuerySimple("us") + " WHERE us.user.id.id = :userId";

		Map<String, Object> params = new HashMap<>();
		params.put("userId", userId);

		return super.findAllByQuery(hql, params);
	}

	@Transactional(readOnly = true)
	public UserSubsidiary findByUserAndSubsidiary(Long userId, Long subsidiaryId) throws Exception {

		Node node = FilterHelper.createTree(Junction.AND);
		FilterHelper.addCondition(node, "user.id.id", Operator.EQUAL, new Value<Long>(userId));
		FilterHelper.addCondition(node, "id.subsidiaryId", Operator.EQUAL, new Value<Long>(subsidiaryId));

		List<UserSubsidiary> users = super.findAllByFilter(node, null);

		if (users == null || users.size() == 0)
			return null;

		return users.get(0);
	}

	@Transactional(readOnly = true)
	public void setDefualt(Long userId, Long subsidiaryId) throws Exception {
		this.executeQueryDefautl(userId, subsidiaryId, true);
	}

	@Transactional(readOnly = true)
	public void setAllToNoDefualt(Long userId, Long subsidiaryId) throws Exception {
		this.executeQueryDefautl(userId, subsidiaryId, false);
	}

	private void executeQueryDefautl(Long userId, Long subsidiaryId, boolean isEqual) throws Exception {
		String domain = isEqual ? "S" : "N";

		String hql = "UPDATE " + UserSubsidiary.class.getSimpleName() + " up " + " SET up.domainDefault = :domain"
				+ " WHERE up.user.id.id = :userId " + " AND up.id.subsidiaryId " + (isEqual ? "=" : "<>")
				+ ":subsidiaryId ";
		Map<String, Object> params = new HashMap<>();
		params.put("domain", domain);
		params.put("userId", userId);
		params.put("subsidiaryId", subsidiaryId);

		super.executeHQL(hql, params);
	}
}
