package br.com.unimedsc.dao;

import org.springframework.stereotype.Component;

import br.com.unimedsc.core.dao.DAO;
import br.com.unimedsc.core.entity.pk.CompositeEnterprisePK;
import br.com.unimedsc.entities.adm.EnterpriseParameter;

@Component
public class EnterpriseParameterDAO extends DAO<CompositeEnterprisePK<String>, EnterpriseParameter> {

}
