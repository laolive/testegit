package br.com.unimedsc.service;

import br.com.unimedsc.core.service.Service;
import br.com.unimedsc.entities.adm.UserMenu;
import br.com.unimedsc.entities.pk.MenuCompositePK;

public interface UserMenuService extends Service<MenuCompositePK<Long>, UserMenu> {

}