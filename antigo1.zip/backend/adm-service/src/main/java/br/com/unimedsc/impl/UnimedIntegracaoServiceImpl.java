package br.com.unimedsc.impl;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import br.com.unimedsc.core.entity.pk.SimplePK;
import br.com.unimedsc.core.service.impl.ServiceImpl;
import br.com.unimedsc.dao.UnimedIntegracaoDAO;
import br.com.unimedsc.entities.erp.UnimedIntegracao;
import br.com.unimedsc.service.UnimedIntegracaoService;

@Service
public class UnimedIntegracaoServiceImpl extends ServiceImpl<SimplePK<Long>, UnimedIntegracao, UnimedIntegracaoDAO> implements UnimedIntegracaoService {

    @Inject
    protected UnimedIntegracaoServiceImpl(UnimedIntegracaoDAO dao) {
        super(dao);
    }
}
