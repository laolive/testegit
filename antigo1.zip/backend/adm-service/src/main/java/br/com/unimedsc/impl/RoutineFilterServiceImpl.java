package br.com.unimedsc.impl;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import br.com.unimedsc.core.service.impl.ServiceImpl;
import br.com.unimedsc.dao.RoutineFilterDAO;
import br.com.unimedsc.entities.erp.RoutineFilter;
import br.com.unimedsc.entities.pk.RoutineCompositePK;
import br.com.unimedsc.service.RoutineFilterService;

@Service
public class RoutineFilterServiceImpl extends ServiceImpl<RoutineCompositePK<Long>, RoutineFilter, RoutineFilterDAO> implements RoutineFilterService {

	private static final long serialVersionUID = -7424650978294418235L;

	@Inject
	protected RoutineFilterServiceImpl(RoutineFilterDAO dao) {
		super(dao);
	}

}
