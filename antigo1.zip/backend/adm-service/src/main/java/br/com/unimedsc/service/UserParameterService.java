package br.com.unimedsc.service;

import br.com.unimedsc.core.service.Service;
import br.com.unimedsc.entities.adm.UserParameter;
import br.com.unimedsc.entities.pk.UserParameterCompositePK;

public interface UserParameterService extends Service<UserParameterCompositePK<String>, UserParameter>{

}
