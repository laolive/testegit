package br.com.unimedsc.impl;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import br.com.unimedsc.core.entity.pk.SimplePK;
import br.com.unimedsc.core.service.impl.ServiceImpl;
import br.com.unimedsc.dao.RoutineSQLDAO;
import br.com.unimedsc.entities.erp.RoutineSQL;
import br.com.unimedsc.service.RoutineSQLService;

@Service
public class RoutineSQLServiceImpl extends ServiceImpl<SimplePK<Long>, RoutineSQL, RoutineSQLDAO> implements RoutineSQLService {

	private static final long serialVersionUID = -3277530293559795100L;

	@Inject
	protected RoutineSQLServiceImpl(RoutineSQLDAO dao) {
		super(dao);
	}

}
