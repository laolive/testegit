package br.com.unimedsc.dao;

import org.springframework.stereotype.Component;

import br.com.unimedsc.core.dao.DAO;
import br.com.unimedsc.entities.adm.DominioDePara;
import br.com.unimedsc.entities.pk.DominioDeParaPK;

@Component
public class DominioDeParaDAO extends DAO<DominioDeParaPK<Long,Long,Long,Long>, DominioDePara> {

}
