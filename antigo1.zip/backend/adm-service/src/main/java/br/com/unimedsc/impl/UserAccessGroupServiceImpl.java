package br.com.unimedsc.impl;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import br.com.unimedsc.core.service.impl.ServiceImpl;
import br.com.unimedsc.dao.UserAccessGroupDAO;
import br.com.unimedsc.entities.adm.UserAccessGroup;
import br.com.unimedsc.entities.pk.AccessGroupCompositePK;
import br.com.unimedsc.service.UserAccessGroupService;

@Service
public class UserAccessGroupServiceImpl extends ServiceImpl<AccessGroupCompositePK<String>, UserAccessGroup, UserAccessGroupDAO>
		implements UserAccessGroupService {

	private static final long serialVersionUID = 2116125379503538552L;

	@Inject
	protected UserAccessGroupServiceImpl(UserAccessGroupDAO dao) {
		super(dao);
	}
}