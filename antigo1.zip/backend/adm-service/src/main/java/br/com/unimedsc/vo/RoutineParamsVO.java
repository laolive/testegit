package br.com.unimedsc.vo;

import java.util.Calendar;

public class RoutineParamsVO {
	private Long processId;
	private Long routine;
	private String filter;
	private String option;
	private Calendar dateHour;
	private String formDate;
	private Long processIdOrig;

	public Long getProcessId() {
		return processId;
	}

	public void setProcessId(Long processId) {
		this.processId = processId;
	}

	public Long getRoutine() {
		return routine;
	}

	public void setRoutine(Long routine) {
		this.routine = routine;
	}

	public String getFilter() {
		return filter;
	}

	public void setFilter(String filter) {
		this.filter = filter;
	}

	public String getOption() {
		return option;
	}

	public void setOption(String option) {
		this.option = option;
	}

	public Calendar getDateHour() {
		return dateHour;
	}

	public void setDateHour(Calendar dateHour) {
		this.dateHour = dateHour;
	}

	public String getFormDate() {
		return formDate;
	}

	public void setFormDate(String formDate) {
		this.formDate = formDate;
	}

	public Long getProcessIdOrig() {
		return processIdOrig;
	}

	public void setProcessIdOrig(Long processIdOrig) {
		this.processIdOrig = processIdOrig;
	}

}
