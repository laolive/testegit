package br.com.unimedsc.impl;

import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

import javax.inject.Inject;
import javax.persistence.ParameterMode;

import org.springframework.stereotype.Service;

import br.com.unimedsc.core.dao.ProcedureParam;
import br.com.unimedsc.core.entity.pk.SimplePK;
import br.com.unimedsc.core.service.impl.ServiceImpl;
import br.com.unimedsc.dao.RoutineDAO;
import br.com.unimedsc.entities.erp.Routine;
import br.com.unimedsc.service.RoutineService;
import br.com.unimedsc.vo.RoutineParamsVO;

@Service
public class RoutineServiceImpl extends ServiceImpl<SimplePK<Long>, Routine, RoutineDAO> implements RoutineService {

	private static final long serialVersionUID = 6067002080680471281L;

	@Inject
	protected RoutineServiceImpl(RoutineDAO dao) {
		super(dao);
	}

	@Override
	public Map<String, Object> confirmRoutine(RoutineParamsVO routineParamsVO) throws Exception {
		Map<String, ProcedureParam> params = new HashMap<String, ProcedureParam>();
			
		ProcedureParam param1 = new ProcedureParam(routineParamsVO.getProcessId(), Long.class, ParameterMode.INOUT);
		ProcedureParam param2 = new ProcedureParam(routineParamsVO.getRoutine(), Long.class, ParameterMode.IN);
		ProcedureParam param3 = new ProcedureParam(routineParamsVO.getFilter(), String.class, ParameterMode.IN);
		ProcedureParam param4 = new ProcedureParam(routineParamsVO.getOption(), String.class, ParameterMode.IN);
		ProcedureParam param5 = new ProcedureParam(null, String.class, ParameterMode.OUT);
		ProcedureParam param6 = new ProcedureParam(routineParamsVO.getDateHour(), Calendar.class, ParameterMode.IN);
		ProcedureParam param7 = new ProcedureParam(routineParamsVO.getFormDate(), String.class, ParameterMode.IN);
		ProcedureParam param8 = new ProcedureParam(routineParamsVO.getProcessIdOrig(), Long.class, ParameterMode.IN);
		
		params.put("PRM_COD_PRCSSO", param1);
		params.put("PRM_COD_ROTINA ", param2);
		params.put("PRM_DES_FILTRO", param3);
		params.put("PRM_DES_OPCAO", param4);
		params.put("PRM_MSG_ERRO", param5);
		params.put("PRM_DTH_INIC_PREV", param6);
		params.put("PRM_IND_FORMA_AGENDA", param7);
		params.put("PRM_COD_PRCSSO_ORIG", param8);
			
		Map<String, Object> returnMap = super.executeProcedure("K_ERP_PROCESSO.P_AGENDA_EXEC", params);
		
		if (returnMap.get("PRM_MSG_ERRO") != null)
			throw new Exception(returnMap.get("PRM_MSG_ERRO").toString());

		return returnMap;
	}
}
