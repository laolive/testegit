package br.com.unimedsc.dao;

import org.springframework.stereotype.Component;

import br.com.unimedsc.core.dao.DAO;
import br.com.unimedsc.entities.erp.ProcessOption;
import br.com.unimedsc.entities.pk.ProcessCompositePK;

@Component
public class ProcessOptionDAO extends DAO<ProcessCompositePK<Long>, ProcessOption>{
	         
}

