package br.com.unimedsc.service;

import br.com.unimedsc.core.entity.pk.CompositeEnterprisePK;
import br.com.unimedsc.core.service.Service;
import br.com.unimedsc.entities.adm.AccessGroup;

public interface AccessGroupService extends Service<CompositeEnterprisePK<Long>, AccessGroup>{
	
}
