package br.com.unimedsc.impl;

import org.springframework.stereotype.Service;

import br.com.unimedsc.core.service.impl.ServiceImpl;
import br.com.unimedsc.dao.UserMenuDAO;
import br.com.unimedsc.entities.adm.UserMenu;
import br.com.unimedsc.entities.pk.MenuCompositePK;
import br.com.unimedsc.service.UserMenuService;

@Service
public class UserMenuServiceImpl extends ServiceImpl<MenuCompositePK<Long>, UserMenu, UserMenuDAO>
		implements UserMenuService {

	private static final long serialVersionUID = 1460851066487531718L;

	protected UserMenuServiceImpl(UserMenuDAO dao) {
		super(dao);
	}
}
