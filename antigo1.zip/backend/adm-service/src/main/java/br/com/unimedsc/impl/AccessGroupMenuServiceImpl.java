package br.com.unimedsc.impl;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import br.com.unimedsc.core.service.impl.ServiceImpl;
import br.com.unimedsc.dao.AccessGroupMenuDAO;
import br.com.unimedsc.entities.adm.AccessGroupMenu;
import br.com.unimedsc.entities.pk.AccessGroupCompositePK;
import br.com.unimedsc.service.AccessGroupMenuService;

@Service
public class AccessGroupMenuServiceImpl extends ServiceImpl<AccessGroupCompositePK<Long>, AccessGroupMenu, AccessGroupMenuDAO>
		implements AccessGroupMenuService {

	private static final long serialVersionUID = 8232661534872239752L;

	@Inject
	protected AccessGroupMenuServiceImpl(AccessGroupMenuDAO dao) {
		super(dao);
	}
}