package br.com.unimedsc.impl;

import org.springframework.stereotype.Service;

import br.com.unimedsc.core.entity.pk.CompositeEnterprisePK;
import br.com.unimedsc.core.service.impl.ServiceImpl;
import br.com.unimedsc.dao.EnterpriseArchiveDAO;
import br.com.unimedsc.entities.erp.EnterpriseArchive;
import br.com.unimedsc.service.EnterpriseArchiveService;

@Service
public class EnterpriseArchiveServiceImpl extends ServiceImpl<CompositeEnterprisePK<Long>, EnterpriseArchive, EnterpriseArchiveDAO> implements EnterpriseArchiveService {

	private static final long serialVersionUID = 4835008087780450672L;

	protected EnterpriseArchiveServiceImpl(EnterpriseArchiveDAO dao) {
		super(dao);
	}

}
