package br.com.unimedsc.impl;

import javax.inject.Inject;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.com.unimedsc.core.entity.pk.SimplePK;
import br.com.unimedsc.core.service.impl.ServiceImpl;
import br.com.unimedsc.dao.ProcessAlertDAO;
import br.com.unimedsc.entities.erp.Process;
import br.com.unimedsc.entities.erp.ProcessAlert;
import br.com.unimedsc.entities.erp.dto.ProcessParamsDTO;
import br.com.unimedsc.entities.pk.ProcessCompositePK;
import br.com.unimedsc.service.ProcessAlertService;
import br.com.unimedsc.service.ProcessService;

@Service
public class ProcessAlertServiceImpl extends ServiceImpl<ProcessCompositePK<Long>, ProcessAlert, ProcessAlertDAO>
        implements ProcessAlertService {

    private static final long serialVersionUID = -3028506584043673991L;

    @Inject
    protected ProcessAlertServiceImpl(ProcessAlertDAO dao) {
        super(dao);
    }
    
	@Inject
	protected ProcessService processService;
    
    @Transactional(readOnly = false)
    public ProcessAlert generateAlert(ProcessParamsDTO processParamsDTO) throws Exception {
    	
    	ProcessAlert processAlert = new ProcessAlert();
    	ProcessCompositePK<Long> pk = new ProcessCompositePK<Long>();
    	pk.setProcessId(processParamsDTO.getProcessId());
    	pk.setId(null);
    	processAlert.setPk(pk);
    	
    	processAlert.setMessage(processParamsDTO.getDescriptionWarning());
    	processAlert.setKey(processParamsDTO.getDescriptionKey());
    	
    	insert(processAlert);
    	
        SimplePK<Long> processPk = new SimplePK<Long>();
        processPk.setId(processParamsDTO.getProcessId());
        
        Process process = processService.findById(processPk);
        process.setDomainAlert("S");
        
        processService.update(process);
        
        return processAlert;
    }
}
