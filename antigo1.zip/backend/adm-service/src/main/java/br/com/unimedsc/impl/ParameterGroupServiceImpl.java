package br.com.unimedsc.impl;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import br.com.unimedsc.core.entity.pk.SimplePK;
import br.com.unimedsc.core.service.impl.ServiceImpl;
import br.com.unimedsc.dao.ParameterGroupDAO;
import br.com.unimedsc.entities.erp.ParameterGroup;
import br.com.unimedsc.service.ParameterGroupService;

@Service
public class ParameterGroupServiceImpl extends ServiceImpl<SimplePK<String>, ParameterGroup, ParameterGroupDAO> 
		implements ParameterGroupService {

	private static final long serialVersionUID = 3908150373588105756L;

	@Inject
	protected ParameterGroupServiceImpl(ParameterGroupDAO dao) {
		super(dao);
	}
}
