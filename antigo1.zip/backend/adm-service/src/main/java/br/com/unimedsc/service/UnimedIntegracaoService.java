package br.com.unimedsc.service;

import br.com.unimedsc.core.entity.pk.SimplePK;
import br.com.unimedsc.core.service.Service;
import br.com.unimedsc.entities.erp.UnimedIntegracao;

public interface UnimedIntegracaoService extends Service<SimplePK<Long>, UnimedIntegracao> {
}
