package br.com.unimedsc.service;

import java.util.List;

import br.com.unimedsc.core.entity.pk.SimplePK;
import br.com.unimedsc.core.order.Order;
import br.com.unimedsc.core.service.Service;
import br.com.unimedsc.entities.adm.AccessGroup;
import br.com.unimedsc.entities.erp.Menu;

public interface MenuService extends Service<SimplePK<Long>, Menu> {

	public List<Menu> getMenuByUser(Long userId, Long enterpriseId) throws Exception;

	public List<Menu> getFullMenu() throws Exception;

	public List<Menu> findMenuTreeView(Order order) throws Exception;

	public List<Menu> getMenuByProfile(AccessGroup profile);

}
