package br.com.unimedsc.service;

import javax.servlet.http.HttpServletRequest;

import br.com.unimedsc.core.entity.pk.SimplePK;
import br.com.unimedsc.core.exception.UFException;
import br.com.unimedsc.core.service.Service;
import br.com.unimedsc.entities.adm.User;
import br.com.unimedsc.vo.UserUpdatePasswordVO;

public interface UserService extends Service<SimplePK<Long>, User> {
	public User findByLogin(String login) throws Exception;

	public void updatePassword(UserUpdatePasswordVO updatePasswordVO) throws UFException, Exception;

	public String recoverPassword(HttpServletRequest request, String login, String email) throws Exception;

	public String validateToken(UserUpdatePasswordVO updatePasswordVO) throws UFException, Exception;
}