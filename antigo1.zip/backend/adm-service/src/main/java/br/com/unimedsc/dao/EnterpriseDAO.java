package br.com.unimedsc.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Component;

import br.com.unimedsc.core.dao.DAO;
import br.com.unimedsc.core.entity.pk.SimplePK;
import br.com.unimedsc.entities.adm.UserSubsidiary;
import br.com.unimedsc.entities.erp.Enterprise;

@Component
public class EnterpriseDAO extends DAO<SimplePK<Long>, Enterprise> {

	public List<Enterprise> findAllByUser(Long userId) throws Exception {
		String hql =  "SELECT DISTINCT(ent)"
				     + " FROM " + Enterprise.class.getSimpleName() + " ent, "
				                + UserSubsidiary.class.getSimpleName() + " usSub"
				    + " WHERE usSub.user.id.id = :userId "
				      + " AND usSub.subsidiary.enterprise.id.id = ent.id.id "
				      + " AND usSub.user.businessGroup.id.id = ent.businessGroup.id.id"
				    + " ORDER BY ent.enterpriseName";
		
		Map<String, Object> params = new HashMap<>();
		params.put("userId", userId);
		
		return super.findAllByQuery(hql, params);
	}

}
