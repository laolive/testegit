package br.com.unimedsc.service;

import java.util.List;

import br.com.unimedsc.core.entity.pk.SimplePK;
import br.com.unimedsc.core.service.Service;
import br.com.unimedsc.dto.AlertDTO;
import br.com.unimedsc.entities.erp.Alert;

public interface AlertService extends Service<SimplePK<Long>, Alert> {

	public List<Alert> findEmailsOpen() throws Exception;

	public Alert newAlert(AlertDTO alert) throws Exception;
}
