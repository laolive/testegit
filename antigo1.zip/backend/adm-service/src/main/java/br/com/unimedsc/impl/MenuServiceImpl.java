package br.com.unimedsc.impl;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import br.com.unimedsc.core.entity.pk.SimplePK;
import br.com.unimedsc.core.filter.FilterHelper;
import br.com.unimedsc.core.filter.Junction;
import br.com.unimedsc.core.filter.Node;
import br.com.unimedsc.core.filter.Operator;
import br.com.unimedsc.core.filter.Value;
import br.com.unimedsc.core.order.Order;
import br.com.unimedsc.core.service.impl.ServiceImpl;
import br.com.unimedsc.dao.MenuDAO;
import br.com.unimedsc.entities.adm.AccessGroup;
import br.com.unimedsc.entities.adm.AccessGroupMenu;
import br.com.unimedsc.entities.erp.Menu;
import br.com.unimedsc.service.MenuService;

@Service
public class MenuServiceImpl extends ServiceImpl<SimplePK<Long>, Menu, MenuDAO> implements MenuService {
	private static final long serialVersionUID = -4763183141641518890L;

	@Inject
	protected MenuServiceImpl(MenuDAO dao) {
		super(dao);
	}

	@Override
	public List<Menu> getMenuByProfile(AccessGroup profile) {
		List<Menu> listMenu = new ArrayList<Menu>();
		
		for (AccessGroupMenu pm : profile.getAccessGroupMenus()) {
			listMenu = getParentsMenus(listMenu, pm.getMenu());
			listMenu.add(pm.getMenu());
		}

		List<Menu> fullMenu = new LinkedList<>();

		for (Menu menu : listMenu) {
			buildMenu(menu, fullMenu);
		}

		return fullMenu;

	}

	private List<Menu> getParentsMenus(List<Menu> menus, Menu leaf) {
		if (leaf.getMenuSuperior() != null) {
			getParentsMenus(menus, leaf.getMenuSuperior());
			if (!menus.contains(leaf.getMenuSuperior()))
				menus.add(leaf.getMenuSuperior());
		}
		return menus;

	}

	@Override
	public List<Menu> getMenuByUser(Long userId, Long enterpriseId) throws Exception {
		List<Menu> listMenu = dao.getMenuByUser(userId, enterpriseId);
		List<Menu> fullMenu = new LinkedList<>();

		for (Menu menu : listMenu) {
			buildMenu(menu, fullMenu);
		}

		return fullMenu;
	}

	@Override
	public List<Menu> getFullMenu() throws Exception {
		List<Menu> listMenu = dao.getFullMenu();
		List<Menu> fullMenu = new LinkedList<>();

		for (Menu menu : listMenu) {
			buildMenu(menu, fullMenu);
		}

		return fullMenu;
	}

	private void buildMenu(Menu menu, List<Menu> fullMenu) {
		if (menu.getMenuSuperior() == null) {
			fullMenu.add(menu);
			return;
		} else {
			Menu menuAux;
			Long menuSupId;
			Long menuId;

			for (Menu subMenu : fullMenu) {
				menuSupId = menu.getMenuSuperior().getPk().getId();
				menuId = menu.getPk().getId();
				if (subMenu.getPk().getId().equals(menuSupId)) {
					menuAux = this.existInFullMenu(menuId, subMenu.getChildren());
					if (menuAux == null) {
						subMenu.getChildren().add(menu);
						break;
					}
				} else {
					this.buildMenu(menu, subMenu.getChildren());
				}
			}
		}
		return;
	}

	private Menu existInFullMenu(Long menuSupId, List<Menu> listMenu) {
		for (Menu menu2 : listMenu) {
			if (menu2.getPk().getId().equals(menuSupId))
				return menu2;
		}

		return null;
	}

	@Override
	public List<Menu> findMenuTreeView(Order order) throws Exception {
		Node node = FilterHelper.createTree(Junction.AND);
		FilterHelper.addCondition(node, "menuSuperior", Operator.ISNULL);

		List<Menu> parents = super.findAllByFilter(node, order);
		for (Menu cc : parents) {
			List<Menu> children = this.findChildrenMenu(cc, order);
			cc.setChildren(children);
		}
		return parents;
	}

	public List<Menu> findChildrenMenu(Menu menu, Order order) throws Exception {
		Node node = FilterHelper.createTree(Junction.AND);
		FilterHelper.addCondition(node, "menuSuperior", Operator.EQUAL, new Value<Menu>(menu));

		List<Menu> newChildren = super.findAllByFilter(node, order);
		if (newChildren != null) {
			for (Menu cc : newChildren) {
				List<Menu> children = this.findChildrenMenu(cc, order);
				cc.setChildren(children);
			}
		}
		return newChildren;

	}

}
