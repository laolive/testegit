package br.com.unimedsc.dao;

import org.springframework.stereotype.Component;

import br.com.unimedsc.core.dao.DAO;
import br.com.unimedsc.entities.adm.AccessGroupMenu;
import br.com.unimedsc.entities.pk.AccessGroupCompositePK;

@Component
public class AccessGroupMenuDAO extends DAO<AccessGroupCompositePK<Long>, AccessGroupMenu> {

}