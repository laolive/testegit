package br.com.unimedsc.dao;

import org.springframework.stereotype.Component;

import br.com.unimedsc.core.dao.DAO;
import br.com.unimedsc.entities.adm.UserParameter;
import br.com.unimedsc.entities.pk.UserParameterCompositePK;

@Component
public class UserParamaterDAO extends DAO<UserParameterCompositePK<String>, UserParameter> {
	
	

}
