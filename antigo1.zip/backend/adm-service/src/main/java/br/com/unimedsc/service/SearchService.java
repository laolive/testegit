package br.com.unimedsc.service;

import br.com.unimedsc.core.service.Service;
import br.com.unimedsc.entities.cfg.Search;
import br.com.unimedsc.entities.pk.PanelCompositePK;

public interface SearchService extends Service<PanelCompositePK<Long>, Search> {

}
