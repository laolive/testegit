package br.com.unimedsc.service;

import br.com.unimedsc.core.service.Service;
import br.com.unimedsc.entities.erp.RoutineOption;
import br.com.unimedsc.entities.pk.RoutineCompositePK;

public interface RoutineOptionService extends Service<RoutineCompositePK<Long>, RoutineOption>{

}