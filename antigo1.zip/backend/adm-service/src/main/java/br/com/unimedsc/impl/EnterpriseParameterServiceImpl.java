package br.com.unimedsc.impl;

import org.springframework.stereotype.Service;

import br.com.unimedsc.core.entity.pk.CompositeEnterprisePK;
import br.com.unimedsc.core.service.impl.ServiceImpl;
import br.com.unimedsc.dao.EnterpriseParameterDAO;
import br.com.unimedsc.entities.adm.EnterpriseParameter;
import br.com.unimedsc.service.EnterpriseParameterService;

@Service
public class EnterpriseParameterServiceImpl extends ServiceImpl<CompositeEnterprisePK<String>, EnterpriseParameter, EnterpriseParameterDAO> implements EnterpriseParameterService {

	private static final long serialVersionUID = 5478433101433541686L;

	protected EnterpriseParameterServiceImpl(EnterpriseParameterDAO dao) {
		super(dao);
	}

}
