package br.com.unimedsc.impl;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import br.com.unimedsc.core.entity.pk.SimplePK;
import br.com.unimedsc.core.service.impl.ServiceImpl;
import br.com.unimedsc.dao.BusinessGroupDAO;
import br.com.unimedsc.entities.erp.BusinessGroup;
import br.com.unimedsc.service.BusinessGroupService;

@Service
public class BusinessGroupServiceImpl extends ServiceImpl<SimplePK<Long>, BusinessGroup, BusinessGroupDAO>
		implements BusinessGroupService {

	private static final long serialVersionUID = 6519651684275468434L;

	@Inject
	protected BusinessGroupServiceImpl(BusinessGroupDAO dao) {
		super(dao);
	}
}
