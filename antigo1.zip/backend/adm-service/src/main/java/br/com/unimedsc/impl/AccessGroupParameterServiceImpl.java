package br.com.unimedsc.impl;

import org.springframework.stereotype.Service;

import br.com.unimedsc.core.service.impl.ServiceImpl;
import br.com.unimedsc.dao.AccessGroupParameterServiceDAO;
import br.com.unimedsc.entities.adm.AccessGroupParameter;
import br.com.unimedsc.entities.pk.AccessGroupCompositePK;
import br.com.unimedsc.service.AccessGroupParameterService;

@Service
public class AccessGroupParameterServiceImpl extends ServiceImpl<AccessGroupCompositePK<String>, AccessGroupParameter, AccessGroupParameterServiceDAO> implements AccessGroupParameterService{
	private static final long serialVersionUID = -8915005590904703646L;

	protected AccessGroupParameterServiceImpl(AccessGroupParameterServiceDAO dao) {
		super(dao);
	}

}
