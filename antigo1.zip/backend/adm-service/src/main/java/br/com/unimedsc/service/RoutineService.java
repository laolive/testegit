package br.com.unimedsc.service;

import java.util.Map;

import br.com.unimedsc.core.entity.pk.SimplePK;
import br.com.unimedsc.core.service.Service;
import br.com.unimedsc.entities.erp.Routine;
import br.com.unimedsc.vo.RoutineParamsVO;

public interface RoutineService extends Service<SimplePK<Long>, Routine>{

	Map<String, Object> confirmRoutine(RoutineParamsVO routineParamsVO) throws Exception;
	
}