package br.com.unimedsc.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.Query;

import br.com.unimedsc.core.utils.SessionUtil;
import org.springframework.stereotype.Component;

import br.com.unimedsc.core.dao.DAO;
import br.com.unimedsc.core.entity.pk.SimplePK;
import br.com.unimedsc.dto.TransactionDTO;
import br.com.unimedsc.entities.adm.UserTransaction;
import br.com.unimedsc.entities.erp.Transaction;

@Component
public class TransactionDAO extends DAO<SimplePK<Long>, Transaction> {

	@SuppressWarnings("unchecked")
	public List<TransactionDTO> getPermissionByUser(Long userId) throws Exception {
		String hql = "" + " SELECT new " + TransactionDTO.class.getName()
				+ "(t.pk.id, t.transactionName, t.transactionRoute, ut.domainInsert, ut.domainUpdate, ut.domainDelete)"
				+ "	FROM " + UserTransaction.class.getName() + " ut " + "		JOIN ut.transaction t "
				+ " JOIN ut.userEnterprise ue "
				+ "		JOIN ue.user u " + "	WHERE u.pk.id = :idUser ";

		Map<String, Object> params = new HashMap<String, Object>();
		params.put("idUser", userId);

		Query query = super.getQuery(hql, params);

		return (List<TransactionDTO>) query.getResultList();

	}

	@SuppressWarnings("unchecked")
	public List<Object[]> getPermissionByUser1() throws Exception {
		String sql = "SELECT COD_TRANSC as id, " + " NOM_TRANSC as transactionName," + " DES_ROTA as transactionRoute, "
				+ this.getCoalesce("1", "domainInsert", "ALLOWINSERT", "INCL") + ", "
				+ this.getCoalesce("2", "domainUpdate", "ALLOWUPDATE", "ALT") + ", "
				+ this.getCoalesce("3", "domainDelete", "ALLOWDELETE", "EXCL") + " FROM ERP_TRANSACAO erpT";

		Query query = super.getEntityManager().createNativeQuery(sql, "TransactionTransient");
		return (List<Object[]>) query.getResultList();
	}

	private String getCoalesce(String order, String aliasPermission, String propertie, String column) throws Exception {
		Long userId = SessionUtil.getInstance().getUserId();

		return "(NVL( (SELECT DISTINCT(" + aliasPermission + ".VAL_DOMAIN)" + " FROM ADM_USUARIO_TRANSACAO usuT" + order
				+ " INNER JOIN ERP_DOMINIO " + aliasPermission + " ON " + aliasPermission + ".NOM_DOMAIN = 'FLAG' "
				+ " AND " + aliasPermission + ".COD_DOMAIN = usuT" + order + ".DM_FLAG_" + column
				+ " INNER JOIN ERP_TRANSACAO trans" + order + " ON trans" + order + ".COD_TRANSC = usuT" + order
				+ ".COD_TRANSC " + " INNER JOIN ADM_USUARIO us" + order + " ON us" + order + ".COD_USU = "
				+ userId + "AND us" + order + ".COD_USU = usuT" + order + ".COD_USU"
				+ " WHERE usuT" + order + ".COD_TRANSC = erpT.COD_TRANSC),"

				+ " (NVL((SELECT DISTINCT(" + aliasPermission + ".VAL_DOMAIN) " + " FROM ADM_PERFIL_TRANSACAO perT"
				+ order + " INNER JOIN ERP_DOMINIO " + aliasPermission + " ON " + aliasPermission
				+ ".NOM_DOMAIN = 'FLAG' " + " AND " + aliasPermission + ".VAL_DOMAIN = 'S'" + " AND " + aliasPermission
				+ ".COD_DOMAIN = pert" + order + ".DM_FLAG_" + column + " INNER JOIN ERP_TRANSACAO trans" + order
				+ " ON trans" + order + ".COD_TRANSC = pert" + order + ".COD_TRANSC" + " WHERE EXISTS (SELECT us"
				+ order + ".COD_USU" + " FROM ADM_USUARIO_PERFIL usP" + order + " INNER JOIN ADM_USUARIO us" + order
				+ " ON us" + order + ".COD_USU = " + userId + " AND usP" + order
				+ ".COD_USU = us" + order + ".COD_USU" + " WHERE usP" + order + ".COD_PERFIL= perT" + order
				+ ".COD_PERFIL)" + "AND NOT EXISTS (SELECT usuTT" + order + ".COD_USU "
				+ " FROM ADM_USUARIO_TRANSACAO usuTT" + order + " INNER JOIN ADM_USUARIO uss" + order + " ON uss"
				+ order + ".COD_USU = " + userId + " AND uss" + order + ".COD_USU = usuTT"
				+ order + ".COD_USU " + " WHERE usuTT" + order + ".COD_TRANSC = pert" + order + ".COD_TRANSC )"
				+ "AND perT" + order + ".COD_TRANSC = erpT.COD_TRANSC), " + " 'N')))) AS " + propertie;
	}
}