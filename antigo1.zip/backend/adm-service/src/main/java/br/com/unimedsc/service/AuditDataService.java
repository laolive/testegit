package br.com.unimedsc.service;

import br.com.unimedsc.core.entity.pk.SimplePK;
import br.com.unimedsc.core.service.Service;
import br.com.unimedsc.entities.erp.AuditData;

public interface AuditDataService extends Service<SimplePK<Long>, AuditData> {

}
