package br.com.unimedsc.impl;

import br.com.unimedsc.core.filter.*;
import br.com.unimedsc.core.service.impl.ServiceImpl;
import br.com.unimedsc.dao.DominioDeParaDAO;
import br.com.unimedsc.entities.adm.DominioDePara;
import br.com.unimedsc.entities.pk.DominioDeParaPK;
import br.com.unimedsc.service.DominioDeParaService;
import org.springframework.stereotype.Service;

import javax.inject.Inject;
import java.util.List;

@Service
public class DominioDeParaServiceImpl extends ServiceImpl<DominioDeParaPK<Long, Long, Long, Long>,
        DominioDePara, DominioDeParaDAO> implements DominioDeParaService {

    @Inject
    protected DominioDeParaServiceImpl(DominioDeParaDAO dao) {
        super(dao);
    }

    @Override
    public DominioDePara findByDominioItemIdDe(Long dominioItemIdDe) throws Exception {
        Node node = FilterHelper.createTree(Junction.AND);
        FilterHelper.addCondition(node, "pk.dominioItemIdDe", Operator.EQUAL, new Value<>(dominioItemIdDe));

        List<DominioDePara> dominiosDePara = super.findAllByFilter(node, null);

        DominioDePara dominioDePara = null;

        if (!dominiosDePara.isEmpty()) {
            dominioDePara = dominiosDePara.get(0);
        }

        return dominioDePara;
    }

    @Override
    public DominioDePara findByDominioItemIdPara(Long dominioItemIdPara) throws Exception {
        Node node = FilterHelper.createTree(Junction.AND);
        FilterHelper.addCondition(node, "pk.dominioItemIdPara", Operator.EQUAL, new Value<>(dominioItemIdPara));

        List<DominioDePara> dominiosDePara = super.findAllByFilter(node, null);

        DominioDePara dominioDePara = null;

        if (!dominiosDePara.isEmpty()) {
            dominioDePara = dominiosDePara.get(0);
        }

        return dominioDePara;
    }
}