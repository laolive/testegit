package br.com.unimedsc.impl;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import br.com.unimedsc.core.entity.pk.CompositeEnterprisePK;
import br.com.unimedsc.core.service.impl.ServiceImpl;
import br.com.unimedsc.dao.SubsidiaryDAO;
import br.com.unimedsc.entities.erp.Subsidiary;
import br.com.unimedsc.service.SubsidiaryService;

@Service
public class SubsidiaryServiceImpl extends ServiceImpl<CompositeEnterprisePK<Long>, Subsidiary, SubsidiaryDAO>
		implements SubsidiaryService {

	private static final long serialVersionUID = 2108481423109282077L;

	@Inject
	protected SubsidiaryServiceImpl(SubsidiaryDAO dao) {
		super(dao);
	}
}
