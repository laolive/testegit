package br.com.unimedsc.impl;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import br.com.unimedsc.core.service.impl.ServiceImpl;
import br.com.unimedsc.dao.ProcessFileDAO;
import br.com.unimedsc.entities.erp.ProcessFile;
import br.com.unimedsc.entities.pk.ProcessCompositePK;
import br.com.unimedsc.service.ProcessFileService;

@Service
public class ProcessFileServiceImpl extends ServiceImpl<ProcessCompositePK<Long>, ProcessFile, ProcessFileDAO>
		implements ProcessFileService {

	private static final long serialVersionUID = -1530624292577061437L;

	@Inject
	protected ProcessFileServiceImpl(ProcessFileDAO dao) {
		super(dao);
	}
}
