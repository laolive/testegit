package br.com.unimedsc.dao;

import org.springframework.stereotype.Component;

import br.com.unimedsc.core.dao.DAO;
import br.com.unimedsc.entities.adm.UserMenu;
import br.com.unimedsc.entities.pk.MenuCompositePK;


@Component
public class UserMenuDAO extends DAO<MenuCompositePK<Long>, UserMenu> {
	
}