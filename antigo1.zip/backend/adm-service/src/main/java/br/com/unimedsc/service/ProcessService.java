package br.com.unimedsc.service;

import br.com.unimedsc.core.entity.pk.SimplePK;
import br.com.unimedsc.core.service.Service;
import br.com.unimedsc.entities.erp.Process;
import br.com.unimedsc.entities.erp.dto.ProcessParamsDTO;

public interface ProcessService extends Service<SimplePK<Long>, Process> {
	Process startProcess(ProcessParamsDTO processParamsDTO) throws Exception;
	Process finishProcess(ProcessParamsDTO processParamsDTO) throws Exception;
	Process updateProcessPercentual(ProcessParamsDTO processParamsDTO) throws Exception;
}
