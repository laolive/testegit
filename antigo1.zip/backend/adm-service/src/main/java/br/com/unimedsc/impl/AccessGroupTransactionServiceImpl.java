package br.com.unimedsc.impl;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import br.com.unimedsc.core.service.impl.ServiceImpl;
import br.com.unimedsc.dao.AccessGroupTransactionDAO;
import br.com.unimedsc.entities.adm.AccessGroupTransaction;
import br.com.unimedsc.entities.pk.AccessGroupCompositePK;
import br.com.unimedsc.service.AccessGroupTransactionService;

@Service
public class AccessGroupTransactionServiceImpl extends ServiceImpl<AccessGroupCompositePK<Long>, AccessGroupTransaction, AccessGroupTransactionDAO>
		implements AccessGroupTransactionService {

	private static final long serialVersionUID = -506589302680277034L;

	@Inject
	protected AccessGroupTransactionServiceImpl(AccessGroupTransactionDAO dao) {
		super(dao);
	}
}