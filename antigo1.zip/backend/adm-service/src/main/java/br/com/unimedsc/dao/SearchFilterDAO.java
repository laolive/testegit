package br.com.unimedsc.dao;

import org.springframework.stereotype.Component;

import br.com.unimedsc.core.dao.DAO;
import br.com.unimedsc.entities.cfg.SearchFilter;
import br.com.unimedsc.entities.pk.SearchCompositePK;

@Component
public class SearchFilterDAO extends DAO<SearchCompositePK<Long>, SearchFilter> {

}
