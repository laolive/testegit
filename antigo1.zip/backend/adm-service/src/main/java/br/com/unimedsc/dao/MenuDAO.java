package br.com.unimedsc.dao;

import br.com.unimedsc.core.dao.DAO;
import br.com.unimedsc.core.entity.pk.SimplePK;
import br.com.unimedsc.core.utils.SessionUtil;
import br.com.unimedsc.entities.erp.Menu;
import br.com.unimedsc.entities.repository.MenuRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Component;

import java.util.*;

@Component
public class MenuDAO extends DAO<SimplePK<Long>, Menu> {

    @Autowired
    private MenuRepository menuRepository;

    public List<Menu> getMenuByUser(Long userId, Long enterpriseId) throws Exception {
        return loadAllMenuPermission(menuRepository.findAllWithTransaction(), userId, enterpriseId);
    }

    public List<Menu> getFullMenu() throws Exception {
        return menuRepository.findAll();
    }

    @Override
    protected void executeBeforeSave(Menu entity) throws Exception {
        if (entity.getMenuSuperior() != null) {
            Menu menuSuperior = super.findById(entity.getMenuSuperior().getPk());
            entity.setMenuSuperior(menuSuperior);
        }
        super.executeBeforeSave(entity);
    }

    public List<Menu> loadAllMenuPermission(List<Menu> menuList, Long userId, Long enterpriseId) {
        List<Menu> menu = new ArrayList<>();

        for (Menu m : menuList) {
            List<Menu> childMenu = child(m, new ArrayList<>(), userId, enterpriseId);

            for (Menu child : childMenu) {
                menu.add(child);
            }
        }

        Set<Menu> setOfMenu = new LinkedHashSet<>(menu);

        menu.clear();
        menu.addAll(setOfMenu);

        return menu;
    }

    public List<Menu> child(Menu menu, List<Menu> menuList, Long userId, Long enterpriseId) {
        List<Menu> children = menuRepository.findByAndSort(menu.getPk().getId(), new Sort("menuSuperior"));
        for (Menu me : children) {
            menuList = child(me, menuList, userId, enterpriseId);
            List<Menu> admMenu = menuRepository.findMenuFromAdmMenu(userId, enterpriseId, me.getPk().getId());
            List<Menu> groupMenu = menuRepository.findMenuFromGroupMenuAndUserGroup(userId, enterpriseId, me.getPk().getId());
            if (admMenu.size() > 0 || groupMenu.size() > 0) {
                Menu parent = me.getMenuSuperior();
                List<Menu> parentMenu = new ArrayList<>();
                while (parent != null) {
                    parentMenu.add(parent);
                    parent = parent.getMenuSuperior();
                }

                for (int i = parentMenu.size() - 1; i >= 0; i--) {
                    menuList.add(parentMenu.get(i));
                }

                menuList.add(me);
            }
        }
        return menuList;
    }
}
