package br.com.unimedsc.impl;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import br.com.unimedsc.core.entity.pk.SimplePK;
import br.com.unimedsc.core.service.impl.ServiceImpl;
import br.com.unimedsc.dao.UnimedDAO;
import br.com.unimedsc.entities.erp.Unimed;
import br.com.unimedsc.service.UnimedService;

@Service
public class UnimedServiceImpl extends ServiceImpl<SimplePK<Long>, Unimed, UnimedDAO> implements UnimedService {
	private static final long serialVersionUID = -4763183141641518890L;
	
	@Inject
	protected UnimedServiceImpl(UnimedDAO dao) {
		super(dao);
	}
	
}
