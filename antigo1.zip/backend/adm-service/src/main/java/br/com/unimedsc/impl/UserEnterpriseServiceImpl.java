package br.com.unimedsc.impl;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import br.com.unimedsc.core.entity.pk.CompositeEnterprisePK;
import br.com.unimedsc.core.service.impl.ServiceImpl;
import br.com.unimedsc.dao.UserEnterpriseDAO;
import br.com.unimedsc.entities.adm.UserEnterprise;
import br.com.unimedsc.service.UserEnterpriseService;

@Service
public class UserEnterpriseServiceImpl extends
		ServiceImpl<CompositeEnterprisePK<Long>, UserEnterprise, UserEnterpriseDAO> implements UserEnterpriseService {
	private static final long serialVersionUID = 5823690101115606771L;

	@Inject
	protected UserEnterpriseServiceImpl(UserEnterpriseDAO dao) {
		super(dao);
	}

}
