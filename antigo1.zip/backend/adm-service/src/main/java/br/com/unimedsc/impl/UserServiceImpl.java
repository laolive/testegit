package br.com.unimedsc.impl;

import java.net.HttpURLConnection;
import java.util.Calendar;
import java.util.List;
import java.util.UUID;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;

import br.com.unimedsc.core.oauth2.OAuth2Context;
import org.springframework.security.crypto.bcrypt.BCrypt;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.com.unimedsc.core.entity.pk.SimplePK;
import br.com.unimedsc.core.exception.UFException;
import br.com.unimedsc.core.filter.FilterHelper;
import br.com.unimedsc.core.filter.Junction;
import br.com.unimedsc.core.filter.Node;
import br.com.unimedsc.core.filter.Operator;
import br.com.unimedsc.core.filter.Value;
import br.com.unimedsc.core.service.impl.ServiceImpl;
import br.com.unimedsc.core.utils.CommonsHelper;
import br.com.unimedsc.core.utils.HttpUrlUtil;
import br.com.unimedsc.core.utils.GatewayUtil;
import br.com.unimedsc.dao.UserDAO;
import br.com.unimedsc.entities.adm.User;
import br.com.unimedsc.entities.erp.Alert;
import br.com.unimedsc.service.UserService;
import br.com.unimedsc.system.ReturnDefault;
import br.com.unimedsc.vo.UserUpdatePasswordVO;

@Service
public class UserServiceImpl extends ServiceImpl<SimplePK<Long>, User, UserDAO> implements UserService {

	private static final long serialVersionUID = 7481538637544864117L;

	@Inject
	private OAuth2Context oAuth2Context;

	@Inject
	protected UserServiceImpl(UserDAO dao) {
		super(dao);
	}

	@Override
	@Transactional(readOnly = true)
	public User findByLogin(String login) throws Exception {

		Node node = FilterHelper.createTree(Junction.AND);
		FilterHelper.addCondition(node, "login", Operator.EQUAL, new Value<String>(login.toLowerCase()));

		List<User> users = super.findAllByFilter(node, null);

		if (users == null || users.size() == 0)
			throw new Exception("Usuário inválido!");

		return users.get(0);
	}

	@Transactional
	public void updatePassword(UserUpdatePasswordVO updatePasswordVO) throws Exception {
        BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
		User user = this.findById(updatePasswordVO.getPk());

		updatePasswordVO.setConfirmPassword(updatePasswordVO.getConfirmPassword());
		updatePasswordVO.setNewPassword(updatePasswordVO.getNewPassword());

		if (!updatePasswordVO.getAdmin() && user.getPassword() != null
                && !passwordEncoder.matches(updatePasswordVO.getOldPassword(), user.getPassword())) {
			throw new UFException("A senha informada é inválida.");
		} else if (!updatePasswordVO.getNewPassword().equals(updatePasswordVO.getConfirmPassword())) {
			throw new UFException("As senhas não conferem.");
		} else {
			dao.updatePassword(user.getPk(), updatePasswordVO.getNewPassword(),
					updatePasswordVO.getDateLastAccess());
		}
	}

	@Override
	@Transactional(readOnly = false)
	public String recoverPassword(HttpServletRequest request, String login, String email)
			throws Exception {

		Node node = FilterHelper.createTree(Junction.AND);
		FilterHelper.addCondition(node, "login", Operator.EQUAL, new Value<String>(login));
		FilterHelper.addCondition(node, "email", Operator.EQUAL, new Value<String>(email));

		List<User> users = super.findAllByFilter(node, null);

		if (users == null || users.size() == 0)
			throw new UFException("Dados incorretos!");

		User user = users.get(0);

		String token = UUID.randomUUID().toString();
		Calendar validityToken = Calendar.getInstance();
		validityToken.add(Calendar.HOUR_OF_DAY, 1);

		user.setToken(token);
		user.setValidityToken(validityToken);

		dao.update(user);

		String url = request.getHeader("origin");
		url = url + "/#/recover-password?token=" + token;

		String subject = "Recuperação de Senha";
		String msg = "Clique <a href='" + url + "'>aqui</a> para alterar sua senha.";

		Alert alert = new Alert();
		alert.setAlertDescription(msg);
		alert.setCreationDate(Calendar.getInstance());
		alert.setDestinationUser(user);
		alert.setCreationUser(user);
		alert.setDomainAlertType("R");
		alert.setDomainOpen("S");
		alert.setDomainSendType("E");
		alert.setSubject(subject);
		alert.setPk(new SimplePK<Long>());
		
		HttpUrlUtil httpUrlUtil = new HttpUrlUtil(oAuth2Context);

		String urlAlert = GatewayUtil.getInstance().getGateway() + "/msn/alert/insert";
		httpUrlUtil.postByEntity(urlAlert, alert, request, null);
		httpUrlUtil.readSingleLineResponseObject(ReturnDefault.class);

		httpUrlUtil.disconnect();

		return "Uma mensagem com orientações foi enviado para o email cadastrado.";
	}

	@Override
	@Transactional(readOnly = false)
	public String validateToken(UserUpdatePasswordVO updatePasswordVO) throws Exception {

		if (!updatePasswordVO.getNewPassword().equals(updatePasswordVO.getConfirmPassword()))
			throw new UFException("Senhas não conferem!");

		Node node = FilterHelper.createTree(Junction.AND);
		FilterHelper.addCondition(node, "token", Operator.EQUAL, new Value<String>(updatePasswordVO.getOldPassword()));

		List<User> user = super.findAllByFilter(node, null);

		if (user == null || user.size() == 0)
			throw new UFException("Token inválido!");

		if (user.get(0).getValidityToken().before(Calendar.getInstance()))
			throw new UFException("Token expirado!");

		updatePasswordVO.setNewPassword(CommonsHelper.decodeBase64(updatePasswordVO.getNewPassword()));

		dao.updatePassword(user.get(0).getPk(),
				CommonsHelper.getInstance().encodeMD5(updatePasswordVO.getNewPassword()),
				updatePasswordVO.getDateLastAccess());

		user.get(0).setToken(null);
		user.get(0).setValidityToken(null);

		dao.update(user.get(0));

		return "Senha atualizada!";
	}

}
