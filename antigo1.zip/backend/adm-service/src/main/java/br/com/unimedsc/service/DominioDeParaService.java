package br.com.unimedsc.service;

import br.com.unimedsc.core.service.Service;
import br.com.unimedsc.entities.adm.DominioDePara;
import br.com.unimedsc.entities.pk.DominioDeParaPK;

public interface DominioDeParaService extends Service<DominioDeParaPK<Long, Long, Long, Long>, DominioDePara> {

    DominioDePara findByDominioItemIdDe(Long dominioItemIdDe) throws Exception;

    DominioDePara findByDominioItemIdPara(Long dominioItemIdDe) throws Exception;
}
