package br.com.unimedsc.service;

import br.com.unimedsc.core.entity.pk.SimplePK;
import br.com.unimedsc.core.service.Service;
import br.com.unimedsc.entities.adm.Dominio;
import br.com.unimedsc.entities.adm.DominioItem;

import java.util.List;

public interface DominioItemService extends Service<SimplePK<Integer>, DominioItem> {

    DominioItem findByValor(Dominio dominio, String valor) throws Exception;

    List<DominioItem> findAllByDominio(Dominio dominio) throws Exception;
}
