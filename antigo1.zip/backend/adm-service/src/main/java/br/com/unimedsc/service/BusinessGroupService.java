package br.com.unimedsc.service;

import br.com.unimedsc.core.entity.pk.SimplePK;
import br.com.unimedsc.core.service.Service;
import br.com.unimedsc.entities.erp.BusinessGroup;

public interface BusinessGroupService extends Service<SimplePK<Long>, BusinessGroup> {

}