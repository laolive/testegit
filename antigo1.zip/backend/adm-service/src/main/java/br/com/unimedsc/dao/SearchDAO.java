package br.com.unimedsc.dao;

import org.springframework.stereotype.Component;

import br.com.unimedsc.core.dao.DAO;
import br.com.unimedsc.entities.cfg.Search;
import br.com.unimedsc.entities.pk.PanelCompositePK;

@Component
public class SearchDAO extends DAO<PanelCompositePK<Long>, Search> {

}
