package br.com.unimedsc.dao;

import org.springframework.stereotype.Component;

import br.com.unimedsc.core.dao.DAO;
import br.com.unimedsc.entities.erp.ProcessFile;
import br.com.unimedsc.entities.pk.ProcessCompositePK;

@Component
public class ProcessFileDAO extends DAO<ProcessCompositePK<Long>, ProcessFile>{
	         
}

