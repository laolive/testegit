package br.com.unimedsc.common;

import java.util.Map;

import br.com.unimedsc.dao.DomainDAO;
import br.com.unimedsc.entities.erp.Domain;

/**
 * Esta classe deve ser usada somente atravez de DomainServiceImpl.getDomains()
 * */
public class DomainHelper {

	public Map<String, Map<String, Domain>> domains;

	private static DomainHelper domainHelper;

	public static DomainHelper getInstance() {
		checkPermission();
		if (domainHelper == null) {
			domainHelper = new DomainHelper();
		}
		return domainHelper;
	}

	private static void checkPermission(){
	    StackTraceElement element = (new Throwable()).getStackTrace()[2];
        String className = element.getClassName();
        try {
			Class<?> callerClass = Class.forName(className);
			if (callerClass != DomainDAO.class) {
		        throw new java.lang.IllegalAccessError();
		    }
		} catch (ClassNotFoundException e) {
			throw new java.lang.IllegalAccessError();
		}   
	}

}