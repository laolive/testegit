package br.com.unimedsc.service;

import java.util.List;

import br.com.unimedsc.core.entity.pk.SimplePK;
import br.com.unimedsc.core.service.Service;
import br.com.unimedsc.dto.TransactionDTO;
import br.com.unimedsc.entities.erp.Transaction;

public interface TransactionService extends Service<SimplePK<Long>, Transaction> {

	public List<TransactionDTO> getPermissionByUser(Long userId) throws Exception;

}
