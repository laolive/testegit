package br.com.unimedsc.impl;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import br.com.unimedsc.core.entity.pk.CompositeEnterprisePK;
import br.com.unimedsc.core.service.impl.ServiceImpl;
import br.com.unimedsc.dao.UnimedEnterpriseDAO;
import br.com.unimedsc.entities.erp.UnimedEnterprise;
import br.com.unimedsc.service.UnimedEnterpriseService;

@Service
public class UnimedEnterpriseServiceImpl extends ServiceImpl<CompositeEnterprisePK<Long>, UnimedEnterprise, UnimedEnterpriseDAO> implements UnimedEnterpriseService {
	
	private static final long serialVersionUID = -4631171997847034838L;

	@Inject
	protected UnimedEnterpriseServiceImpl(UnimedEnterpriseDAO dao) {
		super(dao);
	}
	
}
