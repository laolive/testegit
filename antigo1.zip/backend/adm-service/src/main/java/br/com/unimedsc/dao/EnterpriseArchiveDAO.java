package br.com.unimedsc.dao;

import org.springframework.stereotype.Component;

import br.com.unimedsc.core.dao.DAO;
import br.com.unimedsc.core.entity.pk.CompositeEnterprisePK;
import br.com.unimedsc.entities.erp.EnterpriseArchive;

@Component
public class EnterpriseArchiveDAO extends DAO<CompositeEnterprisePK<Long>, EnterpriseArchive>{
	         
}

